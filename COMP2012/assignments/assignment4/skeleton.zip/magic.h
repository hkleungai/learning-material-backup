#include <string>
using std::string;

struct Magic
{
    string prefix;
    string suffix;
    int price; //its price
    int quantity; //its quantity in the inventory
};
