#include <iostream>
#include "school-namespaces.h"

using namespace std;
namespace eg = engineering;
namespace sc = science;

// Note: Different implementations of this function are allowed if the outputs are correct.

void QueryEvents() {
    cout << "Select the school: 1. School of Engineering; 2. School of Science:";
    char choice;
    while(cin >> choice) {
        if (choice == '1' || choice == '2')
            break;
        else
            cout << "Select from 1 or 2." << endl;
    }

    if(choice == '1') {
        cout << "Select the department: 1. Department of CSE; 2. Department of ECE; 3. All:";
        cin >> choice;
        switch (choice) {
            case '1': eg::cse::show_events(); break;
            case '2': eg::ece::show_events(); break;
            case '3': eg::show_events(); break;
            default: cout << "Invalid input." << endl;
        }
    }
    else {
        cout << "Select the department: 1. Department of Mathematics; 2. Department of Physics; 3. All:";
        cin >> choice;
        switch (choice) {
            case '1': sc::math::show_events(); break;
            case '2': sc::physics::show_events(); break;
            case '3': sc::show_events(); break;
            default: cout << "Invalid input." << endl;
        }
    }
}