#include <iostream>
#include "events-query.h"

using namespace std;

int main() {

    cout << "Welcome to 30th Anniversary of HKUST! Check Events by Department: " << endl;
    QueryEvents();
    return 0;
}
