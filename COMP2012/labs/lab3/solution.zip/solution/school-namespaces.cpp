#include <iostream>
#include <string>
#include "school-namespaces.h"

// Note: Different implementations are allowed.

using namespace std;
namespace eg = engineering;
namespace sc = science;

string eg::cse::events[] {
    "9:00 Making Machine Learning Automated and Trustworthy.",
    "11:00 The Next Frontier in Type Inference.",
    "14:00 AI-Human Teaming for Decision Making."
};

string eg::ece::events[] {
    "15:00 2D Materials, from Academia to Industry.",
    "16:00 Bridging Vision and Language for Cross-Modal Understanding and Generation."
};

string sc::events[] {
    "10:00 A variational approach to describe the moduli space of minimal immersions in hyperbolic."
};

string sc::math::events[] {
    "16:00 Rate of blow up in the thin obstacle problem."
};

string sc::physics::events[] {
    "11:00 Interfacial Dynamics between a Hydrogel and a Fluid: Modeling and Simulation.",
    "14:00 Application of Flow Model to Theoretical Physics."
};

void eg::cse::show_events() {
    cout << "Welcome to Department of CSE!" << endl;
    for (string s:events){
        cout << s << endl;
    }
}

void eg::ece::show_events() {
    cout << "Welcome to Department of ECE!" << endl;
    for (string s:events){
        cout << s << endl;
    }
}

void eg::show_events() {
    cout << "Welcome to School of Engineering!" << endl;
    for (string s:cse::events){
        cout << s << endl;
    }
    for (string s:ece::events){
        cout << s << endl;
    }
}

void sc::math::show_events() {
    cout << "Welcome to Department of Mathematics!" << endl;
    for (string s:events){
        cout << s << endl;
    }
}

void sc::physics::show_events() {
    cout << "Welcome to Department of Physics!" << endl;
    for (string s:events){
        cout << s << endl;
    }
}

void sc::show_events() {
    cout << "Welcome to School of Science!" << endl;
    for (string s:events){
        cout << s << endl;
    }
    for (string s:math::events){
        cout << s << endl;
    }
    for (string s:physics::events){
        cout << s << endl;
    }
}