#include "Manager.h"

//TODO: Implement Manager.cpp