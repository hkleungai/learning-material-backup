#include "ParkingLot.h"
#include "Vehicle.h"
#include <string>
#include <iostream>
using namespace std;

class PrivateCar: public Vehicle {
    public:
        PrivateCar(const string& plate_no, const string& brand);
        void leave(ParkingLot *parking_lot);
        void print() const;

    private:
        string brand;
};