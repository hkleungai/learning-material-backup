//
// Created by Benran on 2021/7/18.
//

#include "Queue.h"
#include "EthernetFrame.h"

void queueResizeRing(Queue &queue, unsigned int newCapacity) {
    Queue tmp = queue;
    queue.ring = new EthernetFrame * [newCapacity];
    queue.capacity = newCapacity;
    queue.size = newCapacity < tmp.size ? newCapacity : tmp.size;
    queue.head = 0;

    for (unsigned int i = 0; i < queue.size; ++i) {
        unsigned int oldIndex = (tmp.head + i) % tmp.capacity;
        queue.ring[i] = tmp.ring[oldIndex];
    }

    for (unsigned int i = queue.size; i < queue.capacity; ++i) {
        queue.ring[i] = nullptr;
    }

    for (unsigned int i = queue.size; i < tmp.size; ++i) {
        unsigned int oldIndex = (tmp.head + i) % tmp.capacity;
        freeFrame(tmp.ring[oldIndex]);
    }

    delete [] tmp.ring;
}

void enqueue(Queue &queue, EthernetFrame *frame) {
    if (queue.size >= queue.capacity) {
        queueResizeRing(queue, (queue.size + 1) * 2);
    }

    queue.ring[(queue.head + queue.size) % queue.capacity] = frame;
    ++queue.size;
}

void dequeue(Queue &queue) {
    if (queue.size == 0) {
        return;
    }

    freeFrame(queue.ring[queue.head]);
    queue.ring[queue.head] = nullptr;
    queue.head = (queue.head + 1) % queue.capacity;
    --queue.size;
}

const EthernetFrame *queueFront(const Queue &queue) {
    if (queue.size == 0) {
        return nullptr;
    }

    return queue.ring[queue.head];
}

const EthernetFrame *queueBack(const Queue &queue) {
    if (queue.size == 0) {
        return nullptr;
    }

    return queue.ring[(queue.head + queue.size - 1) % queue.capacity];
}

bool queueIsEmpty(const Queue &queue) {
    return queue.size == 0;
}

void freeQueue(Queue &queue) {
    for (unsigned int i = 0; i < queue.capacity; ++i) {
        freeFrame(queue.ring[i]);
    }
    delete [] queue.ring;
    queue.capacity = queue.size = queue.head = 0;
}
