//
// Created by Benran on 2021/7/19.
//

#include "EthernetFrame.h"

void initFrame(EthernetFrame &frame, const string &source, const string &destination,
               const string &payload, EtherType type) {
    frame.source = source;
    frame.destination = destination;
    frame.payload = payload;
    frame.type = type;
}

void initFrame(EthernetFrame *frame, const string &source, const string &destination,
               const string &payload, EtherType type) {
    if (frame == nullptr) {
        return;
    }
    frame->source = source;
    frame->destination = destination;
    frame->payload = payload;
    frame->type = type;
}

void swapFrames(EthernetFrame &frame1, EthernetFrame &frame2) {
    EthernetFrame tmp = frame1;
    frame1 = frame2;
    frame2 = tmp;
}

void swapFrames(EthernetFrame *frame1, EthernetFrame *frame2) {
    if (frame1 == nullptr || frame2 == nullptr || frame1 == frame2) {
        return;
    }
    EthernetFrame tmp = *frame1;
    *frame1 = *frame2;
    *frame2 = tmp;
}

EthernetFrame *createFrame(const string &source, const string &destination, const string &payload, EtherType type) {
    EthernetFrame *frame = new EthernetFrame;
    initFrame(frame, source, destination, payload, type);
    return frame;
}

void freeFrame(EthernetFrame *frame) {
    delete frame;
}
