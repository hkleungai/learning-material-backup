#ifndef MY_UNIQUE_PTR_H_
#define MY_UNIQUE_PTR_H_

#include <utility>

template <typename T>
class my_unique_ptr {
public:
	/*******************************
	 * Constructors and Destructor *
	 *******************************/

	// Default Constructor, p is empty.
	my_unique_ptr() : p(nullptr) {}

	// Parameterized Constructor, takes ownership of p.
	/*
	 * Note: There exists the issue of 2 my_unique_ptrs thinking they have single and separate ownership of the same object.
	 * We ignore this for the sake of lab simplicity, as it is a complex problem to solve.
	 */
	my_unique_ptr(T* p) : p(p) {}

	// Copy Constructor - transfers ownership of object from u to this pointer
	my_unique_ptr(my_unique_ptr<T>& x) : p(x.p) {
		x.p = nullptr;
	}

	// Destructor - deallocate p if it is not a nullptr.
	~my_unique_ptr() {
		if (p != nullptr)
			delete p;
	}



	/************************
	 * Operator Overloading *
	 ************************/

	// Copy Assignment Operator.
	my_unique_ptr<T>& operator=(my_unique_ptr<T>& x) {
		my_unique_ptr<T> tmp(x);
		swap(tmp);
		return *this;
	}

	// Dereference Operators.
	T& operator*() const {
		return *p;
	}

	T* operator->() const {
		return p;
	}



	/*********************
	 * Utility Functions *
	 *********************/

	T* get_pointer() const { return p; }
	bool is_empty() const { return p == nullptr; }

	T* release() {
		T* tmp = p;
		p = nullptr;
		return tmp;
	}

	void reset() {
		my_unique_ptr<T> tmp;
		swap(tmp);
	}

	void reset(T* p) {
		my_unique_ptr<T> tmp(p);
		swap(tmp);
	}
	
	void swap(my_unique_ptr<T>& x) {
		T* tmp_p = x.p;
		x.p = p;
		p = tmp_p;
	}



private:
	T* p;
};

#endif /* MY_UNIQUE_PTR_H_ */
