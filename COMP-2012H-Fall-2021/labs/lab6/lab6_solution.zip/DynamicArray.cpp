#include "DynamicArray.h"
#include <iostream>

DynamicArray::DynamicArray(int array[], int size) {
    for(int i = 0 ; i < size ; i++) {
        insertAt(array[i], i);
    }
}

int DynamicArray::get(int index) const {
    return List::get(index);
}

void DynamicArray::set(int index, int data) {
    return List::set(index, data);
}

void DynamicArray::push_back(int data) {
    insertAt(data, size());
}

void DynamicArray::print() const {
    std::cout << "Dynamic Array | Empty: " << (empty() ? "Y" : "N") << " | Size: " << size() << " | {";
    
    for (int i = 0; i < size(); i++) {
        std::cout << this->get(i);
        if( i != size() - 1) {
            std::cout << ", ";
        }
    }    
    std::cout << "}" << std::endl;    
}
