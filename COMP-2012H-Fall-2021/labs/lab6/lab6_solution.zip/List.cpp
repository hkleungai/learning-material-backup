#include "List.h"
#include <iostream>

List::Node::Node(int data): data(data), next(nullptr) {};

List::List(): head(nullptr) { };

List::List(const List& rhs) {
    if (rhs.head == nullptr) {
        head = nullptr;
        return;
    }

    head = new Node(rhs.head->data);
    Node* lhs_ptr = head;

    for (Node* rhs_ptr = rhs.head->next; rhs_ptr != nullptr; rhs_ptr = rhs_ptr->next) {
        lhs_ptr->next = new Node(rhs_ptr->data);
        lhs_ptr = lhs_ptr->next;
    }

    lhs_ptr->next = nullptr;
};

List::~List() {
    for (Node* ptr = head; ptr != nullptr; ) {
        Node* to_delete = ptr;
        ptr = ptr->next;
        delete to_delete;
    }
};

List& List::assign(const List& rhs) {
    List rhs_copy = List(rhs);
    delete this;
    head = rhs_copy.head;
    return *this;
}

bool List::empty() const {
    return (head == nullptr);
}

int List::size() const {
    int count = 0;
    for (Node* ptr = head; ptr != nullptr; ptr = ptr->next)
        count++;
    return count;
}

void List::print() const {
    std::cout << "Linked List | Empty: " << (empty() ? "Y" : "N") << " | Size: " << size() << " | ";
    for(Node* ptr = head; ptr != nullptr; ptr = ptr->next) {
        std::cout << ptr->data << " -> ";
    }    
    std::cout << "x" << std::endl;
}

void List::insertAt(int data, int index) {
    if (index > size() || index < 0)
        exit(-1);
    
    Node* new_node = new Node(data);
    
    if (index == 0) {
        new_node->next = head;
        head = new_node;
        return;
    }

    Node* ptr = head;
    for (int i = 0; i < index - 1; i++)
        ptr = ptr->next;
    new_node->next = ptr->next;
    ptr->next = new_node;
}

void List::removeAt(int index) {
    if (index >= size() || index < 0)
        exit(-1);
    
    if (index == 0) {
        Node* old_head = head;
        head = head->next;
        delete old_head;
        return;
    }
    
    Node* ptr = head;
    for (int i = 0; i < index - 1; i++)
        ptr = ptr->next;
    Node* old_node = ptr->next;
    ptr->next = old_node->next;
    delete old_node;
}

int List::get(int index) const {
    if (index >= size() || index < 0)
        exit(-1);
    
    Node* ptr = head;
    for (int i = 0; i < index; i++)
        ptr = ptr->next;
    return ptr->data;
}

void List::set(int index, int data) {
    if (index >= size() || index < 0)
        exit(-1);
    
    Node* ptr = head;
    for (int i = 0; i < index; i++)
        ptr = ptr->next;
    ptr->data = data;
}
