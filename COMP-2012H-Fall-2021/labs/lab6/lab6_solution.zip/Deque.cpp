#include "Deque.h"
#include <iostream>

void Deque::push_front(int data) {
    insertAt(data, 0);
}

void Deque::push_back(int data) {
    insertAt(data, size());
}

void Deque::pop_front() {
    removeAt(0);
}

void Deque::pop_back() {
    removeAt(size() - 1);
}

int Deque::peek_front() const {
    if (size() == 0) {
        std::cout << "Empty!" << std::endl;
        return 0;
    }
    return get(0);
}

int Deque::peek_back() const {
    if (size() == 0) {
        std::cout << "Empty!" << std::endl;
        return 0;
    }
    return get(size() - 1);
}

void Deque::print() const {
    std::cout << "Deque | Empty: " << (empty() ? "Y" : "N") << " | Size: " << size() << " | ";
    for (int i = 0; i < size(); i++) {
        std::cout << "<" << get(i) << ">";
    }
    std::cout << std::endl;
}
