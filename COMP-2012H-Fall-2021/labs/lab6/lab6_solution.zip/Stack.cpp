#include "Stack.h"
#include <iostream>

void Stack::push(int data) {
    push_front(data);
}

void Stack::pop() {
    pop_front();
}

int Stack::top() const {
    return peek_front();
}

void Stack::print() const {
    std::cout << "Stack | Empty: " << (empty()?"Y":"N") << " | Size: " << size() << " | ";
    for(int i = 0; i < size(); i++) {
        std::cout << "<" << get(i) << "]";
    }
    std::cout << std::endl;
}
