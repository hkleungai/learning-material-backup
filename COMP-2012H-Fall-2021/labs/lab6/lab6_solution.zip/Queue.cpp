#include "Queue.h"
#include <iostream>

void Queue::push(int data) {
    push_back(data);
}

void Queue::pop() {
    pop_front();
}

int Queue::peek() const {
    return peek_front();
}

void Queue::print() const {
    std::cout << "Queue | Empty: " << (empty() ? "Y" : "N") << " | Size: " << size() <<" | ";
    for(int i = 0; i < size(); i++) {
        std::cout << "<" << get(i) << "]";
    }    
    std::cout << std::endl;    
}
