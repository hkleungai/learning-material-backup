/**
* Linked list representing the body of the snake
*/

struct SnakeBody
{
	SnakeBody* prev = nullptr, * next = nullptr;

	// Coordinates on the grid
	int x = 0, y = 0;
};

//Returns the head of the snake
SnakeBody* get_head(SnakeBody& body) {
	if (body.prev == nullptr) {
		return &body;
	}
	return get_head(*(body.prev));
}

//Returns the tail of the snake
SnakeBody* get_tail(SnakeBody& body) {
	if (body.next == nullptr) {
		return &body;
	}
	return get_tail(*(body.next));
}

//Returns the nth next snake body. In particular, returns the pointer to body (the input) if n=0. Returns the tail of the snake if n is too large. 
SnakeBody* get_next_body(SnakeBody& body, int n) {
	if (n <= 0 || body.next == nullptr) {
		return &body;
	}
	return get_next_body(*(body.next), n-1);
}

/**
* Removes itself (the given argument) from the linked list. WARNING: Does not destroy (delete) itself from memory!
*/
void remove_self(SnakeBody& body) {
	if (body.next != nullptr) {
		body.next->prev = body.prev;
	}
	if (body.prev != nullptr) {
		body.prev->next = body.next;
	}
	body.next = nullptr;
	body.prev = nullptr;
}

/**
* Assume that the linked list is locally ABC. 
* Then the list becomes ANBC. Make sure to consider the cases where this is the head/tail.
* This function assumes that N is not already in the list.
*/
void insert_into_previous(SnakeBody& B, SnakeBody* N) {
	N->prev = B.prev;
	N->next = &B;
	if (B.prev != nullptr) {
		B.prev->next = N;
	}
	B.prev = N;
}

/**
* Assume that the linked list is locally ABC.
* Then the list becomes ABNC
*/
void insert_into_next(SnakeBody& B, SnakeBody* N) {
	N->prev = &B;
	N->next = B.next;
	if (B.next != nullptr) {
		B.next->prev = N;
	}
	B.next = N;
}
