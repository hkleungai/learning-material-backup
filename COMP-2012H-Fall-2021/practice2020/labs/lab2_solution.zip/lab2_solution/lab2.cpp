#include <iostream>
using std::cin;
using std::cout;

#include "lab2.h"

// Game State Global Variables defined here.
int grid[NUM_ROWS][NUM_COLS]; // Global variable int default initializes to 0.
char label[NUM_ROWS][NUM_COLS]; // Manually assigned to all ' ' in main.cpp.
char current_player = PLAYER_X;
int num_O_orbs = 0;
int num_X_orbs = 0;
bool is_game_over = false;

void display_grid() {
	cout << '\n';
	cout << ' ';
	for (int col = 0; col < NUM_COLS; col += 1) {
		cout << "   " << char(col + 'A'); // ASCII arithmetic and static type-casting.
	}
	cout << "\n\n";

	for (int row = 0; row < NUM_ROWS; row += 1) {
		cout << row+1;
		for (int col = 0; col < NUM_COLS; col += 1)	{
			cout << "  ";
			cout << label[row][col];
			if (grid[row][col] == 0) {
				cout << '.';
			} else {
				cout << grid[row][col];
			}
		}
		cout << "\n\n";
	}

	cout << "Number of O Orbs: " << num_O_orbs << '\n';
	cout << "Number of X Orbs: " << num_X_orbs << '\n';
	cout << '\n';
}

/*
 * Task 1: Implement the get_input() function.
 * - Ask current_player for cell coordinates, and convert to array coordinates [row][col].
 * - cin format is column-letter followed immediately by row-number (e.g. C4).
 * - Note that the variable col is int; perform the appropriate type conversion on column-letter.
 * - Note that C++ arrays are zero-indexed (i.e. index starts at 0).
 * - If the cell coordinates are invalid, output the corresponding error messages, and ask for input again.
 * - Out-of-bounds error: [row][col] is outside the grid.
 * - Opponent-orb(s) error: [row][col] contains opponent's orb(s).
 */
/*
 * Output messages: Please copy and paste from here.
 * cout << "Player " << current_player << ", please enter cell coordinates: ";
 * cout << "Given coordinates are out of bounds!" << '\n';
 * cout << "Selected cell has an opponent's orb!" << '\n';
 * cout << "Invalid input. Please enter again." << '\n' << '\n';
 */
void get_input(int& row, int& col) {
	char col_letter;
	bool is_input_valid;
	do {
		is_input_valid = true;
		cout << "Player " << current_player << ", please enter cell coordinates: ";
		cin >> col_letter >> row;
		row = row - 1;
		col = (int)(col_letter - 'A');

		if (row < 0 || row >= NUM_ROWS || col < 0 || col >= NUM_COLS) {
			cout << "Given coordinates are out of bounds!" << '\n';
			cout << "Invalid input. Please enter again." << '\n' << '\n';
			is_input_valid = false;
		} else if (grid[row][col] > 0 && label[row][col] != current_player) {
			cout << "Selected cell has an opponent's orb!" << '\n';
			cout << "Invalid input. Please enter again." << '\n' << '\n';
			is_input_valid = false;
		}
	} while (!is_input_valid);
}

/*
 * Task 2: Implement the place_orb() function.
 * - Do nothing if [row][col] is outside the grid.
 * - Add an orb with current_player's label to [row][col] (similarly for explosion), also update num_O_orbs and num_X_orbs.
 * - Update is_game_over, i.e. if all orbs on the grid are the same label, and there are at least two orbs.
 * - If the game is not over, check explosion condition and implement explosion recursion if appropriate.
 * - Remember to correctly determine the number of neighbor cells; only adjacent, not diagonal.
 * - If the cell has exploded and is now empty, remember to update with the EMPTY_CELL label.
 * - For ease of automated grading, recursive calls must be in the order Up-Down-Left-Right.
 * - In addition, please code the subtasks in the above listed order.
 */
void place_orb(int row, int col) {
	// Do nothing if [row][col] is outside the grid.
	if (row < 0 || row >= NUM_ROWS || col < 0 || col >= NUM_COLS) {
		return;
	}

	// Add an orb with current_player's label to [row][col] (similarly for explosion), also update num_O_orbs and num_X_orbs.
	if (label[row][col] == PLAYER_O) {
		num_O_orbs -= grid[row][col];
	} else if (label[row][col] == PLAYER_X) {
		num_X_orbs -= grid[row][col];
	}

	grid[row][col] += 1;
	label[row][col] = current_player;

	if (label[row][col] == PLAYER_O) {
		num_O_orbs += grid[row][col];
	} else {
		num_X_orbs += grid[row][col];
	}

	// Update is_game_over.
	if ((num_O_orbs == 0 || num_X_orbs == 0) && (num_O_orbs + num_X_orbs >= 2)) {
		is_game_over = true;
	}

	// If the game is not over, check explosion condition and implement explosion recursion if appropriate.
	if (!is_game_over) {
		// Making use of C++ bool "true" value equivalent to int "1" value, to determine the number of neighbor cells in one-line of code.
		int num_neighbors = 4 - (row == 0) - (row == NUM_ROWS - 1) - (col == 0) - (col == NUM_COLS - 1); // Four corners of the grid.
		if (grid[row][col] >= num_neighbors) {
			if (label[row][col] == PLAYER_O) {
				num_O_orbs -= grid[row][col];
			} else {
				num_X_orbs -= grid[row][col];
			}
			grid[row][col] = 0;
			label[row][col] = EMPTY_CELL; // Resetting exploded cell label to EMPTY_CELL.

			// Up-Down-Left-Right order for recursive calls.
			place_orb(row-1, col);
			place_orb(row+1, col);
			place_orb(row, col-1);
			place_orb(row, col+1);
		}
	}
}
