#ifndef LAB2_H_
#define LAB2_H_

// Game State Constants.
const int NUM_ROWS = 9;
const int NUM_COLS = 6;
const char PLAYER_O = 'O';
const char PLAYER_X = 'X';
const char EMPTY_CELL = ' ';

// Game State Global Variables.
extern int grid[NUM_ROWS][NUM_COLS];
extern char label[NUM_ROWS][NUM_COLS];
extern char current_player;
extern int num_O_orbs;
extern int num_X_orbs;
extern bool is_game_over;

// Gameplay Functions.
void display_grid();
void get_input(int& row, int& col);
void place_orb(int row, int col);

#endif /* LAB2_H_ */
