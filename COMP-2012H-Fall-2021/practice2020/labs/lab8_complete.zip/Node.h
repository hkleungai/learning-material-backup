#ifndef NODE_H_
#define NODE_H_
#include <iostream>
class Node {
public:
	Node() = default;
	Node(int a) {
		if (a == -1) {
			key = -1e9;
		} else if (a == 1) {
			key = 1e9;
		}
	}
	Node(int a, int b) :
			key(a), value(b) {
	}
	bool operator<(const Node &rhs) const;
	bool operator>(const Node &rhs) const;
	friend std::ostream& operator<<(std::ostream &os, const Node &n);
private:
	int key = 0, value = 0;
};

#endif /* NODE_H_ */
