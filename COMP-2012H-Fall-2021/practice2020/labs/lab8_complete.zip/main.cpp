#include "BST.cpp"
#include "Node.h"

#include <random>
#include <set>
using namespace std;

ostream& operator<<(ostream &os, const Node &n) {
	os << '(' << n.key << ',' << n.value << ')';
	return os;
}

void task1_tests(int prefix=0) {
	BST<Node> bst;
	cout << "Task " << prefix+1 << " Tests" << endl;
	bst.insert(Node { 5, 5 });
	if (bst.check_BST())
		cout << "OK. Tree is still a BST after inserting 5" << endl;
	else
		cout << "Tree is no longer a BST after inserting 5" << endl;

	bst.insert(Node { 2, 2 });
	if (bst.check_BST())
		cout << "OK. Tree is still a BST after inserting 2" << endl;
	else
		cout << "Tree is no longer a BST after inserting 2" << endl;

	bst.insert(Node { 8, 8 });
	if (bst.check_BST())
		cout << "OK. Tree is still a BST after inserting 8" << endl;
	else
		cout << "Tree is no longer a BST after inserting 8" << endl;

	bst.insert(Node { 9, 9 });
	if (bst.check_BST())
		cout << "OK. Tree is still a BST after inserting 9" << endl;
	else
		cout << "Tree is no longer a BST after inserting 9" << endl;

	bst.insert(Node { 7, 7 });
	if (bst.check_BST())
		cout << "OK. Tree is still a BST after inserting 7" << endl;
	else
		cout << "Tree is no longer a BST after inserting 7" << endl;

	bst.insert(Node { 11, 11 });
	if (bst.check_BST())
		cout << "OK. Tree is still a BST after inserting 11" << endl;
	else
		cout << "Tree is no longer a BST after inserting 11" << endl;

	bst.insert(Node { 15, 15 });
	if (bst.check_BST())
		cout << "OK. Tree is still a BST after inserting 15" << endl;
	else
		cout << "Tree is no longer a BST after inserting 15" << endl;

	bst.insert(Node { 1, 1 });
	if (bst.check_BST())
		cout << "OK. Tree is still a BST after inserting 1" << endl;
	else
		cout << "Tree is no longer a BST after inserting 1" << endl;

	bst.insert(Node { 14, 14 });
	if (bst.check_BST())
		cout << "OK. Tree is still a BST after inserting 14" << endl;
	else
		cout << "Tree is no longer a BST after inserting 14" << endl;

	bst.insert(Node { 6, 6 });
	if (bst.check_BST())
		cout << "OK. Tree is still a BST after inserting 6" << endl;
	else
		cout << "Tree is no longer a BST after inserting 6" << endl;

	bst.insert(Node { 3, 3 });
	if (bst.check_BST())
		cout << "OK. Tree is still a BST after inserting 3" << endl;
	else
		cout << "Tree is no longer a BST after inserting 3" << endl;

	bst.insert(Node { 4, 4 });
	if (bst.check_BST())
		cout << "OK. Tree is still a BST after inserting 4" << endl;
	else
		cout << "Tree is no longer a BST after inserting 4" << endl;

	bst.insert(Node { 10, 10 });
	if (bst.check_BST())
		cout << "OK. Tree is still a BST after inserting 10" << endl;
	else
		cout << "Tree is no longer a BST after inserting 10" << endl;

	bst.insert(Node { 12, 12 });
	if (bst.check_BST())
		cout << "OK. Tree is still a BST after inserting 12" << endl;
	else
		cout << "Tree is no longer a BST after inserting 12" << endl;

	bst.insert(Node { 13, 13 });
	if (bst.check_BST())
		cout << "OK. Tree is still a BST after inserting 13" << endl;
	else
		cout << "Tree is no longer a BST after inserting 13" << endl;
	
	cout << "Task 1 Tests Complete" << endl;
}

void task2_tests() {
	BST<Node> bst;
	cout << "Task 2 preparation..." << endl;
	bst.insert(Node { 5, 5 });
	bst.insert(Node { 2, 2 });
	bst.insert(Node { 8, 8 });
	bst.insert(Node { 9, 9 });
	bst.insert(Node { 7, 7 });
	bst.insert(Node { 11, 11 });
	bst.insert(Node { 15, 15 });
	bst.insert(Node { 1, 1 });
	bst.insert(Node { 14, 14 });
	bst.insert(Node { 6, 6 });
	bst.insert(Node { 3, 3 });
	bst.insert(Node { 4, 4 });
	bst.insert(Node { 10, 10 });
	bst.insert(Node { 12, 12 });
	bst.insert(Node { 13, 13 });
	cout << "Task 2 Tests" << endl;
	
	bst.remove(Node { 9, 9 });
	if (bst.check_BST())
		cout << "OK. Tree is still a BST after removing 9" << endl;
	else
		cout << "Tree is no longer a BST after removing 9" << endl;
	
	bst.remove(Node { 13, 13 });
	if (bst.check_BST())
		cout << "OK. Tree is still a BST after removing 13" << endl;
	else
		cout << "Tree is no longer a BST after removing 13" << endl;
	
	bst.remove(Node { 12, 12 });
	if (bst.check_BST())
		cout << "OK. Tree is still a BST after removing 12" << endl;
	else
		cout << "Tree is no longer a BST after removing 12" << endl;
	
	bst.remove(Node { 2, 2 });
	if (bst.check_BST())
		cout << "OK. Tree is still a BST after removing 2" << endl;
	else
		cout << "Tree is no longer a BST after removing 2" << endl;
	
	bst.remove(Node { 5, 5 });
	if (bst.check_BST())
		cout << "OK. Tree is still a BST after removing 5" << endl;
	else
		cout << "Tree is no longer a BST after removing 5" << endl;
	
	bst.remove(Node { 4, 4 });
	if (bst.check_BST())
		cout << "OK. Tree is still a BST after removing 4" << endl;
	else
		cout << "Tree is no longer a BST after removing 4" << endl;
	
	bst.remove(Node { 3, 3 });
	if (bst.check_BST())
		cout << "OK. Tree is still a BST after removing 3" << endl;
	else
		cout << "Tree is no longer a BST after removing 3" << endl;
	
	bst.remove(Node { 15, 15 });
	if (bst.check_BST())
		cout << "OK. Tree is still a BST after removing 15" << endl;
	else
		cout << "Tree is no longer a BST after removing 15" << endl;
	
	bst.remove(Node { 14, 14 });
	if (bst.check_BST())
		cout << "OK. Tree is still a BST after removing 14" << endl;
	else
		cout << "Tree is no longer a BST after removing 14" << endl;
	
	bst.remove(Node { 7, 7 });
	if (bst.check_BST())
		cout << "OK. Tree is still a BST after removing 7" << endl;
	else
		cout << "Tree is no longer a BST after removing 7" << endl;
	
	bst.remove(Node { 8, 8 });
	if (bst.check_BST())
		cout << "OK. Tree is still a BST after removing 8" << endl;
	else
		cout << "Tree is no longer a BST after removing 8" << endl;
	
	bst.remove(Node { 11, 11 });
	if (bst.check_BST())
		cout << "OK. Tree is still a BST after removing 11" << endl;
	else
		cout << "Tree is no longer a BST after removing 11" << endl;
	
	bst.remove(Node { 6, 6 });
	if (bst.check_BST())
		cout << "OK. Tree is still a BST after removing 6" << endl;
	else
		cout << "Tree is no longer a BST after removing 6" << endl;
	
	bst.remove(Node { 1, 1 });
	if (bst.check_BST())
		cout << "OK. Tree is still a BST after removing 1" << endl;
	else
		cout << "Tree is no longer a BST after removing 1" << endl;
	
	bst.remove(Node { 10, 10 });
	if (bst.check_BST())
		cout << "OK. Tree is still a BST after removing 10" << endl;
	else
		cout << "Tree is no longer a BST after removing 10" << endl;
	
	cout << "Is tree empty? " << bst.is_empty() << endl;
	cout << "Task 2 Tests Complete" << endl;
}

void task3_tests() {
	BST<Node> bst;
	cout << "Task 3 preparation..." << endl;
	bst.insert(Node { 5, 5 });
	bst.insert(Node { 2, 2 });
	bst.insert(Node { 8, 8 });
	bst.insert(Node { 9, 9 });
	bst.insert(Node { 7, 7 });
	bst.insert(Node { 11, 11 });
	bst.insert(Node { 15, 15 });
	bst.insert(Node { 1, 1 });
	bst.insert(Node { 14, 14 });
	bst.insert(Node { 6, 6 });
	bst.insert(Node { 3, 3 });
	bst.insert(Node { 4, 4 });
	bst.insert(Node { 10, 10 });
	bst.insert(Node { 12, 12 });
	bst.insert(Node { 13, 13 });
	cout << "Task 3 Tests" << endl << endl;
	cout << "Pre-order Traversal:" << endl;
	bst.pre_order_traversal();
	cout << endl;
	cout << "In-order Traversal:" << endl;
	bst.in_order_traversal();
	cout << endl;
	cout << "Post-order Traversal:" << endl;
	bst.post_order_traversal();
	cout << endl;
	cout << "Task 3 Tests Complete" << endl;
}

void stress_tests() {
	BST<Node> bst;
	BST<Node> bst2;
	BST<Node> bst3;
	bst3.insert(Node { 1, 5 });
	cout << "Stress Tests" << endl << endl;
	bst.remove(Node { 1, 5 });
	bst.insert(Node { 1, 5 });
	bst.remove(Node { 1, 5 });
	bst.remove(Node { 1, 5 });
	cout << "OK. Does not crash" << endl;
	bst.insert(Node { 17588, 13934 });
	bst.insert(Node { 23618, 11124 });
	bst.insert(Node { 9924, 14674 });
	bst.insert(Node { 30366, 6278 });
	bst.insert(Node { 15191, 14198 });
	bst.insert(Node { 23251, 6467 });
	bst.insert(Node { 21836, 10324 });
	bst.insert(Node { 4676, 530 });
	bst.insert(Node { 26044, 11693 });
	bst.insert(Node { 6266, 32228 });
	bst.insert(Node { 21283, 7713 });
	bst.insert(Node { 2924, 3434 });
	bst.insert(Node { 19392, 7677 });
	bst.insert(Node { 12541, 1670 });
	bst.insert(Node { 5950, 14932 });
	bst.insert(Node { 30151, 10239 });
	bst.insert(Node { 11155, 14929 });
	bst.insert(Node { 18711, 5496 });
	bst.insert(Node { 2345, 6859 });
	bst.insert(Node { 31288, 20387 });
	bst.insert(Node { 8763, 26650 });
	bst.insert(Node { 31477, 31922 });
	bst.insert(Node { 20867, 27177 });
	bst.insert(Node { 11097, 5390 });
	bst.insert(Node { 9234, 22221 });
	bst.insert(Node { 4793, 18508 });
	bst.insert(Node { 31359, 32341 });
	bst.insert(Node { 10741, 11869 });
	bst.insert(Node { 17731, 9827 });
	bst.insert(Node { 6906, 6404 });
	bst.insert(Node { 24676, 1786 });
	bst.insert(Node { 6539, 6541 });
	bst.insert(Node { 21073, 7639 });
	bst.insert(Node { 14658, 3773 });
	bst.insert(Node { 29197, 19461 });
	bst.insert(Node { 25809, 20229 });
	bst.insert(Node { 14480, 29100 });
	bst.insert(Node { 23182, 17146 });
	bst.insert(Node { 16747, 31786 });
	bst.insert(Node { 21039, 1034 });
	bst.insert(Node { 16042, 6756 });
	bst.insert(Node { 12241, 21351 });
	bst.insert(Node { 25598, 2910 });
	bst.insert(Node { 26688, 32072 });
	bst.insert(Node { 3356, 15114 });
	bst.insert(Node { 31346, 31825 });
	bst.insert(Node { 9056, 8542 });
	bst.insert(Node { 8788, 29007 });
	bst.insert(Node { 1718, 6057 });
	bst.insert(Node { 10442, 17193 });
	bst.insert(Node { 32186, 6183 });
	bst.insert(Node { 29936, 31508 });
	bst.insert(Node { 28958, 7123 });
	bst.insert(Node { 17063, 12549 });
	bst.insert(Node { 30284, 2684 });
	bst.insert(Node { 8781, 7276 });
	bst.insert(Node { 27981, 28955 });
	bst.insert(Node { 9675, 7455 });
	bst.insert(Node { 13802, 29284 });
	bst.insert(Node { 24277, 20628 });
	bst.insert(Node { 16401, 9627 });
	bst.insert(Node { 4717, 1876 });
	bst.insert(Node { 31610, 22441 });
	bst.insert(Node { 17833, 11948 });
	bst.insert(Node { 27273, 25199 });
	bst.insert(Node { 1975, 678 });
	bst.insert(Node { 23671, 3674 });
	bst.insert(Node { 7454, 7224 });
	bst.insert(Node { 4781, 12856 });
	bst.insert(Node { 28742, 12218 });
	bst.insert(Node { 21872, 1354 });
	bst.insert(Node { 27451, 3997 });
	bst.insert(Node { 15299, 22426 });
	bst.insert(Node { 7854, 18267 });
	bst.insert(Node { 10889, 9358 });
	bst.insert(Node { 23101, 25258 });
	bst.insert(Node { 20203, 13246 });
	bst.insert(Node { 6644, 13557 });
	bst.insert(Node { 6137, 15363 });
	bst.insert(Node { 27923, 13580 });
	bst.insert(Node { 29588, 15568 });
	bst.insert(Node { 14865, 16667 });
	bst.insert(Node { 21131, 454 });
	bst.insert(Node { 994, 24281 });
	bst.insert(Node { 14340, 1154 });
	bst.insert(Node { 5238, 19457 });
	bst.insert(Node { 22558, 8378 });
	bst.insert(Node { 12418, 29446 });
	bst.insert(Node { 2516, 20104 });
	bst.insert(Node { 14466, 6147 });
	bst.insert(Node { 4133, 22277 });
	bst.insert(Node { 23295, 20976 });
	bst.insert(Node { 32369, 14106 });
	bst.insert(Node { 15373, 9244 });
	bst.insert(Node { 15399, 9363 });
	bst.insert(Node { 13849, 19415 });
	bst.insert(Node { 27549, 26997 });
	bst.insert(Node { 6113, 5743 });
	bst.insert(Node { 14399, 2450 });
	bst.insert(Node { 964, 21343 });
	if (bst.check_BST())
		cout << "OK. Tree is still a BST after insertions" << endl;
	else
		cout << "Tree is no longer a BST after insertions" << endl;
	bst.remove(Node { 23618, 11124 });
	bst.remove(Node { 23618, 11124 });
	bst.remove(Node { 21283, 7713 });
	bst.remove(Node { 21283, 7713 });
	cout << "OK. Does not crash after repeated removals" << endl;
	bst.remove(Node { -100, 30 });
	bst.remove(Node { 5000, 30 });
	bst.remove(Node { 10000000, 30 });
	cout << "OK. Does not crash when removing nonexistent nodes" << endl;
	bst.remove(Node { 16401, 9627 });
	bst.remove(Node { 9924, 14674 });
	bst.remove(Node { 27273, 25199 });
	bst.remove(Node { 2345, 6859 });
	bst.remove(Node { 7854, 18267 });
	bst.remove(Node { 1718, 6057 });
	bst.remove(Node { 1975, 678 });
	bst.remove(Node { 14399, 2450 });
	bst.remove(Node { 2516, 20104 });
	bst.remove(Node { 21131, 454 });
	bst.remove(Node { 16401, 9627 });
	bst.remove(Node { 10889, 9358 });
	bst.remove(Node { 32369, 14106 });
	bst.remove(Node { 17063, 12549 });
	bst.remove(Node { 21039, 1034 });
	bst.remove(Node { 17588, 13934 });
	bst.remove(Node { 6644, 13557 });
	bst.remove(Node { 4781, 12856 });
	bst.remove(Node { 994, 24281 });
	bst.remove(Node { 1975, 678 });
	bst.remove(Node { 9924, 14674 });
	bst.remove(Node { 16747, 31786 });
	bst.remove(Node { 29936, 31508 });
	bst.remove(Node { 14399, 2450 });
	bst.remove(Node { 14865, 16667 });
	bst.remove(Node { 16747, 31786 });
	bst.remove(Node { 29936, 31508 });
	bst.remove(Node { 19392, 7677 });
	bst.remove(Node { 13849, 19415 });
	bst.remove(Node { 6539, 6541 });
	bst.remove(Node { 14340, 1154 });
	bst.remove(Node { 21283, 7713 });
	bst.remove(Node { 28742, 12218 });
	bst.remove(Node { 14480, 29100 });
	bst.remove(Node { 15399, 9363 });
	bst.remove(Node { 23182, 17146 });
	bst.remove(Node { 21836, 10324 });
	bst.remove(Node { 6113, 5743 });
	bst.remove(Node { 28958, 7123 });
	bst.remove(Node { 21073, 7639 });
	bst.remove(Node { 21836, 10324 });
	bst.remove(Node { 4676, 530 });
	bst.remove(Node { 8788, 29007 });
	bst.remove(Node { 10889, 9358 });
	bst.remove(Node { 21283, 7713 });
	bst.remove(Node { 6644, 13557 });
	bst.remove(Node { 4717, 1876 });
	bst.remove(Node { 31346, 31825 });
	bst.remove(Node { 7854, 18267 });
	bst.remove(Node { 29936, 31508 });
	bst.remove(Node { 2924, 3434 });
	bst.remove(Node { 27273, 25199 });
	bst.remove(Node { 26688, 32072 });
	bst.remove(Node { 11097, 5390 });
	bst.remove(Node { 6266, 32228 });
	bst.remove(Node { 21039, 1034 });
	bst.remove(Node { 3356, 15114 });
	bst.remove(Node { 21872, 1354 });
	bst.remove(Node { 14658, 3773 });
	bst.remove(Node { 14466, 6147 });
	bst.remove(Node { 8781, 7276 });
	bst.remove(Node { 15299, 22426 });
	bst.remove(Node { 31288, 20387 });
	bst.remove(Node { 6137, 15363 });
	bst.remove(Node { 7454, 7224 });
	bst.remove(Node { 12418, 29446 });
	bst.remove(Node { 6539, 6541 });
	bst.remove(Node { 964, 21343 });
	bst.remove(Node { 6906, 6404 });
	bst.remove(Node { 1975, 678 });
	bst.remove(Node { 994, 24281 });
	bst.remove(Node { 31359, 32341 });
	bst.remove(Node { 6539, 6541 });
	bst.remove(Node { 27981, 28955 });
	bst.remove(Node { 964, 21343 });
	bst.remove(Node { 20867, 27177 });
	bst.remove(Node { 31477, 31922 });
	bst.remove(Node { 6266, 32228 });
	bst.remove(Node { 31610, 22441 });
	bst.remove(Node { 23295, 20976 });
	bst.remove(Node { 23101, 25258 });
	bst.remove(Node { 17731, 9827 });
	bst.remove(Node { 23295, 20976 });
	bst.remove(Node { 6113, 5743 });
	bst.remove(Node { 21836, 10324 });
	bst.remove(Node { 17833, 11948 });
	bst.remove(Node { 8763, 26650 });
	bst.remove(Node { 8788, 29007 });
	bst.remove(Node { 29197, 19461 });
	bst.remove(Node { 15373, 9244 });
	bst.remove(Node { 14865, 16667 });
	bst.remove(Node { 25598, 2910 });
	bst.remove(Node { 21836, 10324 });
	bst.remove(Node { 13802, 29284 });
	bst.remove(Node { 3356, 15114 });
	bst.remove(Node { 8788, 29007 });
	bst.remove(Node { 30284, 2684 });
	bst.remove(Node { 20203, 13246 });
	bst.remove(Node { 27451, 3997 });
	bst.remove(Node { 29197, 19461 });
	if (bst.check_BST())
		cout << "OK. Tree is still a BST after removals" << endl;
	else
		cout << "Tree is no longer a BST after removals" << endl;
	bst.insert(Node { 13299, 943 });
	bst.remove(Node { 15399, 9363 });
	bst.insert(Node { 15610, 27144 });
	bst.insert(Node { 14894, 16149 });
	bst.remove(Node { 14894, 16149 });
	bst.remove(Node { 14894, 16149 });
	bst.insert(Node { 24918, 5068 });
	bst.insert(Node { 6819, 19694 });
	bst.insert(Node { 11548, 3210 });
	bst.remove(Node { 14399, 2450 });
	bst.insert(Node { 1960, 15491 });
	bst.insert(Node { 18096, 31459 });
	bst.insert(Node { 22214, 13388 });
	bst.remove(Node { 11548, 3210 });
	bst.insert(Node { 13552, 18681 });
	bst.remove(Node { 15610, 27144 });
	bst.remove(Node { 11548, 3210 });
	bst.insert(Node { 14462, 6597 });
	bst.remove(Node { 24918, 5068 });
	bst.insert(Node { 21115, 16797 });
	bst.insert(Node { 27021, 27220 });
	bst.insert(Node { 30797, 29966 });
	bst.insert(Node { 15559, 18444 });
	bst.insert(Node { 399, 22449 });
	bst.remove(Node { 21115, 16797 });
	bst.remove(Node { 30797, 29966 });
	bst.insert(Node { 11579, 30044 });
	bst.remove(Node { 21115, 16797 });
	bst.insert(Node { 25143, 16572 });
	bst.insert(Node { 26070, 19331 });
	bst.remove(Node { 11579, 30044 });
	bst.remove(Node { 14462, 6597 });
	bst.insert(Node { 17347, 2945 });
	bst.insert(Node { 12798, 9596 });
	bst.remove(Node { 11579, 30044 });
	bst.remove(Node { 26070, 19331 });
	bst.insert(Node { 10615, 19902 });
	bst.remove(Node { 399, 22449 });
	bst.insert(Node { 14877, 5623 });
	bst.remove(Node { 30797, 29966 });
	bst.remove(Node { 399, 22449 });
	bst.remove(Node { 14877, 5623 });
	bst.insert(Node { 15125, 27971 });
	bst.insert(Node { 2730, 28924 });
	bst.insert(Node { 11258, 8340 });
	bst.remove(Node { 2730, 28924 });
	bst.insert(Node { 2656, 6060 });
	bst.remove(Node { 10615, 19902 });
	bst.insert(Node { 25245, 6241 });
	bst.insert(Node { 28820, 10281 });
	bst.remove(Node { 25245, 6241 });
	bst.remove(Node { 17347, 2945 });
	bst.insert(Node { 8543, 6620 });
	bst.remove(Node { 12798, 9596 });
	bst.remove(Node { 11258, 8340 });
	bst.insert(Node { 1363, 16206 });
	bst.insert(Node { 25860, 7904 });
	bst.insert(Node { 16970, 24372 });
	bst.insert(Node { 18735, 19167 });
	bst.remove(Node { 8543, 6620 });
	bst.insert(Node { 1123, 2732 });
	bst.insert(Node { 19233, 21617 });
	bst.remove(Node { 25245, 6241 });
	bst.insert(Node { 6847, 11471 });
	bst.remove(Node { 8543, 6620 });
	bst.remove(Node { 19233, 21617 });
	bst.insert(Node { 25276, 31307 });
	bst.insert(Node { 26786, 2311 });
	bst.remove(Node { 19233, 21617 });
	bst.insert(Node { 24620, 2802 });
	bst.remove(Node { 19233, 21617 });
	bst.insert(Node { 10363, 1812 });
	bst.insert(Node { 5019, 19125 });
	bst.remove(Node { 10363, 1812 });
	bst.insert(Node { 5611, 14911 });
	bst.remove(Node { 18735, 19167 });
	bst.insert(Node { 14138, 6627 });
	bst.insert(Node { 32599, 26240 });
	bst.remove(Node { 10363, 1812 });
	bst.insert(Node { 12182, 23578 });
	bst.insert(Node { 17018, 24743 });
	bst.remove(Node { 26786, 2311 });
	bst.remove(Node { 14138, 6627 });
	bst.remove(Node { 32599, 26240 });
	bst.insert(Node { 26658, 25738 });
	bst.insert(Node { 18986, 24195 });
	bst.insert(Node { 12347, 14599 });
	bst.remove(Node { 18986, 24195 });
	bst.insert(Node { 10261, 7973 });
	bst.remove(Node { 18986, 24195 });
	bst.remove(Node { 17018, 24743 });
	bst.insert(Node { 27377, 1832 });
	bst.remove(Node { 14138, 6627 });
	bst.insert(Node { 17427, 6615 });
	bst.insert(Node { 8864, 8458 });
	bst.insert(Node { 28740, 15949 });
	bst.remove(Node { 18986, 24195 });
	bst.remove(Node { 18986, 24195 });
	bst.remove(Node { 10261, 7973 });
	bst.insert(Node { 1700, 9919 });
	if (bst.check_BST())
		cout << "OK. Tree is still a BST" << endl;
	else
		cout << "Tree is no longer a BST" << endl;
	cout << endl;
	bst2.pre_order_traversal();
	bst2.in_order_traversal();
	bst2.post_order_traversal();
	bst3.pre_order_traversal();
	bst3.in_order_traversal();
	bst3.post_order_traversal();
	cout << "OK. Does not crash" << endl << endl;
	cout << "Pre-order Traversal:" << endl;
	bst.pre_order_traversal();
	cout << endl;
	cout << "In-order Traversal:" << endl;
	bst.in_order_traversal();
	cout << endl;
	cout << "Post-order Traversal:" << endl;
	bst.post_order_traversal();
	cout << endl;
	bst.remove(Node { 27377, 1832 });
	bst.remove(Node { 27377, 1832 });
	bst.insert(Node { 27689, 15069 });
	bst.remove(Node { 27377, 1832 });
	bst.remove(Node { 8864, 8458 });
	bst.remove(Node { 17427, 6615 });
	bst.remove(Node { 27689, 15069 });
	bst.insert(Node { 9608, 28969 });
	bst.remove(Node { 27377, 1832 });
	bst.remove(Node { 27377, 1832 });
	bst.remove(Node { 8864, 8458 });
	bst.insert(Node { 27938, 119 });
	bst.insert(Node { 24114, 24368 });
	bst.insert(Node { 23732, 10524 });
	bst.remove(Node { 17427, 6615 });
	bst.remove(Node { 9608, 28969 });
	bst.insert(Node { 6382, 28883 });
	bst.remove(Node { 6382, 28883 });
	bst.remove(Node { 8864, 8458 });
	bst.insert(Node { 7505, 24682 });
	bst.remove(Node { 1700, 9919 });
	bst.insert(Node { 19540, 28704 });
	bst.remove(Node { 1700, 9919 });
	bst.insert(Node { 5058, 10183 });
	bst.remove(Node { 1700, 9919 });
	bst.insert(Node { 10107, 32236 });
	bst.insert(Node { 28105, 28278 });
	bst.insert(Node { 11871, 26248 });
	bst.remove(Node { 23732, 10524 });
	bst.remove(Node { 6382, 28883 });
	bst.remove(Node { 6382, 28883 });
	bst.insert(Node { 4172, 24647 });
	bst.insert(Node { 5122, 29255 });
	bst.insert(Node { 9916, 31421 });
	bst.insert(Node { 11571, 2421 });
	bst.insert(Node { 25703, 25785 });
	bst.remove(Node { 5058, 10183 });
	bst.insert(Node { 25762, 26209 });
	bst.remove(Node { 4172, 24647 });
	bst.insert(Node { 5178, 28524 });
	bst.insert(Node { 14625, 919 });
	bst.remove(Node { 5178, 28524 });
	bst.remove(Node { 25703, 25785 });
	bst.insert(Node { 30408, 6016 });
	bst.remove(Node { 14625, 919 });
	bst.remove(Node { 30408, 6016 });
	bst.insert(Node { 20852, 4304 });
	bst.insert(Node { 28403, 11054 });
	bst.insert(Node { 18984, 27913 });
	bst.remove(Node { 28403, 11054 });
	bst.insert(Node { 10316, 25836 });
	bst.remove(Node { 20852, 4304 });
	bst.remove(Node { 14625, 919 });
	bst.insert(Node { 1715, 24416 });
	bst.insert(Node { 21410, 14961 });
	bst.remove(Node { 10316, 25836 });
	bst.remove(Node { 18984, 27913 });
	bst.remove(Node { 25762, 26209 });
	bst.insert(Node { 30278, 32438 });
	bst.remove(Node { 14625, 919 });
	bst.remove(Node { 18984, 27913 });
	bst.insert(Node { 7409, 21800 });
	bst.remove(Node { 10316, 25836 });
	bst.remove(Node { 28403, 11054 });
	bst.remove(Node { 18984, 27913 });
	bst.insert(Node { 30393, 10691 });
	bst.insert(Node { 18097, 10988 });
	bst.remove(Node { 28403, 11054 });
	bst.insert(Node { 8538, 10903 });
	bst.insert(Node { 14992, 7554 });
	bst.insert(Node { 2800, 29425 });
	bst.insert(Node { 7380, 31588 });
	bst.remove(Node { 30278, 32438 });
	bst.insert(Node { 31584, 30597 });
	bst.remove(Node { 31584, 30597 });
	bst.insert(Node { 8291, 15676 });
	bst.insert(Node { 11807, 2217 });
	bst.remove(Node { 11807, 2217 });
	bst.remove(Node { 8291, 15676 });
	bst.remove(Node { 7380, 31588 });
	bst.remove(Node { 8291, 15676 });
	bst.remove(Node { 30393, 10691 });
	bst.remove(Node { 8538, 10903 });
	bst.insert(Node { 31708, 21546 });
	bst.remove(Node { 18097, 10988 });
	bst.remove(Node { 30393, 10691 });
	bst.insert(Node { 21639, 7312 });
	bst.remove(Node { 8538, 10903 });
	bst.remove(Node { 8291, 15676 });
	bst.remove(Node { 14992, 7554 });
	bst.insert(Node { 9247, 22360 });
	bst.remove(Node { 9247, 22360 });
	bst.insert(Node { 648, 31260 });
	bst.insert(Node { 28583, 25716 });
	bst.remove(Node { 31708, 21546 });
	bst.remove(Node { 11807, 2217 });
	bst.insert(Node { 12102, 28977 });
	bst.insert(Node { 8131, 2599 });
	bst.remove(Node { 28583, 25716 });
	bst.insert(Node { 31699, 695 });

	cout << "Pre-order Traversal:" << endl;
	bst.pre_order_traversal();
	cout << endl;
	cout << "In-order Traversal:" << endl;
	bst.in_order_traversal();
	cout << endl;
	cout << "Post-order Traversal:" << endl;
	bst.post_order_traversal();
	cout << endl;
	cout << "Stress Tests Complete" << endl;
}

int main(int argc, char** argv) {
	cout << boolalpha;
	if (argc == 1) {
		task1_tests();
		cout << endl;
		task2_tests();
		cout << endl;
		task3_tests();
	}
	else {
		switch(argv[1][0]) {
		case '1':
			task1_tests();
			break;
		case '2':
			task2_tests();
			break;
		case '3':
			task3_tests();
			break;
		case '4':
			stress_tests();
			break;
		case 'h':
			task1_tests(4444);
			break;
		};
	}
	return 0;
}

