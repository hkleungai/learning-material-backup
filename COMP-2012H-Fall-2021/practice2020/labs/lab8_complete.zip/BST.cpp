#include "BST.h"

template<typename T>
void BST<T>::print_node(BSTnode *&p) {
	std::cout << (p->data) << std::endl;
}

template<typename T>
bool BST<T>::check_BST(BSTnode *&p, T min, T max) {
	if (p == nullptr)
		return true;
	if (p->data < min || p->data > max)
		return false;
	return check_BST(p->ls, min, p->data) && check_BST(p->rs, p->data, max);
}

template<typename T>
bool BST<T>::check_BST() {
	T min { -1 };
	T max { 1 };
	return check_BST(root, min, max);
}

template<typename T>
bool BST<T>::contains(const BSTnode * const &p, const T &x) const {
	if (p == nullptr)
		return false;
	if (!(p->data < x) && !(p->data > x))
		return true;
	if (x < p->data)
		return contains(p->ls, x);
	else
		return contains(p->rs, x);
}

template<typename T>
bool BST<T>::contains(const T &x) const {
	return contains(root, x);
}

//Task 1 & 2: BST insertion and deletion
template<typename T>
void BST<T>::insert(BSTnode *&p, const T &x) {
	if (p == nullptr) {
		p = new BSTnode(x);
		return;
	}
	if (x < p->data) {
		insert(p->ls, x);
	} else {
		insert(p->rs, x);
	}
}

template<typename T>
void BST<T>::remove(BSTnode *&p, const T &x) {
	if (p == nullptr)
		return;
	if (x < p->data) {
		remove(p->ls, x);
	} else if (x > p->data) {
		remove(p->rs, x);
	} else {
		if (p->ls && p->rs) {
			BSTnode *q = p->rs;
			while (q->ls)
				q = q->ls;
			p->data = q->data;
			remove(p->rs, q->data);
		} else {
			BSTnode *q = p;
			if (p->ls)
				p = p->ls;
			else if (p->rs)
				p = p->rs;
			else
				p = nullptr;
			q->ls = q->rs = nullptr;
			delete q;
			q = nullptr;
		}
	}
}

template<typename T>
void BST<T>::insert(const T &x) {
	insert(root, x);
}
template<typename T>
void BST<T>::remove(const T &x) {
	remove(root, x);
}

//Task 3: BST traversals
template<typename T>
void BST<T>::in_order_traversal(BSTnode *&p) {
	if (p == nullptr)
		return;
	in_order_traversal(p->ls);
	print_node(p);
	in_order_traversal(p->rs);
}

template<typename T>
void BST<T>::pre_order_traversal(BSTnode *&p) {
	if (p == nullptr)
		return;
	print_node(p);
	pre_order_traversal(p->ls);
	pre_order_traversal(p->rs);
}

template<typename T>
void BST<T>::post_order_traversal(BSTnode *&p) {
	if (p == nullptr)
		return;
	post_order_traversal(p->ls);
	post_order_traversal(p->rs);
	print_node(p);
}

template<typename T>
void BST<T>::in_order_traversal() {
	in_order_traversal(root);
}

template<typename T>
void BST<T>::pre_order_traversal() {
	pre_order_traversal(root);
}

template<typename T>
void BST<T>::post_order_traversal() {
	post_order_traversal(root);
}
