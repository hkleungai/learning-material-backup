#include <iostream>
using std::cout;
using std::endl;

#include "BaseArray.h"

BaseArray::BaseArray() : size{0}, head_index{0}, capacity{INITIAL_CAPACITY}, internal_array{new int[INITIAL_CAPACITY]} {}

BaseArray::BaseArray(const BaseArray& rhs) : size{rhs.size}, head_index{rhs.head_index}, capacity{rhs.capacity} {
	this->internal_array = new int[rhs.capacity];
	for (int i = 0; i < rhs.size; i += 1) {
		this->internal_array[(rhs.head_index + i) % rhs.capacity] = rhs.internal_array[(rhs.head_index + i) % rhs.capacity];
	}
}

BaseArray::~BaseArray() { delete[] internal_array; }

BaseArray& BaseArray::operator=(const BaseArray& rhs) {
	if (this != &rhs) {
		delete[] this->internal_array;
		this->internal_array = new int[rhs.capacity];
		for (int i = 0; i < rhs.size; i += 1) {
			this->internal_array[(rhs.head_index + i) % rhs.capacity] = rhs.internal_array[(rhs.head_index + i) % rhs.capacity];
		}

		this->capacity = rhs.capacity;
		this->size = rhs.size;
		this->head_index = rhs.head_index;
	}
	return *this;
}

const int& BaseArray::operator[](int index) const { return internal_array[index]; }
int& BaseArray::operator[](int index) { return internal_array[index]; }

int BaseArray::get_capacity() const { return capacity; }

void BaseArray::reallocate_capacity(int new_capacity) {
	if ((new_capacity == capacity) || (new_capacity < size) || (new_capacity < INITIAL_CAPACITY)) { return; }

	int* internal_array_temp = new int[new_capacity];
	for (int i = 0; i < size; i += 1) {
		internal_array_temp[i] = internal_array[(head_index + i) % capacity];
	}
	delete[] internal_array;
	internal_array = internal_array_temp;
	capacity = new_capacity;
	head_index = 0;
}

void BaseArray::print() const {
	if (size == 0) {
		cout << "Empty." << endl;
		return;
	}

	for (int i = 0; i < size; i += 1) {
		cout << internal_array[(head_index + i) % capacity] << ' ';
	}
	cout << endl;
}
