#include "Stack.h"

Stack::Stack() {}
Stack::Stack(const Stack& rhs) : BaseArray(rhs) {}
Stack::~Stack() {}

Stack& Stack::operator=(const Stack& rhs) {
	BaseArray::operator=(rhs);
	return *this;
}

int Stack::get_size() const { return size; }
bool Stack::is_empty() const { return (size == 0); }
const int& Stack::peek() const { return (*this)[size - 1]; }

void Stack::push(int data) {
	if (size >= get_capacity()) { reallocate_capacity(2*get_capacity()); }
	(*this)[size] = data;
	size += 1;
}

void Stack::pop() {
	if (is_empty()) { return; }
	size -= 1;
	if (size <= 4*get_capacity()) { reallocate_capacity(get_capacity()/2); }
}

void Stack::print() const { BaseArray::print(); }
