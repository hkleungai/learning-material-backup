#ifndef QUEUE_H_
#define QUEUE_H_

#include "BaseArray.h"

class Queue : public BaseArray {
public:
	Queue();
	Queue(const Queue& rhs);
	~Queue();

	Queue& operator=(const Queue& rhs);

	int get_size() const;
	bool is_empty() const;
	const int& peek() const;
	void enqueue(int data);
	void dequeue();
	void print() const;
};

#endif /* QUEUE_H_ */
