#include "Queue.h"

Queue::Queue() {}
Queue::Queue(const Queue& rhs) : BaseArray(rhs) {}
Queue::~Queue() {}

Queue& Queue::operator=(const Queue& rhs) {
	BaseArray::operator=(rhs);
	return *this;
}

int Queue::get_size() const { return size; }
bool Queue::is_empty() const { return (size == 0); }
const int& Queue::peek() const { return (*this)[head_index]; }

void Queue::enqueue(int data) {
	if (size >= get_capacity()) { reallocate_capacity(2*get_capacity()); }
	(*this)[(head_index + size) % get_capacity()] = data;
	size += 1;
}

void Queue::dequeue() {
	if (is_empty()) { return; }
	head_index = (head_index + 1) % get_capacity();
	size -= 1;
	if (size <= 4*get_capacity()) { reallocate_capacity(get_capacity()/2); }
}

void Queue::print() const { BaseArray::print(); }
