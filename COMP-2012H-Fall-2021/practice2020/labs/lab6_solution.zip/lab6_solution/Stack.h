#ifndef STACK_H_
#define STACK_H_

#include "BaseArray.h"

class Stack : public BaseArray {
public:
	Stack();
	Stack(const Stack& rhs);
	~Stack();

	Stack& operator=(const Stack& rhs);

	int get_size() const;
	bool is_empty() const;
	const int& peek() const;
	void push(int data);
	void pop();
	void print() const;
};

#endif /* STACK_H_ */
