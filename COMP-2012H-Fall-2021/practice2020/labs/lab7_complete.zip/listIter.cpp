#include "listIter.h"

template<typename T>
bool listIter<T>::operator==(const listIter<T> &rhs) {
	return ptr == rhs.ptr;
}

template<typename T>
bool listIter<T>::operator!=(const listIter<T> &rhs) {
	return ptr != rhs.ptr;
}

template<typename T>
T& listIter<T>::operator *() {
	return ptr->content;
}

//Task 2: Iterator for myList
template<typename T>
listIter<T>& listIter<T>::operator++() {
	ptr = ptr->next;
	return *this;
}

template<typename T>
listIter<T>& listIter<T>::operator--() {
	ptr = ptr->prev;
	return *this;
}

template<typename T>
listIter<T> listIter<T>::operator++(int) {
	listIter<T> temp = listIter<T>(*this);
	ptr = ptr->next;
	return temp;
}

template<typename T>
listIter<T> listIter<T>::operator--(int) {
	listIter<T> temp = listIter<T>(*this);
	ptr = ptr->prev;
	return temp;
}
