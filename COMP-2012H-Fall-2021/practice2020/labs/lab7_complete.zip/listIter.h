#ifndef LISTITER_H_
#define LISTITER_H_

#include "Node.h"

template<typename T>
class myList;

template<typename T>
class listIter {
	friend class myList<T> ;
public:
	listIter() = default;
	listIter(Node<T> *_ptr) :
			ptr(_ptr) {
	}
	listIter& operator++();
	listIter& operator--();
	listIter operator++(int);
	listIter operator--(int);
	bool operator==(const listIter &rhs);
	bool operator!=(const listIter &rhs);
	T& operator*();
private:
	Node<T> *ptr = nullptr;
};

#endif /* LISTITER_H_ */
