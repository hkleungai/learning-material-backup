#ifndef LINKED_LIST_H
#define LINKED_LIST_H

#include "Node.h"
#include "listIter.h"
#include <iostream>

template<typename T>
std::ostream& operator<<(std::ostream &os, myList<T> &list);

template<typename T>
class myList {
public:
	myList();
	~myList();
	void print();
	void print_front();
	void print_back();
	void clear();
	int size() const {
		return this->_size;
	}
	bool empty() const {
		return this->_size == 0;
	}

	void push_back(T content);
	void push_front(T content);
	void pop_back();
	void pop_front();

	listIter<T> begin();
	listIter<T> end();
	void insert(listIter<T> &p, T content);
	void erase(listIter<T> &p);

private:
	void insert(Node<T> *prev, Node<T> *ins);
	void remove(Node<T> *del);
	Node<T> *head;
	int _size { 0 };
};

#endif // LINKED_LIST_H
