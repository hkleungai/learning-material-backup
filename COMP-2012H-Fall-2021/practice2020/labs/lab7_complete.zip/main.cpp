#include "myList.cpp"
#include "listIter.cpp"

#include <iostream>
using namespace std;


void task1_tests(int prefix=0) {
	cout << "Task 1 tests" << endl;
	cout << boolalpha;
	myList<int> list;
	list.print_front();
	list.print_back();
	list.print();
	cout << list.empty() << endl;
	list.push_front(prefix+13);
	list.print_front();
	list.print_back();
	list.print();
	cout << list.empty() << endl;
	list.push_back(15);
	list.print_front();
	list.print_back();
	list.print();
	cout << list.empty() << endl;
	list.push_front(prefix+27);
	list.print_front();
	list.print_back();
	list.print();
	cout << list.empty() << endl;
	list.push_back(29);
	list.print_front();
	list.print_back();
	list.print();
	cout << list.empty() << endl;
	list.pop_front();
	list.print_front();
	list.print_back();
	list.print();
	cout << list.empty() << endl;
	list.pop_front();
	list.print_front();
	list.print_back();
	list.print();
	cout << list.empty() << endl;
	list.pop_back();
	list.print_front();
	list.print_back();
	list.print();
	cout << list.empty() << endl;
	list.pop_back();
	list.print_front();
	list.print_back();
	list.print();
	cout << list.empty() << endl;
	list.push_front(prefix+100);
	list.print_front();
	list.print_back();
	list.print();
	cout << list.empty() << endl;
	list.push_front(prefix+200);
	list.print_front();
	list.print_back();
	list.print();
	cout << list.empty() << endl;
	list.push_back(300);
	list.print_front();
	list.print_back();
	list.print();
	cout << list.empty() << endl;
	list.push_front(prefix+400);
	list.print_front();
	list.print_back();
	list.print();
	cout << list.empty() << endl;
	list.push_back(500);
	list.print_front();
	list.print_back();
	list.print();
	cout << list.empty() << endl;
	list.push_back(600);
	list.print_front();
	list.print_back();
	list.print();
	cout << list.empty() << endl;
	list.push_front(prefix+700);
	list.print_front();
	list.print_back();
	list.print();
	cout << list.empty() << endl;
	list.push_back(800);
	list.print_front();
	list.print_back();
	list.print();
	cout << list.empty() << endl;
	list.push_back(900);
	list.print_front();
	list.print_back();
	list.print();
	cout << list.empty() << endl;
	list.push_front(prefix+1000);
	list.print_front();
	list.print_back();
	list.print();
	cout << list.empty() << endl;
	list.pop_front();
	list.print_front();
	list.print_back();
	list.print();
	cout << list.empty() << endl;
	list.pop_front();
	list.print_front();
	list.print_back();
	list.print();
	cout << list.empty() << endl;
	list.pop_back();
	list.print_front();
	list.print_back();
	list.print();
	cout << list.empty() << endl;
	list.pop_front();
	list.print_front();
	list.print_back();
	list.print();
	cout << list.empty() << endl;
	list.pop_back();
	list.print_front();
	list.print_back();
	list.print();
	cout << list.empty() << endl;
	list.pop_back();
	list.print_front();
	list.print_back();
	list.print();
	cout << list.empty() << endl;
	list.pop_front();
	list.print_front();
	list.print_back();
	list.print();
	cout << list.empty() << endl;
	list.pop_back();
	list.print_front();
	list.print_back();
	list.print();
	cout << list.empty() << endl;
	list.pop_back();
	list.print_front();
	list.print_back();
	list.print();
	cout << list.empty() << endl;
	list.pop_front();
	list.print_front();
	list.print_back();
	list.print();
	cout << list.empty() << endl;
	list.pop_front();
	list.print_front();
	list.print_back();
	list.print();
	cout << list.empty() << endl;
	list.pop_back();
	list.print_front();
	list.print_back();
	list.print();
	cout << list.empty() << endl;
	cout << "Task 1 tests complete" << endl;
}

void task2_tests() {
	cout << boolalpha;
	cout << "Task 2 tests" << endl;
	myList<int> list;
	list.push_front(100);
	list.push_front(200);
	list.push_back(300);
	list.push_front(400);
	list.push_back(500);
	list.push_back(600);
	list.push_front(700);
	list.push_back(800);
	list.push_back(900);
	list.push_front(1000);
	listIter<int> it = list.begin();
	for (int i = 0; i < 5; i++) {
		cout << *it++ << " ";
	}
	cout << endl;
	for (; it != list.end();) {
		cout << *it++ << " ";
	}
	cout << endl;
	it--;
	for (int i = 0; i < 7; i++) {
		cout << *it-- << " ";
	}
	cout << endl;
	for (; it != list.begin();) {
		cout << *--it << " ";
	}
	cout << endl;
	list.pop_back();
	list.pop_back();
	list.pop_front();
	list.push_back(700);
	for (it = list.begin(); it != list.end(); it++)
		;
	it--;
	cout << (list.begin() == it) << endl;
	cout << (list.begin() != it) << endl;
	cout << (*list.begin() == *it) << endl;
	for (; it != list.begin(); it--)
		;
	cout << (list.begin() == it) << endl;
	cout << (list.begin() != it) << endl;
	cout << (*list.begin() == *it) << endl;
	cout << "Task 2 tests complete" << endl;
}

void task3_tests() {
	cout << "Task 3 tests" << endl;
	myList<int> list;
	cout << list << endl;
	list.push_front(700);
	list.push_front(100);
	list.push_back(900);
	list.push_front(200);
	cout << list << endl;
	list.pop_front();
	cout << list << endl;
	list.pop_back();
	cout << list << endl;
	list.push_back(300);
	list.push_back(500);
	list.push_front(400);
	cout << list << endl;
	list.push_back(600);
	list.push_back(1000);
	list.push_front(800);
	list.pop_front();
	cout << list << endl;
	list.pop_back();
	cout << list << endl;
	list.pop_front();
	list.pop_front();
	list.pop_back();
	list.pop_front();
	list.pop_back();
	cout << list << endl;
	list.pop_front();
	cout << list << endl;
	cout << "Task 3 tests complete" << endl;
}

void task4_tests() {
	cout << boolalpha;
	cout << "Task 4 tests" << endl;
	myList<int> list;
	listIter<int> it = list.begin();
	list.insert(it, 100);
	cout << list << endl;
	list.pop_back();
	it = list.end();
	list.insert(it, 100);
	cout << list << endl;
	list.pop_front();
	it = list.begin();
	list.insert(it, 300);
	list.insert(it, 500);
	list.insert(it, 700);
	cout << list << endl;
	cout << (it == list.end()) << endl;
	it--;
	list.erase(it);
	cout << list << endl;
	it--;
	list.erase(it);
	cout << list << endl;
	it--;
	list.erase(it);
	cout << list << endl;
	it = list.begin();
	list.insert(it, 300);
	it = list.begin();
	list.insert(it, 500);
	it = list.begin();
	list.insert(it, 700);
	cout << list << endl;
	it = list.begin();
	list.erase(it);
	cout << list << endl;
	list.erase(it);
	cout << list << endl;
	list.erase(it);
	cout << list << endl;
	list.pop_back();
	list.push_front(100);
	list.push_front(200);
	list.push_back(300);
	list.push_front(400);
	list.push_back(500);
	list.push_back(600);
	list.push_front(700);
	list.push_back(800);
	list.push_back(900);
	list.push_front(1000);
	cout << list << endl;
	it = list.begin();
	list.insert(it, 5000);
	cout << list << endl;
	list.pop_front();
	cout << list << endl;
	it = list.end();
	list.insert(it, 5000);
	cout << list << endl;
	list.pop_back();
	cout << list << endl;
	for (listIter<int> it = list.begin(); it != list.end(); it++) {
		list.insert(it, 300);
		cout << list << endl;
	}
	for (listIter<int> it = list.end(); --it != list.begin();) {
		list.erase(it);
		cout << list << endl;
	}
	it = list.begin();
	list.erase(it);
	cout << list << endl;
	cout << "Task 4 tests complete" << endl;
}

int main(int argc, char** argv) {
	if (argc == 1) {
		task1_tests();
		cout << endl;
		task2_tests();
		cout << endl;
		task3_tests();
		cout << endl;
		task4_tests();
	}
	else {
		switch(argv[1][0]) {
		case '1':
			task1_tests();
			break;
		case '2':
			task2_tests();
			break;
		case '3':
			task3_tests();
			break;
		case '4':
			task4_tests();
			break;
		case 'h':
			task1_tests(2222);
			break;
		};
	}
	return 0;
}
