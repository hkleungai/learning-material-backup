#include "myList.h"
#include <iostream>

using namespace std;

template<typename T>
myList<T>::myList() {
	this->head = new Node<T>;
	head->next = head;
	head->prev = head;
}

template<typename T>
myList<T>::~myList() {
	clear();
	delete this->head;
}

template<typename T>
void myList<T>::clear() {
	while (!empty()) {
		this->remove(this->head->next);
	}
}

template<typename T>
void myList<T>::insert(Node<T> *prev, Node<T> *ins) {
	prev->next->prev = ins;
	ins->next = prev->next;
	prev->next = ins;
	ins->prev = prev;
	_size++;
}

template<typename T>
void myList<T>::remove(Node<T> *del) {
	del->prev->next = del->next;
	del->next->prev = del->prev;
	delete del;
	del = nullptr;
	_size--;
}

template<typename T>
void myList<T>::print() {
	if (empty()) {
		std::cout << "<empty>" << std::endl;
		return;
	}
	for (Node<T> *p = head->next; p != head; p = p->next) {
		std::cout << p->content << " ";
	}
	std::cout << std::endl;
}

template<typename T>
void myList<T>::print_front() {
	if (empty()) {
		std::cout << "nil" << std::endl;
		return;
	}
	std::cout << head->next->content << std::endl;
}

template<typename T>
void myList<T>::print_back() {
	if (empty()) {
		std::cout << "nil" << std::endl;
		return;
	}
	std::cout << head->prev->content << std::endl;
}

//Task 1: Essential Operations for myList
template<typename T>
void myList<T>::push_back(T content) {
	insert(head->prev, new Node<T> { content });
}

template<typename T>
void myList<T>::push_front(T content) {
	insert(head, new Node<T> { content });
}

template<typename T>
void myList<T>::pop_back() {
	if (!empty())
		remove(head->prev);
}

template<typename T>
void myList<T>::pop_front() {
	if (!empty())
		remove(head->next);
}

//Task 2: Iterators for myList
template<typename T>
listIter<T> myList<T>::begin() {
	return listIter<T>(head->next);
}

template<typename T>
listIter<T> myList<T>::end() {
	return listIter<T>(head);
}

//Task 3: print myList to cout
template<typename T>
ostream& operator<<(ostream &os, myList<T> &list) {
	if (list.empty()) {
		os << "<empty>";
		return os;
	}
	for (listIter<int> it = list.begin(); it != list.end(); it++) {
		os << *it << " ";
	}
	return os;
}

//Task 4: Insertions and Deletions using Iterator
template<typename T>
void myList<T>::insert(listIter<T> &p, T content) {
	insert(p.ptr->prev, new Node<T> { content });
}

template<typename T>
void myList<T>::erase(listIter<T> &p) {
	p.ptr = p.ptr->next;
	remove(p.ptr->prev);
}
