#include "Document.h"

struct Stack
{
    Document **stack_array = nullptr;
    unsigned int stack_size = 0;
    unsigned int stack_capacity = 0;
};

// Task 3 - Simulating a document stack using a simple wrapper around a
// dynamically resizeable array
void reallocate_stack_array(Stack &, unsigned int);
void stack_push(Stack &, Document *);
void stack_pop(Stack &);
const Document *stack_peek(const Stack &);
bool stack_is_empty(const Stack &);
void destroy_stack(Stack &);
