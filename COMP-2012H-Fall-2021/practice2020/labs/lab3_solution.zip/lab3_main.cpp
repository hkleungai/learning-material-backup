#include <iostream>
#include <chrono>
#include "Stack.h"

using namespace std::chrono;

void print_document(const Document *document)
{
    if (document == nullptr)
    {
        cout << "nullptr" << endl;
        return;
    }
    cout << "Name: " << document->name << endl;
    cout << "Description: " << document->description << endl;
    cout << "No. of pages: " << document->num_pages << endl;
}

void task1_tests()
{
    cout << "Task 1 tests" << endl;
    Document document1;
    initialize_document_by_reference(document1, "ABCD", "EFGH", 100);
    print_document(&document1);
    Document document2;
    initialize_document_by_pointer(&document2, "IJKL", "MNOP", 200);
    print_document(&document2);
    initialize_document_by_pointer(nullptr, "QRST", "UVWX", 300);
    swap_documents_by_reference(document1, document2);
    print_document(&document1);
    print_document(&document2);
    swap_documents_by_pointer(&document1, &document2);
    swap_documents_by_pointer(&document1, nullptr);
    swap_documents_by_pointer(nullptr, &document2);
    swap_documents_by_pointer(nullptr, nullptr);
    print_document(&document1);
    print_document(&document2);
    cout << "Task 1 tests complete" << endl;
}

void task2_tests()
{
    cout << "Task 2 tests" << endl;
    Document *document = create_document("Dynamic document", "Document created using dynamic allocation", 123);
    print_document(document);
    destroy_document(document);
    destroy_document(nullptr);
    document = create_document("Dynamic document II", "Document created using dynamic allocation, again", 456);
    destroy_document(nullptr);
    print_document(document);
    destroy_document(document);
    cout << "Task 2 tests complete" << endl;
}

void task3_tests()
{
    cout << "Task 3 tests" << endl;
    Stack stack;
    cout << boolalpha;
    cout << stack_is_empty(stack) << endl;
    print_document(stack_peek(stack));
    stack_pop(stack);
    cout << stack_is_empty(stack) << endl;
    print_document(stack_peek(stack));
    stack_push(stack, create_document("Doc #1", "Doc Desc #1", 10));
    cout << stack_is_empty(stack) << endl;
    print_document(stack_peek(stack));
    stack_push(stack, create_document("Doc #2", "Doc Desc #2", 20));
    cout << stack_is_empty(stack) << endl;
    print_document(stack_peek(stack));
    stack_push(stack, create_document("Doc #3", "Doc Desc #3", 35));
    cout << stack_is_empty(stack) << endl;
    print_document(stack_peek(stack));
    stack_pop(stack);
    cout << stack_is_empty(stack) << endl;
    print_document(stack_peek(stack));
    stack_push(stack, create_document("Doc #4", "Doc Desc #4", 42));
    cout << stack_is_empty(stack) << endl;
    print_document(stack_peek(stack));
    stack_push(stack, create_document("Doc #5", "Doc Desc #5", 45));
    cout << stack_is_empty(stack) << endl;
    print_document(stack_peek(stack));
    stack_push(stack, create_document("Doc #6", "Doc Desc #6", 37));
    cout << stack_is_empty(stack) << endl;
    print_document(stack_peek(stack));
    stack_push(stack, create_document("Doc #7", "Doc Desc #7", 138));
    cout << stack_is_empty(stack) << endl;
    print_document(stack_peek(stack));
    stack_pop(stack);
    cout << stack_is_empty(stack) << endl;
    print_document(stack_peek(stack));
    stack_pop(stack);
    cout << stack_is_empty(stack) << endl;
    print_document(stack_peek(stack));
    stack_pop(stack);
    cout << stack_is_empty(stack) << endl;
    print_document(stack_peek(stack));
    stack_pop(stack);
    cout << stack_is_empty(stack) << endl;
    print_document(stack_peek(stack));
    stack_pop(stack);
    cout << stack_is_empty(stack) << endl;
    print_document(stack_peek(stack));
    stack_pop(stack);
    cout << stack_is_empty(stack) << endl;
    print_document(stack_peek(stack));
    stack_pop(stack);
    cout << stack_is_empty(stack) << endl;
    print_document(stack_peek(stack));
    stack_push(stack, create_document("Doc #8", "Doc Desc #8", 242));
    cout << stack_is_empty(stack) << endl;
    print_document(stack_peek(stack));
    stack_push(stack, create_document("Doc #9", "Doc Desc #9", 1004));
    cout << stack_is_empty(stack) << endl;
    print_document(stack_peek(stack));
    stack_push(stack, create_document("Doc #10", "Doc Desc #10", 102));
    cout << stack_is_empty(stack) << endl;
    print_document(stack_peek(stack));
    stack_push(stack, create_document("Doc #11", "Doc Desc #11", 112));
    cout << stack_is_empty(stack) << endl;
    print_document(stack_peek(stack));
    stack_push(stack, create_document("Doc #12", "Doc Desc #12", 46));
    cout << stack_is_empty(stack) << endl;
    print_document(stack_peek(stack));
    stack_push(stack, create_document("Doc #13", "Doc Desc #13", 25));
    cout << stack_is_empty(stack) << endl;
    print_document(stack_peek(stack));
    stack_push(stack, create_document("Doc #14", "Doc Desc #14", 20));
    cout << stack_is_empty(stack) << endl;
    print_document(stack_peek(stack));
    stack_push(stack, create_document("Doc #15", "Doc Desc #15", 3));
    cout << stack_is_empty(stack) << endl;
    print_document(stack_peek(stack));
    stack_push(stack, create_document("Doc #16", "Doc Desc #16", 7));
    cout << stack_is_empty(stack) << endl;
    print_document(stack_peek(stack));
    stack_push(stack, create_document("Doc #17", "Doc Desc #17", 17));
    cout << stack_is_empty(stack) << endl;
    print_document(stack_peek(stack));
    stack_push(stack, create_document("Doc #18", "Doc Desc #18", 18));
    cout << stack_is_empty(stack) << endl;
    print_document(stack_peek(stack));
    stack_push(stack, create_document("Doc #19", "Doc Desc #19", 5));
    cout << stack_is_empty(stack) << endl;
    print_document(stack_peek(stack));
    stack_push(stack, create_document("Doc #20", "Doc Desc #20", 52));
    cout << stack_is_empty(stack) << endl;
    print_document(stack_peek(stack));
    stack_push(stack, create_document("Doc #21", "Doc Desc #21", 65));
    cout << stack_is_empty(stack) << endl;
    print_document(stack_peek(stack));
    stack_push(stack, create_document("Doc #22", "Doc Desc #22", 77));
    cout << stack_is_empty(stack) << endl;
    print_document(stack_peek(stack));
    stack_push(stack, create_document("Doc #23", "Doc Desc #23", 1));
    cout << stack_is_empty(stack) << endl;
    print_document(stack_peek(stack));
    while (!stack_is_empty(stack))
    {
        print_document(stack_peek(stack));
        stack_pop(stack);
    }
    cout << stack_is_empty(stack) << endl;
    for (int i = 0; i < 100; ++i)
        stack_push(stack, create_document("Yet another document", "Yet another document description", 42));
    destroy_stack(stack);
    cout << noboolalpha;
    cout << "Task 3 tests complete" << endl;
}

void bonus_tests()
{
    cout << "Bonus tests" << endl;
    high_resolution_clock::time_point start = high_resolution_clock::now();
    Stack stack;
    for (int i = 0; i < 2e7; ++i)
    {
        stack_push(stack, nullptr);
        stack_peek(stack);
    }
    for (int i = 0; i < 2e7; ++i)
    {
        stack_pop(stack);
        stack_is_empty(stack);
    }
    high_resolution_clock::time_point end = high_resolution_clock::now();
    cout << "Execution time: " << duration_cast<milliseconds>(end - start).count() << "ms" << endl;
    cout << "Bonus tests complete" << endl;
}

int main(int argc, char **argv)
{
    if (argc > 1)
    {
        bonus_tests();
    }
    else
    {
        task1_tests();
        task2_tests();
        task3_tests();
    }
    return 0;
}
