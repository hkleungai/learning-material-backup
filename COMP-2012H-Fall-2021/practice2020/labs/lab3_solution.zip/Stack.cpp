#include "Stack.h"

void reallocate_stack_array(Stack &stack, unsigned int stack_capacity)
{
    if (stack_capacity == 0)
    {
        for (unsigned int i = 0; i < stack.stack_size; ++i)
            delete stack.stack_array[i];
        delete[] stack.stack_array;
        stack.stack_array = nullptr;
        stack.stack_size = 0;
        stack.stack_capacity = 0;
        return;
    }
    Document **new_stack_array = new Document *[stack_capacity];
    unsigned int new_stack_size = stack.stack_size < stack_capacity ? stack.stack_size : stack_capacity;
    unsigned int new_stack_capacity = stack_capacity;
    for (unsigned int i = 0; i < new_stack_size; ++i)
        new_stack_array[i] = stack.stack_array[i];
    for (unsigned int i = new_stack_size; i < stack.stack_size; ++i)
        delete stack.stack_array[i];
    delete[] stack.stack_array;
    stack.stack_array = new_stack_array;
    stack.stack_size = new_stack_size;
    stack.stack_capacity = new_stack_capacity;
}

void stack_push(Stack &stack, Document *document)
{
    if (stack.stack_array == nullptr)
    {
        reallocate_stack_array(stack, 1);
        stack.stack_array[0] = document;
        stack.stack_size = 1;
        return;
    }
    if (stack.stack_size == stack.stack_capacity)
        reallocate_stack_array(stack, 2 * stack.stack_capacity);
    stack.stack_array[stack.stack_size] = document;
    ++stack.stack_size;
}

void stack_pop(Stack &stack)
{
    if (stack.stack_size == 0)
        return;
    --stack.stack_size;
    delete stack.stack_array[stack.stack_size];
    if (4 * stack.stack_size <= stack.stack_capacity)
        reallocate_stack_array(stack, stack.stack_capacity / 2);
}

const Document *stack_peek(const Stack &stack)
{
    if (stack.stack_size == 0)
        return nullptr;
    return stack.stack_array[stack.stack_size - 1];
}

bool stack_is_empty(const Stack &stack)
{
    return stack.stack_size == 0;
}

void destroy_stack(Stack &stack)
{
    reallocate_stack_array(stack, 0);
}
