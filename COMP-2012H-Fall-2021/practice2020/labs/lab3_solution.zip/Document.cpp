#include "Document.h"

// Task 1 - Passing arguments by reference and as pointers
void initialize_document_by_reference(Document &document, string name, string description, int num_pages)
{
    document.name = name;
    document.description = description;
    document.num_pages = num_pages;
}

void initialize_document_by_pointer(Document *document, string name, string description, int num_pages)
{
    if (document == nullptr)
        return;
    document->name = name;
    document->description = description;
    document->num_pages = num_pages;
}

void swap_documents_by_reference(Document &document1, Document &document2)
{
    Document temp = document1;
    document1 = document2;
    document2 = temp;
}

void swap_documents_by_pointer(Document *document1, Document *document2)
{
    if (document1 == nullptr || document2 == nullptr)
        return;
    Document temp = *document1;
    *document1 = *document2;
    *document2 = temp;
}

// Task 2 - Dynamically create Document objects using operator new
Document *create_document(string name, string description, int num_pages)
{
    Document *document = new Document;
    document->name = name;
    document->description = description;
    document->num_pages = num_pages;
    return document;
}

void destroy_document(Document *document)
{
    delete document;
}
