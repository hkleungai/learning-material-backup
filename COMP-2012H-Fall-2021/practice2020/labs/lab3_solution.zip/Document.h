#include <string>
using namespace std;

struct Document
{
    string name;
    string description;
    int num_pages;
};

// Task 1 - Passing arguments by reference and as pointers
void initialize_document_by_reference(Document &, string, string, int);
void initialize_document_by_pointer(Document *, string, string, int);
void swap_documents_by_reference(Document &, Document &);
void swap_documents_by_pointer(Document *, Document *);

// Task 2 - Dynamically create Document objects using operator new
Document *create_document(string, string, int);
void destroy_document(Document *);
