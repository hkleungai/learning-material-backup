#include "Deque.h"

Deque create_deque() { return Deque{nullptr, nullptr}; }

void destroy_deque(Deque& deque) {
	for (Node* current = deque.front; current != deque.back;) {
		current = current->next;
		destroy_node(current->prev);
	}
	destroy_node(deque.back);
	deque.front = deque.back = nullptr;
}

void push_front(Deque& deque, int data) {
	if (deque.front == nullptr) {
		deque.front = deque.back = create_node(data);
		return;
	}

	Node* new_node = create_node(data, nullptr, deque.front);
	deque.front->prev = new_node;
	deque.front = new_node;
}

void push_back(Deque& deque, int data) {
	if (deque.front == nullptr) {
		deque.front = deque.back = create_node(data);
		return;
	}

	Node* new_node = create_node(data, deque.back, nullptr);
	deque.back->next = new_node;
	deque.back = new_node;
}

void pop_front(Deque& deque) {
	if (deque.front == nullptr) { return; }

	if (deque.front == deque.back) {
		destroy_node(deque.front);
		deque.front = deque.back = nullptr;
		return;
	}

	Node* new_front = deque.front->next;
	new_front->prev = nullptr;
	destroy_node(deque.front);
	deque.front = new_front;
}

void pop_back(Deque& deque) {
	if (deque.front == nullptr) { return; }

	if (deque.front == deque.back) {
		destroy_node(deque.front);
		deque.front = deque.back = nullptr;
		return;
	}

	Node* new_back = deque.back->prev;
	new_back->next = nullptr;
	destroy_node(deque.back);
	deque.back = new_back;
}

const Node* peek_front(const Deque& deque) { return deque.front; }
const Node* peek_back(const Deque& deque) { return deque.back; }

bool is_empty(const Deque& deque) { return (deque.front == nullptr); }

const Node* peek(const Deque& deque, int index) {
	if (index < 0) { return nullptr; }
	const Node* target = deque.front;
	for (int i = 0; i < index && target != nullptr; i += 1, target = target->next) {}
	return target;
}

void insert(Deque& deque, int index, int data) {
	if (index < 0) { return; }
	if (index == 0) {
		push_front(deque, data);
		return;
	}

	int i = 0;
	Node* target = deque.front;
	for (; i < index && target != nullptr; i += 1, target = target->next) {}

	if (i < index) { return; }
	if (target == nullptr) {
		push_back(deque, data);
		return;
	}

	Node* new_node = create_node(data, target->prev, target);
	target->prev->next = new_node;
	target->prev = new_node;
}

void remove(Deque& deque, int index) {
	if (index < 0) { return; }
	if (index == 0) {
		pop_front(deque);
		return;
	}

	int i = 0;
	Node* target = deque.front;
	for (; i < index && target != nullptr; i += 1, target = target->next) {}

	if (target == nullptr) { return; }
	if (target == deque.back) {
		pop_back(deque);
		return;
	}

	target->prev->next = target->next;
	target->next->prev = target->prev;
	destroy_node(target);
}
