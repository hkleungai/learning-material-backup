#include "Node.h"
Node* create_node(int data) { return new Node{data, nullptr, nullptr}; }
Node* create_node(int data, Node* prev, Node* next) { return new Node{data, prev, next}; }
void destroy_node(Node* node) { delete node; }
