#ifndef LINKED_LIST_H
#define LINKED_LIST_H

#include <string>
using std::string;

class Node {
public:
	Node();
	Node(string content);

	string content;
	Node* next{nullptr};
	Node* prev{nullptr};
};

class LinkedList {
public:
	LinkedList();
	~LinkedList();

	unsigned int get_size() const;
	Node* get_head() const;
	Node* get_tail() const;
	Node* get_sentinel() const;

	void insert(Node* prev_node, Node* ins_node);
	void remove(Node* del_node);
	void push_back(const string& content);

private:
	Node* sentinel;
	int size{0};
};

#endif // LINKED_LIST_H
