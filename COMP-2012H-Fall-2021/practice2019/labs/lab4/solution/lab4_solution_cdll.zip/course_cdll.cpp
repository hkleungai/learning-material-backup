#include <iostream>

#include "course_cdll.h"
using std::cout;
using std::endl;

Course::Course(const string& course_name, unsigned int quota) : course_name{course_name}, quota{quota} {}

Course::~Course() {
	cout << course_name << " : "
			<< "Enrolled " << get_num_enrolled()
			<< ", Waitlisted " << get_num_waitlisted()
			<< endl;
}

string Course::enroll(const string& student_name) {
	for (Node* current{student_list.get_head()}; current != student_list.get_sentinel(); current = current->next) {
		if (current->content == student_name) {
			return "Existed";
		}
	}
	student_list.push_back(student_name);
	return "Successful";
}

string Course::drop(const string& student_name) {
	for (Node* current{student_list.get_head()}; current != student_list.get_sentinel(); current = current->next) {
		if (current->content == student_name) {
			student_list.remove(current);
			return "Successful";
		}
	}
	return "Not existed";
}

string Course::query_status(const string& student_name) {
	unsigned int position{0};
	for (Node* current{student_list.get_head()}; current != student_list.get_sentinel(); current = current->next, ++position) {
		if (current->content == student_name) {
			if (position < quota) {
				return "Enrolled";
			}
			else {
				return "Waitlisted";
			}
		}
	}
	return "Not existed";
}

int Course::get_num_enrolled() const {
	return (student_list.get_size() <= quota) ? student_list.get_size() : quota;
}

int Course::get_num_waitlisted() const {
	return (student_list.get_size() > quota) ? (student_list.get_size() - quota) : 0;
}
