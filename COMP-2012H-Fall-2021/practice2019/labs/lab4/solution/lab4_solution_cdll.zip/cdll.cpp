#include "cdll.h"

Node::Node() {}

Node::Node(string content) : content{content} {}

LinkedList::LinkedList() : sentinel{new Node{}} {
	sentinel->next = sentinel->prev = sentinel; // Sentinel with garbage content and circularly pointing to itself.
}

LinkedList::~LinkedList() {
	for (Node* current_node{sentinel->next}; current_node != sentinel; current_node = current_node->next, delete current_node->prev) {}
	delete sentinel;
}

unsigned int LinkedList::get_size() const { return size; }

Node* LinkedList::get_head() const { return sentinel->next; }

Node* LinkedList::get_tail() const { return sentinel->prev; }

Node* LinkedList::get_sentinel() const { return sentinel; }

void LinkedList::insert(Node* prev_node, Node* ins_node) {
	if (prev_node == nullptr || ins_node == nullptr) { return; }

	ins_node->next = prev_node->next;
	ins_node->next->prev = ins_node;
	ins_node->prev = prev_node;
	prev_node->next = ins_node;
	size += 1;
}

void LinkedList::remove(Node* del_node) {
	if (del_node == nullptr || del_node == sentinel) { return; }

	del_node->prev->next = del_node->next;
	del_node->next->prev = del_node->prev;
	delete del_node;
	size -= 1;
}

void LinkedList::push_back(const string& content) {
	insert(get_tail(), new Node{content});
}
