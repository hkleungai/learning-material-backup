/* File: temperature1.h */
class temperature
{   ...
    inline double
    kelvin() const
    {
        return degree;
    }
};