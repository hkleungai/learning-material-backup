void temperature::kelvin(const temperature* this) const
{
    return this->degree;
}