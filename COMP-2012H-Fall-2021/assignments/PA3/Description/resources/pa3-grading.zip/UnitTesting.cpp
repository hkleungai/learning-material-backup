#include <iostream>
#include <vector>
#include <algorithm>
#include <unordered_set>
#include <sstream>
#include <set>
#include "City.h"

#define TEST_NAME(test_suite_name, test_name) test_suite_name##_##test_name
#define TEST(test_suite_name, test_name) \
void TEST_NAME(test_suite_name, test_name)()

#define EXPECT_TRUE(cond) \
do {                      \
    if (!(cond)) {        \
        cerr << "Expected true on line " << __LINE__ << endl; \
        exit (1);         \
    }                     \
} while (false)

#define EXPECT_FALSE(cond) \
do {                      \
    if ((cond)) {        \
        cerr << "Expected false on line " << __LINE__ << endl; \
        exit (1);         \
    }                     \
} while (false)

#define EXPECT_EQ(a, b) \
do {                    \
    if ((a) != (b)) {   \
        cerr << "Equality check failed on line " << __LINE__ << endl; \
        exit(1); }      \
    } while (false)

#define EXPECT_NE(a, b) \
do {                    \
    if ((a) == (b)) {   \
        cerr << "Inequality check failed on line " << __LINE__ << endl; \
        exit(1); }      \
    } while (false)

using namespace std;

namespace UnitTesting {
    string city_tostring(const City &city) {
        string result = string();

        for (int y = 0; y < city.get_grid_size(); ++y) {
            for (int x = 0; x < city.get_grid_size(); ++x) {
                Building *building = city.get_at(x, y);
                if (building) {
                    if (dynamic_cast<Clinic*>(building)) {
                        result += 'C';
                    } else if (dynamic_cast<Hospital*>(building)) {
                        result += 'H';
                    } else if (dynamic_cast<SilverMine*>(building)) {
                        result += 'S';
                    } else if (dynamic_cast<GoldMine*>(building)) {
                        result += 'G';
                    } else if (dynamic_cast<House*>(building)) {
                        result += 'E';
                    } else if (dynamic_cast<Apartment*>(building)) {
                        result += 'A';
                    }
                }
                else {
                    result += 'X';
                }
            }
            result += '\n';
        }
        return result;
    }
}

// Test 1
TEST(City, Constructor) {
    City *city = new City {10};

    EXPECT_EQ(city->get_turn(), 1);
    EXPECT_EQ(city->get_budget(), 150);
    EXPECT_EQ(city->get_grid_size(), 10);
}

// Test 2
TEST(City, GetAtEmpty) {
    City *city = new City {10};

    for (int x = 0; x < 10; ++x) {
        for (int y = 0; y < 10; ++y) {
            EXPECT_EQ(city->get_at(x, y), nullptr);
        }
    }
}

// Test 3
TEST(City, IsEmptyAt) {
    City *city = new City {10};

    for (int x = 0; x < 10; ++x) {
        for (int y = 0; y < 10; ++y) {
            EXPECT_TRUE(city->is_empty_at(x, y));
        }
    }
}

// Test 4
TEST(City, CanConstructSuccess) {
    City *city = new City {10};

    EXPECT_TRUE(city->can_construct(Building::Type::CLINIC));
    EXPECT_TRUE(city->can_construct(Building::Type::SILVER_MINE));
    EXPECT_TRUE(city->can_construct(Building::Type::HOUSE));
}

// Test 5
TEST(City, CanConstructFailBudget) {
    City *city = new City {10};

    EXPECT_FALSE(city->can_construct(Building::Type::HOSPITAL));
    EXPECT_FALSE(city->can_construct(Building::Type::GOLD_MINE));
    EXPECT_FALSE(city->can_construct(Building::Type::APARTMENT));
}

// Test 6
TEST(City, CanConstructCoordinateSuccess) {
    City *city = new City {10};

    for (int x = 0; x < 10; ++x) {
        for (int y = 0; y < 10; ++y) {
            EXPECT_TRUE(city->can_construct(Building::Type::CLINIC, x, y));
        }
    }
}

// Test 7
TEST(City, CanConstructCoordinateFailBudget) {
    City *city = new City {10};

    for (int x = 0; x < 10; ++x) {
        for (int y = 0; y < 10; ++y) {
            EXPECT_FALSE(city->can_construct(Building::Type::HOSPITAL, x, y));
        }
    }
}

// Test 8
TEST(City, ConstructAtSuccess) {
    City *city = new City {10};

    EXPECT_TRUE(city->construct_at(Building::Type::CLINIC, 0, 0));

    EXPECT_NE(city->get_at(0, 0), nullptr);

    EXPECT_EQ(city->get_budget(), 100);
}

// Test 9
TEST(City, ConstructAtFail) {
    City *city = new City {10};

    EXPECT_TRUE(city->construct_at(Building::Type::CLINIC, 0, 0));
    EXPECT_FALSE(city->construct_at(Building::Type::CLINIC, 0, 0));

    EXPECT_NE(city->get_at(0, 0), nullptr);

    EXPECT_EQ(city->get_budget(), 100);
}

// Test 10
TEST(City, DemolishAtSuccess) {
    City *city = new City {10};

    EXPECT_TRUE(city->construct_at(Building::Type::CLINIC, 0, 0));

    EXPECT_TRUE(city->demolish_at(0, 0));

    EXPECT_EQ(city->get_at(0, 0), nullptr);

    EXPECT_EQ(city->get_budget(), 100);
}

// Test 11
TEST(City, DemolishAtFail) {
    City *city = new City {10};

    EXPECT_TRUE(city->construct_at(Building::Type::CLINIC, 0, 0));

    EXPECT_TRUE(city->demolish_at(0, 0));
    EXPECT_FALSE(city->demolish_at(0, 0));

    EXPECT_EQ(city->get_at(0, 0), nullptr);

    EXPECT_EQ(city->get_budget(), 100);
}

// Test 12
TEST(City, Load1) {
    City *city = new City {"test-empty.txt"};

    EXPECT_EQ(city->get_grid_size(), 12);
    EXPECT_EQ(city->get_budget(), 10000);
    EXPECT_EQ(city->get_turn(), 5);

    string str = "XXXXXXXXXXXX\n"
                 "XXXXXXXXXXXX\n"
                 "XXXXXXXXXXXX\n"
                 "XXXXXXXXXXXX\n"
                 "XXXXXXXXXXXX\n"
                 "XXXXXXXXXXXX\n"
                 "XXXXXXXXXXXX\n"
                 "XXXXXXXXXXXX\n"
                 "XXXXXXXXXXXX\n"
                 "XXXXXXXXXXXX\n"
                 "XXXXXXXXXXXX\n"
                 "XXXXXXXXXXXX\n";

    EXPECT_EQ(UnitTesting::city_tostring(*city), str);
}

// Test 13
TEST(City, Load2) {
    City *city = new City {"test-small.txt"};

    EXPECT_EQ(city->get_grid_size(), 10);
    EXPECT_EQ(city->get_budget(), 12);
    EXPECT_EQ(city->get_turn(), 3);

    string str = "ESXXXXXXXX\n"
                 "CXXXXXXXXX\n"
                 "XXXXXXXXXX\n"
                 "XXXXXXXXXX\n"
                 "XXXXXXXXXX\n"
                 "XXXXXXXXXX\n"
                 "XXXXXXXXXX\n"
                 "XXXXXXXXXX\n"
                 "XXXXXXXXXX\n"
                 "XXXXXXXXXX\n";

    EXPECT_EQ(UnitTesting::city_tostring(*city), str);
}

// Test 14
TEST(City, Load3) {
    City *city = new City {"test-large.txt"};

    EXPECT_EQ(city->get_grid_size(), 10);
    EXPECT_EQ(city->get_budget(), 9952);
    EXPECT_EQ(city->get_turn(), 31);

    string str = "ESXXXXXXXX\n"
                 "CXXXXXXXXX\n"
                 "XXXXXXXXXX\n"
                 "XXXXXXXXXX\n"
                 "XXXXXXXXXX\n"
                 "XXXXXXXXXX\n"
                 "XXXXXXXXXX\n"
                 "XXXXXXXXGH\n"
                 "XXXXXXXHAA\n"
                 "XXXXXXSAHS\n";

    EXPECT_EQ(UnitTesting::city_tostring(*city), str);
}

// Test 15
TEST(City, Save1) {
    City *city = new City {10};

    city->save("test-save.txt");

    City *city2 = new City {"test-save.txt"};

    EXPECT_EQ(city2->get_grid_size(), 10);
    EXPECT_EQ(city2->get_budget(), 150);
    EXPECT_EQ(city2->get_turn(), 1);

    EXPECT_EQ(city2->get_population(), 0);

    EXPECT_EQ(UnitTesting::city_tostring(*city), UnitTesting::city_tostring(*city2));
}

// Test 16
TEST(City, Save2) {
    City *city = new City {"test-small.txt"};

    city->save("test-save.txt");

    City *city2 = new City {"test-save.txt"};

    EXPECT_EQ(city2->get_grid_size(), 10);
    EXPECT_EQ(city2->get_budget(), 12);
    EXPECT_EQ(city2->get_turn(), 3);

    EXPECT_EQ(city2->get_population(), 11);

    EXPECT_EQ(UnitTesting::city_tostring(*city), UnitTesting::city_tostring(*city2));
}

// Test 17
TEST(City, Save3) {
    City *city = new City {"test-large.txt"};

    city->save("test-save.txt");

    City *city2 = new City {"test-save.txt"};

    EXPECT_EQ(city2->get_grid_size(), 10);
    EXPECT_EQ(city2->get_budget(), 9952);
    EXPECT_EQ(city2->get_turn(), 31);

    EXPECT_EQ(city2->get_population(), 829);

    EXPECT_EQ(UnitTesting::city_tostring(*city), UnitTesting::city_tostring(*city2));
}

// Test 18
TEST(City, GetRevenue1) {
    City *city = new City {10};

    EXPECT_EQ(city->get_revenue(), 0);
}

// Test 19
TEST(City, GetRevenue2) {
    City *city = new City {"test-small.txt"};

    EXPECT_EQ(city->get_revenue(), 22);
}

// Test 20
TEST(City, GetRevenue3) {
    City *city = new City {"test-large.txt"};

    EXPECT_EQ(city->get_revenue(), 5455);
}

// Test 21
TEST(City, GetPopulation1) {
    City *city = new City {10};

    EXPECT_EQ(city->get_population(), 0);
}

// Test 22
TEST(City, GetPopulation2) {
    City *city = new City {"test-small.txt"};

    EXPECT_EQ(city->get_population(), 11);
}

// Test 23
TEST(City, GetPopulation3) {
    City *city = new City {"test-large.txt"};

    EXPECT_EQ(city->get_population(), 829);
}

// Test 24
TEST(City, GetMaxPopulation1) {
    City *city = new City {10};

    EXPECT_EQ(city->get_max_population(), 0);
}

// Test 25
TEST(City, GetMaxPopulation2) {
    City *city = new City {"test-small.txt"};

    EXPECT_EQ(city->get_max_population(), 50);
}

// Test 26
TEST(City, GetMaxPopulation3) {
    City *city = new City {"test-large.txt"};

    EXPECT_EQ(city->get_max_population(), 1300);
}

// Test 27
TEST(City, GetPopulationGrowth1) {
    City *city = new City {10};

    EXPECT_EQ(city->get_population_growth(), 0);
}

// Test 28
TEST(City, GetPopulationGrowth2) {
    City *city = new City {"test-small.txt"};

    EXPECT_EQ(city->get_population_growth(), 4);
}

// Test 29
TEST(City, GetPopulationGrowth3) {
    City *city = new City {"test-large.txt"};

    EXPECT_EQ(city->get_population_growth(), 112);
}

// Test 30
TEST(City, GetPopulationGrowthRate1) {
    City *city = new City {10};

    EXPECT_EQ(city->get_population_growth_rate(), 0);
}

// Test 31
TEST(City, GetPopulationGrowthRate2) {
    City *city = new City {"test-small.txt"};

    EXPECT_EQ(city->get_population_growth_rate(), 49);
}

// Test 32
TEST(City, GetPopulationGrowthRate3) {
    City *city = new City {"test-large.txt"};

    EXPECT_EQ(city->get_population_growth_rate(), 311);
}

// Test 33
TEST(City, NextTurn1) {
    City *city = new City {10};

    city->move_to_next_turn();

    EXPECT_EQ(city->get_grid_size(), 10);
    EXPECT_EQ(city->get_budget(), 150);
    EXPECT_EQ(city->get_turn(), 2);

    EXPECT_EQ(city->get_population(), 0);
}

// Test 34
TEST(City, NextTurn2) {
    City *city = new City {"test-small.txt"};

    city->move_to_next_turn();

    EXPECT_EQ(city->get_grid_size(), 10);
    EXPECT_EQ(city->get_budget(), 34);
    EXPECT_EQ(city->get_turn(), 4);

    EXPECT_EQ(city->get_population(), 15);
}

// Test 35
TEST(City, NextTurn3) {
    City *city = new City {"test-large.txt"};

    city->move_to_next_turn();

    EXPECT_EQ(city->get_grid_size(), 10);
    EXPECT_EQ(city->get_budget(), 15407);
    EXPECT_EQ(city->get_turn(), 32);

    EXPECT_EQ(city->get_population(), 941);
}

// Test 36
TEST(Building, Clinic) {
    City *city = new City {10};
    Building *building = new Clinic{*city};

    EXPECT_EQ(building->get_type(), Building::Type::CLINIC);
    EXPECT_EQ(building->get_category(), Building::Category::HEALTH);
    EXPECT_EQ(building->get_cost(), 50);
}

// Test 37
TEST(Building, Hospital) {
    City *city = new City {10};
    Building *building = new Hospital{*city};

    EXPECT_EQ(building->get_type(), Building::Type::HOSPITAL);
    EXPECT_EQ(building->get_category(), Building::Category::HEALTH);
    EXPECT_EQ(building->get_cost(), 500);
}

// Test 38
TEST(Building, SilverMine) {
    City *city = new City {10};
    Building *building = new SilverMine{*city};

    EXPECT_EQ(building->get_type(), Building::Type::SILVER_MINE);
    EXPECT_EQ(building->get_category(), Building::Category::REVENUE);
    EXPECT_EQ(building->get_cost(), 50);
}

// Test 39
TEST(Building, GoldMine) {
    City *city = new City {10};
    Building *building = new GoldMine{*city};

    EXPECT_EQ(building->get_type(), Building::Type::GOLD_MINE);
    EXPECT_EQ(building->get_category(), Building::Category::REVENUE);
    EXPECT_EQ(building->get_cost(), 400);
}

// Test 40
TEST(Building, House) {
    City *city = new City {10};
    Building *building = new House{*city, 0};

    EXPECT_EQ(building->get_type(), Building::Type::HOUSE);
    EXPECT_EQ(building->get_category(), Building::Category::RESIDENTIAL);
    EXPECT_EQ(building->get_cost(), 50);
}

// Test 41
TEST(Building, Apartment) {
    City *city = new City {10};
    Building *building = new Apartment{*city, 0};

    EXPECT_EQ(building->get_type(), Building::Type::APARTMENT);
    EXPECT_EQ(building->get_category(), Building::Category::RESIDENTIAL);
    EXPECT_EQ(building->get_cost(), 300);
}

typedef void (*Testcase)();

std::vector<Testcase> testcases = {
    TEST_NAME(City, Constructor), // 1
    TEST_NAME(City, GetAtEmpty),
    TEST_NAME(City, IsEmptyAt),
    TEST_NAME(City, CanConstructSuccess),
    TEST_NAME(City, CanConstructFailBudget), // 5
    TEST_NAME(City, CanConstructCoordinateSuccess),
    TEST_NAME(City, CanConstructCoordinateFailBudget),
    TEST_NAME(City, ConstructAtSuccess),
    TEST_NAME(City, ConstructAtFail),
    TEST_NAME(City, DemolishAtSuccess), // 10
    TEST_NAME(City, DemolishAtFail),
    TEST_NAME(City, Load1),
    TEST_NAME(City, Load2),
    TEST_NAME(City, Load3),
    TEST_NAME(City, Save1), // 15
    TEST_NAME(City, Save2),
    TEST_NAME(City, Save3),
    TEST_NAME(City, GetRevenue1),
    TEST_NAME(City, GetRevenue2),
    TEST_NAME(City, GetRevenue3), // 20
    TEST_NAME(City, GetPopulation1),
    TEST_NAME(City, GetPopulation2),
    TEST_NAME(City, GetPopulation3),
    TEST_NAME(City, GetMaxPopulation1),
    TEST_NAME(City, GetMaxPopulation2), // 25
    TEST_NAME(City, GetMaxPopulation3),
    TEST_NAME(City, GetPopulationGrowth1),
    TEST_NAME(City, GetPopulationGrowth2),
    TEST_NAME(City, GetPopulationGrowth3),
    TEST_NAME(City, GetPopulationGrowthRate1), // 30
    TEST_NAME(City, GetPopulationGrowthRate2),
    TEST_NAME(City, GetPopulationGrowthRate3),
    TEST_NAME(City, NextTurn1),
    TEST_NAME(City, NextTurn2),
    TEST_NAME(City, NextTurn3), // 35

    TEST_NAME(Building, Clinic),
    TEST_NAME(Building, Hospital),
    TEST_NAME(Building, SilverMine),
    TEST_NAME(Building, GoldMine),
    TEST_NAME(Building, House), // 40
    TEST_NAME(Building, Apartment),
};

int main(int argc, char **argv)
{
    if (argc == 2) {
        int testcase = atoi(argv[1]) - 1;

        if (testcase >= 0 && testcase < testcases.size()) {
            testcases[testcase]();
            cout << "Test " << argv[1] << " PASSED" << endl;
        }

        else if (testcase == -1) {
            for (auto t: testcases)
                t();
            cout << "All tests PASSED" << endl;
        }
    }

    if (argc == 1) {
        for (auto t: testcases)
            t();
        cout << "All tests PASSED" << endl;
    }
}