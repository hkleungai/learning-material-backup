#include "student_linked_list.h"

void print_student_list(const Student_List& student_list, bool reverse) {
	if (student_list.size == 0) {
		cout << "Student List is empty!" << endl;
	}

	if (!reverse) {
		for (Student_Node* current = student_list.head; current != nullptr; current = current->next) {
			print_student(current->student);
		}
	}

	else {
		for (Student_Node* current = student_list.tail; current != nullptr; current = current->prev) {
			print_student(current->student);
		}
	}
}

/* Task 4
 * Implement the insert_student() and delete_student() functions for the Student Linked List.
 * For insert(), the new node should be inserted before the index node, or at the end of the linked list if (index == student_list.size).
 * For delete(), the node at index should be deleted.
 * Remember to handle the special case of head/tail.
 * Also update student_list.head and/or student_list.tail if required, as well as student_list.size.
 * You can assume that index is always within valid range.
 */
void insert_student(Student_List& student_list, const Student& student, int index) {
	if ((index < 0) || (index > student_list.size)) {
		return;
	}

	Student_Node* new_student_node = new Student_Node;
	new_student_node->student = student;

	// Handle the special case of head.
	if (index == 0) {
		new_student_node->next = student_list.head;

		if (student_list.head != nullptr) {
			student_list.head->prev = new_student_node;
		}
		else {
			student_list.tail = new_student_node;
		}

		student_list.head = new_student_node;
		student_list.size++;

		return;
	}

	// Handle the special case of tail.
	if (index == student_list.size) {
		new_student_node->prev = student_list.tail;

		if (student_list.tail != nullptr) {
			student_list.tail->next = new_student_node;
		}
		else {
			student_list.head = new_student_node;
		}

		student_list.tail = new_student_node;
		student_list.size++;

		return;
	}

	// Handle the regular cases.
	Student_Node* index_node = student_list.head;
	for (int i = 0; i < index; i++) {
		index_node = index_node->next;
	}

	new_student_node->next = index_node;
	new_student_node->prev = index_node->prev;
	index_node->prev->next = new_student_node;
	index_node->prev = new_student_node;

	student_list.size++;
}

void delete_student(Student_List& student_list, int index) {
	if ((index < 0) || (index >= student_list.size)) {
		return;
	}

	Student_Node* target = student_list.head;
	for (int i = 0; i < index; i++) {
		target = target->next;
	}

	// Handle the special case of head/tail. Also remember to update student_list.
	if (index > 0) {
		target->prev->next = target->next;
	}
	if (index < student_list.size - 1) {
		target->next->prev = target->prev;
	}

	if (index == 0) {
		student_list.head = student_list.head->next;
	}
	if (index == student_list.size - 1) {
		student_list.tail = student_list.tail->prev;
	}

	delete target;
	student_list.size--;
}

/* Task 5
 * Swap the nodes located at index1 and index2.
 * Update their next/prev pointers, as well as their neighbors.
 * Remember to handle the special case of index1 and/or index2 being the head and/or tail.
 * Also special case if they are adjacent nodes.
 * Also update student_list.head and/or student_list.tail if required.
 * You can assume that index1 and index2 are always within valid range.
 * To simplify your code, swap index1 and index2 if index2 is smaller than index1.
 * If index1 and index2 are equal, then do nothing.
 */
void swap_student(Student_List& student_list, int index1, int index2) {
	if ((index1 < 0) || (index2 < 0) || (index1 >= student_list.size) || (index2 >= student_list.size) || (index1 == index2)) {
		return;
	}

	// Make sure that index1 is always smaller than index2, to simplify our code.
	if (index1 > index2) {
		int temp = index1;
		index1 = index2;
		index2 = temp;
	}

	Student_Node* student1 = student_list.head;
	Student_Node* student2 = student_list.head;
	for (int i = 0; i < index1; i++) {
		student1 = student1->next;
	}
	for (int j = 0; j < index2; j++) {
		student2 = student2->next;
	}

	// Handle the special case of adjacent nodes.
	if (((index2 - index1) == 1)) {
		// Also handle the special case of student1/student are the head/tail.
		if (index1 > 0) {
			student1->prev->next = student2;
		}
		if (index2 < student_list.size - 1) {
			student2->next->prev = student1;
		}

		student1->next = student2->next;
		student2->prev = student1->prev;

		student2->next = student1;
		student1->prev = student2;
	}

	// Otherwise handle non-adjacent nodes.
	else {
		// First handle the next/prev pointers of student1/student2 neighbor nodes.
		// Also handles special cases where student1/student2 are the head/tail.
		if (index1 > 0) {
			student1->prev->next = student2;
		}
		student2->prev->next = student1;

		student1->next->prev = student2;
		if (index2 < student_list.size - 1) {
			student2->next->prev = student1;
		}

		// Then handle the next/prev pointers of student1/student2 nodes themselves.
		Student_Node* temp = student1->prev;
		student1->prev = student2->prev;
		student2->prev = temp;

		temp = student1->next;
		student1->next = student2->next;
		student2->next = temp;
	}

	// Also update head/tail if they were swapped.
	if (index1 == 0) {
		student_list.head = student2;
	}
	if (index2 == student_list.size - 1) {
		student_list.tail = student1;
	}
}

/* Bonus Task
 * You may use the swap() function that you have implemented in Task 5.
 * sort_options can be used as an argument to a switch-case statement.
 * Names should be sorted by alphanumeric order, you may use the <algorithm> library function lexicographical_compare() for the strings.
 * Gender is sorted as MALE first, FEMALE second.
 * ID, Age, and CGPA are both sorted by ascending numerical order.
 * If the student_list only has 0 or 1 elements, then do nothing.
 * For simplicity, you may use the Bubble Sort algorithm, which is inefficient but straightforward to code.
 */
void sort_student_list(Student_List& student_list, Sort_Options sort_options) {
	if ((student_list.size == 0) || (student_list.size == 1)) {
		return;
	}

	// Simple but inefficient Bubble Sort.
	bool sorted = false;
	while (!sorted) {
		sorted = true;
		Student_Node* current = student_list.head;
		Student_Node* current_next = student_list.head->next;

		for (int i = 0; i < student_list.size - 1; i++) {
			bool out_of_order = false;
			switch (sort_options) {
			case NAME:
				if (!lexicographical_compare(current->student.name.begin(), current->student.name.end(),
												current_next->student.name.begin(), current_next->student.name.end())) {
					out_of_order = true;
				}
				break;

			case GENDER:
				if ((current->student.gender == FEMALE) && (current_next->student.gender == MALE)) {
					out_of_order = true;
				}
				break;

			case ID:
				if (current->student.id > current_next->student.id) {
					out_of_order = true;
				}
				break;

			case AGE:
				if (current->student.age > current_next->student.age) {
					out_of_order = true;
				}
				break;

			case CGPA:
				if (current->student.cgpa > current_next->student.cgpa) {
					out_of_order = true;
				}
				break;

			default:
				break;
			}

			if (out_of_order) {
				sorted = false;
				swap_student(student_list, i, i+1);
			}

			current = current->next;
			current_next = current_next->next;
		}
	}
}

/* Task 6
 * Delete the whole Student Linked List.
 * Make sure to delete each node individually.
 * Also remember to reset student_list.head and student_list.prev to nullptr.
 */
void delete_student_list(Student_List& student_list) {
	if (student_list.size == 0) {
		return;
	}

	if (student_list.size == 1) {
		delete student_list.head;
	}

	// Here, size >= 2, which simplifies the for-loop checking.
	// An iterative algorithm is faster than a recursive algorithm, however it is more complicated.
	else {
		for (Student_Node *current_prev = student_list.head, *current = student_list.head->next;
				current != nullptr;
				current_prev = current, current = current->next) {
			delete current_prev;
		}
		delete student_list.tail;
	}

	student_list.head = nullptr;
	student_list.tail = nullptr;
	student_list.size = 0;
}
