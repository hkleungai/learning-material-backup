#include <QFont>

#include <sstream>

#include "square.h"

using std::string;
using std::ostringstream;

Square* Square::highlighted;

extern QFont* chess_font;

Square::Square(QWidget* parent, int _x, int _y) :
    QPushButton(parent),
    x(_x),
    y(_y),
    is_highlighted(false)
{
    this->render();
    connect(this, &Square::clicked, this, &Square::clicked_handler);
    highlighted = nullptr;
}

void Square::render() {
    setGeometry(QRect(OFFSET_X + SQUARE_WIDTH * this->x, OFFSET_Y + SQUARE_HEIGHT * this->y, SQUARE_WIDTH, SQUARE_HEIGHT));
    setVisible(true);
    setFlat(true);
    setAutoFillBackground(true);
    setFont(*chess_font);
    setText("");
    setStyle("border-color", "black");
    setStyle("border-width", "0px");
    setStyle("border-style", "solid");
    if ((this->x + this->y) % 2 == 0)
        setStyle("background-color", "gray");
    else
        setStyle("background-color", "white");
    applyStyle();
}

void Square::setStyle(string key, string value) {
    this->style[key] = value;
}

void Square::applyStyle() {
    ostringstream s;
    for (StyleMap::iterator i=this->style.begin(); i!=this->style.end(); i++) {
        s << i->first << ":" << i->second << ";";
    }
    string style_string = s.str();
    setStyleSheet(QString::fromStdString(style_string));
}

void Square::set_highlighted(bool value) {
    if (value) {
        setStyle("border-color", "black");
        setStyle("border-width", "5px");
        setStyle("border-style", "solid");
    }
    else {
        setStyle("border-color", "black");
        setStyle("border-width", "0px");
        setStyle("border-style", "solid");
    }
    applyStyle();
    this->is_highlighted=value;
}

bool Square::get_highlighted() const {
    return this->is_highlighted;
}

void Square::clicked_handler() {
    if (highlighted) highlighted->set_highlighted(false);
    this->set_highlighted(true);
    highlighted = this;
}
