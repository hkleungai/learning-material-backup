#include <QFont>
#include <QFontDatabase>

#include "mainwindow.h"
#include "ui_mainwindow.h"

QFont* chess_font;

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow),
    game_window(nullptr)
{
    ui->setupUi(this);
    chess_font = new QFont(QFontDatabase::applicationFontFamilies(QFontDatabase::addApplicationFont(":/fonts/usual.ttf")).at(0), 40);

    connect(this->ui->startButton, &QPushButton::clicked, this, &MainWindow::startButton_clicked_handler);
}

MainWindow::~MainWindow()
{
    if (this->game_window != nullptr) delete this->game_window;
    delete chess_font;

    delete this->ui;
}

void MainWindow::startButton_clicked_handler()
{
    if (this->game_window == nullptr) {
        this->game_window = new GameWindow(nullptr);
        this->game_window->show();
        connect(this->game_window, &GameWindow::closed, this, &MainWindow::game_window_closed_handler);
        this->hide();
    }
}

void MainWindow::game_window_closed_handler() {
    if (this->game_window) delete this->game_window;
    this->game_window = nullptr;
    this->show();
}
