#include "ArrayStack.h"

ArrayStack::ArrayStack(unsigned int startingArraySize) : ArrayAbstractQueue(startingArraySize) {}
ArrayStack::ArrayStack(const ArrayStack& arrayStack) : ArrayAbstractQueue(arrayStack) {};
ArrayStack::~ArrayStack() {};

ArrayStack& ArrayStack::operator=(const ArrayStack& arrayStack) {
	dynamic_cast<ArrayAbstractQueue&>(*this) = dynamic_cast<const ArrayAbstractQueue&>(arrayStack);
	return *this;
}

int ArrayStack::peek() const {
	return getDataAtIndex(numElements - 1);
}

void ArrayStack::push(int element) {
	resizeArrayIfNeeded(PUSH);
	getDataAtIndex(numElements) = element;
	numElements++;
}

int ArrayStack::pop() {
	int element = getDataAtIndex(numElements - 1);
	numElements--;
	resizeArrayIfNeeded(POP);
	return element;
}

void ArrayStack::popAll(int data[]) {
	if (data != nullptr) {
		for (unsigned int i = getNumElements(), j = 0; i > 0; i--, j++) {
			data[j] = getDataAtIndex(i - 1);
		}
	}
	numElements = 0; // Technically unneeded, but included for clarity and similarity with push() and pop().
	resizeArrayIfNeeded(POPALL);
}
