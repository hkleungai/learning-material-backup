#include "ArrayQueue.h"

ArrayQueue::ArrayQueue(unsigned int startingArraySize) : ArrayAbstractQueue(startingArraySize) {}
ArrayQueue::ArrayQueue(const ArrayQueue& arrayQueue) : ArrayAbstractQueue(arrayQueue) {};
ArrayQueue::~ArrayQueue() {};

ArrayQueue& ArrayQueue::operator=(const ArrayQueue& arrayQueue) {
	dynamic_cast<ArrayAbstractQueue&>(*this) = dynamic_cast<const ArrayAbstractQueue&>(arrayQueue);
	return *this;
}

int ArrayQueue::peek() const {
	return getDataAtIndex(headIndex);
}

void ArrayQueue::push(int element) {
	resizeArrayIfNeeded(PUSH);
	getDataAtIndex((headIndex + numElements) % getArraySize()) = element;
	numElements++;
}

int ArrayQueue::pop() {
	int element = getDataAtIndex(headIndex);
	headIndex = (headIndex + 1) % getArraySize();
	numElements--;
	resizeArrayIfNeeded(POP);
	return element;
}

void ArrayQueue::popAll(int data[]) {
	if (data != nullptr) {
		for (unsigned int i = 0; i < numElements; i++) {
			data[i] = getDataAtIndex((headIndex + i) % getArraySize());
		}
	}
	numElements = 0; // Technically unneeded, but included for clarity and similarity with push() and pop().
	resizeArrayIfNeeded(POPALL);
}
