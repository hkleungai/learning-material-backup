#include "ArrayDeque.h"

ArrayDeque::ArrayDeque(unsigned int startingArraySize) : ArrayQueue(startingArraySize) {}
ArrayDeque::ArrayDeque(const ArrayDeque& arrayDeque) : ArrayQueue(arrayDeque) {};
ArrayDeque::~ArrayDeque() {};

ArrayDeque& ArrayDeque::operator=(const ArrayDeque& arrayDeque) {
	dynamic_cast<ArrayQueue&>(*this) = dynamic_cast<const ArrayQueue&>(arrayDeque);
	return *this;
}

int ArrayDeque::peekBack() const {
	return getDataAtIndex((headIndex + numElements - 1) % getArraySize());
}

void ArrayDeque::pushFront(int element) {
	resizeArrayIfNeeded(PUSH);
	headIndex = (headIndex + getArraySize() - 1) % getArraySize();
	getDataAtIndex(headIndex) = element;
	numElements++;
}

int ArrayDeque::popBack() {
	int element = getDataAtIndex((headIndex + numElements - 1) % getArraySize());
	numElements--;
	resizeArrayIfNeeded(POP);
	return element;
}

void ArrayDeque::popAllFromBack(int data[]) {
	if (data != nullptr) {
		for (unsigned int i = numElements, j = 0; i > 0; i--, j++) {
			data[j] = getDataAtIndex((headIndex + i - 1) % getArraySize());
		}
	}
	numElements = 0; // Technically unneeded, but included for clarity and similarity with push() and pop().
	resizeArrayIfNeeded(POPALL);
}
