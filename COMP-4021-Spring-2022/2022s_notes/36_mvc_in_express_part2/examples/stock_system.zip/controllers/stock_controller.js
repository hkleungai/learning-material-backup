const stocks = require("../models/stocks");

// Handle the get stock request
const get = async (req, res) => {
    const { code } = req.body;

    try {
        stock = await stocks.getStock(code);
        req.session.stock = stock;
    } catch (error) {
        console.log(error);
        res.redirect("/");
        return;
    }

    res.redirect("/table");
};

// Handle the change stock request
const change = (req, res) => {
    if (req.session.stock) delete req.session.stock;
    res.redirect("/");
};

// Show the stock table
const showTable = (req, res) => {
    if (!req.session.stock) {
        res.redirect("/");
        return;
    }

    res.render("table", { stock: req.session.stock });
};

// Show the stock chart
const showChart = (req, res) => {
    if (!req.session.stock) {
        res.redirect("/");
        return;
    }

    res.render("chart", { stock: req.session.stock });
};

module.exports = { get, change, showTable, showChart };
