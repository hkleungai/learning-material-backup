const express = require("express");

console.log("You have installed express successfully.");
