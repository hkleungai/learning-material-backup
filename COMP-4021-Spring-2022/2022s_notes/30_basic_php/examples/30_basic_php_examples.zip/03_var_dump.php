<!DOCTYPE html>
<html>
<head>
    <title>Dumping Variable Content</title>
</head>
<body>
    <?php
    $age = 18;
    var_dump($age);
    ?>
</body>
</html>
