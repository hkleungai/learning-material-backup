<!DOCTYPE html>
<html>
<head>
    <title>Welcome!</title>
</head>
<body>
    <?= "Welcome to my page!" ?>
</body>
</html>

