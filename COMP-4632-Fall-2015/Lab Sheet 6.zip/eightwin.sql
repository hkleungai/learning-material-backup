CREATE DATABASE eightwin DEFAULT CHARSET utf8;
USE eightwin;

CREATE TABLE User (
    _id BIGINT NOT NULL AUTO_INCREMENT,
    email VARCHAR(100),
    password VARCHAR(30),
    name VARCHAR(50),
    hkid VARCHAR(9),
    phone CHAR(8),
    address VARCHAR(1000),
    status CHAR(1),  -- E/D/A
    PRIMARY KEY (_id)
);

CREATE TABLE Game (
    _id BIGINT NOT NULL AUTO_INCREMENT,
    code CHAR(5),
    oddshome REAL,
    oddsdraw REAL,
    oddsaway REAL,
    result CHAR(1),  -- H/D/A
    PRIMARY KEY (_id)
);

CREATE TABLE User_Game (
    _id BIGINT NOT NULL AUTO_INCREMENT,
    user_id BIGINT,
    game_id BIGINT,
    bet CHAR(1),  -- H/D/A
    amount REAL,
    PRIMARY KEY (_id)
);

INSERT INTO User (email, password, name, hkid, phone, address, status) VALUES ('admin', 'P@ssw0rd', 'Administrator', '', '', '', 'A');
