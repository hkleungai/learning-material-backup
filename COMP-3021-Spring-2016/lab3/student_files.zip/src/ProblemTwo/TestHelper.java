package ProblemTwo;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;

public class TestHelper
{
	public static boolean equals(String paramString1, String paramString2)
			throws IOException, FileNotFoundException
	{
		BufferedReader localBufferedReader1 = new BufferedReader(new FileReader(paramString1));

		BufferedReader localBufferedReader2 = new BufferedReader(new FileReader(paramString2));

		String str1 = localBufferedReader1.readLine();
		String str2 = localBufferedReader2.readLine();
		while ((str1 != null) && (str2 != null))
		{
			if (!str1.equals(str2)) {
				break;
			}
			str1 = localBufferedReader1.readLine();
			str2 = localBufferedReader2.readLine();
		}
		localBufferedReader1.close();
		localBufferedReader2.close();

		return (str1 == null) && (str2 == null);
	}

	public static <T> boolean equals(ArrayList<T> paramArrayList1, ArrayList<T> paramArrayList2)
	{
		Iterator localIterator1 = paramArrayList1.iterator();
		Iterator localIterator2 = paramArrayList2.iterator();
		while ((localIterator1.hasNext()) && (localIterator2.hasNext())) {
			if (!localIterator1.next().equals(localIterator2.next())) {
				return false;
			}
		}
		return (!localIterator1.hasNext()) && (!localIterator1.hasNext());
	}
}
