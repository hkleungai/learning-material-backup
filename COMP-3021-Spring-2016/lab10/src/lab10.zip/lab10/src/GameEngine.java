import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.util.*;
import javax.swing.*;
import javax.swing.BorderFactory; 
import javax.swing.border.Border;
import javax.swing.border.TitledBorder;
import javax.swing.border.EtchedBorder;

/**
 * This class works as a game engine which loops to do updates.
 *
 */
class GameEngine extends JPanel implements Runnable {

	// Field variables
	public static final int NUM_BLOCKS = 32; // 4 X 8
	public static final int BLOCK_SPACE = 5;
	public static final int WIDTH = (Block.WIDTH+BLOCK_SPACE)*8+BLOCK_SPACE;
	public static final int HEIGHT = 364;
	public static final int THRESHOLD = BouncerFrame.HEIGHT - 2*Ball.RADIUS;
	public static final int BALL_START_XPOS = 20;
	public static final int BALL_START_YPOS = 280;
	public static final int BAR_START_XPOS = 0;
	public static final int BAR_START_YPOS = 300;
	public static final int LEVEL1_INTERVAL = 100;	// speed of level 1
	public static final int LEVEL2_INTERVAL = 90;	// speed of level 2
	public static final int LEVEL3_INTERVAL = 80;	// speed of level 3
	public static final int LEVEL4_INTERVAL = 70;	// speed of level 4
	public static final int LEVEL5_INTERVAL = 60;	// speed of level 5

	public static boolean isHitBottom = false;	// indicates if the ball hits the bottom
	//  set as global for simplicity
	public static boolean isCheat = false;	// tooggle cheat mode
	// set as global for simplicity
	int blocksDestroyed = 0;
	boolean gameStarted = false;
	boolean stopRequested = false;
	boolean suspendRequested = false;
	Ball ball;
	Block[] blockArray;
	Bar bar;
	int currentInterval;
	int score;

	private SuspendRequestor suspender =  new SuspendRequestor();

	public GameEngine() {

		currentInterval = LEVEL1_INTERVAL;
		score = 0;
		setSize(WIDTH, HEIGHT);
		setBorder(BorderFactory.createEtchedBorder(EtchedBorder.RAISED));
		blockArray = new Block[GameEngine.NUM_BLOCKS];
		int x = 10 , y = 10;
		for(int i=0; i<4; i++) {
			for(int j=0; j<8 ; j++) {
				blockArray[i*8 + j] = new Block(x, y, Color.YELLOW);
				x = x + Block.WIDTH + BLOCK_SPACE;
			}
			x = 10;	// reset the x position			
			y = y + Block.HEIGHT + 5;
		} 
		bar = new Bar(BAR_START_XPOS, BAR_START_YPOS, Color.BLACK);
		// position the ball above the center of the bar
		ball = new Ball(bar.getXPos()+Bar.WIDTH/2-ball.RADIUS, bar.getYPos()-2*Ball.RADIUS, Color.RED, 10, 10);
		repaint();
		requestFocus();
		addKeyListener(new KeyHandler());
	} // end of GameEngine(RecordPanel)

	public void startGame() {

		if(!gameStarted) {
			gameStarted = true;
			stopRequested = false;
			suspendRequested = false;
			ball.setXPos(bar.getXPos()+Bar.WIDTH/2);
			ball.setYPos(bar.getYPos()-Ball.RADIUS);

			//*******place your code here to make the game start*****

			//*****************************************************
		}

	} // end of startGame()

	public void suspendResumeGame() {
		suspendRequested = !suspendRequested;
		if(gameStarted) {
			//********Handle the request according to the state of the game*******
			//**********Only need to write codes inside this if-block*************
		}

	} // end of suspendResumeGame()

	public void requestSuspend() { 
		//*********place your code here*************


	} // end of requestSuspend()

	public synchronized void requestResume() { 
		//*********place your code here*************


	} // end of requestResume()

	public void stopGame() {
		stopRequested = true;
		gameStarted = false;
	} // end of stopGame()


	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		Graphics2D g2 = (Graphics2D)g;
		// draw the ball
		ball.draw(g2);
		// draw the blocks
		for(int i=0; i<blockArray.length; i++) {
			if(!blockArray[i].isDestroyed()){
				blockArray[i].draw(g2);
				//System.out.println(i + "th block drawn");
			}
		}
		// draw the bar
		bar.draw(g2);
		// debug message for showing the dimension of the game panel
		//System.out.println(getWidth()+" X "+getHeight());
	} // end of paintComponent(Graphics)


	public void run() {
		// loop thoughout the whole game, unless stop is requested
		while(!stopRequested) {

			//******place your code here to make the suspend/resume work*******


			//***************************************************************
			// check if the ball hits any block
			int blockResult;
			for(int i=0; i<blockArray.length; i++) {
				if(!blockArray[i].isDestroyed()) {
					blockResult = blockArray[i].isHit(ball);	
					if(blockResult == Block.TOP_OR_BOTTOM) {
						blockArray[i].setDestroyed(true);
						ball.setYVel(-ball.getYVel());
						// increase score
						score += currentInterval;
						blocksDestroyed++;
					} 
					else if(blockResult == Block.LEFT_OR_RIGHT) {
						blockArray[i].setDestroyed(true);
						ball.setXVel(-ball.getXVel());
						// increase score
						score += currentInterval;
						blocksDestroyed++;
					}
					else {	// do nothing
					}
				}	
			}

			// check if all the blocks are destroyed
			if(blocksDestroyed >= NUM_BLOCKS) {			
				// repaint all the things
				repaint();
				stopGame();
				JOptionPane.showMessageDialog(this, "You've won!\nScore = "+score);
				System.exit(0);	
			}

			// check if the ball hits the bar
			int barResult = bar.isHit(ball);
			if(barResult==Bar.LEFT_SIDE || barResult==Bar.RIGHT_SIDE) {
				// make it move faster horizontally
				ball.setXVel(ball.getXVel()+2);
				ball.setYVel(-ball.getYVel());
			} 
			else if(barResult == Bar.MIDDLE) {
				ball.setYVel(-ball.getYVel());
			}
			else {
				// do nothing, since no hit	
			}

			// check if the ball has hit the bottom
			if(!isCheat && isHitBottom) {
				stopGame();
				JOptionPane.showMessageDialog(this, "Game Over!\nScore = "+score);
				System.exit(0);					
			}
			// move the ball
			ball.move(getWidth(), getHeight());
			// repaint all the things
			repaint();
			// sleep for delay
			try {
				Thread.sleep(currentInterval);
			} catch(InterruptedException ie) {}
		}
	} // end of run()

	// public boolean isFocusTraversable() <- Deprecated since JDK1.4
	public boolean isFocusable() {
		return true; // allow panel to get input focus
	}

	/**
	 * Inner class for handling the left and right button events
	 *
	 */
	private class KeyHandler extends KeyAdapter {
		public void keyPressed(KeyEvent event) {
			int keyCode = event.getKeyCode();
			if (keyCode == KeyEvent.VK_LEFT && !suspendRequested) {
				//System.out.println("left pressed");
				bar.move(getWidth(), getHeight(), Bar.LEFT);
				if(!gameStarted)
					ball.setXPos(bar.getXPos()+Bar.WIDTH/2-Ball.RADIUS);
			}
			else if (keyCode == KeyEvent.VK_RIGHT && !suspendRequested) {
				//System.out.println("right pressed");
				bar.move(getWidth(), getHeight(), Bar.RIGHT);
				if(!gameStarted)
					ball.setXPos(bar.getXPos()+Bar.WIDTH/2-Ball.RADIUS);
			}
			else if (keyCode == KeyEvent.VK_UP) {
				//System.out.println("up pressed");
				if(!gameStarted)
					startGame();
			}
			else if (keyCode == KeyEvent.VK_C) {
				isCheat = !isCheat;
				if(isCheat)	ball.setColor(Color.BLUE);
				else ball.setColor(Color.RED);
			}
			else if (keyCode == KeyEvent.VK_P) {
				suspendResumeGame();
			}
			else {
				// do nothing
			}
			repaint();
		} // end of keyPressed(KeyEvent)
	} // end of KeyHandler inner class definition
} // end of GameEngine class definition

// The class for us to use its objects as locks
class SuspendRequestor{
	public synchronized void set ( boolean b){
		suspendRequested = b;
		notifyAll();
	}

	public synchronized void waitForResume() throws InterruptedException{
		while ( suspendRequested) wait ();
	}
	private boolean suspendRequested;
}