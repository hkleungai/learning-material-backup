import javax.swing.JFrame;

public class BouncerGame{
  public static void main(String[] paramArrayOfString){
    BouncerFrame localBouncerFrame = new BouncerFrame();
    localBouncerFrame.setDefaultCloseOperation(3);
    localBouncerFrame.show();
  }
}
