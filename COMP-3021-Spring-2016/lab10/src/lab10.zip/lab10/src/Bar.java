import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;
import java.awt.geom.Rectangle2D.Double;

class Bar extends GameElement{
	public static final int WIDTH = 60;
	public static final int HEIGHT = 8;
	public static final int STEP = 20;
	public static final int LEFT = 0;
	public static final int RIGHT = 1;
	public static final int LEFT_SIDE = 2;
	public static final int MIDDLE = 3;
	public static final int RIGHT_SIDE = 4;
	public static final int NO_HIT = 5;

	public Bar(int paramInt1, int paramInt2, Color paramColor){
		super(paramInt1, paramInt2, paramColor);
	}

	public void move(int paramInt1, int paramInt2, int paramInt3){
		if ((paramInt3 == 0) && (this.xPos > 0)) {
			this.xPos -= 20;
		} else if ((paramInt3 == 1) && (this.xPos + 60 < paramInt1)) {
			this.xPos += 20;
		}
	}

	public int isHit(Ball paramBall){
		if ((this.yPos <= paramBall.getYPos() + 5) && (paramBall.getYPos() <= this.yPos + 8)){
			if ((paramBall.getXPos() + 5 >= this.xPos) && (paramBall.getXPos() - 5 <= this.xPos + 60)){
				paramBall.setYPos(this.yPos - 10 - 1);
				if (paramBall.getXPos() <= 6) {
					return 2;
				}
				if (paramBall.getXPos() >= 54) {
					return 4;
				}
				return 3;
			}
			return 5;
		}
		return 5;
	}

	public void draw(Graphics2D paramGraphics2D){
		paramGraphics2D.setColor(this.color);
		paramGraphics2D.fill(new Rectangle2D.Double(this.xPos, this.yPos, 60.0D, 8.0D));
	}
}
