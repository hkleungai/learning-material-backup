import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;
import java.awt.geom.Rectangle2D.Double;

class Block extends GameElement{
	public static final int WIDTH = 30;
	public static final int HEIGHT = 15;
	public static final int NO_HIT = 0;
	public static final int TOP_OR_BOTTOM = 1;
	public static final int LEFT_OR_RIGHT = 2;
	private boolean destroyed = false;

	public Block(int paramInt1, int paramInt2, Color paramColor){
		super(paramInt1, paramInt2, paramColor);
	}

	public void setDestroyed(boolean paramBoolean){
		this.destroyed = paramBoolean;
	}

	public boolean isDestroyed(){
		return this.destroyed;
	}

	public int isHit(Ball paramBall){
		if ((paramBall.getYPos() + 5 >= this.yPos) && (paramBall.getYPos() - 5 <= this.yPos + 15) && (paramBall.getXPos() + 5 >= this.xPos) && (paramBall.getXPos() - 5 <= this.xPos + 30)){
			int i = paramBall.getPrevXPos();
			int j = paramBall.getPrevYPos();
			int k = paramBall.getXPos();
			int m = paramBall.getYPos();

			int n = (this.yPos - m) * (i - k) / (j - m) + k;
			int i1 = this.yPos;
			if ((Math.min(i, k) <= n) && (n <= Math.max(i, k)) && (Math.min(j, m) <= i1) && (i1 <= Math.max(j, m)) && (this.xPos <= n) && (n <= this.xPos + 30)) {
				return 1;
			}
			int i2 = (this.yPos + 15 - m) * (i - k) / (j - m) + k;

			int i3 = this.yPos + 15;
			if ((Math.min(i, k) <= i2) && (i2 <= Math.max(i, k)) && (Math.min(j, m) <= i3) && (i3 <= Math.max(j, m)) && (this.xPos <= i2) && (i2 <= this.xPos + 30)) {
				return 1;
			}
			int i4 = this.xPos;
			int i5 = (j - m) / (i - k) * (this.xPos - k) + m;
			if ((Math.min(i, k) <= i4) && (i4 <= Math.max(i, k)) && (Math.min(j, m) <= i5) && (i5 <= Math.max(j, m)) && (this.yPos <= i5) && (i5 <= this.yPos + 15)) {
				return 2;
			}
			int i6 = this.xPos + 30;
			int i7 = (j - m) / (i - k) * (this.xPos + 30 - k) + m;
			if ((Math.min(i, k) <= i6) && (i6 <= Math.max(i, k)) && (Math.min(j, m) <= i7) && (i7 <= Math.max(j, m)) && (this.yPos <= i7) && (i7 <= this.yPos + 15)) {
				return 2;
			}
			return 0;
		}
		return 0;
	}

	public void draw(Graphics2D paramGraphics2D){
		paramGraphics2D.setColor(this.color);
		paramGraphics2D.fill(new Rectangle2D.Double(this.xPos, this.yPos, 30.0D, 15.0D));
	}
}