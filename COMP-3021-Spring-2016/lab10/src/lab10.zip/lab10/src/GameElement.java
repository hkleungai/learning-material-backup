import java.awt.Color;

class GameElement{
	int xPos;
	int yPos;
	Color color;

	public GameElement(int paramInt1, int paramInt2, Color paramColor){
		this.xPos = paramInt1;
		this.yPos = paramInt2;
		this.color = paramColor;
	}

	public void setXPos(int paramInt){
		this.xPos = paramInt;
	}

	public int getXPos(){
		return this.xPos;
	}

	public void setYPos(int paramInt){
		this.yPos = paramInt;
	}

	public int getYPos(){
		return this.yPos;
	}

	public void setColor(Color paramColor){
		this.color = paramColor;
	}

	public Color getColor(){
		return this.color;
	}
}
