
public class Circle extends Shape {
	// Properties of the class...
	public double radius;

	// Constructor of the class...
	public Circle(double aRadius) {
		System.out.println("I am a circle!");
		radius = aRadius;
	}
}
