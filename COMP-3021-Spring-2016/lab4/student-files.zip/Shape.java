
public class Shape {
	public Shape(){
		System.out.println("I am a shape!");
	}
}
