
public class Triangle extends Shape{
	// Properties of the class...
	public double base;
	public double height;

	// Constructor of the class...
	public Triangle(double aBase, double aHeight) {
		System.out.println("I am a triangle!");
		base = aBase;
		height = aHeight;
	}
}
