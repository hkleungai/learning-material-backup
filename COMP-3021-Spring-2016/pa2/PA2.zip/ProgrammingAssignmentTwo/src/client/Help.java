package client;

import java.awt.*;
import javax.swing.border.*;
import java.net.*;
import javax.swing.*;
import java.awt.event.*;

public class Help extends JDialog {
	JPanel titlePanel = new JPanel();
	JPanel contentPanel = new JPanel();
	JPanel closePanel = new JPanel();
	JButton close = new JButton();
	JLabel title = new JLabel("Client-Side Help");
	JTextArea help = new JTextArea(); 
	Color bg = new Color(255,255,255);
	public Help(JFrame frame) {
		super(frame, true);
		try {
			jbInit();
		}
		catch (Exception e) {
			e.printStackTrace();
		}

		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		this.setLocation( (int) (screenSize.width - 400) / 2 + 25,
				(int) (screenSize.height - 320) / 2);
		this.setResizable(false);
	}
	private void jbInit() throws Exception {
		this.setSize(new Dimension(350, 270));
		this.setTitle("Help");
		titlePanel.setBackground(bg);;
		contentPanel.setBackground(bg);
		closePanel.setBackground(bg);
		help.setText("1. Set Server IP Address and Port No"+
				"(Default Config\n      127.0.0.1:8888).\n"+
				"2. Enter your user name (Default is hkuster).\n"+
				"3. Click Logon to Connect to Server;\n"+
				"	Click Logout to disconnect to Server.\n"+
				"4. Select  user to receive messages and enter message in the message box\n"+
				".	Meanwhile, select emotion and send messages.\n");
		help.setEditable(false);
		titlePanel.add(new Label("              "));
		titlePanel.add(title);
		titlePanel.add(new Label("              "));
		contentPanel.add(help);
		closePanel.add(new Label("              "));
		closePanel.add(close);
		closePanel.add(new Label("              "));
		Container contentPane = getContentPane();
		contentPane.setLayout(new BorderLayout());
		contentPane.add(titlePanel, BorderLayout.NORTH);
		contentPane.add(contentPanel, BorderLayout.CENTER);
		contentPane.add(closePanel, BorderLayout.SOUTH);
		close.setText("Close");

		close.addActionListener(
				new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						dispose();
					}
				}
				);
	}
}
