package client;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import java.io.*;
import java.net.*;

public class ChatClient extends JFrame implements ActionListener{
	String ip = "127.0.0.1";
	int port = 8888;
	String userName = "hkuster";
	int type = 0;
	Image icon;
	JComboBox combobox;
	JTextArea messageShow;
	JScrollPane messageScrollPane;
	JLabel express,sendToLabel,messageLabel ;
	JTextField clientMessage;
	JCheckBox checkbox;
	JComboBox actionlist;
	JButton clientMessageButton;
	JTextField showStatus;
	Socket socket;
	ObjectOutputStream output;
	ObjectInputStream input;
	ClientReceive recvThread;

	JMenuBar jMenuBar = new JMenuBar(); 
	JMenu operateMenu = new JMenu ("Operation(O)"); 
	JMenuItem loginItem = new JMenuItem ("Logon(I)");
	JMenuItem logoffItem = new JMenuItem ("Logout(L)");
	JMenuItem exitItem=new JMenuItem ("Exit(X)");
	JMenu conMenu=new JMenu ("Config(C)");
	JMenuItem userItem=new JMenuItem ("User Config(U)");
	JMenuItem connectItem=new JMenuItem ("Connection Config(C)");	
	JMenu helpMenu=new JMenu ("Help(H)");
	JMenuItem helpItem=new JMenuItem ("Help(H)");

	JToolBar toolBar = new JToolBar();
	JButton loginButton;
	JButton logoffButton;
	JButton userButton;
	JButton connectButton;
	JButton exitButton;

	Dimension faceSize = new Dimension(700, 600);
	JPanel downPanel ;
	GridBagLayout girdBag;
	GridBagConstraints girdBagCon;
	public ChatClient(){
		init();
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.pack();
		this.setSize(faceSize);
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		this.setLocation( (int) (screenSize.width - faceSize.getWidth()) / 2,
				(int) (screenSize.height - faceSize.getHeight()) / 2);
		this.setResizable(false);
		this.setTitle("Client-Side Chatting Room");
		this.setIconImage(icon);
		show();
		operateMenu.setMnemonic('O');
		loginItem.setMnemonic ('I'); 
		loginItem.setAccelerator (KeyStroke.getKeyStroke (KeyEvent.VK_I,InputEvent.CTRL_MASK));
		logoffItem.setMnemonic ('L'); 
		logoffItem.setAccelerator (KeyStroke.getKeyStroke (KeyEvent.VK_L,InputEvent.CTRL_MASK));
		exitItem.setMnemonic ('X'); 
		exitItem.setAccelerator (KeyStroke.getKeyStroke (KeyEvent.VK_X,InputEvent.CTRL_MASK));
		conMenu.setMnemonic('C');
		userItem.setMnemonic ('U'); 
		userItem.setAccelerator (KeyStroke.getKeyStroke (KeyEvent.VK_U,InputEvent.CTRL_MASK));
		connectItem.setMnemonic ('C'); 
		connectItem.setAccelerator (KeyStroke.getKeyStroke (KeyEvent.VK_C,InputEvent.CTRL_MASK));
		helpMenu.setMnemonic('H');
		helpItem.setMnemonic ('H'); 
		helpItem.setAccelerator (KeyStroke.getKeyStroke (KeyEvent.VK_H,InputEvent.CTRL_MASK));
	}

	public void init(){
		Container contentPane = getContentPane();
		contentPane.setLayout(new BorderLayout());
		operateMenu.add (loginItem);
		operateMenu.add (logoffItem);
		operateMenu.add (exitItem);
		jMenuBar.add (operateMenu); 
		conMenu.add (userItem);
		conMenu.add (connectItem);
		jMenuBar.add (conMenu);
		helpMenu.add (helpItem);
		jMenuBar.add (helpMenu); 
		setJMenuBar (jMenuBar);

		loginButton = new JButton("logon");
		logoffButton = new JButton("logout");
		userButton  = new JButton("User Config" );
		connectButton  = new JButton("Connect Config" );
		exitButton = new JButton("Exit" );

		loginButton.setToolTipText("Connect to Server");
		logoffButton.setToolTipText("Disconnect to Server");
		userButton.setToolTipText("Config User Info");
		connectButton.setToolTipText("Config Server Info");

		toolBar.add(userButton);
		toolBar.add(connectButton);
		toolBar.addSeparator();
		toolBar.add(loginButton);
		toolBar.add(logoffButton);
		toolBar.addSeparator();
		toolBar.add(exitButton);
		contentPane.add(toolBar,BorderLayout.NORTH);
		checkbox = new JCheckBox("whisper");
		checkbox.setSelected(false);
		actionlist = new JComboBox();
		actionlist.addItem("smilely");
		actionlist.addItem("gladly");
		actionlist.addItem("slightly");
		actionlist.addItem("angrily");
		actionlist.addItem("carefully");
		actionlist.addItem("silently");
		actionlist.setSelectedIndex(0);

		loginButton.setEnabled(true);
		logoffButton.setEnabled(false);

		loginItem.addActionListener(this);
		logoffItem.addActionListener(this);
		exitItem.addActionListener(this);
		userItem.addActionListener(this);
		connectItem.addActionListener(this);
		helpItem.addActionListener(this);	

		loginButton.addActionListener(this);
		logoffButton.addActionListener(this);
		userButton.addActionListener(this);
		connectButton.addActionListener(this);
		exitButton.addActionListener(this);
		combobox = new JComboBox();
		combobox.insertItemAt("All Users",0);
		combobox.setSelectedIndex(0);
		messageShow = new JTextArea();
		messageShow.setEditable(false);

		messageScrollPane = new JScrollPane(messageShow,
				JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
				JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		messageScrollPane.setPreferredSize(new Dimension(400,400));
		messageScrollPane.revalidate();
		clientMessage = new JTextField(23);
		clientMessage.setEnabled(false);
		clientMessageButton = new JButton();
		clientMessageButton.setText("Send");

		clientMessage.addActionListener(this);
		clientMessageButton.addActionListener(this);
		sendToLabel = new JLabel("Send To:");
		express = new JLabel("emotions: ");
		messageLabel = new JLabel("Send Message: ");
		downPanel = new JPanel();
		girdBag = new GridBagLayout();
		downPanel.setLayout(girdBag);
		girdBagCon = new GridBagConstraints();
		girdBagCon.gridx = 0;
		girdBagCon.gridy = 0;
		girdBagCon.gridwidth = 5;
		girdBagCon.gridheight = 2;
		girdBagCon.ipadx = 5;
		girdBagCon.ipady = 5;
		JLabel none = new JLabel("    ");
		girdBag.setConstraints(none,girdBagCon);
		downPanel.add(none);
		girdBagCon = new GridBagConstraints();
		girdBagCon.gridx = 0;
		girdBagCon.gridy = 2;
		girdBagCon.insets = new Insets(1,0,0,0);

		girdBag.setConstraints(sendToLabel,girdBagCon);
		downPanel.add(sendToLabel);
		girdBagCon = new GridBagConstraints();
		girdBagCon.gridx =1;
		girdBagCon.gridy = 2;
		girdBagCon.anchor = GridBagConstraints.LINE_START;
		girdBag.setConstraints(combobox,girdBagCon);
		downPanel.add(combobox);
		girdBagCon = new GridBagConstraints();
		girdBagCon.gridx =2;
		girdBagCon.gridy = 2;
		girdBagCon.anchor = GridBagConstraints.LINE_END;
		girdBag.setConstraints(express,girdBagCon);
		downPanel.add(express);
		girdBagCon = new GridBagConstraints();
		girdBagCon.gridx = 3;
		girdBagCon.gridy = 2;
		girdBagCon.anchor = GridBagConstraints.LINE_START;

		girdBag.setConstraints(actionlist,girdBagCon);
		downPanel.add(actionlist);
		girdBagCon = new GridBagConstraints();
		girdBagCon.gridx = 4;
		girdBagCon.gridy = 2;
		girdBagCon.insets = new Insets(1,0,0,0);

		girdBag.setConstraints(checkbox,girdBagCon);
		downPanel.add(checkbox);
		girdBagCon = new GridBagConstraints();
		girdBagCon.gridx = 0;
		girdBagCon.gridy = 3;
		girdBag.setConstraints(messageLabel,girdBagCon);
		downPanel.add(messageLabel);
		girdBagCon = new GridBagConstraints();
		girdBagCon.gridx = 1;
		girdBagCon.gridy = 3;
		girdBagCon.gridwidth = 3;
		girdBagCon.gridheight = 1;
		girdBag.setConstraints(clientMessage,girdBagCon);
		downPanel.add(clientMessage);
		girdBagCon = new GridBagConstraints();
		girdBagCon.gridx = 4;
		girdBagCon.gridy = 3;
		girdBag.setConstraints(clientMessageButton,girdBagCon);
		downPanel.add(clientMessageButton);
		showStatus = new JTextField(35);
		showStatus.setEditable(false);
		girdBagCon = new GridBagConstraints();
		girdBagCon.gridx = 0;
		girdBagCon.gridy = 5;
		girdBagCon.gridwidth = 5;
		girdBag.setConstraints(showStatus,girdBagCon);
		downPanel.add(showStatus);
		contentPane.add(messageScrollPane,BorderLayout.CENTER);
		contentPane.add(downPanel,BorderLayout.SOUTH);

		this.addWindowListener(
				new WindowAdapter(){
					public void windowClosing(WindowEvent e){
						if(type == 1){
							DisConnect();
						}
						System.exit(0);
					}
				}
				);
	}

	public void actionPerformed(ActionEvent e) {
		Object obj = e.getSource();
		if (obj == userItem || obj == userButton) {
			UserConf userConf = new UserConf(this,userName);
			userConf.show();
			userName = userConf.userInputName;
		}
		else if (obj == connectItem || obj == connectButton) {
			ConnectConf conConf = new ConnectConf(this,ip,port);
			conConf.show();
			ip = conConf.userInputIp;
			port = conConf.userInputPort;
		}
		else if (obj == loginItem || obj == loginButton) {
			Connect();
		}
		else if (obj == logoffItem || obj == logoffButton) {
			DisConnect();
			showStatus.setText("");
		}
		else if (obj == clientMessage || obj == clientMessageButton) {
			SendMessage();
			clientMessage.setText("");
		}
		else if (obj == exitButton || obj == exitItem) {
			int j=JOptionPane.showConfirmDialog(
					this,"really?","exit",
					JOptionPane.YES_OPTION,JOptionPane.QUESTION_MESSAGE);

			if (j == JOptionPane.YES_OPTION){
				if(type == 1){
					DisConnect();
				}
				System.exit(0);
			}
		}
		else if (obj == helpItem) {
			Help helpDialog = new Help(this);
			helpDialog.show();
		}
	}
	public void Connect(){
		try{
			socket = new Socket(ip,port);
		}
		catch (Exception e){
			JOptionPane.showConfirmDialog(
					this,"cannot connect to server.\nBe sure the connection config is correct.","info",
					JOptionPane.DEFAULT_OPTION,JOptionPane.WARNING_MESSAGE);
			return;
		}
		try{
			output = new ObjectOutputStream(socket.getOutputStream());
			output.flush();
			input  = new ObjectInputStream(socket.getInputStream() );

			output.writeObject(userName);
			output.flush();

			recvThread = new ClientReceive(socket,output,input,combobox,messageShow,showStatus);
			recvThread.start();
			loginButton.setEnabled(false);
			loginItem.setEnabled(false);
			userButton.setEnabled(false);
			userItem.setEnabled(false);
			connectButton.setEnabled(false);
			connectItem.setEnabled(false);
			logoffButton.setEnabled(true);
			logoffItem.setEnabled(true);
			clientMessage.setEnabled(true);
			messageShow.append("Connect to Server "+ip+":"+port+" successfully...\n");
			type = 1;
		}
		catch (Exception e){
			System.out.println(e);
			return;
		}
	}
	public void DisConnect(){
		loginButton.setEnabled(true);
		loginItem.setEnabled(true);
		userButton.setEnabled(true);
		userItem.setEnabled(true);
		connectButton.setEnabled(true);
		connectItem.setEnabled(true);
		logoffButton.setEnabled(false);
		logoffItem.setEnabled(false);
		clientMessage.setEnabled(false);
		if(socket.isClosed()){
			return ;
		}
		try{
			output.writeObject("User Offline");
			output.flush();
			input.close();
			output.close();
			socket.close();
			messageShow.append("Disconnect to Server...\n");
			type = 0;
		}
		catch (Exception e){

		}
	}
	public void SendMessage(){
		String toSomebody = combobox.getSelectedItem().toString();
		String status  = "";
		if(checkbox.isSelected()){
			status = "whipser";
		}
		String action = actionlist.getSelectedItem().toString();
		String message = clientMessage.getText();
		if(socket.isClosed()){
			return ;
		}
		try{
			output.writeObject("Chatting Information");
			output.flush();
			output.writeObject(toSomebody);
			output.flush();
			output.writeObject(status);
			output.flush();
			output.writeObject(action);
			output.flush();
			output.writeObject(message);
			output.flush();
		}
		catch (Exception e){

		}
	}

	Image getImage(String filename) {
		URLClassLoader urlLoader = (URLClassLoader)this.getClass().
				getClassLoader();
		URL url = null;
		Image image = null;
		url = urlLoader.findResource(filename);
		image = Toolkit.getDefaultToolkit().getImage(url);
		MediaTracker mediatracker = new MediaTracker(this);
		try {
			mediatracker.addImage(image, 0);
			mediatracker.waitForID(0);
		}
		catch (InterruptedException _ex) {
			image = null;
		}
		if (mediatracker.isErrorID(0)) {
			image = null;
		}
		return image;
	}

	public static void main(String[] args) {
		ChatClient app = new ChatClient();
	}
}
