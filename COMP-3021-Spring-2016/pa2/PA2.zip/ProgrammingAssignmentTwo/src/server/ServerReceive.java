package server;

import javax.swing.*;
import java.io.*;
import java.net.*;

public class ServerReceive extends Thread {
	JTextArea textarea;
	JTextField textfield;
	JComboBox combobox;
	Node client;
	UserLinkList userLinkList;	
	public boolean isStop;	
	public ServerReceive(JTextArea textarea,JTextField textfield,
			JComboBox combobox,Node client,UserLinkList userLinkList){
		this.textarea = textarea;
		this.textfield = textfield;
		this.client = client;
		this.userLinkList = userLinkList;
		this.combobox = combobox;	
		isStop = false;
	}
	public void run(){
		sendUserList();	
		while(!isStop && !client.socket.isClosed()){
			try{
				String type = (String)client.input.readObject();
				if(type.equalsIgnoreCase("Chatting Information")){
					String toSomebody = (String)client.input.readObject();
					String status  = (String)client.input.readObject();
					String action  = (String)client.input.readObject();
					String message = (String)client.input.readObject();
					String msg = client.username 
							+" "+ action
							+ "To "
							+ toSomebody 
							+ " Say : "
							+ message
							+ "\n";
					if(status.equalsIgnoreCase("Whisper")){
						msg = " [Whisper] " + msg;
					}
					textarea.append(msg);

					if(toSomebody.equalsIgnoreCase("All Users")){
						sendToAll(msg);
					}
					else{
						try{
							client.output.writeObject("Chatting Information");
							client.output.flush();
							client.output.writeObject(msg);
							client.output.flush();
						}
						catch (Exception e){

						}	
						Node node = userLinkList.findUser(toSomebody);	
						if(node != null){
							node.output.writeObject("Chatting Information"); 
							node.output.flush();
							node.output.writeObject(msg);
							node.output.flush();
						}
					}
				}
				else if(type.equalsIgnoreCase("User Log Off")){
					Node node = userLinkList.findUser(client.username);
					userLinkList.delUser(node);
					String msg = "User " + client.username + " offline\n";
					int count = userLinkList.getCount();
					combobox.removeAllItems();
					combobox.addItem("All Users");
					int i = 0;
					while(i < count){
						node = userLinkList.findUser(i);
						if(node == null) {
							i ++;
							continue;
						} 
						combobox.addItem(node.username);
						i++;
					}
					combobox.setSelectedIndex(0);
					textarea.append(msg);
					textfield.setText("Online Users " + userLinkList.getCount());	
					sendToAll(msg);
					sendUserList();
					break;
				}
			}
			catch (Exception e){

			}
		}
	}


	public void sendToAll(String msg){
		int count = userLinkList.getCount();	
		int i = 0;
		while(i < count){
			Node node = userLinkList.findUser(i);
			if(node == null) {
				i ++;
				continue;
			}	
			try{
				node.output.writeObject("Chatting Information");
				node.output.flush();
				node.output.writeObject(msg);
				node.output.flush();
			}
			catch (Exception e){

			}	
			i++;
		}
	}


	public void sendUserList(){
		String userlist = "";
		int count = userLinkList.getCount();
		int i = 0;
		while(i < count){
			Node node = userLinkList.findUser(i);
			if(node == null) {
				i ++;
				continue;
			}	
			userlist += node.username;
			userlist += '\n';
			i++;
		}	
		i = 0;
		while(i < count){
			Node node = userLinkList.findUser(i);
			if(node == null) {
				i ++;
				continue;
			} 	
			try{
				node.output.writeObject("User List");
				node.output.flush();
				node.output.writeObject(userlist);
				node.output.flush();
			}
			catch (Exception e){

			}
			i++;
		}
	}
}
