package examples.jsp.notes;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import java.io.PrintWriter;
import java.io.IOException;
import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.util.Vector;
import com.sun.jsp.runtime.*;
import java.beans.*;
import com.sun.jsp.JspException;


public class ReuseBean_jsp_1 extends HttpJspBase {

    static char[][] _jspx_html_data = null;
    // begin [file="D:\\201\\jswdk-1.0.1\\examples\\jsp\\notes\\ReuseBean.jsp";from=(18,0);to=(18,55)]
    // end

    public ReuseBean_jsp_1( ) {
    }

    private static boolean _jspx_inited = false;

    public final void _jspx_init() throws JspException {
        ObjectInputStream oin = null;
        int numStrings = 0;
        try {
            FileInputStream fin = new FileInputStream("work\\%3A8010%2Fexamples\\examples.jsp.notesReuseBean.dat");
            oin = new ObjectInputStream(fin);
            _jspx_html_data = (char[][]) oin.readObject();
        } catch (Exception ex) {
            throw new JspException("Unable to open data file");
        } finally {
            if (oin != null)
                try { oin.close(); } catch (IOException ignore) { }
        }
    }

    public void _jspService(HttpServletRequest request, HttpServletResponse  response)
        throws IOException, ServletException {

        JspFactory _jspxFactory = null;
        PageContext pageContext = null;
        HttpSession session = null;
        ServletContext application = null;
        ServletConfig config = null;
        JspWriter out = null;
        Object page = this;
        String  _value = null;
        try {

            if (_jspx_inited == false) {
                _jspx_init();
                _jspx_inited = true;
            }
            _jspxFactory = JspFactory.getDefaultFactory();
            response.setContentType("text/html");
            pageContext = _jspxFactory.getPageContext(this, request, response,
			"", true, 8192, true);

            application = pageContext.getServletContext();
            config = pageContext.getServletConfig();
            session = pageContext.getSession();
            out = pageContext.getOut();

            out.print(_jspx_html_data[0]);
            // begin [file="D:\\201\\jswdk-1.0.1\\examples\\jsp\\notes\\ReuseBean.jsp";from=(18,0);to=(18,55)]
                jspBean201.SimpleBean test = null;
                boolean _jspx_specialtest  = false;
                 synchronized (pageContext) {
                    test= (jspBean201.SimpleBean)
                    pageContext.getAttribute("test",PageContext.PAGE_SCOPE);
                    if ( test == null ) {
                        _jspx_specialtest = true;
                        try {
                            test = (jspBean201.SimpleBean) Beans.instantiate(getClassLoader(), "jspBean201.SimpleBean");
                        } catch (Exception exc) {
                             throw new ServletException (" Cannot create bean of class "+"jspBean201.SimpleBean");
                        }
                        pageContext.setAttribute("test", test, PageContext.PAGE_SCOPE);
                    }
                 } 
                if(_jspx_specialtest == true) {
            // end
            // begin [file="D:\\201\\jswdk-1.0.1\\examples\\jsp\\notes\\ReuseBean.jsp";from=(18,0);to=(18,55)]
                }
            // end
            out.print(_jspx_html_data[1]);
            // begin [file="D:\\201\\jswdk-1.0.1\\examples\\jsp\\notes\\ReuseBean.jsp";from=(19,0);to=(21,37)]
                test.setMessage("Hello WWW");
            // end
            out.print(_jspx_html_data[2]);
            // begin [file="D:\\201\\jswdk-1.0.1\\examples\\jsp\\notes\\ReuseBean.jsp";from=(24,0);to=(24,50)]
                out.print(JspRuntimeLibrary.toString(test.getMessage()));
            // end
            out.print(_jspx_html_data[3]);

        } catch (Throwable t) {
            if (out.getBufferSize() != 0)
                out.clear();
            throw new JspException("Unknown exception: ", t);
        } finally {
            out.flush();
            _jspxFactory.releasePageContext(pageContext);
        }
    }
}
