
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class HelloAgainServlet extends HttpServlet
{
     public void doGet(HttpServletRequest req,
                  HttpServletResponse resp)
                  throws ServletException, IOException
     {
		resp.setContentType("text/html");

		// get session if exists, does not create
		HttpSession session = req.getSession(false);


		PrintWriter out = resp.getWriter();
		out.println("<HTML><BODY><h1>Count me!</h1><HR>");

		if (session == null)
		{	out.println("Welcome, I don't believe we've met!");

			// create session
			session = req.getSession(true);
			++count;
			out.println("I think of you as "+ session.getId());
		}
		else
		{	// int n=((Integer)session.getValue("Count")).intValue();

			out.println("You again? " + session.getId());
			out.println("that makes " + (++count) + " visits!");
		}
		out.println("</BODY></HTML>");
		out.close();
    }
	int count;
}


