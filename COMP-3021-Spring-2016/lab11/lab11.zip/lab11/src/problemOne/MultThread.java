package problemOne;

public class MultThread extends Thread {
	private int n;  // n*n matrix
	private int i, j; // row, column

	public MultThread(int size, int ii, int jj) {
		n = size;
		i = ii;
		j = jj;
	}

	public void run() {
		// each thread calculates C[i][j]
		/* PLACE YOUR CODE HERE */

	}
}
