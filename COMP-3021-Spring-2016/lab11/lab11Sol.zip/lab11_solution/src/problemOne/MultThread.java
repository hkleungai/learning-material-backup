package problemOne;

public class MultThread extends Thread {
    private int n;  // n*n matrix
    private int i, j; // row, column
 
    public MultThread(int size, int ii, int jj) {
            n = size;
            i = ii;
            j = jj;
    }
 
    public void run() {
            Matrix.C[i][j] = 0;
            for(int x = 0; x < n; x++)
                Matrix.C[i][j] += Matrix.A[i][x] * Matrix.B[x][j];
    }
}
