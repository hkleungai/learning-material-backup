package problemOne;

import java.util.Random;

//Develop an execution driven simulator for a multiprocessor that solves a 3x3 matrix multiply (i.e., AxB=C, where A,B,C are 3x3 matrixes) following these steps:
//
//1. define A, B, C as instance variables using a suitable data-structure
//2. set the values in the constructor
//3. create a thread for every processor so that each processor will compute one element of the resulting matrix.
//4. in each thread calculate one element (i.e., multiply the elements of  one raw from A and one column from B, and add the results to get the value of C[i.j]).
//5. the main thread should wait until all the other threads are done and then print the matrix C


public class Matrix {
    public static int[][] A, B, C;
    public int n;
 
    public void printMatrix(int[][] M) {
            for(int i = 0; i < n; i++) {
                for(int j = 0; j < n; j++)
                        System.out.print("\t"+M[i][j]);
                System.out.println();
            }
    }
 
    public Matrix() {
            n = 3;
            A = new int[n][n];
            B = new int[n][n];
            C = new int[n][n];
            Random r = new Random();
            for(int i = 0; i < n; i++)
                for(int j = 0; j < n; j++) {
                        A[i][j] = i+j; // keep numbers below 10 :)
                        B[i][j] = i-j;
                }
    }
 
    public void doWork() {
            MultThread[][] mt = new MultThread[n][n];
 
            for(int i = 0; i < n; i++)
                for(int j = 0; j < n; j++) {
                        mt[i][j] = new MultThread(3, i, j);
                        mt[i][j].start();
                }
 
            try {
            for(int i = 0; i < n; i++)
                for(int j = 0; j < n; j++)
                        mt[i][j].join();
            } catch(InterruptedException ie) {}
 
            System.out.println("\nA =");
            printMatrix(A);
            System.out.println("\nB =");
            printMatrix(B);
            System.out.println("\nC =");
            printMatrix(C);
    }
 
    public static void main(String args[]) {
            Matrix m = new Matrix();
            m.doWork();
    }
}
