package p2;

import java.util.*;

/**
 * The class models a product catalog. This class implements the interface
 * Iterable<Product> to being able to iterate through the products using the
 * for-each loop.
 * 
 * @version 1.1.0
 * @see Product
 */
public class Catalog implements Iterable<Product> {
	private ArrayList<Product> products;
	/**
	 * Creates the collection products, which is initially empty.
	 */
	public Catalog() {
		products = new ArrayList<Product>();
	}

	/**
	 * Adds the specified product to the collection products.
	 * 
	 * @param product
	 *            new product to be added.
	 */
	public void addProduct(Product product) {
		products.add(product);
	}

	/**
	 * Returns an iterator over the instances in the collection products.
	 * 
	 * return an Iterator of Product
	 */
	public Iterator<Product> iterator() {
		return products.iterator();
	}

	/**
	 * Returns a reference to the Product instance with the specified code.
	 * Returns null if there are no products in the catalog with the specified
	 * code.
	 * 
	 * @param code
	 *            the specified code of the product being looking for.
	 * @return Returns a reference to the Product instance with the specified
	 *         code.Returns null if there are no products in the catalog with
	 *         the specified code.
	 */
	public Product getProduct(String code) {
		for (Iterator<Product> i = iterator(); i.hasNext();) {
			Product product = i.next();
			if (product.getCode().equals(code))
				return product;
		}
		return null;
	}

	/**
	 * Returns the number of instances in the collection products.
	 * 
	 * @return Returns the number of instances in the collection products.
	 */
	public int getNumberOfProducts() {
		return products.size();
	}
}
