package p2;


public class Milk extends Product{
	private String origin;
	private String heat;
	private String flavor;
	private String aroma;
	private String acidity;
	private String body;
	public Milk(String initialCode , String initialDescription , double initialPrice , String initialOrigin , String initialHeat , String initialFlavor , String initialAroma , String initialAcidity , String initialBody){
		super(initialCode , initialDescription , initialPrice);
		this.origin = initialOrigin;
		this.heat = initialHeat;
		this.flavor = initialFlavor;
		this.aroma = initialAroma;
		this.acidity = initialAcidity;
		this.body = initialBody;
	}
	public String getOrigin(){
		return this.origin;
	}
	public String getHeat(){
		return this.heat;
	}
	public String getFlavor(){
		return this.flavor;
	}
	public String getAroma(){
		return this.aroma;
	}
	public String getAcidity(){
		return this.acidity;
	}
	public String getBody(){
		return this.body;
	}
	public String toString(){
		return super.toString()+"_"+getOrigin()+"_"+getHeat()+"_"+getFlavor()+"_"+getAroma()+"_"+getAcidity()+"_"+getBody();
	}
}