package p1;
public interface VHS {
	public String getFormat();
	public String getLanguage();
}
