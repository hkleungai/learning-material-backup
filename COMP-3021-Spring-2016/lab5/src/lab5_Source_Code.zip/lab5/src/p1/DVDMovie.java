package p1;
public class DVDMovie extends Movie implements DVD{
	private int regionCode;
	private String[] audioTracks;
	private String[] subtitles;
	
	public DVDMovie(String title, String[] starring, 
			String director, int regionCode2, 
			String[] audioTracks2,
			String[] subtitles2) {
		super(title, starring, director);
		// TODO Auto-generated constructor stub
		this.regionCode = regionCode2;
		this.audioTracks = audioTracks2;
		this.subtitles = subtitles2;
	}
	public int getRegionCode(){
		return regionCode;
	}
	public String[] getAudioTracks(){
		return this.audioTracks;
	}
	public String[] getSubtitles(){
		return this.subtitles;
	}
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return super.getTitle()+","+this.regionCode;
	}
}
