package p1;
public class VHSMovie extends Movie implements VHS {
	private String format;
	private String language;
	public VHSMovie(String title, String[] starring, 
			String director, String format2, 
			String language2) {
		// TODO Auto-generated constructor stub
		super(title, starring, director);
		this.format = format2;
		this.language = language2;
	}
	public String getFormat(){
		return format;
	}
	public String getLanguage(){
		return language;
	}
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return super.getTitle()+","+this.format+","+this.language;
	}
}
