package p1;

public interface DVD {
	public int getRegionCode(); 
	public String[] getAudioTracks();
	public String[] getSubtitles();
}
