package p2;

/**
 * Modify this file accordingly.
 * @author
 *
 */
public abstract class Shape {
	/**
	 * place your code here
	 */
	
	public abstract String getName();
	public abstract double getArea();
	
}
