package p2;

/**
 * Modify this file accordingly
 * @author
 *
 */
public class Rectangle extends Shape {
	// Properties of the class... 
	public double width;
	public double length;
	
	// Constructor of the class...
	public Rectangle(double aWidth, double aLength) {
		width = aWidth;
		length = aLength;
	}
	// Methods of the class... 
	public String getName() {
		/**
		 * place your code here
		 */
		return "Rectangle";
	}
	
	public double getArea() {
		/**
		 * place your code here
		 */
		return this.length*this.width;
	}
}
