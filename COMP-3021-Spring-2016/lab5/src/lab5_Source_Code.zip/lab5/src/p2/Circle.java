package p2;

/**
 * Modify this file accordingly
 * @author
 *
 */
public class Circle extends Shape {
	// Properties of the class... 
	public double radius;
	
	// Constructor of the class...
	public Circle(double aRadius) {
		radius = aRadius; 
	}
	// Methods of the class... 
	public String getName() {
		/**
		 * place your code here
		 */
		return "Circle";

	}
	
	public double getArea() {
		/**
		 * place your code here
		 */
		return Math.PI*this.radius*this.radius;
	}
}
