public class String_demo {

	 

         public static void main(String args[])

         {

             int ascii[] = { 65, 66, 67, 68};

             String s = new String(ascii, 1, 3);

             System.out.println(s);

         }

   
	
}
