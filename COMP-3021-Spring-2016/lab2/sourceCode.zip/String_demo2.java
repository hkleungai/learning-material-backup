class String_demo2 {
	 
    public static void main(String args[])

    {

        char chars[] = {'a', 'b', 'c'};

        String s = new String(chars);

        String s1 = "abcd";

        int len1 = s1.length();

        int len2 = s.length();

        System.out.println(len1 + " " + len2);

    }

}