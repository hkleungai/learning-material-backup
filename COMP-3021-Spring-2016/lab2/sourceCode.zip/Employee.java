import java.util.Date;

public class Employee {
	private String firstName, lastName;
	private Date hireDate;

	public Employee(String fn, String ln) {
		this(fn, ln, new Date());
		System.out.println("Inside first constructor");
	}
	
	public Employee(String fn, String ln, Date hd) {
	 	System.out.println("Inside second constructor");
	 	firstName = fn;
		lastName = ln;
		hireDate = hd;
	}
	public static void main(String args[])
	{
		Employee e = new Employee("Beetle", "Bailey");
	}
}
