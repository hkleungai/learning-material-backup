/*-- Stack.cpp-------------------------------------------------------------
 This file implements Stack member functions.
 --------------------------------------------------------------------------*/

#include <iostream>
using namespace std;

#include "Stack_ll.h"

//--- Definition of Stack constructor
Stack::Stack()
{
    //To Do: intialize the member in class Stack
    // ...
}

//--- Definition of empty()
bool Stack::empty() const
{
	//To DO: judge whether the linked list is empty
	// ...
}

//--- Definition of push()
void Stack::push(const int& value)
{
    //TO DO: new pin is joining to the linked list
    //       update the pointers of myTop
    // ...
}

//--- Definition of display()
void Stack::display(ostream& out) const
{
    //To DO: begin at myTop, print the pinID in the linked list by 'out'
    // ...
}

//--- Definition of topID()
int Stack::topID() const
{
    //To Do: return the pinID of myTop if the stack is non-empty.
	// ...
	if( ) //condition
	{
	    // ...

	}
	else
	{
	    cerr << "*** Stack is empty -- returning garbage value ***\n";
		int garbage;
		return garbage;
	}
}

//--- Definition of pop()
void Stack::pop()
{
    // TO DO: delete the head of "linked list" stack, and update the location of myTop
    // ...
	if () //condition
	{
	    // ...

	}
	else
		cerr << "*** Stack is empty -- can't remove a value ***\n";
}
