#include <iostream>

#include "Game.h"
using namespace std;


int main() {
	Game game("game.txt");
	game.start();

	return 0;
}
