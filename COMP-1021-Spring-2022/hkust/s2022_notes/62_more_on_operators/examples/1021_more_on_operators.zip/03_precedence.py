"""
This shows three examples explaining the operator precedence when brackets
are not used in the expression.
"""

x = 17 / 2 * 3 + 2
print(x)

x = 19 % 4 + 15 / 2 * 3
print(x)

x = 17 / 2 % 2 * 3**3
print(x)
