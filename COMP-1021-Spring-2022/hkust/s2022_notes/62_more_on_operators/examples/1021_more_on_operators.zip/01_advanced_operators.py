"""
This example shows the use of advanced operators **, // and -.
"""

# Using the power operator **
print(2 ** 2)
print(3 ** 2)

# Using the integer division operator //
print(3 / 3, 3 // 3)
print(4 / 3, 4 // 3)
print(5 / 3, 5 // 3)
print(6 / 3, 6 // 3)
print(7 / 3, 7 // 3)
print(8 / 3, 8 // 3)

# Using the negation operator -
x = 10
print(-x)
