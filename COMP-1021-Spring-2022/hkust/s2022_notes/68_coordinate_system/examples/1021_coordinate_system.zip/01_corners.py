import turtle

turtle.setworldcoordinates(0, 0, 1, 1)
turtle.up()
turtle.goto(0, 0)
turtle.dot(100)
turtle.goto(0, 1)
turtle.dot(100)
turtle.goto(1, 1)
turtle.dot(100)
turtle.goto(1, 0)
turtle.dot(100)

turtle.done()
