import turtle

turtle.color("purple")
turtle.width(10)

side=0
while side < 5:
    turtle.forward(200)
    turtle.right(144)
    side = side + 1

turtle.done()
