count = 10
while count >= 1:
    print(count)
    count = count - 1
