count = 1
while count <= 10:
    print(count)
    count = count + 1
