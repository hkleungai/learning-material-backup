object ChainedMatch {
  0 match {
    case x => x 
  } match {
    case 42 => "Yeah"
  }
}