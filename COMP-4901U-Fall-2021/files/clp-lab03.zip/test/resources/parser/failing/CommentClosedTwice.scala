/* This comment is closed twice,
which should not be interpreted as a single closed comment

*/*/