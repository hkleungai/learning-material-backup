abstract Boolean
case class def else error extends false if Int match object String
true Unit val
