object LetError1 {
  def test(): Int = {
    val x: Int = 1;
    false
  }
}
