object ArithError1 {
  1 + true
}
