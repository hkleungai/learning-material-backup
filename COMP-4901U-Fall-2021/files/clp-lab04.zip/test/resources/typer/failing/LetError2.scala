object LetError2 {
  def test(): Int = {
    val x: Int = false;
    2
  }
}
