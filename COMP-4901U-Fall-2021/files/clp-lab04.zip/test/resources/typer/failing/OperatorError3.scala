object OperatorError {
    val str: String = !true;
    str
}
