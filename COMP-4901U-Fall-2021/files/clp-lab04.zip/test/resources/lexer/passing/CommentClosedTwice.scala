/* This comment is closed twice,
which should be an error:

*/*/