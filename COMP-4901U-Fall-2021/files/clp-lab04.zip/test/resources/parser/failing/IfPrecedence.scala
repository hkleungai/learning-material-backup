object IfPrecedence {
  if (true) { 1 } else { 0 } + 42
}