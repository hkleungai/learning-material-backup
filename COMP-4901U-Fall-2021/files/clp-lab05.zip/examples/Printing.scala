object Printing {
  Std.printInt(0); Std.printInt(-222); Std.printInt(42);
  Std.printBoolean(true); Std.printBoolean(false);
  Std.printString(Std.digitToString(0));
  Std.printString(Std.digitToString(5));
  Std.printString(Std.digitToString(9));
  Std.printString(Std.intToString(0));
  Std.printString(Std.intToString(-111));
  Std.printString(Std.intToString(22));
  Std.printString("Hello " ++ "world!");
  Std.printString("" ++ "")
}
