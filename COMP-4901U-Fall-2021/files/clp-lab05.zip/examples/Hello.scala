object Hello {
  Std.printString("Hello " ++ "world!")
}
