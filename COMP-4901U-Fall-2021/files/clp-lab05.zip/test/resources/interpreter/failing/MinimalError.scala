object MinimalError {
	error("")
}
