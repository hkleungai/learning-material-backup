object OperatorError {
    val str: String = 1 + 1;
    str
}
