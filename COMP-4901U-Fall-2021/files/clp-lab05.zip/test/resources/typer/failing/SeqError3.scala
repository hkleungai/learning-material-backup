object SeqError {
  val x: Boolean = (true; 2);
  0
}
