object Args {
  def foo(i: Int): Int = { foo(1, 2) }
}
