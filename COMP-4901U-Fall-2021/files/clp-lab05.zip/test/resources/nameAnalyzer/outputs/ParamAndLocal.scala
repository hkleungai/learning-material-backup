object ParamAndLocal_0 {
  def foo_0(i_0: Int): Int = {
    val i_1: Int =
      (i_0 + 1);
    i_1
  }
}

