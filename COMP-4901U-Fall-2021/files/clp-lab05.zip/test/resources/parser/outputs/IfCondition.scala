object IfCondition {
  (if((
    val x: Boolean =
      true;
    x
  )) {
    1
  } else {
    2
  })
}
