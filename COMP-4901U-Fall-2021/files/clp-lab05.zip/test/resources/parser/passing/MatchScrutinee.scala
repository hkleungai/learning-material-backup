object IfMatch {
  if (true) { 1 } else { 2 } match {
    case 1 => true
    case 2 => false
  }
}
