//source: Chau Ming Kit
//date: 23/9/2000

#include <iostream>
#include <string>
#include "List.h"
using namespace std;

extern string *arrCity;
extern int intNumCity;
extern void ResBuild();

int main()
{
	string strCity;
	int intCost;
	int intTotal;
	List list;

	ResBuild();
	list.Init(arrCity, intNumCity);
	list.Insert("Seoul");
	list.Delete("Beijing");
	list.Delete("Athens");

	cout << "List Accessing Problem - Transpose\n";
	cout << "Type Cities to Access and end with '#' (q to exit)\n";
	cout << " e.g. London HongKong Paris ... HongKong #\n\n";

	while (true) {
		intCost = -1;
		intTotal = 0;

		list.Print();
		cout << "\nCities > ";

		while(cin >> strCity)
		{
			//Exit
			if (strCity == "q" || strCity == "#")
				break;
			intCost = list.Access(strCity);
			if (intCost != -1) {
				intTotal = intTotal + intCost;
			}
		}

		if (intTotal == 0)
			return 0;
		cout << "Cost:" << intTotal << "\n\n";

		if (strCity == "q")
			return 0;
	}
	return 0;
}