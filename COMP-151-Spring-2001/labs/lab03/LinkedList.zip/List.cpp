//source: Chau Ming Kit
//date: 23/9/2000

#include "List.h"

List::List()
{
	m_Head = NULL;
}

List::~List()
{
	sCity *ptrTemp;
	while (m_Head != NULL)
	{
		ptrTemp = m_Head;
		m_Head = m_Head->ptrNext;
		delete ptrTemp;
	}
}

void List::Init(string arrCity[], int intCity)
{
	int i;
	for(i=0; i<intCity; i++)
	{
		Insert(arrCity[i]);
	}
}

void List::Print()
{
	sCity *ptrTemp;
	ptrTemp = m_Head;
	while(ptrTemp != NULL)
	{
		cout << ptrTemp->strCity << ", ";
		ptrTemp = ptrTemp->ptrNext;
	}
}

int List::Access(string strCity)
{
	int count;
	sCity *ptrTemp;

	if (m_Head == NULL)		// empty list
		return -1;
	else {
		if (m_Head->strCity == strCity) {
			return 1;
		}
		else {
			count = 1;
			ptrTemp = m_Head;
			while (ptrTemp->ptrNext != NULL)
			{
				count++;
				if (ptrTemp->ptrNext->strCity == strCity) {
					return count;
				}
				ptrTemp = ptrTemp->ptrNext;
			}
		}
		return -1;
	}
}

bool List::Insert(string strCity)
{
	if (strCity == "q") {
		cerr << "invalid city name\n";
		return false;
	}

	if (m_Head == NULL) {	// empty list
		m_Head = new sCity;
		m_Head->strCity = strCity;
		m_Head->ptrNext = NULL;
	}
	else {
		//Create new node
		sCity *ptrCity;
		ptrCity = new sCity;
		ptrCity->strCity = strCity;
		ptrCity->ptrNext = NULL;

		sCity *ptrTemp;
		ptrTemp = m_Head;
		while (ptrTemp->ptrNext != NULL)
		{
			if (ptrTemp->strCity == strCity)	// discard duplicated node
				return false;
			ptrTemp = ptrTemp->ptrNext;
		}
		if (ptrTemp->strCity == strCity)	// checking the last node
			return false;

		//Append to last
		ptrTemp->ptrNext = ptrCity;
	}
	return true;
}
