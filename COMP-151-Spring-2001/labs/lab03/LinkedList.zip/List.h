//source: Chau Ming Kit
//date: 23/9/2000

#ifndef LIST_H
#define LIST_H

#include <iostream>
#include <string>
using namespace std;

class List {
private:
	struct sCity {
		string strCity;
		sCity* ptrNext;
	};
	sCity* m_Head;

	bool Insert(string strCity);

public:
	List();
	~List();

	void Init(string arrCity[], int intCity);
	void Print();

	int Access(string strCity);
};

#endif