

public class SimpleProgram {
	//check if input a is not smaller than input b
	public static boolean compare(int a, int b){
		if(a >= b){
			return true;
		}
		else{
			return false;
		}
	}
}
