

public class ClassExampleWithNoFailure {
	public static int twice(int x) {
		return x+x;
	}
	public static int foo(int x, int y) {
		  int z = twice(x);
		  if (z == -144 && y > 20) {
			System.out.println("Trigger failure branch"); 
		    assert(false);  // assert failure 
		  }
		  return y*z;
		}
}
