

public class ClassExampleWithFailure {
	public static int sq(int x) {
		return x*x;
	}
	public static int foo(int x, int y) {
		  int z = sq(x);
		  if (y> 20 && z == 144) {
			System.out.println("Trigger failure branch");
		    assert(false);  // assert failure 
		  }
		  return y*z;
		}
}
