import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class ClassExampleWithNoFailureRegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        int int2 = ClassExampleWithNoFailure.foo((-44800000), 880803840);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        int int2 = ClassExampleWithNoFailure.foo(560, (-1432125440));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1957691392) + "'", int2 == (-1957691392));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        int int2 = ClassExampleWithNoFailure.foo((-1451098112), 91750400);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        int int2 = ClassExampleWithNoFailure.foo((-664797184), (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 184549376 + "'", int2 == 184549376);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        int int1 = ClassExampleWithNoFailure.twice((-301989888));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-603979776) + "'", int1 == (-603979776));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test006");
        int int2 = ClassExampleWithNoFailure.foo(536870912, 671088640);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test007");
        int int1 = ClassExampleWithNoFailure.twice(1714421760);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-866123776) + "'", int1 == (-866123776));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        int int2 = ClassExampleWithNoFailure.foo(458752000, 310378496);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        int int1 = ClassExampleWithNoFailure.twice(99328);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 198656 + "'", int1 == 198656);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        int int2 = ClassExampleWithNoFailure.foo((-1792000000), 86528);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1761607680 + "'", int2 == 1761607680);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        int int1 = ClassExampleWithNoFailure.twice(1703936000);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-887095296) + "'", int1 == (-887095296));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        int int2 = ClassExampleWithNoFailure.foo(409600000, 3476480);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-268435456) + "'", int2 == (-268435456));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        int int1 = ClassExampleWithNoFailure.twice((-11200000));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-22400000) + "'", int1 == (-22400000));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test014");
        int int2 = ClassExampleWithNoFailure.foo((-1024000), 977403904);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2147483648) + "'", int2 == (-2147483648));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        int int2 = ClassExampleWithNoFailure.foo((-1872887808), 939524096);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        int int1 = ClassExampleWithNoFailure.twice((-1416101888));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1462763520 + "'", int1 == 1462763520);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        int int2 = ClassExampleWithNoFailure.foo(1954807808, (-71680000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test018");
        int int1 = ClassExampleWithNoFailure.twice((-2079850496));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 135266304 + "'", int1 == 135266304);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test019");
        int int2 = ClassExampleWithNoFailure.foo(872415232, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        int int2 = ClassExampleWithNoFailure.foo(0, (-28672000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        int int2 = ClassExampleWithNoFailure.foo(1738240, 4);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13905920 + "'", int2 == 13905920);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test022");
        int int2 = ClassExampleWithNoFailure.foo(1415315456, 1761607680);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        int int2 = ClassExampleWithNoFailure.foo(409600, (-1677721600));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test024");
        int int2 = ClassExampleWithNoFailure.foo(40, 179200);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14336000 + "'", int2 == 14336000);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        int int2 = ClassExampleWithNoFailure.foo(1502347264, 25600);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1610612736 + "'", int2 == 1610612736);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        int int1 = ClassExampleWithNoFailure.twice((-444596224));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-889192448) + "'", int1 == (-889192448));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        int int2 = ClassExampleWithNoFailure.foo(64, (-1342177280));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        int int1 = ClassExampleWithNoFailure.twice((-35651584));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-71303168) + "'", int1 == (-71303168));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        int int2 = ClassExampleWithNoFailure.foo(367001600, 444596224);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        int int2 = ClassExampleWithNoFailure.foo(0, (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test031");
        int int2 = ClassExampleWithNoFailure.foo((-2141978624), 440401920);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        int int2 = ClassExampleWithNoFailure.foo(1194852352, 400);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1895825408) + "'", int2 == (-1895825408));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        int int1 = ClassExampleWithNoFailure.twice(605696000);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1211392000 + "'", int1 == 1211392000);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        int int2 = ClassExampleWithNoFailure.foo(880803840, (-28672000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        int int2 = ClassExampleWithNoFailure.foo(346112, 1217134592);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1073741824) + "'", int2 == (-1073741824));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        int int2 = ClassExampleWithNoFailure.foo((-1744830464), 1514240);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        int int2 = ClassExampleWithNoFailure.foo(10, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        int int2 = ClassExampleWithNoFailure.foo((-2147483648), (-163840000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        int int2 = ClassExampleWithNoFailure.foo((-2867200), (-60569600));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 603979776 + "'", int2 == 603979776);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        int int1 = ClassExampleWithNoFailure.twice(1211039744);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1872887808) + "'", int1 == (-1872887808));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        int int2 = ClassExampleWithNoFailure.foo((-80), 716800);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-114688000) + "'", int2 == (-114688000));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        int int1 = ClassExampleWithNoFailure.twice((-1056964608));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-2113929216) + "'", int1 == (-2113929216));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        int int2 = ClassExampleWithNoFailure.foo(294912000, (-131072000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test044");
        int int2 = ClassExampleWithNoFailure.foo((-81920), 138444800);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1073741824) + "'", int2 == (-1073741824));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        int int2 = ClassExampleWithNoFailure.foo(805306368, 100663296);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        int int2 = ClassExampleWithNoFailure.foo((int) (byte) -1, (-1792000000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-710967296) + "'", int2 == (-710967296));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        int int1 = ClassExampleWithNoFailure.twice(20480);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 40960 + "'", int1 == 40960);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        int int2 = ClassExampleWithNoFailure.foo(416, (-1771896832));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1044381696) + "'", int2 == (-1044381696));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test049");
        int int2 = ClassExampleWithNoFailure.foo((-71303168), (-202530816));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test050");
        int int2 = ClassExampleWithNoFailure.foo(1799356416, 183500800);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        int int2 = ClassExampleWithNoFailure.foo((-56000), (-2079850496));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1409286144 + "'", int2 == 1409286144);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        int int1 = ClassExampleWithNoFailure.twice(1194852352);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1905262592) + "'", int1 == (-1905262592));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        int int2 = ClassExampleWithNoFailure.foo(405061632, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        int int2 = ClassExampleWithNoFailure.foo(1514240, 637534208);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        int int2 = ClassExampleWithNoFailure.foo(1, 2013265920);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-268435456) + "'", int2 == (-268435456));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        int int2 = ClassExampleWithNoFailure.foo((-1872183296), 1502347264);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        int int2 = ClassExampleWithNoFailure.foo((-740130816), 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1917714432) + "'", int2 == (-1917714432));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        int int2 = ClassExampleWithNoFailure.foo((-696254464), (-12800));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        int int1 = ClassExampleWithNoFailure.twice(64);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 128 + "'", int1 == 128);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        int int2 = ClassExampleWithNoFailure.foo((-573440000), 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1146880000) + "'", int2 == (-1146880000));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        int int1 = ClassExampleWithNoFailure.twice(1638400000);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1018167296) + "'", int1 == (-1018167296));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        int int2 = ClassExampleWithNoFailure.foo(1600, (-1018167296));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1744830464 + "'", int2 == 1744830464);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        int int2 = ClassExampleWithNoFailure.foo(716800000, (-1196425216));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        int int2 = ClassExampleWithNoFailure.foo((-60569600), 560);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 881524736 + "'", int2 == 881524736);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test065");
        int int1 = ClassExampleWithNoFailure.twice((-2085617664));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 123731968 + "'", int1 == 123731968);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test066");
        int int1 = ClassExampleWithNoFailure.twice((-71303168));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-142606336) + "'", int1 == (-142606336));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test067");
        int int1 = ClassExampleWithNoFailure.twice((-4480));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-8960) + "'", int1 == (-8960));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        int int2 = ClassExampleWithNoFailure.foo(1120000, (-1023410176));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        int int2 = ClassExampleWithNoFailure.foo(37636, 1552);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 116822144 + "'", int2 == 116822144);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test070");
        int int2 = ClassExampleWithNoFailure.foo((-931840000), (-40));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1532755968 + "'", int2 == 1532755968);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        int int1 = ClassExampleWithNoFailure.twice(184549376);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 369098752 + "'", int1 == 369098752);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        int int1 = ClassExampleWithNoFailure.twice(198656);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 397312 + "'", int1 == 397312);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test073");
        int int1 = ClassExampleWithNoFailure.twice((-1140850688));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2013265920 + "'", int1 == 2013265920);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        int int1 = ClassExampleWithNoFailure.twice(1409286144);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1476395008) + "'", int1 == (-1476395008));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        int int2 = ClassExampleWithNoFailure.foo(812646400, 139059200);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        int int2 = ClassExampleWithNoFailure.foo((-1924661248), 31784960);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test077");
        int int1 = ClassExampleWithNoFailure.twice(570425344);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1140850688 + "'", int1 == 1140850688);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        int int2 = ClassExampleWithNoFailure.foo(22020096, (-664797184));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        int int2 = ClassExampleWithNoFailure.foo((int) (byte) 0, (-8691200));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test080");
        int int2 = ClassExampleWithNoFailure.foo(1207959552, 1506803712);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        int int1 = ClassExampleWithNoFailure.twice((-11796480));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-23592960) + "'", int1 == (-23592960));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        int int1 = ClassExampleWithNoFailure.twice((-57344000));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-114688000) + "'", int1 == (-114688000));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        int int1 = ClassExampleWithNoFailure.twice(1552000);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3104000 + "'", int1 == 3104000);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test084");
        int int2 = ClassExampleWithNoFailure.foo(99328, (-12416000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1201668096) + "'", int2 == (-1201668096));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test085");
        int int2 = ClassExampleWithNoFailure.foo(31784960, 637534208);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        int int2 = ClassExampleWithNoFailure.foo(1811939328, 198656);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        int int2 = ClassExampleWithNoFailure.foo(10, 15520);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 310400 + "'", int2 == 310400);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test088");
        int int2 = ClassExampleWithNoFailure.foo(1056964608, (-1089339392));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        int int1 = ClassExampleWithNoFailure.twice((-1853882368));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 587202560 + "'", int1 == 587202560);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test090");
        int int2 = ClassExampleWithNoFailure.foo(20480, 442499072);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        int int2 = ClassExampleWithNoFailure.foo((-947912704), 1415315456);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        int int2 = ClassExampleWithNoFailure.foo(5824000, 1619001344);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        int int2 = ClassExampleWithNoFailure.foo((-71303168), (-1044381696));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test094");
        int int1 = ClassExampleWithNoFailure.twice(1761607680);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-771751936) + "'", int1 == (-771751936));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        int int1 = ClassExampleWithNoFailure.twice((-1863680000));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 567607296 + "'", int1 == 567607296);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        int int2 = ClassExampleWithNoFailure.foo(1732247552, 179200000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test097");
        int int1 = ClassExampleWithNoFailure.twice((-2085093376));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 124780544 + "'", int1 == 124780544);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        int int2 = ClassExampleWithNoFailure.foo(1366294528, (-2085093376));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test099");
        int int2 = ClassExampleWithNoFailure.foo((-2001207296), (-2141978624));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        int int1 = ClassExampleWithNoFailure.twice((-1549271040));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1196425216 + "'", int1 == 1196425216);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        int int2 = ClassExampleWithNoFailure.foo((-14000), 327680000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-989855744) + "'", int2 == (-989855744));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        int int2 = ClassExampleWithNoFailure.foo(1954807808, 2138570752);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        int int1 = ClassExampleWithNoFailure.twice(805306368);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1610612736 + "'", int1 == 1610612736);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        int int2 = ClassExampleWithNoFailure.foo(0, (-5734400));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        int int1 = ClassExampleWithNoFailure.twice(891289600);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1782579200 + "'", int1 == 1782579200);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test106");
        int int2 = ClassExampleWithNoFailure.foo((-809500672), (-23592960));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        int int2 = ClassExampleWithNoFailure.foo((-256), 327680000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-268435456) + "'", int2 == (-268435456));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test108");
        int int1 = ClassExampleWithNoFailure.twice(44040192);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 88080384 + "'", int1 == 88080384);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        int int1 = ClassExampleWithNoFailure.twice((-11200));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-22400) + "'", int1 == (-22400));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test110");
        int int2 = ClassExampleWithNoFailure.foo(891289600, 5324800);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test111");
        int int2 = ClassExampleWithNoFailure.foo((-358400000), 1392771072);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test112");
        int int1 = ClassExampleWithNoFailure.twice(1532755968);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1229455360) + "'", int1 == (-1229455360));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        int int2 = ClassExampleWithNoFailure.foo((-734003200), (-1439170560));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        int int2 = ClassExampleWithNoFailure.foo((-1714421760), (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-866123776) + "'", int2 == (-866123776));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test115");
        int int2 = ClassExampleWithNoFailure.foo(142606336, (-810123264));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test116");
        int int1 = ClassExampleWithNoFailure.twice((-335544320));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-671088640) + "'", int1 == (-671088640));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test117");
        int int1 = ClassExampleWithNoFailure.twice(116822144);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 233644288 + "'", int1 == 233644288);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test118");
        int int2 = ClassExampleWithNoFailure.foo(1638400000, (-771751936));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test119");
        int int2 = ClassExampleWithNoFailure.foo(2560, 899678208);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2147483648) + "'", int2 == (-2147483648));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test120");
        int int2 = ClassExampleWithNoFailure.foo((int) (byte) 100, 400);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 80000 + "'", int2 == 80000);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test121");
        int int2 = ClassExampleWithNoFailure.foo(1872183296, 100663296);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test122");
        int int2 = ClassExampleWithNoFailure.foo((-24832000), 5600);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1054474240 + "'", int2 == 1054474240);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test123");
        int int1 = ClassExampleWithNoFailure.twice(320);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 640 + "'", int1 == 640);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test124");
        int int2 = ClassExampleWithNoFailure.foo(160, (-222298112));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1879048192 + "'", int2 == 1879048192);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test125");
        int int1 = ClassExampleWithNoFailure.twice(1502347264);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1290272768) + "'", int1 == (-1290272768));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test126");
        int int2 = ClassExampleWithNoFailure.foo((-1549271040), 1120000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 805306368 + "'", int2 == 805306368);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test127");
        int int2 = ClassExampleWithNoFailure.foo((-163840000), (-86528000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2147483648) + "'", int2 == (-2147483648));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test128");
        int int2 = ClassExampleWithNoFailure.foo(13905920, (-6922240));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1677721600 + "'", int2 == 1677721600);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test129");
        int int2 = ClassExampleWithNoFailure.foo(31784960, 69529600);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1610612736 + "'", int2 == 1610612736);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test130");
        int int2 = ClassExampleWithNoFailure.foo(549191680, (-1146880000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test131");
        int int1 = ClassExampleWithNoFailure.twice(67108864);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 134217728 + "'", int1 == 134217728);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test132");
        int int1 = ClassExampleWithNoFailure.twice((-24832));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-49664) + "'", int1 == (-49664));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test133");
        int int2 = ClassExampleWithNoFailure.foo((-8320), (-740130816));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2105540608 + "'", int2 == 2105540608);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test134");
        int int2 = ClassExampleWithNoFailure.foo(80000, (-256));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-40960000) + "'", int2 == (-40960000));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test135");
        int int2 = ClassExampleWithNoFailure.foo((-160), 233644288);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1751728128) + "'", int2 == (-1751728128));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test136");
        int int2 = ClassExampleWithNoFailure.foo(1392771072, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test137");
        int int2 = ClassExampleWithNoFailure.foo(1738240, (-809500672));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test138");
        int int1 = ClassExampleWithNoFailure.twice(798752768);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1597505536 + "'", int1 == 1597505536);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test139");
        int int2 = ClassExampleWithNoFailure.foo((-1901068288), 320);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1207959552) + "'", int2 == (-1207959552));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test140");
        int int1 = ClassExampleWithNoFailure.twice(367001600);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 734003200 + "'", int1 == 734003200);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test141");
        int int2 = ClassExampleWithNoFailure.foo((-335544320), 5824000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test142");
        int int2 = ClassExampleWithNoFailure.foo((-35651584), (-16000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1610612736) + "'", int2 == (-1610612736));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test143");
        int int2 = ClassExampleWithNoFailure.foo(872415232, 1506803712);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test144");
        int int2 = ClassExampleWithNoFailure.foo(810123264, (-1229455360));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test145");
        int int2 = ClassExampleWithNoFailure.foo(179200, (-704643072));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test146");
        int int2 = ClassExampleWithNoFailure.foo((-71303168), 1098383360);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test147");
        int int2 = ClassExampleWithNoFailure.foo((-249561088), (-1673527296));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test148");
        int int2 = ClassExampleWithNoFailure.foo(69529600, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test149");
        int int2 = ClassExampleWithNoFailure.foo((-405061632), 1744830464);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test150");
        int int1 = ClassExampleWithNoFailure.twice((-200));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-400) + "'", int1 == (-400));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test151");
        int int2 = ClassExampleWithNoFailure.foo(0, (-1957691392));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test152");
        int int2 = ClassExampleWithNoFailure.foo((-1668808704), (-1600));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1543503872 + "'", int2 == 1543503872);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test153");
        int int1 = ClassExampleWithNoFailure.twice((-2048000));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-4096000) + "'", int1 == (-4096000));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test154");
        int int2 = ClassExampleWithNoFailure.foo(0, (-301989888));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test155");
        int int2 = ClassExampleWithNoFailure.foo(5824000, 23296000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 69206016 + "'", int2 == 69206016);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test156");
        int int2 = ClassExampleWithNoFailure.foo(7000, 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14000 + "'", int2 == 14000);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test157");
        int int2 = ClassExampleWithNoFailure.foo(0, 716800);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test158");
        int int2 = ClassExampleWithNoFailure.foo(1673527296, 69206016);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test159");
        int int1 = ClassExampleWithNoFailure.twice(123731968);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 247463936 + "'", int1 == 247463936);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test160");
        int int1 = ClassExampleWithNoFailure.twice(17920000);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 35840000 + "'", int1 == 35840000);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test161");
        int int2 = ClassExampleWithNoFailure.foo((-23592960), 560);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-654311424) + "'", int2 == (-654311424));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test162");
        int int2 = ClassExampleWithNoFailure.foo((-1591738368), (-24832));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1073741824) + "'", int2 == (-1073741824));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test163");
        int int2 = ClassExampleWithNoFailure.foo(0, 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test164");
        int int2 = ClassExampleWithNoFailure.foo(416, (-104857600));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1342177280) + "'", int2 == (-1342177280));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test165");
        int int2 = ClassExampleWithNoFailure.foo((int) (short) -1, (-16));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32 + "'", int2 == 32);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test166");
        int int1 = ClassExampleWithNoFailure.twice((-173056000));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-346112000) + "'", int1 == (-346112000));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test167");
        int int2 = ClassExampleWithNoFailure.foo((-2070020096), 550600704);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test168");
        int int2 = ClassExampleWithNoFailure.foo((-2079850496), 1427898368);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test169");
        int int2 = ClassExampleWithNoFailure.foo((-1917714432), 512000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1073741824 + "'", int2 == 1073741824);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test170");
        int int2 = ClassExampleWithNoFailure.foo(1731985408, (-8960000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1073741824) + "'", int2 == (-1073741824));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test171");
        int int2 = ClassExampleWithNoFailure.foo(5408, (-56000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-605696000) + "'", int2 == (-605696000));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test172");
        int int1 = ClassExampleWithNoFailure.twice(179200000);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 358400000 + "'", int1 == 358400000);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test173");
        int int1 = ClassExampleWithNoFailure.twice((-1445265408));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1404436480 + "'", int1 == 1404436480);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test174");
        int int2 = ClassExampleWithNoFailure.foo(0, (-1394081792));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test175");
        int int2 = ClassExampleWithNoFailure.foo(112000, 1081600);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1760231424 + "'", int2 == 1760231424);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test176");
        int int2 = ClassExampleWithNoFailure.foo((-173056), (-249561088));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test177");
        int int2 = ClassExampleWithNoFailure.foo((-268435456), 444596224);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test178");
        int int2 = ClassExampleWithNoFailure.foo((-249561088), (-136757248));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test179");
        int int2 = ClassExampleWithNoFailure.foo((-1290272768), (-1048576000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test180");
        int int2 = ClassExampleWithNoFailure.foo((-2147483648), 3880);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test181");
        int int2 = ClassExampleWithNoFailure.foo((-17382400), 436207616);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test182");
        int int2 = ClassExampleWithNoFailure.foo((-60569600), (-1591738368));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test183");
        int int1 = ClassExampleWithNoFailure.twice(1552);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3104 + "'", int1 == 3104);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test184");
        int int1 = ClassExampleWithNoFailure.twice(6553600);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13107200 + "'", int1 == 13107200);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test185");
        int int2 = ClassExampleWithNoFailure.foo((-2070020096), (-163840000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test186");
        int int1 = ClassExampleWithNoFailure.twice(201326592);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 402653184 + "'", int1 == 402653184);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test187");
        int int2 = ClassExampleWithNoFailure.foo(0, 86528);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test188");
        int int2 = ClassExampleWithNoFailure.foo(774504448, (-65536000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test189");
        int int1 = ClassExampleWithNoFailure.twice(219676672);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 439353344 + "'", int1 == 439353344);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test190");
        int int2 = ClassExampleWithNoFailure.foo((-1668808704), (-80));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 721420288 + "'", int2 == 721420288);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test191");
        int int1 = ClassExampleWithNoFailure.twice((-1054474240));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-2108948480) + "'", int1 == (-2108948480));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test192");
        int int1 = ClassExampleWithNoFailure.twice((-671088640));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1342177280) + "'", int1 == (-1342177280));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test193");
        int int2 = ClassExampleWithNoFailure.foo((-1416101888), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test194");
        int int1 = ClassExampleWithNoFailure.twice(536870912);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1073741824 + "'", int1 == 1073741824);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test195");
        int int1 = ClassExampleWithNoFailure.twice((-753369088));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1506738176) + "'", int1 == (-1506738176));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test196");
        int int1 = ClassExampleWithNoFailure.twice((-654311424));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1308622848) + "'", int1 == (-1308622848));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test197");
        int int1 = ClassExampleWithNoFailure.twice(13107200);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 26214400 + "'", int1 == 26214400);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test198");
        int int2 = ClassExampleWithNoFailure.foo(212992000, 100663296);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test199");
        int int2 = ClassExampleWithNoFailure.foo(2, (-889192448));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 738197504 + "'", int2 == 738197504);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test200");
        int int2 = ClassExampleWithNoFailure.foo(1677721600, 1363607552);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test201");
        int int1 = ClassExampleWithNoFailure.twice((-1577058304));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1140850688 + "'", int1 == 1140850688);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test202");
        int int1 = ClassExampleWithNoFailure.twice((-1280));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-2560) + "'", int1 == (-2560));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test203");
        int int2 = ClassExampleWithNoFailure.foo(1863680000, 86528);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-973078528) + "'", int2 == (-973078528));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test204");
        int int1 = ClassExampleWithNoFailure.twice((-645632));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1291264) + "'", int1 == (-1291264));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test205");
        int int1 = ClassExampleWithNoFailure.twice(80000);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 160000 + "'", int1 == 160000);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test206");
        int int1 = ClassExampleWithNoFailure.twice(1363607552);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1567752192) + "'", int1 == (-1567752192));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test207");
        int int1 = ClassExampleWithNoFailure.twice(40960);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 81920 + "'", int1 == 81920);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test208");
        int int2 = ClassExampleWithNoFailure.foo((-1018167296), 885948416);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test209");
        int int2 = ClassExampleWithNoFailure.foo(872415232, (-1409286144));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test210");
        int int2 = ClassExampleWithNoFailure.foo(219676672, (-6922240));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test211");
        int int2 = ClassExampleWithNoFailure.foo(2240000, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test212");
        int int2 = ClassExampleWithNoFailure.foo((-710967296), 1835008000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test213");
        int int1 = ClassExampleWithNoFailure.twice(1792000000);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-710967296) + "'", int1 == (-710967296));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test214");
        int int1 = ClassExampleWithNoFailure.twice(81920);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 163840 + "'", int1 == 163840);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test215");
        int int1 = ClassExampleWithNoFailure.twice(885948416);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1771896832 + "'", int1 == 1771896832);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test216");
        int int2 = ClassExampleWithNoFailure.foo(20480, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4096000 + "'", int2 == 4096000);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test217");
        int int1 = ClassExampleWithNoFailure.twice(421789696);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 843579392 + "'", int1 == 843579392);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test218");
        int int2 = ClassExampleWithNoFailure.foo(1775239168, 138444800);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test219");
        int int2 = ClassExampleWithNoFailure.foo(204800000, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test220");
        int int2 = ClassExampleWithNoFailure.foo(116822144, (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-233644288) + "'", int2 == (-233644288));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test221");
        int int2 = ClassExampleWithNoFailure.foo((-1872183296), (-2113929216));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test222");
        int int2 = ClassExampleWithNoFailure.foo((-202530816), (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 411631616 + "'", int2 == 411631616);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test223");
        int int2 = ClassExampleWithNoFailure.foo(819200000, (-1960000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1442840576 + "'", int2 == 1442840576);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test224");
        int int2 = ClassExampleWithNoFailure.foo(1885339648, 100663296);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test225");
        int int1 = ClassExampleWithNoFailure.twice((-40960000));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-81920000) + "'", int1 == (-81920000));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test226");
        int int2 = ClassExampleWithNoFailure.foo(1760231424, 15520);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1304428544 + "'", int2 == 1304428544);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test227");
        int int2 = ClassExampleWithNoFailure.foo(0, (-28000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test228");
        int int2 = ClassExampleWithNoFailure.foo(1054474240, 1744830464);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test229");
        int int1 = ClassExampleWithNoFailure.twice((-2867200));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-5734400) + "'", int1 == (-5734400));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test230");
        int int1 = ClassExampleWithNoFailure.twice(26214400);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 52428800 + "'", int1 == 52428800);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test231");
        int int2 = ClassExampleWithNoFailure.foo((-2098200576), 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 98566144 + "'", int2 == 98566144);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test232");
        int int2 = ClassExampleWithNoFailure.foo((-499122176), (-62080));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1073741824) + "'", int2 == (-1073741824));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test233");
        int int2 = ClassExampleWithNoFailure.foo(143360000, (-496640000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 536870912 + "'", int2 == 536870912);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test234");
        int int2 = ClassExampleWithNoFailure.foo((-1764163584), 810123264);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test235");
        int int1 = ClassExampleWithNoFailure.twice(1342177280);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1610612736) + "'", int1 == (-1610612736));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test236");
        int int2 = ClassExampleWithNoFailure.foo((-160), (-1567752192));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-830472192) + "'", int2 == (-830472192));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test237");
        int int1 = ClassExampleWithNoFailure.twice(248320);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 496640 + "'", int1 == 496640);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test238");
        int int2 = ClassExampleWithNoFailure.foo(37636, 1792000000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-318898176) + "'", int2 == (-318898176));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test239");
        int int2 = ClassExampleWithNoFailure.foo((int) (byte) 100, (-573440000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1276116992 + "'", int2 == 1276116992);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test240");
        int int1 = ClassExampleWithNoFailure.twice(722632704);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1445265408 + "'", int1 == 1445265408);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test241");
        int int2 = ClassExampleWithNoFailure.foo((-887095296), 1421934592);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test242");
        int int2 = ClassExampleWithNoFailure.foo((-645632), 80);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-103301120) + "'", int2 == (-103301120));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test243");
        int int2 = ClassExampleWithNoFailure.foo((-35651584), (-80));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1409286144 + "'", int2 == 1409286144);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test244");
        int int2 = ClassExampleWithNoFailure.foo((-12416000), (-52428800));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test245");
        int int2 = ClassExampleWithNoFailure.foo(409600, (-1078198272));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test246");
        int int2 = ClassExampleWithNoFailure.foo(722632704, 800);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 866123776 + "'", int2 == 866123776);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test247");
        int int2 = ClassExampleWithNoFailure.foo((-1933574144), (-603979776));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test248");
        int int2 = ClassExampleWithNoFailure.foo((-1549271040), 1442840576);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test249");
        int int1 = ClassExampleWithNoFailure.twice((-1506738176));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1281490944 + "'", int1 == 1281490944);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test250");
        int int2 = ClassExampleWithNoFailure.foo(183500800, 1211392000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test251");
        int int2 = ClassExampleWithNoFailure.foo((-1416101888), 43264);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1342177280) + "'", int2 == (-1342177280));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test252");
        int int2 = ClassExampleWithNoFailure.foo(411631616, 3476480);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-671088640) + "'", int2 == (-671088640));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test253");
        int int2 = ClassExampleWithNoFailure.foo((-17920000), 721420288);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test254");
        int int1 = ClassExampleWithNoFailure.twice((-1738240000));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 818487296 + "'", int1 == 818487296);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test255");
        int int2 = ClassExampleWithNoFailure.foo(1081600, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test256");
        int int1 = ClassExampleWithNoFailure.twice((-124160));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-248320) + "'", int1 == (-248320));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test257");
        int int2 = ClassExampleWithNoFailure.foo((-1107296256), 5408);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2147483648) + "'", int2 == (-2147483648));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test258");
        int int2 = ClassExampleWithNoFailure.foo((-1089339392), 448000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 402653184 + "'", int2 == 402653184);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test259");
        int int2 = ClassExampleWithNoFailure.foo((-1056964608), 89600);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test260");
        int int2 = ClassExampleWithNoFailure.foo((-285212672), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test261");
        int int2 = ClassExampleWithNoFailure.foo((-645632), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test262");
        int int2 = ClassExampleWithNoFailure.foo(2013265920, (-256));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test263");
        int int2 = ClassExampleWithNoFailure.foo((-64), (-692224));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 88604672 + "'", int2 == 88604672);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test264");
        int int1 = ClassExampleWithNoFailure.twice(32);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 64 + "'", int1 == 64);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test265");
        int int2 = ClassExampleWithNoFailure.foo(560, (-17920000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1404436480 + "'", int2 == 1404436480);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test266");
        int int2 = ClassExampleWithNoFailure.foo((-885948416), 256);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1660944384 + "'", int2 == 1660944384);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test267");
        int int2 = ClassExampleWithNoFailure.foo(612368384, (-931840000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test268");
        int int2 = ClassExampleWithNoFailure.foo((-696254464), 99328);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test269");
        int int2 = ClassExampleWithNoFailure.foo(1811939328, (-233644288));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test270");
        int int2 = ClassExampleWithNoFailure.foo((-1054474240), 1404436480);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test271");
        int int2 = ClassExampleWithNoFailure.foo((-956301312), 1912602624);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test272");
        int int2 = ClassExampleWithNoFailure.foo(313600000, 10240);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1551892480 + "'", int2 == 1551892480);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test273");
        int int2 = ClassExampleWithNoFailure.foo((-358400000), (-722632704));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1073741824) + "'", int2 == (-1073741824));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test274");
        int int1 = ClassExampleWithNoFailure.twice(13905920);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 27811840 + "'", int1 == 27811840);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test275");
        int int2 = ClassExampleWithNoFailure.foo((-49664), (-114688000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1476395008 + "'", int2 == 1476395008);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test276");
        int int2 = ClassExampleWithNoFailure.foo((-1140850688), 3476480);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test277");
        int int2 = ClassExampleWithNoFailure.foo((-5120), 567607296);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1207959552) + "'", int2 == (-1207959552));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test278");
        int int1 = ClassExampleWithNoFailure.twice(416);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 832 + "'", int1 == 832);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test279");
        int int2 = ClassExampleWithNoFailure.foo(721420288, (-1280));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test280");
        int int2 = ClassExampleWithNoFailure.foo((-128), (-1636974592));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1841299456) + "'", int2 == (-1841299456));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test281");
        int int1 = ClassExampleWithNoFailure.twice(6208000);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 12416000 + "'", int1 == 12416000);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test282");
        int int2 = ClassExampleWithNoFailure.foo(27811840, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test283");
        int int1 = ClassExampleWithNoFailure.twice((-1870659584));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 553648128 + "'", int1 == 553648128);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test284");
        int int2 = ClassExampleWithNoFailure.foo((-286720000), 805306368);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test285");
        int int1 = ClassExampleWithNoFailure.twice((-830472192));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1660944384) + "'", int1 == (-1660944384));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test286");
        int int1 = ClassExampleWithNoFailure.twice(553648128);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1107296256 + "'", int1 == 1107296256);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test287");
        int int2 = ClassExampleWithNoFailure.foo((-1872887808), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test288");
        int int2 = ClassExampleWithNoFailure.foo(1048576000, (-56000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1073741824 + "'", int2 == 1073741824);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test289");
        int int2 = ClassExampleWithNoFailure.foo((-1845493760), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test290");
        int int2 = ClassExampleWithNoFailure.foo((-1445265408), (-20));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1976041472 + "'", int2 == 1976041472);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test291");
        int int2 = ClassExampleWithNoFailure.foo(256000, 26214400);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test292");
        int int2 = ClassExampleWithNoFailure.foo(104, (-32000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-6656000) + "'", int2 == (-6656000));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test293");
        int int2 = ClassExampleWithNoFailure.foo(173056, 179200);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1893728256 + "'", int2 == 1893728256);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test294");
        int int1 = ClassExampleWithNoFailure.twice(818487296);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1636974592 + "'", int1 == 1636974592);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test295");
        int int2 = ClassExampleWithNoFailure.foo(716800, 1514240);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1855979520 + "'", int2 == 1855979520);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test296");
        int int2 = ClassExampleWithNoFailure.foo((-1404436480), (-536870912));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test297");
        int int2 = ClassExampleWithNoFailure.foo(80000, 478150656);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2147483648) + "'", int2 == (-2147483648));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test298");
        int int1 = ClassExampleWithNoFailure.twice((-79462400));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-158924800) + "'", int1 == (-158924800));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test299");
        int int1 = ClassExampleWithNoFailure.twice(1379926016);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1535115264) + "'", int1 == (-1535115264));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test300");
        int int2 = ClassExampleWithNoFailure.foo(45875200, 1811939328);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test301");
        int int2 = ClassExampleWithNoFailure.foo((int) (byte) -1, 8960000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-17920000) + "'", int2 == (-17920000));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test302");
        int int2 = ClassExampleWithNoFailure.foo(406323200, (-286720000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test303");
        int int2 = ClassExampleWithNoFailure.foo(0, 1276116992);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test304");
        int int1 = ClassExampleWithNoFailure.twice((-17382400));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-34764800) + "'", int1 == (-34764800));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test305");
        int int2 = ClassExampleWithNoFailure.foo((-810123264), (-179200000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 536870912 + "'", int2 == 536870912);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test306");
        int int2 = ClassExampleWithNoFailure.foo((-1905262592), (-1107296256));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test307");
        int int2 = ClassExampleWithNoFailure.foo(7168000, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 143360000 + "'", int2 == 143360000);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test308");
        int int1 = ClassExampleWithNoFailure.twice((-103301120));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-206602240) + "'", int1 == (-206602240));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test309");
        int int1 = ClassExampleWithNoFailure.twice(3104);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6208 + "'", int1 == 6208);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test310");
        int int2 = ClassExampleWithNoFailure.foo((-346112000), 832);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-404750336) + "'", int2 == (-404750336));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test311");
        int int2 = ClassExampleWithNoFailure.foo(0, 722632704);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test312");
        int int1 = ClassExampleWithNoFailure.twice((-8320));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-16640) + "'", int1 == (-16640));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test313");
        int int2 = ClassExampleWithNoFailure.foo(286720000, 139059200);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1073741824 + "'", int2 == 1073741824);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test314");
        int int2 = ClassExampleWithNoFailure.foo(899678208, 44800000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test315");
        int int2 = ClassExampleWithNoFailure.foo(56000, 183500800);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 671088640 + "'", int2 == 671088640);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test316");
        int int2 = ClassExampleWithNoFailure.foo((-1329594368), 116822144);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1073741824) + "'", int2 == (-1073741824));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test317");
        int int2 = ClassExampleWithNoFailure.foo((-539099136), 13905920);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1073741824 + "'", int2 == 1073741824);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test318");
        int int1 = ClassExampleWithNoFailure.twice(469762048);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 939524096 + "'", int1 == 939524096);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test319");
        int int1 = ClassExampleWithNoFailure.twice(346112);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 692224 + "'", int1 == 692224);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test320");
        int int2 = ClassExampleWithNoFailure.foo((-1778384896), (-1107296256));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test321");
        int int2 = ClassExampleWithNoFailure.foo((-496640000), (-17920000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 469762048 + "'", int2 == 469762048);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test322");
        int int2 = ClassExampleWithNoFailure.foo(1196425216, (-1853882368));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test323");
        int int2 = ClassExampleWithNoFailure.foo((-136757248), 1207959552);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test324");
        int int1 = ClassExampleWithNoFailure.twice(1799356416);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-696254464) + "'", int1 == (-696254464));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test325");
        int int2 = ClassExampleWithNoFailure.foo(0, (-1610612736));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test326");
        int int2 = ClassExampleWithNoFailure.foo(549191680, (-206602240));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test327");
        int int2 = ClassExampleWithNoFailure.foo(210894848, (-25600));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-268435456) + "'", int2 == (-268435456));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test328");
        int int2 = ClassExampleWithNoFailure.foo(128, 710967296);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1619001344 + "'", int2 == 1619001344);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test329");
        int int1 = ClassExampleWithNoFailure.twice(1111490560);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-2071986176) + "'", int1 == (-2071986176));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test330");
        int int2 = ClassExampleWithNoFailure.foo((-1751728128), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test331");
        int int1 = ClassExampleWithNoFailure.twice((-358400000));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-716800000) + "'", int1 == (-716800000));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test332");
        int int2 = ClassExampleWithNoFailure.foo(810123264, 448000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-503316480) + "'", int2 == (-503316480));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test333");
        int int2 = ClassExampleWithNoFailure.foo(553648128, 64);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2147483648) + "'", int2 == (-2147483648));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test334");
        int int1 = ClassExampleWithNoFailure.twice(444596224);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 889192448 + "'", int1 == 889192448);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test335");
        int int2 = ClassExampleWithNoFailure.foo(549191680, 5120);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1610612736 + "'", int2 == 1610612736);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test336");
        int int2 = ClassExampleWithNoFailure.foo(1771896832, (-1636974592));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2147483648) + "'", int2 == (-2147483648));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test337");
        int int1 = ClassExampleWithNoFailure.twice((-1905262592));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 484442112 + "'", int1 == 484442112);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test338");
        int int2 = ClassExampleWithNoFailure.foo(1509949440, 819200000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test339");
        int int1 = ClassExampleWithNoFailure.twice((-1668808704));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 957349888 + "'", int1 == 957349888);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test340");
        int int1 = ClassExampleWithNoFailure.twice(52428800);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 104857600 + "'", int1 == 104857600);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test341");
        int int2 = ClassExampleWithNoFailure.foo(21632, 247463936);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1073741824) + "'", int2 == (-1073741824));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test342");
        int int2 = ClassExampleWithNoFailure.foo(302848000, 620800);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 279969792 + "'", int2 == 279969792);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test343");
        int int2 = ClassExampleWithNoFailure.foo((-136757248), (-1433534464));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test344");
        int int2 = ClassExampleWithNoFailure.foo((-2071986176), 46592000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test345");
        int int1 = ClassExampleWithNoFailure.twice(832);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1664 + "'", int1 == 1664);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test346");
        int int2 = ClassExampleWithNoFailure.foo((-989855744), (-35651584));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test347");
        int int2 = ClassExampleWithNoFailure.foo((-128), (-35651584));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 536870912 + "'", int2 == 536870912);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test348");
        int int2 = ClassExampleWithNoFailure.foo((-1673527296), 112000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1073741824) + "'", int2 == (-1073741824));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test349");
        int int2 = ClassExampleWithNoFailure.foo((-734003200), (-22400000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test350");
        int int2 = ClassExampleWithNoFailure.foo(160, (-2172800));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-695296000) + "'", int2 == (-695296000));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test351");
        int int1 = ClassExampleWithNoFailure.twice((-939524096));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1879048192) + "'", int1 == (-1879048192));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test352");
        int int2 = ClassExampleWithNoFailure.foo((-1905262592), (-896000000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test353");
        int int1 = ClassExampleWithNoFailure.twice((-771751936));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1543503872) + "'", int1 == (-1543503872));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test354");
        int int2 = ClassExampleWithNoFailure.foo(1237319680, (-8320));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1073741824 + "'", int2 == 1073741824);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test355");
        int int1 = ClassExampleWithNoFailure.twice(1476395008);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1342177280) + "'", int1 == (-1342177280));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test356");
        int int2 = ClassExampleWithNoFailure.foo((-124160), 67108864);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test357");
        int int1 = ClassExampleWithNoFailure.twice(142606336);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 285212672 + "'", int1 == 285212672);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test358");
        int int2 = ClassExampleWithNoFailure.foo(956301312, 1703936000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test359");
        int int2 = ClassExampleWithNoFailure.foo((-830472192), 25600);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test360");
        int int2 = ClassExampleWithNoFailure.foo(25600, (-64));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-3276800) + "'", int2 == (-3276800));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test361");
        int int1 = ClassExampleWithNoFailure.twice(1217134592);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1860698112) + "'", int1 == (-1860698112));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test362");
        int int2 = ClassExampleWithNoFailure.foo(567607296, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test363");
        int int2 = ClassExampleWithNoFailure.foo((-4480000), (-1392508928));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test364");
        int int1 = ClassExampleWithNoFailure.twice((-1792000000));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 710967296 + "'", int1 == 710967296);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test365");
        int int2 = ClassExampleWithNoFailure.foo((-1342177280), 1081600);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test366");
        int int2 = ClassExampleWithNoFailure.foo((-947912704), (-696254464));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test367");
        int int2 = ClassExampleWithNoFailure.foo((int) (byte) 1, (-1924661248));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 445644800 + "'", int2 == 445644800);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test368");
        int int2 = ClassExampleWithNoFailure.foo((-369098752), (-124160));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test369");
        int int1 = ClassExampleWithNoFailure.twice(809500672);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1619001344 + "'", int1 == 1619001344);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test370");
        int int2 = ClassExampleWithNoFailure.foo(0, (-664797184));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test371");
        int int2 = ClassExampleWithNoFailure.foo((-256000), 800);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-409600000) + "'", int2 == (-409600000));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test372");
        int int2 = ClassExampleWithNoFailure.foo(69206016, 442499072);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test373");
        int int2 = ClassExampleWithNoFailure.foo(0, 69529600);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test374");
        int int2 = ClassExampleWithNoFailure.foo(445644800, (-12800));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1073741824) + "'", int2 == (-1073741824));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test375");
        int int2 = ClassExampleWithNoFailure.foo((-1757413376), 1509949440);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test376");
        int int1 = ClassExampleWithNoFailure.twice(1976041472);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-342884352) + "'", int1 == (-342884352));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test377");
        int int2 = ClassExampleWithNoFailure.foo(869120, 885948416);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 385875968 + "'", int2 == 385875968);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test378");
        int int2 = ClassExampleWithNoFailure.foo(5600, 210894848);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-209715200) + "'", int2 == (-209715200));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test379");
        int int1 = ClassExampleWithNoFailure.twice((-60569600));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-121139200) + "'", int1 == (-121139200));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test380");
        int int1 = ClassExampleWithNoFailure.twice(612368384);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1224736768 + "'", int1 == 1224736768);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test381");
        int int2 = ClassExampleWithNoFailure.foo((-536870912), (-1764163584));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test382");
        int int1 = ClassExampleWithNoFailure.twice(1308622848);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1677721600) + "'", int1 == (-1677721600));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test383");
        int int2 = ClassExampleWithNoFailure.foo(716800000, 889192448);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test384");
        int int2 = ClassExampleWithNoFailure.foo((-1933574144), 184549376);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test385");
        int int2 = ClassExampleWithNoFailure.foo((-1778384896), (-112000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test386");
        int int1 = ClassExampleWithNoFailure.twice((-3276800));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-6553600) + "'", int1 == (-6553600));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test387");
        int int2 = ClassExampleWithNoFailure.foo((-173056000), 1098383360);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test388");
        int int2 = ClassExampleWithNoFailure.foo((-503316480), 1211039744);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test389");
        int int1 = ClassExampleWithNoFailure.twice((-1660944384));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 973078528 + "'", int1 == 973078528);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test390");
        int int2 = ClassExampleWithNoFailure.foo((-812646400), 20);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1853882368 + "'", int2 == 1853882368);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test391");
        int int2 = ClassExampleWithNoFailure.foo((-6208), (-512000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2062024704 + "'", int2 == 2062024704);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test392");
        int int2 = ClassExampleWithNoFailure.foo((-1577058304), 885948416);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test393");
        int int1 = ClassExampleWithNoFailure.twice((-1146880000));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2001207296 + "'", int1 == 2001207296);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test394");
        int int2 = ClassExampleWithNoFailure.foo(310378496, (-6208000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test395");
        int int1 = ClassExampleWithNoFailure.twice(409600000);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 819200000 + "'", int1 == 819200000);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test396");
        int int2 = ClassExampleWithNoFailure.foo(0, 436207616);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test397");
        int int2 = ClassExampleWithNoFailure.foo((-3461120), 2912000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1281359872) + "'", int2 == (-1281359872));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test398");
        int int2 = ClassExampleWithNoFailure.foo(1308622848, 44040192);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test399");
        int int1 = ClassExampleWithNoFailure.twice(807403520);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1614807040 + "'", int1 == 1614807040);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test400");
        int int1 = ClassExampleWithNoFailure.twice(1636974592);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1021018112) + "'", int1 == (-1021018112));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test401");
        int int2 = ClassExampleWithNoFailure.foo((-112000), (-1957691392));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1879048192) + "'", int2 == (-1879048192));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test402");
        int int2 = ClassExampleWithNoFailure.foo(421789696, (-1677721600));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test403");
        int int2 = ClassExampleWithNoFailure.foo(15892480, 99328);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 335544320 + "'", int2 == 335544320);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test404");
        int int2 = ClassExampleWithNoFailure.foo(496640, 1761607680);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test405");
        int int1 = ClassExampleWithNoFailure.twice((-1744830464));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 805306368 + "'", int1 == 805306368);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test406");
        int int2 = ClassExampleWithNoFailure.foo((-57344000), 880803840);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test407");
        int int2 = ClassExampleWithNoFailure.foo(1241600, (-25600));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 854589440 + "'", int2 == 854589440);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test408");
        int int2 = ClassExampleWithNoFailure.foo((-624951296), (-922746880));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test409");
        int int2 = ClassExampleWithNoFailure.foo((-710967296), (-170917888));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test410");
        int int2 = ClassExampleWithNoFailure.foo(1024000, (-40960000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1073741824) + "'", int2 == (-1073741824));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test411");
        int int2 = ClassExampleWithNoFailure.foo((-645632), (-158924800));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 335544320 + "'", int2 == 335544320);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test412");
        int int2 = ClassExampleWithNoFailure.foo(31784960, (-1308622848));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test413");
        int int1 = ClassExampleWithNoFailure.twice(1506803712);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1281359872) + "'", int1 == (-1281359872));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test414");
        int int1 = ClassExampleWithNoFailure.twice(716800000);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1433600000 + "'", int1 == 1433600000);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test415");
        int int1 = ClassExampleWithNoFailure.twice((-1023410176));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-2046820352) + "'", int1 == (-2046820352));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test416");
        int int2 = ClassExampleWithNoFailure.foo(89600, (-539099136));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 134217728 + "'", int2 == 134217728);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test417");
        int int1 = ClassExampleWithNoFailure.twice((-740130816));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1480261632) + "'", int1 == (-1480261632));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test418");
        int int2 = ClassExampleWithNoFailure.foo((int) 'a', (-49664));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-9634816) + "'", int2 == (-9634816));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test419");
        int int2 = ClassExampleWithNoFailure.foo(385875968, (-889192448));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test420");
        int int2 = ClassExampleWithNoFailure.foo((-1048576000), (-1901068288));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test421");
        int int2 = ClassExampleWithNoFailure.foo((-885948416), 286720000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test422");
        int int2 = ClassExampleWithNoFailure.foo(885948416, (-286720000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test423");
        int int2 = ClassExampleWithNoFailure.foo(186368000, (-1369440256));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test424");
        int int1 = ClassExampleWithNoFailure.twice(14336000);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 28672000 + "'", int1 == 28672000);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test425");
        int int2 = ClassExampleWithNoFailure.foo((-1543503872), (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1610612736) + "'", int2 == (-1610612736));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test426");
        int int2 = ClassExampleWithNoFailure.foo(81920000, (-722632704));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test427");
        int int2 = ClassExampleWithNoFailure.foo(173056, 385875968);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test428");
        int int2 = ClassExampleWithNoFailure.foo((-20480), 163840000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2147483648) + "'", int2 == (-2147483648));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test429");
        int int2 = ClassExampleWithNoFailure.foo(104, (-11200000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1965367296 + "'", int2 == 1965367296);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test430");
        int int2 = ClassExampleWithNoFailure.foo(1427898368, 1589641216);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test431");
        int int1 = ClassExampleWithNoFailure.twice((-34764800));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-69529600) + "'", int1 == (-69529600));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test432");
        int int2 = ClassExampleWithNoFailure.foo(183500800, 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-624951296) + "'", int2 == (-624951296));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test433");
        int int1 = ClassExampleWithNoFailure.twice(1442840576);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1409286144) + "'", int1 == (-1409286144));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test434");
        int int1 = ClassExampleWithNoFailure.twice(204800000);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 409600000 + "'", int1 == 409600000);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test435");
        int int2 = ClassExampleWithNoFailure.foo(397312, 279969792);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test436");
        int int1 = ClassExampleWithNoFailure.twice((-1006632960));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-2013265920) + "'", int1 == (-2013265920));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test437");
        int int2 = ClassExampleWithNoFailure.foo((-654311424), (-1281359872));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test438");
        int int1 = ClassExampleWithNoFailure.twice((-206602240));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-413204480) + "'", int1 == (-413204480));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test439");
        int int2 = ClassExampleWithNoFailure.foo((-24832000), (-1439432704));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1073741824) + "'", int2 == (-1073741824));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test440");
        int int2 = ClassExampleWithNoFailure.foo((-1853882368), 1211392000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test441");
        int int2 = ClassExampleWithNoFailure.foo((-2085617664), 12416000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2147483648) + "'", int2 == (-2147483648));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test442");
        int int1 = ClassExampleWithNoFailure.twice((-624951296));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1249902592) + "'", int1 == (-1249902592));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test443");
        int int2 = ClassExampleWithNoFailure.foo(173056, 135266304);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2147483648) + "'", int2 == (-2147483648));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test444");
        int int1 = ClassExampleWithNoFailure.twice(12416000);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24832000 + "'", int1 == 24832000);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test445");
        int int2 = ClassExampleWithNoFailure.foo((-496640000), (-80));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2141978624) + "'", int2 == (-2141978624));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test446");
        int int2 = ClassExampleWithNoFailure.foo(70, 1799356416);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1493172224) + "'", int2 == (-1493172224));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test447");
        int int1 = ClassExampleWithNoFailure.twice(637534208);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1275068416 + "'", int1 == 1275068416);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test448");
        int int2 = ClassExampleWithNoFailure.foo((-5120), (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10240 + "'", int2 == 10240);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test449");
        int int2 = ClassExampleWithNoFailure.foo(1366294528, 400);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2113929216 + "'", int2 == 2113929216);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test450");
        int int2 = ClassExampleWithNoFailure.foo(620800, 1196425216);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1610612736) + "'", int2 == (-1610612736));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test451");
        int int1 = ClassExampleWithNoFailure.twice((-22400));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-44800) + "'", int1 == (-44800));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test452");
        int int2 = ClassExampleWithNoFailure.foo((-170917888), (-1509425152));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test453");
        int int2 = ClassExampleWithNoFailure.foo(204800000, 1237319680);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test454");
        int int2 = ClassExampleWithNoFailure.foo(1732247552, (-8));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1946157056) + "'", int2 == (-1946157056));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test455");
        int int2 = ClassExampleWithNoFailure.foo((-32), 567607296);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1967128576) + "'", int2 == (-1967128576));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test456");
        int int1 = ClassExampleWithNoFailure.twice((-1249902592));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1795162112 + "'", int1 == 1795162112);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test457");
        int int2 = ClassExampleWithNoFailure.foo(88080384, 2097152000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test458");
        int int2 = ClassExampleWithNoFailure.foo(13905920, 397312);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-973078528) + "'", int2 == (-973078528));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test459");
        int int2 = ClassExampleWithNoFailure.foo((-2), 142606336);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-570425344) + "'", int2 == (-570425344));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test460");
        int int2 = ClassExampleWithNoFailure.foo(24832, 176160768);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test461");
        int int2 = ClassExampleWithNoFailure.foo(244350976, (-1433600000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test462");
        int int2 = ClassExampleWithNoFailure.foo(1625292800, 738197504);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test463");
        int int2 = ClassExampleWithNoFailure.foo((-35651584), 98566144);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test464");
        int int2 = ClassExampleWithNoFailure.foo(1760231424, (-32000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2113929216) + "'", int2 == (-2113929216));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test465");
        int int1 = ClassExampleWithNoFailure.twice((-44800));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-89600) + "'", int1 == (-89600));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test466");
        int int2 = ClassExampleWithNoFailure.foo(5824000, 279969792);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1073741824 + "'", int2 == 1073741824);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test467");
        int int2 = ClassExampleWithNoFailure.foo(0, (-370065408));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test468");
        int int2 = ClassExampleWithNoFailure.foo(204800000, (-12800));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1275068416 + "'", int2 == 1275068416);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test469");
        int int2 = ClassExampleWithNoFailure.foo((-358400000), (-89600));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1660944384) + "'", int2 == (-1660944384));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test470");
        int int2 = ClassExampleWithNoFailure.foo(444596224, 20480);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test471");
        int int2 = ClassExampleWithNoFailure.foo((-2), 15892480);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-63569920) + "'", int2 == (-63569920));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test472");
        int int2 = ClassExampleWithNoFailure.foo((int) (byte) -1, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test473");
        int int2 = ClassExampleWithNoFailure.foo(20480, 142606336);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test474");
        int int2 = ClassExampleWithNoFailure.foo(15892480, (-1863680000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2147483648) + "'", int2 == (-2147483648));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test475");
        int int2 = ClassExampleWithNoFailure.foo((-6656000), (-1291264));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 847249408 + "'", int2 == 847249408);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test476");
        int int2 = ClassExampleWithNoFailure.foo((-1960000), 1731985408);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1577058304) + "'", int2 == (-1577058304));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test477");
        int int1 = ClassExampleWithNoFailure.twice((-695296000));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1390592000) + "'", int1 == (-1390592000));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test478");
        int int2 = ClassExampleWithNoFailure.foo((-249561088), (-1290272768));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test479");
        int int2 = ClassExampleWithNoFailure.foo((-1201668096), 620800);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1073741824) + "'", int2 == (-1073741824));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test480");
        int int2 = ClassExampleWithNoFailure.foo((-11200000), (-71303168));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test481");
        int int2 = ClassExampleWithNoFailure.foo((-1445265408), 411631616);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test482");
        int int2 = ClassExampleWithNoFailure.foo((-335544320), 620800);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test483");
        int int2 = ClassExampleWithNoFailure.foo((-256000), 124780544);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test484");
        int int1 = ClassExampleWithNoFailure.twice(88604672);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 177209344 + "'", int1 == 177209344);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test485");
        int int2 = ClassExampleWithNoFailure.foo((-1276116992), (-1056964608));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test486");
        int int2 = ClassExampleWithNoFailure.foo(310378496, (-89600000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test487");
        int int1 = ClassExampleWithNoFailure.twice((-1439432704));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1416101888 + "'", int1 == 1416101888);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test488");
        int int2 = ClassExampleWithNoFailure.foo(1912602624, 88604672);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test489");
        int int2 = ClassExampleWithNoFailure.foo(2116288512, 16384000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test490");
        int int2 = ClassExampleWithNoFailure.foo((-671088640), 549191680);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test491");
        int int1 = ClassExampleWithNoFailure.twice((-512000));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1024000) + "'", int1 == (-1024000));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test492");
        int int2 = ClassExampleWithNoFailure.foo((-43264), 186368000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1551892480 + "'", int2 == 1551892480);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test493");
        int int2 = ClassExampleWithNoFailure.foo((-2113929216), 1098383360);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test494");
        int int2 = ClassExampleWithNoFailure.foo((-1778384896), (-179200000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test495");
        int int1 = ClassExampleWithNoFailure.twice((-567607296));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1135214592) + "'", int1 == (-1135214592));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test496");
        int int2 = ClassExampleWithNoFailure.foo((-503316480), 50331648);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test497");
        int int1 = ClassExampleWithNoFailure.twice((-734003200));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1468006400) + "'", int1 == (-1468006400));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test498");
        int int2 = ClassExampleWithNoFailure.foo(1241600, 1668808704);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-536870912) + "'", int2 == (-536870912));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test499");
        int int2 = ClassExampleWithNoFailure.foo(1427898368, (-1476395008));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test500");
        int int2 = ClassExampleWithNoFailure.foo(427819008, (-62080));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2147483648) + "'", int2 == (-2147483648));
    }
}

