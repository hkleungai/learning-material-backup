import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class ClassExampleWithNoFailureRegressionTest4 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test01");
        int int2 = ClassExampleWithNoFailure.foo(1196425216, 620800);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1610612736) + "'", int2 == (-1610612736));
    }

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test02");
        int int2 = ClassExampleWithNoFailure.foo(13107200, (-654311424));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test03");
        int int2 = ClassExampleWithNoFailure.foo(1107296256, 15892480);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test04() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test04");
        int int2 = ClassExampleWithNoFailure.foo(1120, 507510784);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1342177280) + "'", int2 == (-1342177280));
    }

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test05");
        int int2 = ClassExampleWithNoFailure.foo((-394264576), (-1212153856));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test06");
        int int2 = ClassExampleWithNoFailure.foo((-1506738176), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test07");
        int int2 = ClassExampleWithNoFailure.foo((-16640), 179200);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1668808704) + "'", int2 == (-1668808704));
    }

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test08");
        int int2 = ClassExampleWithNoFailure.foo(536870912, 224000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test09() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test09");
        int int2 = ClassExampleWithNoFailure.foo(17920, 51200);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1835008000 + "'", int2 == 1835008000);
    }

    @Test
    public void test10() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test10");
        int int2 = ClassExampleWithNoFailure.foo(367001600, (-71680000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test11");
        int int2 = ClassExampleWithNoFailure.foo((-1310720000), (-444596224));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test12() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test12");
        int int2 = ClassExampleWithNoFailure.foo(409600, 973078528);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test13() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test13");
        int int2 = ClassExampleWithNoFailure.foo((-49664000), (-49664));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1891631104) + "'", int2 == (-1891631104));
    }

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test14");
        int int2 = ClassExampleWithNoFailure.foo((-1673527296), (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test15() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test15");
        int int2 = ClassExampleWithNoFailure.foo(1532755968, (-81920000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test16() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test16");
        int int2 = ClassExampleWithNoFailure.foo((-1626079232), (-1668808704));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test17() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test17");
        int int1 = ClassExampleWithNoFailure.twice(256);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 512 + "'", int1 == 512);
    }

    @Test
    public void test18() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test18");
        int int1 = ClassExampleWithNoFailure.twice((-214302720));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-428605440) + "'", int1 == (-428605440));
    }

    @Test
    public void test19() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test19");
        int int2 = ClassExampleWithNoFailure.foo((-346112000), 751173632);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test20() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test20");
        int int2 = ClassExampleWithNoFailure.foo((-32000), (-605696000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1830813696) + "'", int2 == (-1830813696));
    }

    @Test
    public void test21() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test21");
        int int2 = ClassExampleWithNoFailure.foo((-1229455360), 32);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1375731712) + "'", int2 == (-1375731712));
    }

    @Test
    public void test22() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test22");
        int int1 = ClassExampleWithNoFailure.twice((-40));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-80) + "'", int1 == (-80));
    }

    @Test
    public void test23() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test23");
        int int1 = ClassExampleWithNoFailure.twice((-1938227200));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 418512896 + "'", int1 == 418512896);
    }

    @Test
    public void test24() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test24");
        int int2 = ClassExampleWithNoFailure.foo(1664, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test25() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test25");
        int int1 = ClassExampleWithNoFailure.twice(1902116864);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-490733568) + "'", int1 == (-490733568));
    }

    @Test
    public void test26() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test26");
        int int2 = ClassExampleWithNoFailure.foo((-173056000), 818487296);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1744830464) + "'", int2 == (-1744830464));
    }

    @Test
    public void test27() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test27");
        int int1 = ClassExampleWithNoFailure.twice((-1157627904));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1979711488 + "'", int1 == 1979711488);
    }

    @Test
    public void test28() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test28");
        int int1 = ClassExampleWithNoFailure.twice((-316604416));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-633208832) + "'", int1 == (-633208832));
    }

    @Test
    public void test29() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test29");
        int int2 = ClassExampleWithNoFailure.foo((-316604416), (-1290272768));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test30() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test30");
        int int2 = ClassExampleWithNoFailure.foo((-17920000), (-285212672));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test31() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test31");
        int int2 = ClassExampleWithNoFailure.foo((-79462400), 24832);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 654311424 + "'", int2 == 654311424);
    }

    @Test
    public void test32() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test32");
        int int2 = ClassExampleWithNoFailure.foo(1668808704, (-214302720));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test33() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test33");
        int int2 = ClassExampleWithNoFailure.foo((-19269632), 212992000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-536870912) + "'", int2 == (-536870912));
    }

    @Test
    public void test34() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test34");
        int int1 = ClassExampleWithNoFailure.twice((-224000));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-448000) + "'", int1 == (-448000));
    }

    @Test
    public void test35() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test35");
        int int1 = ClassExampleWithNoFailure.twice((-47185920));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-94371840) + "'", int1 == (-94371840));
    }

    @Test
    public void test36() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test36");
        int int2 = ClassExampleWithNoFailure.foo((-1744830464), 640);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test37() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test37");
        int int2 = ClassExampleWithNoFailure.foo((-370065408), 268435456);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test38() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test38");
        int int1 = ClassExampleWithNoFailure.twice((-1917714432));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 459538432 + "'", int1 == 459538432);
    }

    @Test
    public void test39() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test39");
        int int2 = ClassExampleWithNoFailure.foo((-810123264), 559939584);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test40() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test40");
        int int2 = ClassExampleWithNoFailure.foo((-409600000), 1597505536);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test41() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test41");
        int int2 = ClassExampleWithNoFailure.foo(63569920, 17920000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1073741824) + "'", int2 == (-1073741824));
    }

    @Test
    public void test42() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test42");
        int int2 = ClassExampleWithNoFailure.foo((-1056964608), (-1660944384));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test43() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test43");
        int int2 = ClassExampleWithNoFailure.foo(50331648, 14000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 536870912 + "'", int2 == 536870912);
    }

    @Test
    public void test44() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test44");
        int int2 = ClassExampleWithNoFailure.foo(1597505536, 536870912);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test45() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test45");
        int int2 = ClassExampleWithNoFailure.foo((-48174080), 878706688);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test46() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test46");
        int int2 = ClassExampleWithNoFailure.foo((-8320), (-567607296));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 352321536 + "'", int2 == 352321536);
    }

    @Test
    public void test47() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test47");
        int int2 = ClassExampleWithNoFailure.foo(4096000, (-570425344));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test48() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test48");
        int int1 = ClassExampleWithNoFailure.twice((-136757248));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-273514496) + "'", int1 == (-273514496));
    }

    @Test
    public void test49() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test49");
        int int2 = ClassExampleWithNoFailure.foo((-1771896832), 905969664);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test50() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test50");
        int int1 = ClassExampleWithNoFailure.twice(1677721600);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-939524096) + "'", int1 == (-939524096));
    }

    @Test
    public void test51() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test51");
        int int1 = ClassExampleWithNoFailure.twice(272629760);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 545259520 + "'", int1 == 545259520);
    }

    @Test
    public void test52() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test52");
        ClassExampleWithNoFailure classExampleWithNoFailure0 = new ClassExampleWithNoFailure();
        java.lang.Class<?> wildcardClass1 = classExampleWithNoFailure0.getClass();
        java.lang.Class<?> wildcardClass2 = classExampleWithNoFailure0.getClass();
        java.lang.Class<?> wildcardClass3 = classExampleWithNoFailure0.getClass();
        java.lang.Class<?> wildcardClass4 = classExampleWithNoFailure0.getClass();
        java.lang.Class<?> wildcardClass5 = classExampleWithNoFailure0.getClass();
        java.lang.Class<?> wildcardClass6 = classExampleWithNoFailure0.getClass();
        java.lang.Class<?> wildcardClass7 = classExampleWithNoFailure0.getClass();
        java.lang.Class<?> wildcardClass8 = classExampleWithNoFailure0.getClass();
        java.lang.Class<?> wildcardClass9 = classExampleWithNoFailure0.getClass();
        java.lang.Class<?> wildcardClass10 = classExampleWithNoFailure0.getClass();
        java.lang.Class<?> wildcardClass11 = classExampleWithNoFailure0.getClass();
        java.lang.Class<?> wildcardClass12 = classExampleWithNoFailure0.getClass();
        java.lang.Class<?> wildcardClass13 = classExampleWithNoFailure0.getClass();
        java.lang.Class<?> wildcardClass14 = classExampleWithNoFailure0.getClass();
        java.lang.Class<?> wildcardClass15 = classExampleWithNoFailure0.getClass();
        java.lang.Class<?> wildcardClass16 = classExampleWithNoFailure0.getClass();
        java.lang.Class<?> wildcardClass17 = classExampleWithNoFailure0.getClass();
        java.lang.Class<?> wildcardClass18 = classExampleWithNoFailure0.getClass();
        java.lang.Class<?> wildcardClass19 = classExampleWithNoFailure0.getClass();
        java.lang.Class<?> wildcardClass20 = classExampleWithNoFailure0.getClass();
        java.lang.Class<?> wildcardClass21 = classExampleWithNoFailure0.getClass();
        java.lang.Class<?> wildcardClass22 = classExampleWithNoFailure0.getClass();
        java.lang.Class<?> wildcardClass23 = classExampleWithNoFailure0.getClass();
        java.lang.Class<?> wildcardClass24 = classExampleWithNoFailure0.getClass();
        java.lang.Class<?> wildcardClass25 = classExampleWithNoFailure0.getClass();
        java.lang.Class<?> wildcardClass26 = classExampleWithNoFailure0.getClass();
        java.lang.Class<?> wildcardClass27 = classExampleWithNoFailure0.getClass();
        java.lang.Class<?> wildcardClass28 = classExampleWithNoFailure0.getClass();
        java.lang.Class<?> wildcardClass29 = classExampleWithNoFailure0.getClass();
        java.lang.Class<?> wildcardClass30 = classExampleWithNoFailure0.getClass();
        java.lang.Class<?> wildcardClass31 = classExampleWithNoFailure0.getClass();
        java.lang.Class<?> wildcardClass32 = classExampleWithNoFailure0.getClass();
        java.lang.Class<?> wildcardClass33 = classExampleWithNoFailure0.getClass();
        java.lang.Class<?> wildcardClass34 = classExampleWithNoFailure0.getClass();
        java.lang.Class<?> wildcardClass35 = classExampleWithNoFailure0.getClass();
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertNotNull(wildcardClass30);
        org.junit.Assert.assertNotNull(wildcardClass31);
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertNotNull(wildcardClass33);
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertNotNull(wildcardClass35);
    }

    @Test
    public void test53() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test53");
        int int2 = ClassExampleWithNoFailure.foo((int) 'a', 1738240);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 337218560 + "'", int2 == 337218560);
    }

    @Test
    public void test54() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test54");
        int int1 = ClassExampleWithNoFailure.twice((-233644288));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-467288576) + "'", int1 == (-467288576));
    }

    @Test
    public void test55() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test55");
        int int2 = ClassExampleWithNoFailure.foo(812646400, 67108864);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test56() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test56");
        int int1 = ClassExampleWithNoFailure.twice(1024000);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2048000 + "'", int1 == 2048000);
    }

    @Test
    public void test57() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test57");
        int int2 = ClassExampleWithNoFailure.foo(34611200, 1120);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 219676672 + "'", int2 == 219676672);
    }

    @Test
    public void test58() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test58");
        int int2 = ClassExampleWithNoFailure.foo((-969113600), 977403904);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }
}

