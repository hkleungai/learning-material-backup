import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class ClassExampleWithNoFailureRegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        int int2 = ClassExampleWithNoFailure.foo((int) '4', (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5408 + "'", int2 == 5408);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        int int2 = ClassExampleWithNoFailure.foo((int) (byte) 10, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20 + "'", int2 == 20);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        int int2 = ClassExampleWithNoFailure.foo((int) 'a', 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        int int2 = ClassExampleWithNoFailure.foo(5408, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        int int1 = ClassExampleWithNoFailure.twice(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        int int1 = ClassExampleWithNoFailure.twice((int) (short) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2 + "'", int1 == 2);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        int int2 = ClassExampleWithNoFailure.foo((int) (short) -1, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        int int1 = ClassExampleWithNoFailure.twice(10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 20 + "'", int1 == 20);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        int int1 = ClassExampleWithNoFailure.twice((int) '#');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 70 + "'", int1 == 70);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        int int2 = ClassExampleWithNoFailure.foo((int) '4', (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        int int1 = ClassExampleWithNoFailure.twice((int) 'a');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 194 + "'", int1 == 194);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        int int2 = ClassExampleWithNoFailure.foo((int) ' ', (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 640 + "'", int2 == 640);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        int int2 = ClassExampleWithNoFailure.foo((int) ' ', (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-64) + "'", int2 == (-64));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        int int2 = ClassExampleWithNoFailure.foo((int) (byte) 10, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        int int1 = ClassExampleWithNoFailure.twice(20);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 40 + "'", int1 == 40);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        int int1 = ClassExampleWithNoFailure.twice((int) (short) -1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-2) + "'", int1 == (-2));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        int int2 = ClassExampleWithNoFailure.foo((-1), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        int int1 = ClassExampleWithNoFailure.twice(194);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 388 + "'", int1 == 388);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        int int1 = ClassExampleWithNoFailure.twice((int) '4');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 104 + "'", int1 == 104);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        int int1 = ClassExampleWithNoFailure.twice(2);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        int int1 = ClassExampleWithNoFailure.twice((int) (short) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 20 + "'", int1 == 20);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        int int2 = ClassExampleWithNoFailure.foo((int) (short) 0, 640);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        int int1 = ClassExampleWithNoFailure.twice((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2 + "'", int1 == 2);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        int int2 = ClassExampleWithNoFailure.foo(0, (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        int int1 = ClassExampleWithNoFailure.twice(640);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1280 + "'", int1 == 1280);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        int int1 = ClassExampleWithNoFailure.twice((int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 200 + "'", int1 == 200);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        int int2 = ClassExampleWithNoFailure.foo(0, (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        int int2 = ClassExampleWithNoFailure.foo((int) '#', (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7000 + "'", int2 == 7000);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        int int2 = ClassExampleWithNoFailure.foo(2, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        int int2 = ClassExampleWithNoFailure.foo(2, (int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 140 + "'", int2 == 140);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        int int1 = ClassExampleWithNoFailure.twice(5408);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10816 + "'", int1 == 10816);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        int int1 = ClassExampleWithNoFailure.twice(100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 200 + "'", int1 == 200);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        int int2 = ClassExampleWithNoFailure.foo(7000, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-14000) + "'", int2 == (-14000));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        int int2 = ClassExampleWithNoFailure.foo((int) (byte) 10, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-20) + "'", int2 == (-20));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        int int1 = ClassExampleWithNoFailure.twice((int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 20 + "'", int1 == 20);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        int int1 = ClassExampleWithNoFailure.twice(140);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 280 + "'", int1 == 280);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        int int2 = ClassExampleWithNoFailure.foo(1, 200);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 400 + "'", int2 == 400);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        int int2 = ClassExampleWithNoFailure.foo(400, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        int int2 = ClassExampleWithNoFailure.foo(40, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-80) + "'", int2 == (-80));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        int int1 = ClassExampleWithNoFailure.twice(280);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 560 + "'", int1 == 560);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        int int2 = ClassExampleWithNoFailure.foo(1, 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 200 + "'", int2 == 200);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        int int2 = ClassExampleWithNoFailure.foo(200, (int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14000 + "'", int2 == 14000);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        int int2 = ClassExampleWithNoFailure.foo((int) (byte) 10, (-20));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-400) + "'", int2 == (-400));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        int int2 = ClassExampleWithNoFailure.foo((-2), 14000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-56000) + "'", int2 == (-56000));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        int int1 = ClassExampleWithNoFailure.twice((-1));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-2) + "'", int1 == (-2));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        int int2 = ClassExampleWithNoFailure.foo(70, 10816);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1514240 + "'", int2 == 1514240);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        int int2 = ClassExampleWithNoFailure.foo((int) (short) 1, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        int int2 = ClassExampleWithNoFailure.foo((-14000), (-80));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2240000 + "'", int2 == 2240000);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        int int2 = ClassExampleWithNoFailure.foo((-400), (-2));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1600 + "'", int2 == 1600);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        int int2 = ClassExampleWithNoFailure.foo(1, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2) + "'", int2 == (-2));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        int int2 = ClassExampleWithNoFailure.foo((-80), 14000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2240000) + "'", int2 == (-2240000));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        int int2 = ClassExampleWithNoFailure.foo(0, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        int int2 = ClassExampleWithNoFailure.foo(200, 2);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 800 + "'", int2 == 800);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        int int2 = ClassExampleWithNoFailure.foo((int) (byte) 10, (-400));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-8000) + "'", int2 == (-8000));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        int int1 = ClassExampleWithNoFailure.twice((-2));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-4) + "'", int1 == (-4));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        int int2 = ClassExampleWithNoFailure.foo(5408, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        int int2 = ClassExampleWithNoFailure.foo(0, 560);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        int int2 = ClassExampleWithNoFailure.foo((int) (byte) 1, (-8000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-16000) + "'", int2 == (-16000));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        int int2 = ClassExampleWithNoFailure.foo((-400), 1514240);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1211392000) + "'", int2 == (-1211392000));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        int int1 = ClassExampleWithNoFailure.twice(800);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1600 + "'", int1 == 1600);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        int int2 = ClassExampleWithNoFailure.foo((int) 'a', 20);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3880 + "'", int2 == 3880);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        int int2 = ClassExampleWithNoFailure.foo((-400), 1280);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1024000) + "'", int2 == (-1024000));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        int int1 = ClassExampleWithNoFailure.twice((int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        int int2 = ClassExampleWithNoFailure.foo((int) (short) 100, (-80));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-16000) + "'", int2 == (-16000));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        int int2 = ClassExampleWithNoFailure.foo((int) ' ', (-80));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-5120) + "'", int2 == (-5120));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        int int2 = ClassExampleWithNoFailure.foo((-2), (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        int int2 = ClassExampleWithNoFailure.foo((-20), (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 40 + "'", int2 == 40);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        int int2 = ClassExampleWithNoFailure.foo((-14000), 800);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-22400000) + "'", int2 == (-22400000));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        int int1 = ClassExampleWithNoFailure.twice(388);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 776 + "'", int1 == 776);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        int int1 = ClassExampleWithNoFailure.twice(7000);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 14000 + "'", int1 == 14000);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        int int1 = ClassExampleWithNoFailure.twice(3880);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 7760 + "'", int1 == 7760);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        int int2 = ClassExampleWithNoFailure.foo(20, 2240000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 89600000 + "'", int2 == 89600000);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        int int1 = ClassExampleWithNoFailure.twice((int) (short) 100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 200 + "'", int1 == 200);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        int int2 = ClassExampleWithNoFailure.foo((-400), (-1024000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 819200000 + "'", int2 == 819200000);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        int int2 = ClassExampleWithNoFailure.foo(2240000, (int) ' ');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 143360000 + "'", int2 == 143360000);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        int int2 = ClassExampleWithNoFailure.foo(280, 1280);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 716800 + "'", int2 == 716800);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        int int1 = ClassExampleWithNoFailure.twice((-5120));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-10240) + "'", int1 == (-10240));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        int int2 = ClassExampleWithNoFailure.foo(560, (-2240000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1786167296 + "'", int2 == 1786167296);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        int int2 = ClassExampleWithNoFailure.foo(1514240, (-20));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-60569600) + "'", int2 == (-60569600));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        int int1 = ClassExampleWithNoFailure.twice(400);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 800 + "'", int1 == 800);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        int int2 = ClassExampleWithNoFailure.foo((int) (byte) -1, 3880);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-7760) + "'", int2 == (-7760));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        int int1 = ClassExampleWithNoFailure.twice(1786167296);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-722632704) + "'", int1 == (-722632704));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        int int1 = ClassExampleWithNoFailure.twice((-2240000));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-4480000) + "'", int1 == (-4480000));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        int int2 = ClassExampleWithNoFailure.foo(1, 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20 + "'", int2 == 20);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        int int2 = ClassExampleWithNoFailure.foo(104, 14000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2912000 + "'", int2 == 2912000);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        int int2 = ClassExampleWithNoFailure.foo(388, (-8000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-6208000) + "'", int2 == (-6208000));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        int int2 = ClassExampleWithNoFailure.foo(7760, 20);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 310400 + "'", int2 == 310400);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        int int1 = ClassExampleWithNoFailure.twice(4);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 8 + "'", int1 == 8);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        int int2 = ClassExampleWithNoFailure.foo(70, (-16000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2240000) + "'", int2 == (-2240000));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        int int2 = ClassExampleWithNoFailure.foo((int) (short) 0, (-56000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        int int1 = ClassExampleWithNoFailure.twice((-20));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-40) + "'", int1 == (-40));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        int int2 = ClassExampleWithNoFailure.foo((-56000), (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-11200000) + "'", int2 == (-11200000));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        int int2 = ClassExampleWithNoFailure.foo(70, 819200000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1276116992) + "'", int2 == (-1276116992));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        int int1 = ClassExampleWithNoFailure.twice((-64));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-128) + "'", int1 == (-128));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        int int1 = ClassExampleWithNoFailure.twice((-10240));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-20480) + "'", int1 == (-20480));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        int int2 = ClassExampleWithNoFailure.foo((int) (short) 10, (-4480000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-89600000) + "'", int2 == (-89600000));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        int int2 = ClassExampleWithNoFailure.foo(70, (-7760));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1086400) + "'", int2 == (-1086400));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        int int2 = ClassExampleWithNoFailure.foo(14000, (-80));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2240000) + "'", int2 == (-2240000));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        int int2 = ClassExampleWithNoFailure.foo((-11200000), (-11200000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1924661248) + "'", int2 == (-1924661248));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        int int1 = ClassExampleWithNoFailure.twice(2240000);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4480000 + "'", int1 == 4480000);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        int int2 = ClassExampleWithNoFailure.foo(4, 10816);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 86528 + "'", int2 == 86528);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        int int1 = ClassExampleWithNoFailure.twice((int) ' ');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 64 + "'", int1 == 64);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        int int1 = ClassExampleWithNoFailure.twice(14000);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 28000 + "'", int1 == 28000);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        int int2 = ClassExampleWithNoFailure.foo((-2), (-11200000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 44800000 + "'", int2 == 44800000);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        int int1 = ClassExampleWithNoFailure.twice(104);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 208 + "'", int1 == 208);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        int int1 = ClassExampleWithNoFailure.twice(40);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 80 + "'", int1 == 80);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        int int1 = ClassExampleWithNoFailure.twice(2912000);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 5824000 + "'", int1 == 5824000);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        int int1 = ClassExampleWithNoFailure.twice((-1276116992));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1742733312 + "'", int1 == 1742733312);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        int int1 = ClassExampleWithNoFailure.twice(7760);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15520 + "'", int1 == 15520);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        int int2 = ClassExampleWithNoFailure.foo(208, (-20));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-8320) + "'", int2 == (-8320));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        int int2 = ClassExampleWithNoFailure.foo((int) (byte) 100, (-10240));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2048000) + "'", int2 == (-2048000));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        int int2 = ClassExampleWithNoFailure.foo((int) (short) 100, 560);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 112000 + "'", int2 == 112000);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        int int1 = ClassExampleWithNoFailure.twice(5824000);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 11648000 + "'", int1 == 11648000);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        int int2 = ClassExampleWithNoFailure.foo(7000, (-5120));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-71680000) + "'", int2 == (-71680000));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        int int2 = ClassExampleWithNoFailure.foo((-722632704), 28000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-249561088) + "'", int2 == (-249561088));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        int int2 = ClassExampleWithNoFailure.foo(3880, 819200000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 440401920 + "'", int2 == 440401920);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        int int2 = ClassExampleWithNoFailure.foo(0, 5824000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        int int2 = ClassExampleWithNoFailure.foo(0, 44800000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        int int2 = ClassExampleWithNoFailure.foo(2240000, 70);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 313600000 + "'", int2 == 313600000);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        int int2 = ClassExampleWithNoFailure.foo(14000, 143360000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1714421760) + "'", int2 == (-1714421760));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        int int2 = ClassExampleWithNoFailure.foo(400, (int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 28000 + "'", int2 == 28000);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        int int2 = ClassExampleWithNoFailure.foo(14000, 40);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1120000 + "'", int2 == 1120000);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        int int2 = ClassExampleWithNoFailure.foo(716800, (int) ' ');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 45875200 + "'", int2 == 45875200);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        int int1 = ClassExampleWithNoFailure.twice((-6208000));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-12416000) + "'", int1 == (-12416000));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        int int2 = ClassExampleWithNoFailure.foo((-128), (-2048000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 524288000 + "'", int2 == 524288000);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        int int2 = ClassExampleWithNoFailure.foo(70, (-20480));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2867200) + "'", int2 == (-2867200));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        int int1 = ClassExampleWithNoFailure.twice(86528);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 173056 + "'", int1 == 173056);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        int int1 = ClassExampleWithNoFailure.twice(10816);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 21632 + "'", int1 == 21632);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        int int2 = ClassExampleWithNoFailure.foo(1280, (-20480));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-52428800) + "'", int2 == (-52428800));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        int int2 = ClassExampleWithNoFailure.foo(20, (-2048000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-81920000) + "'", int2 == (-81920000));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        int int2 = ClassExampleWithNoFailure.foo((-1), 21632);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-43264) + "'", int2 == (-43264));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        int int2 = ClassExampleWithNoFailure.foo((int) (short) 1, 560);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1120 + "'", int2 == 1120);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        int int2 = ClassExampleWithNoFailure.foo(776, (-2));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-3104) + "'", int2 == (-3104));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        int int2 = ClassExampleWithNoFailure.foo((int) (short) 100, 2);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 400 + "'", int2 == 400);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        int int2 = ClassExampleWithNoFailure.foo(100, 5408);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1081600 + "'", int2 == 1081600);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        int int2 = ClassExampleWithNoFailure.foo(2912000, 14000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-68378624) + "'", int2 == (-68378624));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        int int2 = ClassExampleWithNoFailure.foo((-1211392000), (-40));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1872887808) + "'", int2 == (-1872887808));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        int int2 = ClassExampleWithNoFailure.foo(560, (-7760));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-8691200) + "'", int2 == (-8691200));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        int int1 = ClassExampleWithNoFailure.twice((int) (short) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        int int2 = ClassExampleWithNoFailure.foo(4, 800);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6400 + "'", int2 == 6400);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        int int2 = ClassExampleWithNoFailure.foo(64, 89600000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1416101888) + "'", int2 == (-1416101888));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        int int2 = ClassExampleWithNoFailure.foo((-16000), (-1086400));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 405061632 + "'", int2 == 405061632);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        int int1 = ClassExampleWithNoFailure.twice(112000);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 224000 + "'", int1 == 224000);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        int int2 = ClassExampleWithNoFailure.foo((-40), (-1086400));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 86912000 + "'", int2 == 86912000);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        int int2 = ClassExampleWithNoFailure.foo((-80), 1600);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-256000) + "'", int2 == (-256000));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        int int2 = ClassExampleWithNoFailure.foo(5824000, (-40));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-465920000) + "'", int2 == (-465920000));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        int int2 = ClassExampleWithNoFailure.foo((-56000), (-16000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1792000000 + "'", int2 == 1792000000);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        int int1 = ClassExampleWithNoFailure.twice((-722632704));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1445265408) + "'", int1 == (-1445265408));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        int int1 = ClassExampleWithNoFailure.twice(1120);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2240 + "'", int1 == 2240);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        int int1 = ClassExampleWithNoFailure.twice((-89600000));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-179200000) + "'", int1 == (-179200000));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        int int2 = ClassExampleWithNoFailure.foo((-256000), (-400));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 204800000 + "'", int2 == 204800000);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        int int2 = ClassExampleWithNoFailure.foo(86528, (-722632704));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 637534208 + "'", int2 == 637534208);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        int int1 = ClassExampleWithNoFailure.twice(1120000);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2240000 + "'", int1 == 2240000);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        int int2 = ClassExampleWithNoFailure.foo(2240000, 637534208);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        int int2 = ClassExampleWithNoFailure.foo(28000, 21632);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1211392000 + "'", int2 == 1211392000);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        int int2 = ClassExampleWithNoFailure.foo(5824000, 4);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 46592000 + "'", int2 == 46592000);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        int int1 = ClassExampleWithNoFailure.twice((-400));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-800) + "'", int1 == (-800));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        int int2 = ClassExampleWithNoFailure.foo(28000, (-1872887808));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1384120320 + "'", int2 == 1384120320);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        int int1 = ClassExampleWithNoFailure.twice((-1872887808));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 549191680 + "'", int1 == 549191680);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        int int2 = ClassExampleWithNoFailure.foo(800, 1280);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2048000 + "'", int2 == 2048000);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        int int1 = ClassExampleWithNoFailure.twice(1280);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2560 + "'", int1 == 2560);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        int int2 = ClassExampleWithNoFailure.foo(388, (-1924661248));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1111490560 + "'", int2 == 1111490560);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        int int1 = ClassExampleWithNoFailure.twice((-4));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-8) + "'", int1 == (-8));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        int int2 = ClassExampleWithNoFailure.foo((int) (short) -1, 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-200) + "'", int2 == (-200));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        int int2 = ClassExampleWithNoFailure.foo(0, (-52428800));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        int int1 = ClassExampleWithNoFailure.twice(70);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 140 + "'", int1 == 140);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        int int2 = ClassExampleWithNoFailure.foo((-10240), (-60569600));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-780140544) + "'", int2 == (-780140544));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        int int2 = ClassExampleWithNoFailure.foo(2048000, 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 40960000 + "'", int2 == 40960000);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        int int2 = ClassExampleWithNoFailure.foo(313600000, (-8000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1078198272) + "'", int2 == (-1078198272));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        int int2 = ClassExampleWithNoFailure.foo((-128), (-722632704));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 310378496 + "'", int2 == 310378496);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        int int2 = ClassExampleWithNoFailure.foo((-14000), (-1416101888));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-285212672) + "'", int2 == (-285212672));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        int int2 = ClassExampleWithNoFailure.foo(45875200, 310400);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-603979776) + "'", int2 == (-603979776));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        int int1 = ClassExampleWithNoFailure.twice(549191680);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1098383360 + "'", int1 == 1098383360);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        int int2 = ClassExampleWithNoFailure.foo(716800, 524288000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        int int2 = ClassExampleWithNoFailure.foo(20, (-80));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-3200) + "'", int2 == (-3200));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        int int1 = ClassExampleWithNoFailure.twice((int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-2) + "'", int1 == (-2));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        int int2 = ClassExampleWithNoFailure.foo(140, (-249561088));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1157627904) + "'", int2 == (-1157627904));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        int int2 = ClassExampleWithNoFailure.foo(1600, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        int int2 = ClassExampleWithNoFailure.foo(0, 800);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        int int1 = ClassExampleWithNoFailure.twice(224000);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 448000 + "'", int1 == 448000);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        int int2 = ClassExampleWithNoFailure.foo(448000, (-11200000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2138570752 + "'", int2 == 2138570752);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        int int2 = ClassExampleWithNoFailure.foo(405061632, (-400));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1926758400) + "'", int2 == (-1926758400));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        int int2 = ClassExampleWithNoFailure.foo((-1024000), 1081600);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1086324736 + "'", int2 == 1086324736);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        int int2 = ClassExampleWithNoFailure.foo(0, 40960000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        int int1 = ClassExampleWithNoFailure.twice((-12416000));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-24832000) + "'", int1 == (-24832000));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        int int2 = ClassExampleWithNoFailure.foo((-71680000), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        int int2 = ClassExampleWithNoFailure.foo(4, (-2));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-16) + "'", int2 == (-16));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        int int1 = ClassExampleWithNoFailure.twice(313600000);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 627200000 + "'", int1 == 627200000);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        int int2 = ClassExampleWithNoFailure.foo(2912000, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        int int2 = ClassExampleWithNoFailure.foo((-12416000), (-43264));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 589824000 + "'", int2 == 589824000);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        int int2 = ClassExampleWithNoFailure.foo(819200000, (-1872887808));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        int int1 = ClassExampleWithNoFailure.twice(173056);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 346112 + "'", int1 == 346112);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        int int2 = ClassExampleWithNoFailure.foo((-4), 280);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2240) + "'", int2 == (-2240));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        int int2 = ClassExampleWithNoFailure.foo(2560, 819200000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1879048192) + "'", int2 == (-1879048192));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        int int1 = ClassExampleWithNoFailure.twice(405061632);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 810123264 + "'", int1 == 810123264);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        int int1 = ClassExampleWithNoFailure.twice((-1879048192));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 536870912 + "'", int1 == 536870912);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        int int2 = ClassExampleWithNoFailure.foo(14000, (-1924661248));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1560281088) + "'", int2 == (-1560281088));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        int int1 = ClassExampleWithNoFailure.twice((-22400000));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-44800000) + "'", int1 == (-44800000));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        int int2 = ClassExampleWithNoFailure.foo((int) (short) 0, 2138570752);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        int int2 = ClassExampleWithNoFailure.foo(3880, (-1078198272));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-222298112) + "'", int2 == (-222298112));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        int int2 = ClassExampleWithNoFailure.foo((int) '#', 6400);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 448000 + "'", int2 == 448000);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        int int1 = ClassExampleWithNoFailure.twice(45875200);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 91750400 + "'", int1 == 91750400);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        int int2 = ClassExampleWithNoFailure.foo(0, 2240);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        int int2 = ClassExampleWithNoFailure.foo(388, (int) ' ');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24832 + "'", int2 == 24832);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        int int2 = ClassExampleWithNoFailure.foo(1120, (-22400000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1363607552 + "'", int2 == 1363607552);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        int int1 = ClassExampleWithNoFailure.twice((-1926758400));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 441450496 + "'", int1 == 441450496);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        int int2 = ClassExampleWithNoFailure.foo((-8000), (-2048000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1591738368) + "'", int2 == (-1591738368));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        int int2 = ClassExampleWithNoFailure.foo(388, (-222298112));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-704643072) + "'", int2 == (-704643072));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        int int2 = ClassExampleWithNoFailure.foo(1081600, 140);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 302848000 + "'", int2 == 302848000);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        int int2 = ClassExampleWithNoFailure.foo(44800000, (-16));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1433600000) + "'", int2 == (-1433600000));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        int int2 = ClassExampleWithNoFailure.foo(6400, (-10240));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-131072000) + "'", int2 == (-131072000));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        int int2 = ClassExampleWithNoFailure.foo(5824000, 5408);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1432125440) + "'", int2 == (-1432125440));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        int int1 = ClassExampleWithNoFailure.twice((-4480000));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-8960000) + "'", int1 == (-8960000));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        int int2 = ClassExampleWithNoFailure.foo(2240000, (-3200));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1451098112) + "'", int2 == (-1451098112));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        int int1 = ClassExampleWithNoFailure.twice((-3200));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-6400) + "'", int1 == (-6400));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        int int2 = ClassExampleWithNoFailure.foo((-1432125440), (-40));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1394081792) + "'", int2 == (-1394081792));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        int int2 = ClassExampleWithNoFailure.foo((-40), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        int int2 = ClassExampleWithNoFailure.foo((-249561088), 1098383360);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        int int2 = ClassExampleWithNoFailure.foo((-64), 45875200);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1577058304) + "'", int2 == (-1577058304));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        int int2 = ClassExampleWithNoFailure.foo(1384120320, 441450496);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        int int2 = ClassExampleWithNoFailure.foo((-22400000), 7760);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 244350976 + "'", int2 == 244350976);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        int int2 = ClassExampleWithNoFailure.foo(20, (-1926758400));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 239075328 + "'", int2 == 239075328);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        int int1 = ClassExampleWithNoFailure.twice(21632);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 43264 + "'", int1 == 43264);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        int int2 = ClassExampleWithNoFailure.foo((-4480000), 143360000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1140850688) + "'", int2 == (-1140850688));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        int int1 = ClassExampleWithNoFailure.twice(2560);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 5120 + "'", int1 == 5120);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        int int2 = ClassExampleWithNoFailure.foo((-11200000), (-1591738368));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2147483648) + "'", int2 == (-2147483648));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        int int1 = ClassExampleWithNoFailure.twice(1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2 + "'", int1 == 2);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        int int1 = ClassExampleWithNoFailure.twice(524288000);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1048576000 + "'", int1 == 1048576000);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        int int2 = ClassExampleWithNoFailure.foo((-603979776), (-6400));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        int int2 = ClassExampleWithNoFailure.foo(46592000, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        int int1 = ClassExampleWithNoFailure.twice(200);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 400 + "'", int1 == 400);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        int int2 = ClassExampleWithNoFailure.foo(46592000, (-603979776));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        int int2 = ClassExampleWithNoFailure.foo((int) (short) -1, (-465920000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 931840000 + "'", int2 == 931840000);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        int int2 = ClassExampleWithNoFailure.foo((-14000), 70);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1960000) + "'", int2 == (-1960000));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        int int2 = ClassExampleWithNoFailure.foo(40, (-1394081792));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 142606336 + "'", int2 == 142606336);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        int int1 = ClassExampleWithNoFailure.twice((-20480));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-40960) + "'", int1 == (-40960));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        int int2 = ClassExampleWithNoFailure.foo(204800000, 310400);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 218103808 + "'", int2 == 218103808);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        int int2 = ClassExampleWithNoFailure.foo(1742733312, 776);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1107296256) + "'", int2 == (-1107296256));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        int int2 = ClassExampleWithNoFailure.foo(200, 640);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 256000 + "'", int2 == 256000);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        int int1 = ClassExampleWithNoFailure.twice((-1591738368));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1111490560 + "'", int1 == 1111490560);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        int int2 = ClassExampleWithNoFailure.foo(194, (-1560281088));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 201326592 + "'", int2 == 201326592);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        int int2 = ClassExampleWithNoFailure.foo((-80), 21632);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-3461120) + "'", int2 == (-3461120));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        int int1 = ClassExampleWithNoFailure.twice(6400);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 12800 + "'", int1 == 12800);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        int int2 = ClassExampleWithNoFailure.foo(91750400, (-249561088));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        int int2 = ClassExampleWithNoFailure.foo((int) (short) 1, 3880);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7760 + "'", int2 == 7760);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        int int2 = ClassExampleWithNoFailure.foo((-1714421760), (-1577058304));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        int int1 = ClassExampleWithNoFailure.twice((-2147483648));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        int int2 = ClassExampleWithNoFailure.foo((-249561088), 80);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1275068416) + "'", int2 == (-1275068416));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        int int2 = ClassExampleWithNoFailure.foo(1742733312, (-1394081792));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        int int1 = ClassExampleWithNoFailure.twice((-1960000));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-3920000) + "'", int1 == (-3920000));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        int int2 = ClassExampleWithNoFailure.foo((-1157627904), 1120000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        int int2 = ClassExampleWithNoFailure.foo((-12416000), 1211392000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-922746880) + "'", int2 == (-922746880));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        int int2 = ClassExampleWithNoFailure.foo(819200000, 244350976);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        int int2 = ClassExampleWithNoFailure.foo(142606336, 405061632);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        int int2 = ClassExampleWithNoFailure.foo(536870912, (-40960));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        int int2 = ClassExampleWithNoFailure.foo(313600000, (-64));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1486094336) + "'", int2 == (-1486094336));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        int int1 = ClassExampleWithNoFailure.twice((-16000));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-32000) + "'", int1 == (-32000));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        int int1 = ClassExampleWithNoFailure.twice((-1560281088));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1174405120 + "'", int1 == 1174405120);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        int int2 = ClassExampleWithNoFailure.foo((-3461120), (-52428800));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        int int2 = ClassExampleWithNoFailure.foo(244350976, 2138570752);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        int int2 = ClassExampleWithNoFailure.foo((-1432125440), (-465920000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1610612736 + "'", int2 == 1610612736);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        int int1 = ClassExampleWithNoFailure.twice(80);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 160 + "'", int1 == 160);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        int int2 = ClassExampleWithNoFailure.foo((-1486094336), (-200));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1732247552 + "'", int2 == 1732247552);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        int int2 = ClassExampleWithNoFailure.foo(819200000, 405061632);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        int int1 = ClassExampleWithNoFailure.twice(40960000);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 81920000 + "'", int1 == 81920000);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        int int1 = ClassExampleWithNoFailure.twice((-1432125440));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1430716416 + "'", int1 == 1430716416);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        int int2 = ClassExampleWithNoFailure.foo(10816, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        int int2 = ClassExampleWithNoFailure.foo(1363607552, 20);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1290272768) + "'", int2 == (-1290272768));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        int int2 = ClassExampleWithNoFailure.foo(70, (-1451098112));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1290272768) + "'", int2 == (-1290272768));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        int int2 = ClassExampleWithNoFailure.foo((-8), 1732247552);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1946157056) + "'", int2 == (-1946157056));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        int int1 = ClassExampleWithNoFailure.twice(11648000);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 23296000 + "'", int1 == 23296000);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        int int2 = ClassExampleWithNoFailure.foo(776, 560);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 869120 + "'", int2 == 869120);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        int int2 = ClassExampleWithNoFailure.foo(15520, 2240);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 69529600 + "'", int2 == 69529600);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        int int1 = ClassExampleWithNoFailure.twice(1086324736);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-2122317824) + "'", int1 == (-2122317824));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        int int1 = ClassExampleWithNoFailure.twice((-3461120));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-6922240) + "'", int1 == (-6922240));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        int int2 = ClassExampleWithNoFailure.foo(1610612736, 310378496);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        int int1 = ClassExampleWithNoFailure.twice((-6400));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-12800) + "'", int1 == (-12800));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        int int2 = ClassExampleWithNoFailure.foo(1120, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        int int1 = ClassExampleWithNoFailure.twice((-81920000));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-163840000) + "'", int1 == (-163840000));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        int int1 = ClassExampleWithNoFailure.twice(218103808);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 436207616 + "'", int1 == 436207616);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        int int2 = ClassExampleWithNoFailure.foo(218103808, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        int int2 = ClassExampleWithNoFailure.foo((-128), (-179200000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1369440256) + "'", int2 == (-1369440256));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        int int2 = ClassExampleWithNoFailure.foo(716800, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        int int2 = ClassExampleWithNoFailure.foo(4480000, 81920000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1879048192 + "'", int2 == 1879048192);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        int int2 = ClassExampleWithNoFailure.foo((-285212672), 2240);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2147483648) + "'", int2 == (-2147483648));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        int int1 = ClassExampleWithNoFailure.twice((-7760));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-15520) + "'", int1 == (-15520));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        int int1 = ClassExampleWithNoFailure.twice((-1211392000));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1872183296 + "'", int1 == 1872183296);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        int int2 = ClassExampleWithNoFailure.foo((-249561088), 800);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 134217728 + "'", int2 == 134217728);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        int int2 = ClassExampleWithNoFailure.foo((-32000), 448000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1392771072 + "'", int2 == 1392771072);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        int int2 = ClassExampleWithNoFailure.foo(640, 89600000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1276116992) + "'", int2 == (-1276116992));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        int int1 = ClassExampleWithNoFailure.twice(776);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1552 + "'", int1 == 1552);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        int int2 = ClassExampleWithNoFailure.foo(80, 2048000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 327680000 + "'", int2 == 327680000);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        int int2 = ClassExampleWithNoFailure.foo(441450496, (-56000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1207959552 + "'", int2 == 1207959552);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        int int2 = ClassExampleWithNoFailure.foo((-15520), 627200000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 798752768 + "'", int2 == 798752768);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        int int1 = ClassExampleWithNoFailure.twice((-2122317824));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 50331648 + "'", int1 == 50331648);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        int int2 = ClassExampleWithNoFailure.foo(1879048192, (-40));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        int int2 = ClassExampleWithNoFailure.foo(15520, 239075328);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-805306368) + "'", int2 == (-805306368));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        int int1 = ClassExampleWithNoFailure.twice((-179200000));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-358400000) + "'", int1 == (-358400000));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        int int2 = ClassExampleWithNoFailure.foo((int) (short) -1, 1048576000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2097152000) + "'", int2 == (-2097152000));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        int int1 = ClassExampleWithNoFailure.twice((-222298112));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-444596224) + "'", int1 == (-444596224));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        int int1 = ClassExampleWithNoFailure.twice(1872183296);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-550600704) + "'", int1 == (-550600704));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        int int2 = ClassExampleWithNoFailure.foo((-4480000), (-14000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 885948416 + "'", int2 == 885948416);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        int int2 = ClassExampleWithNoFailure.foo(1081600, (-40));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-86528000) + "'", int2 == (-86528000));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        int int2 = ClassExampleWithNoFailure.foo((-40960), (-60569600));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1174405120 + "'", int2 == 1174405120);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        int int2 = ClassExampleWithNoFailure.foo(869120, 869120);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1089339392) + "'", int2 == (-1089339392));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        int int2 = ClassExampleWithNoFailure.foo(1086324736, 1098383360);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        int int1 = ClassExampleWithNoFailure.twice(28000);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 56000 + "'", int1 == 56000);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        int int2 = ClassExampleWithNoFailure.foo((-12800), 80);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2048000) + "'", int2 == (-2048000));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        int int2 = ClassExampleWithNoFailure.foo((-24832000), (-1107296256));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        int int1 = ClassExampleWithNoFailure.twice((-163840000));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-327680000) + "'", int1 == (-327680000));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        int int2 = ClassExampleWithNoFailure.foo(1872183296, (-71680000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1610612736) + "'", int2 == (-1610612736));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        int int2 = ClassExampleWithNoFailure.foo(3880, (-1879048192));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        int int2 = ClassExampleWithNoFailure.foo(536870912, 637534208);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        int int2 = ClassExampleWithNoFailure.foo(64, (-550600704));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1757413376) + "'", int2 == (-1757413376));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        int int2 = ClassExampleWithNoFailure.foo((-1276116992), 201326592);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        int int2 = ClassExampleWithNoFailure.foo((-256000), (-22400000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1237319680 + "'", int2 == 1237319680);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        int int1 = ClassExampleWithNoFailure.twice((-1757413376));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 780140544 + "'", int1 == 780140544);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        int int2 = ClassExampleWithNoFailure.foo(43264, 400);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 34611200 + "'", int2 == 34611200);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        int int2 = ClassExampleWithNoFailure.foo(0, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        int int1 = ClassExampleWithNoFailure.twice((-1946157056));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 402653184 + "'", int1 == 402653184);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        int int2 = ClassExampleWithNoFailure.foo(346112, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        int int1 = ClassExampleWithNoFailure.twice(436207616);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 872415232 + "'", int1 == 872415232);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        int int1 = ClassExampleWithNoFailure.twice((-1107296256));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2080374784 + "'", int1 == 2080374784);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        int int1 = ClassExampleWithNoFailure.twice((-327680000));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-655360000) + "'", int1 == (-655360000));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        int int1 = ClassExampleWithNoFailure.twice((-1089339392));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2116288512 + "'", int1 == 2116288512);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        int int2 = ClassExampleWithNoFailure.foo(1174405120, (-14000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1073741824) + "'", int2 == (-1073741824));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        int int2 = ClassExampleWithNoFailure.foo(100, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        int int1 = ClassExampleWithNoFailure.twice(44800000);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 89600000 + "'", int1 == 89600000);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        int int2 = ClassExampleWithNoFailure.foo(1552, 2240000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1636974592) + "'", int2 == (-1636974592));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        int int2 = ClassExampleWithNoFailure.foo(400, (-11200000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-370065408) + "'", int2 == (-370065408));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        int int1 = ClassExampleWithNoFailure.twice((-16));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-32) + "'", int1 == (-32));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        int int1 = ClassExampleWithNoFailure.twice(256000);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 512000 + "'", int1 == 512000);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        int int1 = ClassExampleWithNoFailure.twice(1211392000);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1872183296) + "'", int1 == (-1872183296));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        int int2 = ClassExampleWithNoFailure.foo(1742733312, (-1591738368));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        int int2 = ClassExampleWithNoFailure.foo(1174405120, (-1714421760));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        int int2 = ClassExampleWithNoFailure.foo((-358400000), (-16000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1237319680 + "'", int2 == 1237319680);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        int int2 = ClassExampleWithNoFailure.foo(400, 12800);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10240000 + "'", int2 == 10240000);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        int int1 = ClassExampleWithNoFailure.twice(24832);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 49664 + "'", int1 == 49664);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        int int2 = ClassExampleWithNoFailure.foo(104, (-1560281088));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1879048192 + "'", int2 == 1879048192);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        int int1 = ClassExampleWithNoFailure.twice(56000);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 112000 + "'", int1 == 112000);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        int int2 = ClassExampleWithNoFailure.foo(776, (-11200000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-202530816) + "'", int2 == (-202530816));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        int int2 = ClassExampleWithNoFailure.foo((-4), 45875200);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-367001600) + "'", int2 == (-367001600));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        int int1 = ClassExampleWithNoFailure.twice(402653184);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 805306368 + "'", int1 == 805306368);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        int int1 = ClassExampleWithNoFailure.twice(560);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1120 + "'", int1 == 1120);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        int int1 = ClassExampleWithNoFailure.twice(160);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 320 + "'", int1 == 320);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        int int1 = ClassExampleWithNoFailure.twice(15520);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 31040 + "'", int1 == 31040);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        int int2 = ClassExampleWithNoFailure.foo(1392771072, 1120000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1207959552) + "'", int2 == (-1207959552));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        int int2 = ClassExampleWithNoFailure.foo(627200000, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        int int2 = ClassExampleWithNoFailure.foo(81920000, 50331648);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        int int1 = ClassExampleWithNoFailure.twice(23296000);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 46592000 + "'", int1 == 46592000);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        int int1 = ClassExampleWithNoFailure.twice((-603979776));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1207959552) + "'", int1 == (-1207959552));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        int int2 = ClassExampleWithNoFailure.foo((-1), (-128));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 256 + "'", int2 == 256);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        int int1 = ClassExampleWithNoFailure.twice(81920000);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 163840000 + "'", int1 == 163840000);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        int int2 = ClassExampleWithNoFailure.foo((-1591738368), 1732247552);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        int int1 = ClassExampleWithNoFailure.twice(244350976);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 488701952 + "'", int1 == 488701952);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        int int2 = ClassExampleWithNoFailure.foo(40, 1120);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 89600 + "'", int2 == 89600);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        int int1 = ClassExampleWithNoFailure.twice(12800);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 25600 + "'", int1 == 25600);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        int int2 = ClassExampleWithNoFailure.foo((-6400), 5120);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-65536000) + "'", int2 == (-65536000));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        int int2 = ClassExampleWithNoFailure.foo(142606336, (-80));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1342177280) + "'", int2 == (-1342177280));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        int int2 = ClassExampleWithNoFailure.foo(1111490560, 208);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1476395008) + "'", int2 == (-1476395008));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        int int1 = ClassExampleWithNoFailure.twice(627200000);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1254400000 + "'", int1 == 1254400000);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        int int1 = ClassExampleWithNoFailure.twice((-8691200));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-17382400) + "'", int1 == (-17382400));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        int int2 = ClassExampleWithNoFailure.foo(49664, 160);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15892480 + "'", int2 == 15892480);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        int int2 = ClassExampleWithNoFailure.foo((int) (short) -1, 239075328);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-478150656) + "'", int2 == (-478150656));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        int int1 = ClassExampleWithNoFailure.twice((-80));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-160) + "'", int1 == (-160));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        int int2 = ClassExampleWithNoFailure.foo((-3200), 160);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1024000) + "'", int2 == (-1024000));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        int int2 = ClassExampleWithNoFailure.foo((-1924661248), 1120);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 905969664 + "'", int2 == 905969664);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        int int2 = ClassExampleWithNoFailure.foo((-131072000), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        int int2 = ClassExampleWithNoFailure.foo((-2097152000), 1120);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1073741824 + "'", int2 == 1073741824);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        int int1 = ClassExampleWithNoFailure.twice((-249561088));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-499122176) + "'", int1 == (-499122176));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        int int2 = ClassExampleWithNoFailure.foo(1048576000, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        int int1 = ClassExampleWithNoFailure.twice(46592000);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 93184000 + "'", int1 == 93184000);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        int int2 = ClassExampleWithNoFailure.foo((-44800000), (-1714421760));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        int int2 = ClassExampleWithNoFailure.foo((-32000), 1879048192);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        int int2 = ClassExampleWithNoFailure.foo((-370065408), (-32));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2085617664) + "'", int2 == (-2085617664));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        int int2 = ClassExampleWithNoFailure.foo((-32000), (-722632704));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 285212672 + "'", int2 == 285212672);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        int int2 = ClassExampleWithNoFailure.foo(100, 7760);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1552000 + "'", int2 == 1552000);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        int int2 = ClassExampleWithNoFailure.foo(310400, 24832);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1764163584) + "'", int2 == (-1764163584));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        int int1 = ClassExampleWithNoFailure.twice((-800));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1600) + "'", int1 == (-1600));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        int int2 = ClassExampleWithNoFailure.foo((-8320), (-12800));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 212992000 + "'", int2 == 212992000);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        int int2 = ClassExampleWithNoFailure.foo((-2048000), (-1610612736));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        int int2 = ClassExampleWithNoFailure.foo((-1960000), 589824000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-335544320) + "'", int2 == (-335544320));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        int int2 = ClassExampleWithNoFailure.foo(1, (-179200000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-358400000) + "'", int2 == (-358400000));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        int int2 = ClassExampleWithNoFailure.foo((-1276116992), 21632);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1879048192 + "'", int2 == 1879048192);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        int int2 = ClassExampleWithNoFailure.foo((-444596224), 2912000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        int int1 = ClassExampleWithNoFailure.twice(2240);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4480 + "'", int1 == 4480);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        int int1 = ClassExampleWithNoFailure.twice((-1714421760));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 866123776 + "'", int1 == 866123776);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        int int2 = ClassExampleWithNoFailure.foo((-15520), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        int int2 = ClassExampleWithNoFailure.foo(1742733312, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-809500672) + "'", int2 == (-809500672));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        int int2 = ClassExampleWithNoFailure.foo((-80), (-10240));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1638400 + "'", int2 == 1638400);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        int int2 = ClassExampleWithNoFailure.foo((-8960000), (-52428800));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        int int2 = ClassExampleWithNoFailure.foo((-14000), 218103808);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 536870912 + "'", int2 == 536870912);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        int int2 = ClassExampleWithNoFailure.foo(163840000, 302848000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1073741824) + "'", int2 == (-1073741824));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        int int2 = ClassExampleWithNoFailure.foo(28000, 8);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 448000 + "'", int2 == 448000);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        int int1 = ClassExampleWithNoFailure.twice((-1872183296));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 550600704 + "'", int1 == 550600704);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        int int1 = ClassExampleWithNoFailure.twice(1638400);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3276800 + "'", int1 == 3276800);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        int int1 = ClassExampleWithNoFailure.twice(869120);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1738240 + "'", int1 == 1738240);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        int int2 = ClassExampleWithNoFailure.foo(81920000, (-3461120));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1073741824) + "'", int2 == (-1073741824));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        int int1 = ClassExampleWithNoFailure.twice((-922746880));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1845493760) + "'", int1 == (-1845493760));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        int int1 = ClassExampleWithNoFailure.twice(1430716416);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1433534464) + "'", int1 == (-1433534464));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        int int2 = ClassExampleWithNoFailure.foo((-1086400), 1081600);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-753369088) + "'", int2 == (-753369088));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        int int2 = ClassExampleWithNoFailure.foo(550600704, 2240);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1379926016 + "'", int2 == 1379926016);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        int int2 = ClassExampleWithNoFailure.foo((-1445265408), (-202530816));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1073741824) + "'", int2 == (-1073741824));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        int int2 = ClassExampleWithNoFailure.foo(441450496, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 239075328 + "'", int2 == 239075328);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        int int2 = ClassExampleWithNoFailure.foo(50331648, 91750400);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        int int2 = ClassExampleWithNoFailure.foo((-32), (-40));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2560 + "'", int2 == 2560);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        int int1 = ClassExampleWithNoFailure.twice((-12800));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-25600) + "'", int1 == (-25600));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        int int2 = ClassExampleWithNoFailure.foo((-8320), (-285212672));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        int int1 = ClassExampleWithNoFailure.twice(239075328);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 478150656 + "'", int1 == 478150656);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        int int1 = ClassExampleWithNoFailure.twice(2048000);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4096000 + "'", int1 == 4096000);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        int int1 = ClassExampleWithNoFailure.twice(931840000);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1863680000 + "'", int1 == 1863680000);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        int int2 = ClassExampleWithNoFailure.foo(0, (-1107296256));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        int int1 = ClassExampleWithNoFailure.twice((-128));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-256) + "'", int1 == (-256));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        int int2 = ClassExampleWithNoFailure.foo(7000, 640);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8960000 + "'", int2 == 8960000);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        int int2 = ClassExampleWithNoFailure.foo(0, 1879048192);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        int int2 = ClassExampleWithNoFailure.foo(1, (-1872887808));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 549191680 + "'", int2 == 549191680);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        int int2 = ClassExampleWithNoFailure.foo(7000, (-4480000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1704509440 + "'", int2 == 1704509440);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        int int2 = ClassExampleWithNoFailure.foo((-1451098112), 2048000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        int int2 = ClassExampleWithNoFailure.foo(1111490560, (-780140544));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        int int2 = ClassExampleWithNoFailure.foo(1073741824, (-2240000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        int int2 = ClassExampleWithNoFailure.foo(0, (-2097152000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        int int1 = ClassExampleWithNoFailure.twice((-43264));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-86528) + "'", int1 == (-86528));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        int int2 = ClassExampleWithNoFailure.foo((-32), (-327680000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-503316480) + "'", int2 == (-503316480));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        int int2 = ClassExampleWithNoFailure.foo((-1610612736), (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        int int2 = ClassExampleWithNoFailure.foo(201326592, 524288000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        int int2 = ClassExampleWithNoFailure.foo(224000, (-64));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-28672000) + "'", int2 == (-28672000));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        int int1 = ClassExampleWithNoFailure.twice((-285212672));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-570425344) + "'", int1 == (-570425344));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        int int1 = ClassExampleWithNoFailure.twice((-1433534464));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1427898368 + "'", int1 == 1427898368);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        int int2 = ClassExampleWithNoFailure.foo((-2240000), 8960000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-35651584) + "'", int2 == (-35651584));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        int int2 = ClassExampleWithNoFailure.foo(1073741824, (-1600));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        int int2 = ClassExampleWithNoFailure.foo(0, 589824000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        int int2 = ClassExampleWithNoFailure.foo((-2097152000), (-28672000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        int int2 = ClassExampleWithNoFailure.foo((int) (byte) 10, (-179200000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 710967296 + "'", int2 == 710967296);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        int int1 = ClassExampleWithNoFailure.twice(285212672);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 570425344 + "'", int1 == 570425344);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        int int2 = ClassExampleWithNoFailure.foo(163840000, 1081600);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2013265920) + "'", int2 == (-2013265920));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        int int2 = ClassExampleWithNoFailure.foo(570425344, 12800);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        int int2 = ClassExampleWithNoFailure.foo((-71680000), 2080374784);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        int int2 = ClassExampleWithNoFailure.foo((-550600704), (-86528000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-268435456) + "'", int2 == (-268435456));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        int int2 = ClassExampleWithNoFailure.foo(7760, 34611200);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 294912000 + "'", int2 == 294912000);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        int int1 = ClassExampleWithNoFailure.twice((-56000));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-112000) + "'", int1 == (-112000));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        int int1 = ClassExampleWithNoFailure.twice(488701952);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 977403904 + "'", int1 == 977403904);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        int int2 = ClassExampleWithNoFailure.foo(3276800, 15892480);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        int int2 = ClassExampleWithNoFailure.foo(440401920, 11648000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        int int1 = ClassExampleWithNoFailure.twice((-478150656));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-956301312) + "'", int1 == (-956301312));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        int int2 = ClassExampleWithNoFailure.foo((-2), (-478150656));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1912602624 + "'", int2 == 1912602624);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        int int2 = ClassExampleWithNoFailure.foo((-400), 2080374784);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2147483648) + "'", int2 == (-2147483648));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        int int2 = ClassExampleWithNoFailure.foo(1211392000, 885948416);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-536870912) + "'", int2 == (-536870912));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        int int1 = ClassExampleWithNoFailure.twice(819200000);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1638400000 + "'", int1 == 1638400000);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        int int2 = ClassExampleWithNoFailure.foo(524288000, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1048576000 + "'", int2 == 1048576000);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        int int1 = ClassExampleWithNoFailure.twice((-2013265920));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 268435456 + "'", int1 == 268435456);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        int int2 = ClassExampleWithNoFailure.foo((-60569600), 81920000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 536870912 + "'", int2 == 536870912);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        int int1 = ClassExampleWithNoFailure.twice((-1610612736));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1073741824 + "'", int1 == 1073741824);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        int int2 = ClassExampleWithNoFailure.foo((-1872887808), (-956301312));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        int int2 = ClassExampleWithNoFailure.foo((int) 'a', 194);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 37636 + "'", int2 == 37636);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        int int1 = ClassExampleWithNoFailure.twice(512000);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1024000 + "'", int1 == 1024000);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        int int1 = ClassExampleWithNoFailure.twice(810123264);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1620246528 + "'", int1 == 1620246528);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        int int1 = ClassExampleWithNoFailure.twice((-704643072));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1409286144) + "'", int1 == (-1409286144));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        int int2 = ClassExampleWithNoFailure.foo((-1409286144), (-800));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        int int2 = ClassExampleWithNoFailure.foo(400, 15892480);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-170917888) + "'", int2 == (-170917888));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        int int1 = ClassExampleWithNoFailure.twice((-503316480));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1006632960) + "'", int1 == (-1006632960));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        int int2 = ClassExampleWithNoFailure.foo((-499122176), 866123776);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        int int2 = ClassExampleWithNoFailure.foo(1742733312, 798752768);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        int int2 = ClassExampleWithNoFailure.foo(1120000, 10816);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1541963776) + "'", int2 == (-1541963776));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        int int2 = ClassExampleWithNoFailure.foo(1392771072, 402653184);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        int int2 = ClassExampleWithNoFailure.foo(104, (-3104));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-645632) + "'", int2 == (-645632));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        int int2 = ClassExampleWithNoFailure.foo((-86528), (-12800));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2079850496) + "'", int2 == (-2079850496));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        int int2 = ClassExampleWithNoFailure.foo(93184000, (int) ' ');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1668808704 + "'", int2 == 1668808704);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        int int2 = ClassExampleWithNoFailure.foo((-3104), 436207616);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2147483648) + "'", int2 == (-2147483648));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        int int2 = ClassExampleWithNoFailure.foo(140, (-20));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-5600) + "'", int2 == (-5600));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        int int2 = ClassExampleWithNoFailure.foo(0, 1638400000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        int int2 = ClassExampleWithNoFailure.foo((-3104), 4480000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2042036224) + "'", int2 == (-2042036224));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        int int1 = ClassExampleWithNoFailure.twice((-202530816));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-405061632) + "'", int1 == (-405061632));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        int int2 = ClassExampleWithNoFailure.foo(1732247552, 194);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2097152000 + "'", int2 == 2097152000);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        int int2 = ClassExampleWithNoFailure.foo((-1926758400), 488701952);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        int int2 = ClassExampleWithNoFailure.foo(64, (-2042036224));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 612368384 + "'", int2 == 612368384);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        int int2 = ClassExampleWithNoFailure.foo(280, 1048576000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1207959552) + "'", int2 == (-1207959552));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        int int1 = ClassExampleWithNoFailure.twice(4096000);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 8192000 + "'", int1 == 8192000);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        int int2 = ClassExampleWithNoFailure.foo((-28672000), 34611200);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1610612736) + "'", int2 == (-1610612736));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        int int1 = ClassExampleWithNoFailure.twice((-2240));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-4480) + "'", int1 == (-4480));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        int int2 = ClassExampleWithNoFailure.foo(12800, 1668808704);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-536870912) + "'", int2 == (-536870912));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        int int2 = ClassExampleWithNoFailure.foo((-805306368), (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1610612736) + "'", int2 == (-1610612736));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        int int1 = ClassExampleWithNoFailure.twice((-3104));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-6208) + "'", int1 == (-6208));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        int int2 = ClassExampleWithNoFailure.foo(93184000, (-11200000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1853882368) + "'", int2 == (-1853882368));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        int int2 = ClassExampleWithNoFailure.foo(302848000, 23296000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-696254464) + "'", int2 == (-696254464));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        int int2 = ClassExampleWithNoFailure.foo(44800000, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        int int2 = ClassExampleWithNoFailure.foo(4480000, 448000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1714421760) + "'", int2 == (-1714421760));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        int int1 = ClassExampleWithNoFailure.twice((-1290272768));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1714421760 + "'", int1 == 1714421760);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        int int1 = ClassExampleWithNoFailure.twice((-655360000));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1310720000) + "'", int1 == (-1310720000));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        int int2 = ClassExampleWithNoFailure.foo(10240000, (-367001600));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        int int2 = ClassExampleWithNoFailure.foo(1638400, (-1714421760));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        int int2 = ClassExampleWithNoFailure.foo((-1764163584), (-44800000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1342177280 + "'", int2 == 1342177280);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        int int2 = ClassExampleWithNoFailure.foo((-285212672), (-2097152000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        int int1 = ClassExampleWithNoFailure.twice((-52428800));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-104857600) + "'", int1 == (-104857600));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        int int2 = ClassExampleWithNoFailure.foo(478150656, 1514240);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        int int2 = ClassExampleWithNoFailure.foo(512000, (-11200000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1237319680) + "'", int2 == (-1237319680));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        int int2 = ClassExampleWithNoFailure.foo((-1757413376), (-570425344));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        int int1 = ClassExampleWithNoFailure.twice((-2097152000));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 100663296 + "'", int1 == 100663296);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        int int2 = ClassExampleWithNoFailure.foo(23296000, 80);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-567607296) + "'", int2 == (-567607296));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        int int1 = ClassExampleWithNoFailure.twice((-15520));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-31040) + "'", int1 == (-31040));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        int int1 = ClassExampleWithNoFailure.twice(15892480);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 31784960 + "'", int1 == 31784960);
    }
}

