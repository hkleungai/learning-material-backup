import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({ ClassExampleWithFailureRegressionTest0.class, ClassExampleWithFailureRegressionTest1.class, ClassExampleWithFailureRegressionTest2.class, ClassExampleWithFailureRegressionTest3.class, ClassExampleWithFailureRegressionTest4.class })
public class ClassExampleWithFailureRegressionTest {
}

