import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class ClassExampleWithNoFailureRegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        int int2 = ClassExampleWithNoFailure.foo((-6208), (-655360000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2013265920) + "'", int2 == (-2013265920));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        int int2 = ClassExampleWithNoFailure.foo((-550600704), 1174405120);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        int int2 = ClassExampleWithNoFailure.foo(64, 1392771072);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2113929216) + "'", int2 == (-2113929216));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        int int1 = ClassExampleWithNoFailure.twice(1620246528);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1054474240) + "'", int1 == (-1054474240));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        int int2 = ClassExampleWithNoFailure.foo(28000, 1638400000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1308622848 + "'", int2 == 1308622848);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        int int1 = ClassExampleWithNoFailure.twice(872415232);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1744830464 + "'", int1 == 1744830464);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        int int2 = ClassExampleWithNoFailure.foo((-1394081792), 204800000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        int int2 = ClassExampleWithNoFailure.foo((int) (byte) 1, 1704509440);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-885948416) + "'", int2 == (-885948416));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        int int1 = ClassExampleWithNoFailure.twice((-24832000));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-49664000) + "'", int1 == (-49664000));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        int int1 = ClassExampleWithNoFailure.twice((-1086400));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-2172800) + "'", int1 == (-2172800));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        int int2 = ClassExampleWithNoFailure.foo(2, (-1714421760));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1732247552 + "'", int2 == 1732247552);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        int int2 = ClassExampleWithNoFailure.foo(710967296, 142606336);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        int int2 = ClassExampleWithNoFailure.foo((-400), (-7760));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6208000 + "'", int2 == 6208000);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        int int2 = ClassExampleWithNoFailure.foo((-367001600), (-68378624));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        int int1 = ClassExampleWithNoFailure.twice(478150656);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 956301312 + "'", int1 == 956301312);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        int int2 = ClassExampleWithNoFailure.foo(536870912, 15892480);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        int int2 = ClassExampleWithNoFailure.foo((-249561088), 1073741824);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        int int2 = ClassExampleWithNoFailure.foo((-1853882368), (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        int int2 = ClassExampleWithNoFailure.foo((-1853882368), 478150656);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        int int2 = ClassExampleWithNoFailure.foo((-1541963776), 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 844890112 + "'", int2 == 844890112);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        int int1 = ClassExampleWithNoFailure.twice((-8));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-16) + "'", int1 == (-16));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        int int2 = ClassExampleWithNoFailure.foo((-24832000), (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-496640000) + "'", int2 == (-496640000));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        int int2 = ClassExampleWithNoFailure.foo((-163840000), (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-327680000) + "'", int2 == (-327680000));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        int int2 = ClassExampleWithNoFailure.foo(100663296, 37636);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 805306368 + "'", int2 == 805306368);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        int int2 = ClassExampleWithNoFailure.foo(69529600, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        int int2 = ClassExampleWithNoFailure.foo((-32000), 89600);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1439432704) + "'", int2 == (-1439432704));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        int int2 = ClassExampleWithNoFailure.foo((-1140850688), (-1276116992));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        int int2 = ClassExampleWithNoFailure.foo((-704643072), 402653184);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        int int2 = ClassExampleWithNoFailure.foo(448000, 244350976);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1778384896) + "'", int2 == (-1778384896));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        int int2 = ClassExampleWithNoFailure.foo((-222298112), (-655360000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        int int2 = ClassExampleWithNoFailure.foo(478150656, 46592000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        int int1 = ClassExampleWithNoFailure.twice(10240000);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 20480000 + "'", int1 == 20480000);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        int int2 = ClassExampleWithNoFailure.foo((-1086400), (-40960));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1196425216) + "'", int2 == (-1196425216));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        int int2 = ClassExampleWithNoFailure.foo(1600, 1879048192);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        int int2 = ClassExampleWithNoFailure.foo((-1476395008), 905969664);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        int int1 = ClassExampleWithNoFailure.twice(977403904);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1954807808 + "'", int1 == 1954807808);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        int int2 = ClassExampleWithNoFailure.foo(93184000, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 186368000 + "'", int2 == 186368000);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        int int2 = ClassExampleWithNoFailure.foo(0, (-1445265408));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        int int2 = ClassExampleWithNoFailure.foo((-1369440256), 112000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 536870912 + "'", int2 == 536870912);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        int int1 = ClassExampleWithNoFailure.twice(1098383360);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-2098200576) + "'", int1 == (-2098200576));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        int int2 = ClassExampleWithNoFailure.foo((int) (byte) -1, (-809500672));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1619001344 + "'", int2 == 1619001344);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        int int1 = ClassExampleWithNoFailure.twice((-1541963776));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1211039744 + "'", int1 == 1211039744);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        int int2 = ClassExampleWithNoFailure.foo(400, (-80));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-64000) + "'", int2 == (-64000));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        int int2 = ClassExampleWithNoFailure.foo((-2085617664), (-1960000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 671088640 + "'", int2 == 671088640);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        int int2 = ClassExampleWithNoFailure.foo((-922746880), (-31040));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2147483648) + "'", int2 == (-2147483648));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        int int2 = ClassExampleWithNoFailure.foo(302848000, 5824000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 899678208 + "'", int2 == 899678208);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        int int1 = ClassExampleWithNoFailure.twice(3276800);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6553600 + "'", int1 == 6553600);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        int int2 = ClassExampleWithNoFailure.foo((-1778384896), 28000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2147483648) + "'", int2 == (-2147483648));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        int int2 = ClassExampleWithNoFailure.foo((-1577058304), (-104857600));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        int int2 = ClassExampleWithNoFailure.foo(1430716416, (-1439432704));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        int int2 = ClassExampleWithNoFailure.foo(173056, (-8320));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1415315456 + "'", int2 == 1415315456);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        int int2 = ClassExampleWithNoFailure.foo(89600000, (-12416000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 478150656 + "'", int2 == 478150656);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        int int2 = ClassExampleWithNoFailure.foo(2116288512, (-64));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-301989888) + "'", int2 == (-301989888));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        int int2 = ClassExampleWithNoFailure.foo(1514240, 346112);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 221249536 + "'", int2 == 221249536);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        int int1 = ClassExampleWithNoFailure.twice(50331648);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 100663296 + "'", int1 == 100663296);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        int int1 = ClassExampleWithNoFailure.twice(1912602624);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-469762048) + "'", int1 == (-469762048));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        int int2 = ClassExampleWithNoFailure.foo(24832, 570425344);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        int int2 = ClassExampleWithNoFailure.foo((int) ' ', 524288000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-805306368) + "'", int2 == (-805306368));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        int int2 = ClassExampleWithNoFailure.foo(28000, (-1926758400));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-301989888) + "'", int2 == (-301989888));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        int int1 = ClassExampleWithNoFailure.twice(899678208);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1799356416 + "'", int1 == 1799356416);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        int int2 = ClassExampleWithNoFailure.foo((-2147483648), (-478150656));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        int int2 = ClassExampleWithNoFailure.foo(14000, 212992000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1933574144) + "'", int2 == (-1933574144));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        int int2 = ClassExampleWithNoFailure.foo((-570425344), (-1290272768));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        int int2 = ClassExampleWithNoFailure.foo(1120, (-1845493760));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2147483648) + "'", int2 == (-2147483648));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        int int2 = ClassExampleWithNoFailure.foo((-1926758400), 86528);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1610612736) + "'", int2 == (-1610612736));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        int int1 = ClassExampleWithNoFailure.twice(440401920);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 880803840 + "'", int1 == 880803840);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        int int1 = ClassExampleWithNoFailure.twice((-1845493760));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 603979776 + "'", int1 == 603979776);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        int int2 = ClassExampleWithNoFailure.foo((-1946157056), (-1636974592));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        int int2 = ClassExampleWithNoFailure.foo(441450496, 440401920);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        int int2 = ClassExampleWithNoFailure.foo(12800, 1799356416);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        int int2 = ClassExampleWithNoFailure.foo((-10240), (-1778384896));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        int int2 = ClassExampleWithNoFailure.foo(1732247552, 56000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-536870912) + "'", int2 == (-536870912));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        int int2 = ClassExampleWithNoFailure.foo(640, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1280) + "'", int2 == (-1280));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        int int1 = ClassExampleWithNoFailure.twice(134217728);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 268435456 + "'", int1 == 268435456);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        int int2 = ClassExampleWithNoFailure.foo((-49664000), (-3200));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 22020096 + "'", int2 == 22020096);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        int int2 = ClassExampleWithNoFailure.foo(1254400000, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1786167296) + "'", int2 == (-1786167296));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        int int2 = ClassExampleWithNoFailure.foo((-1778384896), 1363607552);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        int int2 = ClassExampleWithNoFailure.foo(34611200, (-1476395008));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        int int2 = ClassExampleWithNoFailure.foo((int) '4', (-8960000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-931840000) + "'", int2 == (-931840000));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        int int2 = ClassExampleWithNoFailure.foo((-1211392000), (-1600));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1901068288) + "'", int2 == (-1901068288));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        int int2 = ClassExampleWithNoFailure.foo(612368384, 5824000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        int int1 = ClassExampleWithNoFailure.twice(5120);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10240 + "'", int1 == 10240);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        int int2 = ClassExampleWithNoFailure.foo((-4480000), (-1764163584));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 134217728 + "'", int2 == 134217728);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        int int2 = ClassExampleWithNoFailure.foo(671088640, 441450496);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        int int2 = ClassExampleWithNoFailure.foo(2912000, 977403904);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1006632960 + "'", int2 == 1006632960);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        int int1 = ClassExampleWithNoFailure.twice((-696254464));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1392508928) + "'", int1 == (-1392508928));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        int int2 = ClassExampleWithNoFailure.foo(1872183296, 310378496);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        int int1 = ClassExampleWithNoFailure.twice((-1486094336));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1322778624 + "'", int1 == 1322778624);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        int int2 = ClassExampleWithNoFailure.foo(15520, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31040 + "'", int2 == 31040);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        int int1 = ClassExampleWithNoFailure.twice((-1786167296));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 722632704 + "'", int1 == 722632704);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        int int2 = ClassExampleWithNoFailure.foo((-5120), (-4));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 40960 + "'", int2 == 40960);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        int int2 = ClassExampleWithNoFailure.foo((-1560281088), 1638400000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        int int2 = ClassExampleWithNoFailure.foo(12800, 208);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5324800 + "'", int2 == 5324800);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        int int2 = ClassExampleWithNoFailure.foo(1620246528, 405061632);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2147483648) + "'", int2 == (-2147483648));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        int int1 = ClassExampleWithNoFailure.twice((-2042036224));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 210894848 + "'", int1 == 210894848);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        int int1 = ClassExampleWithNoFailure.twice(212992000);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 425984000 + "'", int1 == 425984000);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        int int2 = ClassExampleWithNoFailure.foo((-1541963776), (-2042036224));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        int int1 = ClassExampleWithNoFailure.twice(294912000);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 589824000 + "'", int1 == 589824000);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        int int1 = ClassExampleWithNoFailure.twice(10240);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 20480 + "'", int1 == 20480);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        int int2 = ClassExampleWithNoFailure.foo((-6208), 1872183296);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-664797184) + "'", int2 == (-664797184));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        int int2 = ClassExampleWithNoFailure.foo(1280, (-31040));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-79462400) + "'", int2 == (-79462400));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        int int2 = ClassExampleWithNoFailure.foo(81920000, 1872183296);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        int int2 = ClassExampleWithNoFailure.foo(201326592, 14000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2147483648) + "'", int2 == (-2147483648));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        int int2 = ClassExampleWithNoFailure.foo((-202530816), 2560);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1870659584) + "'", int2 == (-1870659584));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        int int2 = ClassExampleWithNoFailure.foo(805306368, (-179200000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        int int2 = ClassExampleWithNoFailure.foo((int) (byte) 0, 1098383360);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        int int1 = ClassExampleWithNoFailure.twice(589824000);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1179648000 + "'", int1 == 1179648000);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        int int2 = ClassExampleWithNoFailure.foo(899678208, (-25600));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        int int2 = ClassExampleWithNoFailure.foo((-1394081792), 776);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1048576000 + "'", int2 == 1048576000);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        int int1 = ClassExampleWithNoFailure.twice((-2113929216));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 67108864 + "'", int1 == 67108864);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        int int2 = ClassExampleWithNoFailure.foo(6208000, (-1445265408));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1006632960 + "'", int2 == 1006632960);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        int int2 = ClassExampleWithNoFailure.foo(1610612736, 2116288512);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        int int2 = ClassExampleWithNoFailure.foo((-1280), (-496640000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 88080384 + "'", int2 == 88080384);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        int int2 = ClassExampleWithNoFailure.foo((-71680000), 1638400);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2147483648) + "'", int2 == (-2147483648));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        int int2 = ClassExampleWithNoFailure.foo((-1433600000), (-15520));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1212153856) + "'", int2 == (-1212153856));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        int int1 = ClassExampleWithNoFailure.twice((-31040));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-62080) + "'", int1 == (-62080));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        int int1 = ClassExampleWithNoFailure.twice((-367001600));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-734003200) + "'", int1 == (-734003200));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        int int1 = ClassExampleWithNoFailure.twice((-1310720000));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1673527296 + "'", int1 == 1673527296);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        int int2 = ClassExampleWithNoFailure.foo(1552000, 3880);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-841381888) + "'", int2 == (-841381888));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        int int1 = ClassExampleWithNoFailure.twice((-465920000));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-931840000) + "'", int1 == (-931840000));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        int int1 = ClassExampleWithNoFailure.twice((-6208));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-12416) + "'", int1 == (-12416));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        int int1 = ClassExampleWithNoFailure.twice((-1394081792));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1506803712 + "'", int1 == 1506803712);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        int int2 = ClassExampleWithNoFailure.foo(956301312, (-696254464));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        int int1 = ClassExampleWithNoFailure.twice(302848000);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 605696000 + "'", int1 == 605696000);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        int int2 = ClassExampleWithNoFailure.foo((-1394081792), (-734003200));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        int int2 = ClassExampleWithNoFailure.foo((-163840000), (-1778384896));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        int int2 = ClassExampleWithNoFailure.foo((-1560281088), (-4));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-402653184) + "'", int2 == (-402653184));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        int int2 = ClassExampleWithNoFailure.foo((-8320), (-49664000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1775239168 + "'", int2 == 1775239168);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        int int2 = ClassExampleWithNoFailure.foo((-655360000), (-1276116992));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        int int2 = ClassExampleWithNoFailure.foo(1081600, (-6922240));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1933574144) + "'", int2 == (-1933574144));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        int int2 = ClassExampleWithNoFailure.foo(256, 302848000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 439353344 + "'", int2 == 439353344);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        int int2 = ClassExampleWithNoFailure.foo(1, 1638400);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3276800 + "'", int2 == 3276800);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        int int2 = ClassExampleWithNoFailure.foo((-60569600), (-3920000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1194852352 + "'", int2 == 1194852352);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        int int2 = ClassExampleWithNoFailure.foo((-31040), 346112);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-11796480) + "'", int2 == (-11796480));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        int int2 = ClassExampleWithNoFailure.foo(86528, (-499122176));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        int int1 = ClassExampleWithNoFailure.twice((-8000));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-16000) + "'", int1 == (-16000));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        int int2 = ClassExampleWithNoFailure.foo((int) (short) 10, (-16));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-320) + "'", int2 == (-320));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        int int2 = ClassExampleWithNoFailure.foo((-722632704), 201326592);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        int int2 = ClassExampleWithNoFailure.foo((-86528000), (-11796480));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2147483648) + "'", int2 == (-2147483648));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        int int2 = ClassExampleWithNoFailure.foo((-2), (-2098200576));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-197132288) + "'", int2 == (-197132288));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        int int2 = ClassExampleWithNoFailure.foo((-358400000), (-1107296256));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        int int2 = ClassExampleWithNoFailure.foo(218103808, (-1778384896));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        int int1 = ClassExampleWithNoFailure.twice((-1636974592));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1021018112 + "'", int1 == 1021018112);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        int int2 = ClassExampleWithNoFailure.foo((-1439432704), 1673527296);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        int int2 = ClassExampleWithNoFailure.foo((-465920000), 866123776);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        int int1 = ClassExampleWithNoFailure.twice(1048576000);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2097152000 + "'", int1 == 2097152000);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        int int2 = ClassExampleWithNoFailure.foo(810123264, (-2085617664));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        int int2 = ClassExampleWithNoFailure.foo((-1290272768), (-1275068416));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        int int1 = ClassExampleWithNoFailure.twice(310400);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 620800 + "'", int1 == 620800);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        int int1 = ClassExampleWithNoFailure.twice((-664797184));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1329594368) + "'", int1 == (-1329594368));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        int int2 = ClassExampleWithNoFailure.foo((-40), (-2867200));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 229376000 + "'", int2 == 229376000);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        int int1 = ClassExampleWithNoFailure.twice((-65536000));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-131072000) + "'", int1 == (-131072000));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        int int2 = ClassExampleWithNoFailure.foo((-65536000), (-1577058304));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        int int2 = ClassExampleWithNoFailure.foo(1514240, 6208000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1731985408 + "'", int2 == 1731985408);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        int int1 = ClassExampleWithNoFailure.twice((-86528000));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-173056000) + "'", int1 == (-173056000));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        int int2 = ClassExampleWithNoFailure.foo(0, 1073741824);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        int int1 = ClassExampleWithNoFailure.twice(69529600);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 139059200 + "'", int1 == 139059200);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        int int1 = ClassExampleWithNoFailure.twice((-256000));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-512000) + "'", int1 == (-512000));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        int int1 = ClassExampleWithNoFailure.twice((-1933574144));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 427819008 + "'", int1 == 427819008);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        int int2 = ClassExampleWithNoFailure.foo((-256000), 8960000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-494927872) + "'", int2 == (-494927872));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        int int2 = ClassExampleWithNoFailure.foo(218103808, 10816);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2147483648) + "'", int2 == (-2147483648));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        int int1 = ClassExampleWithNoFailure.twice((-28672000));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-57344000) + "'", int1 == (-57344000));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        int int1 = ClassExampleWithNoFailure.twice((-1369440256));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1556086784 + "'", int1 == 1556086784);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        int int2 = ClassExampleWithNoFailure.foo(50331648, 1308622848);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        int int1 = ClassExampleWithNoFailure.twice((-536870912));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1073741824) + "'", int1 == (-1073741824));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        int int1 = ClassExampleWithNoFailure.twice(4480);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 8960 + "'", int1 == 8960);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        int int2 = ClassExampleWithNoFailure.foo((-1476395008), 1775239168);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        int int2 = ClassExampleWithNoFailure.foo((-160), (-3920000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1254400000 + "'", int2 == 1254400000);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        int int2 = ClassExampleWithNoFailure.foo((-1024000), 43264);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1589641216 + "'", int2 == 1589641216);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        int int2 = ClassExampleWithNoFailure.foo(200, (-1610612736));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        int int2 = ClassExampleWithNoFailure.foo(0, (-931840000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        int int2 = ClassExampleWithNoFailure.foo(1638400000, (-1600));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1275068416 + "'", int2 == 1275068416);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        int int2 = ClassExampleWithNoFailure.foo((-2098200576), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        int int2 = ClassExampleWithNoFailure.foo(1514240, (-780140544));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        int int2 = ClassExampleWithNoFailure.foo(1552000, (-603979776));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        int int2 = ClassExampleWithNoFailure.foo((-52428800), 405061632);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        int int1 = ClassExampleWithNoFailure.twice(1742733312);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-809500672) + "'", int1 == (-809500672));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        int int2 = ClassExampleWithNoFailure.foo((int) '4', (-52428800));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1157627904) + "'", int2 == (-1157627904));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        int int2 = ClassExampleWithNoFailure.foo((-2042036224), 899678208);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        int int2 = ClassExampleWithNoFailure.foo(2240000, (-4));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-17920000) + "'", int2 == (-17920000));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        int int2 = ClassExampleWithNoFailure.foo((-3200), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        int int1 = ClassExampleWithNoFailure.twice(441450496);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 882900992 + "'", int1 == 882900992);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        int int2 = ClassExampleWithNoFailure.foo((-1924661248), (-8960000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2147483648) + "'", int2 == (-2147483648));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        int int2 = ClassExampleWithNoFailure.foo((-2042036224), (-1310720000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        int int1 = ClassExampleWithNoFailure.twice((-86528));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-173056) + "'", int1 == (-173056));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        int int2 = ClassExampleWithNoFailure.foo((-131072000), 427819008);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        int int2 = ClassExampleWithNoFailure.foo((-170917888), (-367001600));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        int int1 = ClassExampleWithNoFailure.twice((-805306368));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1610612736) + "'", int1 == (-1610612736));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        int int2 = ClassExampleWithNoFailure.foo(285212672, (-1872183296));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        int int2 = ClassExampleWithNoFailure.foo(0, 67108864);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        int int2 = ClassExampleWithNoFailure.foo((-8960000), (-128));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2001207296) + "'", int2 == (-2001207296));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        int int2 = ClassExampleWithNoFailure.foo(40960000, (-5600));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 809500672 + "'", int2 == 809500672);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        int int2 = ClassExampleWithNoFailure.foo((-1089339392), 440401920);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        int int2 = ClassExampleWithNoFailure.foo((-1778384896), (-1290272768));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        int int2 = ClassExampleWithNoFailure.foo((-1610612736), (-5600));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        int int2 = ClassExampleWithNoFailure.foo((-956301312), (-478150656));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        int int1 = ClassExampleWithNoFailure.twice(425984000);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 851968000 + "'", int1 == 851968000);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        int int1 = ClassExampleWithNoFailure.twice((-1924661248));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 445644800 + "'", int1 == 445644800);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        int int1 = ClassExampleWithNoFailure.twice(49664);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 99328 + "'", int1 == 99328);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        int int2 = ClassExampleWithNoFailure.foo((-32), 218103808);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1073741824) + "'", int2 == (-1073741824));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        int int2 = ClassExampleWithNoFailure.foo((-28672000), (-734003200));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        int int1 = ClassExampleWithNoFailure.twice(89600);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 179200 + "'", int1 == 179200);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        int int2 = ClassExampleWithNoFailure.foo(405061632, (-5600));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1204813824) + "'", int2 == (-1204813824));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        int int1 = ClassExampleWithNoFailure.twice(1415315456);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1464336384) + "'", int1 == (-1464336384));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        int int2 = ClassExampleWithNoFailure.foo(0, 20);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        int int2 = ClassExampleWithNoFailure.foo(550600704, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        int int2 = ClassExampleWithNoFailure.foo((-503316480), 1392771072);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        int int2 = ClassExampleWithNoFailure.foo(40, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 80 + "'", int2 == 80);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        int int1 = ClassExampleWithNoFailure.twice((-268435456));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-536870912) + "'", int1 == (-536870912));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        int int2 = ClassExampleWithNoFailure.foo((-400), (-1879048192));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        int int1 = ClassExampleWithNoFailure.twice((-841381888));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1682763776) + "'", int1 == (-1682763776));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        int int2 = ClassExampleWithNoFailure.foo(844890112, 1620246528);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        int int2 = ClassExampleWithNoFailure.foo((-2240000), (-1089339392));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2013265920) + "'", int2 == (-2013265920));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        int int2 = ClassExampleWithNoFailure.foo(1514240, 2560);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-837025792) + "'", int2 == (-837025792));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        int int2 = ClassExampleWithNoFailure.foo((-805306368), (-1486094336));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        int int2 = ClassExampleWithNoFailure.foo((-197132288), 2097152000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        int int2 = ClassExampleWithNoFailure.foo(1237319680, (-202530816));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        int int2 = ClassExampleWithNoFailure.foo((-512000), (-841381888));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 318767104 + "'", int2 == 318767104);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        int int1 = ClassExampleWithNoFailure.twice((-885948416));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1771896832) + "'", int1 == (-1771896832));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        int int2 = ClassExampleWithNoFailure.foo((-358400000), 612368384);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        int int1 = ClassExampleWithNoFailure.twice(445644800);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 891289600 + "'", int1 == 891289600);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        int int2 = ClassExampleWithNoFailure.foo(70, (-40960));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-5734400) + "'", int2 == (-5734400));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        int int2 = ClassExampleWithNoFailure.foo((-14000), (-603979776));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2147483648) + "'", int2 == (-2147483648));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        int int2 = ClassExampleWithNoFailure.foo(866123776, (-469762048));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        int int2 = ClassExampleWithNoFailure.foo(1427898368, 905969664);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        int int1 = ClassExampleWithNoFailure.twice((-809500672));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1619001344) + "'", int1 == (-1619001344));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        int int1 = ClassExampleWithNoFailure.twice((-1771896832));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 751173632 + "'", int1 == 751173632);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        int int2 = ClassExampleWithNoFailure.foo(1211392000, (-405061632));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1879048192 + "'", int2 == 1879048192);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        int int2 = ClassExampleWithNoFailure.foo((-52428800), (-11200000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2147483648) + "'", int2 == (-2147483648));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        int int2 = ClassExampleWithNoFailure.foo(69529600, (-1433534464));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1073741824 + "'", int2 == 1073741824);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        int int2 = ClassExampleWithNoFailure.foo(605696000, (-400));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 774504448 + "'", int2 == 774504448);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        int int1 = ClassExampleWithNoFailure.twice(1619001344);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1056964608) + "'", int1 == (-1056964608));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        int int2 = ClassExampleWithNoFailure.foo((-885948416), (-10240));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2013265920) + "'", int2 == (-2013265920));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        int int2 = ClassExampleWithNoFailure.foo(280, (-1409286144));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1073741824 + "'", int2 == 1073741824);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        int int2 = ClassExampleWithNoFailure.foo((-179200000), (-6922240));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1207959552) + "'", int2 == (-1207959552));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        int int2 = ClassExampleWithNoFailure.foo(2080374784, 179200);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        int int2 = ClassExampleWithNoFailure.foo(7000, 21632);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 302848000 + "'", int2 == 302848000);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        int int1 = ClassExampleWithNoFailure.twice(866123776);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1732247552 + "'", int1 == 1732247552);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        int int2 = ClassExampleWithNoFailure.foo((-16), 186368000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1668808704) + "'", int2 == (-1668808704));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        int int2 = ClassExampleWithNoFailure.foo((-2147483648), (-60569600));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        int int2 = ClassExampleWithNoFailure.foo(405061632, 20480000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1073741824) + "'", int2 == (-1073741824));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        int int2 = ClassExampleWithNoFailure.foo((int) (byte) -1, 524288000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1048576000) + "'", int2 == (-1048576000));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        int int1 = ClassExampleWithNoFailure.twice((-12416));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-24832) + "'", int1 == (-24832));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        int int2 = ClassExampleWithNoFailure.foo(1308622848, (-4480000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        int int2 = ClassExampleWithNoFailure.foo((-268435456), (-1196425216));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        int int2 = ClassExampleWithNoFailure.foo((-1451098112), 1610612736);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        int int2 = ClassExampleWithNoFailure.foo((-62080), (-734003200));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1073741824) + "'", int2 == (-1073741824));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        int int1 = ClassExampleWithNoFailure.twice((-570425344));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1140850688) + "'", int1 == (-1140850688));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        int int2 = ClassExampleWithNoFailure.foo(143360000, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 286720000 + "'", int2 == 286720000);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        int int2 = ClassExampleWithNoFailure.foo(427819008, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        int int1 = ClassExampleWithNoFailure.twice((-1409286144));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1476395008 + "'", int1 == 1476395008);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        int int2 = ClassExampleWithNoFailure.foo(1392771072, (-5600));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 285212672 + "'", int2 == 285212672);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        int int1 = ClassExampleWithNoFailure.twice(427819008);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 855638016 + "'", int1 == 855638016);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        int int2 = ClassExampleWithNoFailure.foo((-1433534464), (-3461120));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1073741824 + "'", int2 == 1073741824);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        int int2 = ClassExampleWithNoFailure.foo(866123776, (-4480));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 536870912 + "'", int2 == 536870912);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        int int2 = ClassExampleWithNoFailure.foo((-15520), (-1901068288));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 603979776 + "'", int2 == 603979776);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        int int2 = ClassExampleWithNoFailure.foo(1912602624, 56000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        int int1 = ClassExampleWithNoFailure.twice(8192000);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 16384000 + "'", int1 == 16384000);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        int int2 = ClassExampleWithNoFailure.foo(1120000, (-400));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-896000000) + "'", int2 == (-896000000));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        int int2 = ClassExampleWithNoFailure.foo((-249561088), (-62080));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1610612736 + "'", int2 == 1610612736);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        int int1 = ClassExampleWithNoFailure.twice(1006632960);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2013265920 + "'", int1 == 2013265920);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        int int2 = ClassExampleWithNoFailure.foo(0, 445644800);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        int int2 = ClassExampleWithNoFailure.foo((-285212672), 49664);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        int int1 = ClassExampleWithNoFailure.twice(851968000);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1703936000 + "'", int1 == 1703936000);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        int int2 = ClassExampleWithNoFailure.foo(1506803712, 5324800);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        int int1 = ClassExampleWithNoFailure.twice(1427898368);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1439170560) + "'", int1 == (-1439170560));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        int int2 = ClassExampleWithNoFailure.foo(1744830464, (-17382400));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        int int2 = ClassExampleWithNoFailure.foo(0, (-5600));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        int int2 = ClassExampleWithNoFailure.foo(268435456, (-1157627904));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        int int2 = ClassExampleWithNoFailure.foo(1620246528, 16384000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        int int2 = ClassExampleWithNoFailure.foo((-1946157056), 671088640);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        int int2 = ClassExampleWithNoFailure.foo(218103808, (-1409286144));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        int int1 = ClassExampleWithNoFailure.twice(1744830464);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-805306368) + "'", int1 == (-805306368));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        int int2 = ClassExampleWithNoFailure.foo(2013265920, 4480000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        int int2 = ClassExampleWithNoFailure.foo((-1054474240), 1744830464);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        int int2 = ClassExampleWithNoFailure.foo((-8960000), 1237319680);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        int int2 = ClassExampleWithNoFailure.foo(89600000, (-800));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1626079232) + "'", int2 == (-1626079232));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        int int2 = ClassExampleWithNoFailure.foo((-885948416), 478150656);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        int int2 = ClassExampleWithNoFailure.foo((-696254464), 70);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1308622848 + "'", int2 == 1308622848);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        int int1 = ClassExampleWithNoFailure.twice(208);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 416 + "'", int1 == 416);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        int int1 = ClassExampleWithNoFailure.twice(100663296);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 201326592 + "'", int1 == 201326592);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        int int2 = ClassExampleWithNoFailure.foo((-1006632960), 1714421760);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        int int1 = ClassExampleWithNoFailure.twice(221249536);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 442499072 + "'", int1 == 442499072);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        int int2 = ClassExampleWithNoFailure.foo(0, 1308622848);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        int int2 = ClassExampleWithNoFailure.foo((-81920000), (-160));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 444596224 + "'", int2 == 444596224);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        int int2 = ClassExampleWithNoFailure.foo((int) (byte) -1, 1237319680);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1820327936 + "'", int2 == 1820327936);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        int int1 = ClassExampleWithNoFailure.twice(1174405120);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1946157056) + "'", int1 == (-1946157056));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        int int2 = ClassExampleWithNoFailure.foo((-5120), 524288000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        int int2 = ClassExampleWithNoFailure.foo((int) (short) 1, 905969664);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1811939328 + "'", int2 == 1811939328);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        int int2 = ClassExampleWithNoFailure.foo(810123264, (-327680000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        int int2 = ClassExampleWithNoFailure.foo(244350976, 4);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1954807808 + "'", int2 == 1954807808);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        int int2 = ClassExampleWithNoFailure.foo((-1157627904), 589824000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        int int1 = ClassExampleWithNoFailure.twice(88080384);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 176160768 + "'", int1 == 176160768);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        int int2 = ClassExampleWithNoFailure.foo(2, 204800000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 819200000 + "'", int2 == 819200000);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        int int2 = ClassExampleWithNoFailure.foo(1731985408, 2048000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        int int2 = ClassExampleWithNoFailure.foo(160, 1280);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 409600 + "'", int2 == 409600);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        int int2 = ClassExampleWithNoFailure.foo((-2867200), (-444596224));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        int int2 = ClassExampleWithNoFailure.foo(550600704, (-1433534464));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        int int2 = ClassExampleWithNoFailure.foo((-800), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        int int2 = ClassExampleWithNoFailure.foo((int) '4', (-17920000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1863680000) + "'", int2 == (-1863680000));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        int int1 = ClassExampleWithNoFailure.twice(8960);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 17920 + "'", int1 == 17920);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        int int2 = ClassExampleWithNoFailure.foo((-465920000), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        int int2 = ClassExampleWithNoFailure.foo((-6400), (-496640000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 440401920 + "'", int2 == 440401920);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        int int2 = ClassExampleWithNoFailure.foo(25600, 140);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7168000 + "'", int2 == 7168000);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        int int2 = ClassExampleWithNoFailure.foo(173056, 2138570752);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1073741824) + "'", int2 == (-1073741824));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        int int1 = ClassExampleWithNoFailure.twice(229376000);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 458752000 + "'", int1 == 458752000);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        int int1 = ClassExampleWithNoFailure.twice(603979776);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1207959552 + "'", int1 == 1207959552);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        int int1 = ClassExampleWithNoFailure.twice(34611200);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 69222400 + "'", int1 == 69222400);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        int int1 = ClassExampleWithNoFailure.twice((-1204813824));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1885339648 + "'", int1 == 1885339648);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        int int1 = ClassExampleWithNoFailure.twice(91750400);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 183500800 + "'", int1 == 183500800);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        int int1 = ClassExampleWithNoFailure.twice(751173632);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1502347264 + "'", int1 == 1502347264);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        int int2 = ClassExampleWithNoFailure.foo(2560, 2240);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11468800 + "'", int2 == 11468800);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        int int2 = ClassExampleWithNoFailure.foo((-285212672), 809500672);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        int int2 = ClassExampleWithNoFailure.foo(1552, 10240);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31784960 + "'", int2 == 31784960);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        int int1 = ClassExampleWithNoFailure.twice((-1464336384));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1366294528 + "'", int1 == 1366294528);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        int int2 = ClassExampleWithNoFailure.foo((-112000), 1342177280);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        int int2 = ClassExampleWithNoFailure.foo((-704643072), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        int int1 = ClassExampleWithNoFailure.twice(620800);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1241600 + "'", int1 == 1241600);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        int int2 = ClassExampleWithNoFailure.foo(10240000, 20);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 409600000 + "'", int2 == 409600000);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        int int2 = ClassExampleWithNoFailure.foo((-79462400), 1589641216);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        int int2 = ClassExampleWithNoFailure.foo(1024000, (-1872887808));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2147483648) + "'", int2 == (-2147483648));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        int int2 = ClassExampleWithNoFailure.foo(0, 8);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        int int2 = ClassExampleWithNoFailure.foo((-358400000), 16384000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        int int1 = ClassExampleWithNoFailure.twice((-469762048));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-939524096) + "'", int1 == (-939524096));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        int int1 = ClassExampleWithNoFailure.twice((-5600));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-11200) + "'", int1 == (-11200));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        int int2 = ClassExampleWithNoFailure.foo(716800, 14000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1404436480) + "'", int2 == (-1404436480));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        int int2 = ClassExampleWithNoFailure.foo(1174405120, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        int int1 = ClassExampleWithNoFailure.twice(1241600);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2483200 + "'", int1 == 2483200);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        int int1 = ClassExampleWithNoFailure.twice((-160));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-320) + "'", int1 == (-320));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        int int2 = ClassExampleWithNoFailure.foo(1098383360, (-268435456));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        int int1 = ClassExampleWithNoFailure.twice(4480000);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 8960000 + "'", int1 == 8960000);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        int int2 = ClassExampleWithNoFailure.foo((-1879048192), 1275068416);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        int int2 = ClassExampleWithNoFailure.foo((-1714421760), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        int int2 = ClassExampleWithNoFailure.foo(3276800, (-536870912));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        int int1 = ClassExampleWithNoFailure.twice((-405061632));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-810123264) + "'", int1 == (-810123264));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        int int1 = ClassExampleWithNoFailure.twice((-14000));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-28000) + "'", int1 == (-28000));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        int int2 = ClassExampleWithNoFailure.foo(0, (-2867200));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        int int2 = ClassExampleWithNoFailure.foo(612368384, (-64000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        int int1 = ClassExampleWithNoFailure.twice((-1329594368));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1635778560 + "'", int1 == 1635778560);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        int int1 = ClassExampleWithNoFailure.twice(458752000);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 917504000 + "'", int1 == 917504000);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        int int2 = ClassExampleWithNoFailure.foo((int) (byte) -1, (-358400000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 716800000 + "'", int2 == 716800000);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        int int2 = ClassExampleWithNoFailure.foo((-6208000), 1081600);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1217134592 + "'", int2 == 1217134592);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        int int2 = ClassExampleWithNoFailure.foo((-603979776), 1954807808);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        int int1 = ClassExampleWithNoFailure.twice(1589641216);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1115684864) + "'", int1 == (-1115684864));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        int int2 = ClassExampleWithNoFailure.foo(1241600, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        int int2 = ClassExampleWithNoFailure.foo((-1048576000), 104);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 939524096 + "'", int2 == 939524096);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        int int2 = ClassExampleWithNoFailure.foo((-173056000), (-696254464));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        int int2 = ClassExampleWithNoFailure.foo((-1006632960), 46592000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        int int2 = ClassExampleWithNoFailure.foo(310400, 1619001344);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2147483648) + "'", int2 == (-2147483648));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        int int2 = ClassExampleWithNoFailure.foo(10816, 882900992);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-805306368) + "'", int2 == (-805306368));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        int int2 = ClassExampleWithNoFailure.foo(4480, (-1048576000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2147483648) + "'", int2 == (-2147483648));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        int int2 = ClassExampleWithNoFailure.foo((-160), (-1433534464));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-830472192) + "'", int2 == (-830472192));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        int int2 = ClassExampleWithNoFailure.foo((-2122317824), 1556086784);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        int int2 = ClassExampleWithNoFailure.foo(400, 3276800);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1673527296) + "'", int2 == (-1673527296));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        int int1 = ClassExampleWithNoFailure.twice((-62080));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-124160) + "'", int1 == (-124160));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        int int2 = ClassExampleWithNoFailure.foo((-603979776), (-1636974592));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        int int2 = ClassExampleWithNoFailure.foo((-104857600), (-7760));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-402653184) + "'", int2 == (-402653184));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        int int2 = ClassExampleWithNoFailure.foo((-1863680000), 14000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 812646400 + "'", int2 == 812646400);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        int int2 = ClassExampleWithNoFailure.foo(320, (-1392508928));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2147483648) + "'", int2 == (-2147483648));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        int int1 = ClassExampleWithNoFailure.twice((-173056));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-346112) + "'", int1 == (-346112));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        int int2 = ClassExampleWithNoFailure.foo((-86528000), 1211039744);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1610612736) + "'", int2 == (-1610612736));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        int int2 = ClassExampleWithNoFailure.foo(1366294528, 805306368);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        int int2 = ClassExampleWithNoFailure.foo((-49664000), (-1006632960));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        int int2 = ClassExampleWithNoFailure.foo((-1409286144), (-1409286144));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        int int2 = ClassExampleWithNoFailure.foo(1120000, (-1946157056));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        int int1 = ClassExampleWithNoFailure.twice(1738240);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3476480 + "'", int1 == 3476480);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        int int2 = ClassExampleWithNoFailure.foo((-24832000), (-1329594368));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        int int2 = ClassExampleWithNoFailure.foo(805306368, (-405061632));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        int int2 = ClassExampleWithNoFailure.foo((-1610612736), (-86528));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        int int2 = ClassExampleWithNoFailure.foo(1514240, (-335544320));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        int int1 = ClassExampleWithNoFailure.twice(1673527296);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-947912704) + "'", int1 == (-947912704));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        int int2 = ClassExampleWithNoFailure.foo(1600, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        int int1 = ClassExampleWithNoFailure.twice((-71680000));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-143360000) + "'", int1 == (-143360000));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        int int2 = ClassExampleWithNoFailure.foo((int) ' ', 1379926016);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1879048192) + "'", int2 == (-1879048192));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        int int1 = ClassExampleWithNoFailure.twice(8960000);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 17920000 + "'", int1 == 17920000);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        int int2 = ClassExampleWithNoFailure.foo((-10240), 1048576000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        int int2 = ClassExampleWithNoFailure.foo((-1960000), (-17920000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2085093376) + "'", int2 == (-2085093376));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        int int1 = ClassExampleWithNoFailure.twice((-143360000));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-286720000) + "'", int1 == (-286720000));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        int int1 = ClassExampleWithNoFailure.twice((-44800000));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-89600000) + "'", int1 == (-89600000));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        int int2 = ClassExampleWithNoFailure.foo((-179200000), (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 358400000 + "'", int2 == 358400000);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        int int2 = ClassExampleWithNoFailure.foo(751173632, (-956301312));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        int int2 = ClassExampleWithNoFailure.foo((-256), 86912000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1549271040) + "'", int2 == (-1549271040));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        int int1 = ClassExampleWithNoFailure.twice(1820327936);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-654311424) + "'", int1 == (-654311424));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        int int2 = ClassExampleWithNoFailure.foo(1820327936, 104);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 671088640 + "'", int2 == 671088640);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        int int2 = ClassExampleWithNoFailure.foo((-405061632), 173056);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-369098752) + "'", int2 == (-369098752));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        int int2 = ClassExampleWithNoFailure.foo(409600000, 224000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1677721600) + "'", int2 == (-1677721600));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        int int2 = ClassExampleWithNoFailure.foo(1363607552, 716800);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 536870912 + "'", int2 == 536870912);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        int int2 = ClassExampleWithNoFailure.foo(1006632960, 427819008);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        int int2 = ClassExampleWithNoFailure.foo(15892480, 70);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2070020096) + "'", int2 == (-2070020096));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        int int2 = ClassExampleWithNoFailure.foo(851968000, 1086324736);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        int int2 = ClassExampleWithNoFailure.foo(93184000, (-15520));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1918369792) + "'", int2 == (-1918369792));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        int int2 = ClassExampleWithNoFailure.foo((-3104), 1308622848);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2147483648) + "'", int2 == (-2147483648));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        int int1 = ClassExampleWithNoFailure.twice(917504000);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1835008000 + "'", int1 == 1835008000);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        int int1 = ClassExampleWithNoFailure.twice((-104857600));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-209715200) + "'", int1 == (-209715200));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        int int1 = ClassExampleWithNoFailure.twice(1835008000);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-624951296) + "'", int1 == (-624951296));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        int int2 = ClassExampleWithNoFailure.foo(2912000, (-4480000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 406323200 + "'", int2 == 406323200);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        int int2 = ClassExampleWithNoFailure.foo((-14000), 716800000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-17825792) + "'", int2 == (-17825792));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        int int2 = ClassExampleWithNoFailure.foo(716800, (-567607296));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1610612736) + "'", int2 == (-1610612736));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        int int2 = ClassExampleWithNoFailure.foo(4, 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 80 + "'", int2 == 80);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        int int1 = ClassExampleWithNoFailure.twice(1207959552);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1879048192) + "'", int1 == (-1879048192));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        int int2 = ClassExampleWithNoFailure.foo((-2079850496), 448000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1610612736 + "'", int2 == 1610612736);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        int int2 = ClassExampleWithNoFailure.foo(302848000, (-947912704));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        int int2 = ClassExampleWithNoFailure.foo((-734003200), (-1048576000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        int int2 = ClassExampleWithNoFailure.foo((-2), (-5120));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20480 + "'", int2 == 20480);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        int int2 = ClassExampleWithNoFailure.foo(22020096, 550600704);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        int int2 = ClassExampleWithNoFailure.foo((-346112), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        int int2 = ClassExampleWithNoFailure.foo(1342177280, (-28672000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        int int1 = ClassExampleWithNoFailure.twice((-370065408));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-740130816) + "'", int1 == (-740130816));
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        int int2 = ClassExampleWithNoFailure.foo((-2867200), (-179200000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-805306368) + "'", int2 == (-805306368));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        int int2 = ClassExampleWithNoFailure.foo(70, 40);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5600 + "'", int2 == 5600);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        int int2 = ClassExampleWithNoFailure.foo(294912000, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        int int2 = ClassExampleWithNoFailure.foo((-841381888), (-2098200576));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        int int2 = ClassExampleWithNoFailure.foo(810123264, (-15520));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 807403520 + "'", int2 == 807403520);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        int int2 = ClassExampleWithNoFailure.foo(201326592, (-503316480));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        int int2 = ClassExampleWithNoFailure.foo((-170917888), (-1416101888));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        int int1 = ClassExampleWithNoFailure.twice((-68378624));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-136757248) + "'", int1 == (-136757248));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        int int1 = ClassExampleWithNoFailure.twice(880803840);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1761607680 + "'", int1 == 1761607680);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        int int2 = ClassExampleWithNoFailure.foo((-939524096), (-16));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        int int2 = ClassExampleWithNoFailure.foo(28000, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        int int2 = ClassExampleWithNoFailure.foo(244350976, (-60569600));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-939524096) + "'", int2 == (-939524096));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        int int1 = ClassExampleWithNoFailure.twice(183500800);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 367001600 + "'", int1 == 367001600);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        int int1 = ClassExampleWithNoFailure.twice(1081600);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2163200 + "'", int1 == 2163200);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        int int2 = ClassExampleWithNoFailure.foo(6400, 367001600);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1073741824) + "'", int2 == (-1073741824));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        int int2 = ClassExampleWithNoFailure.foo(204800000, (-1211392000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1073741824 + "'", int2 == 1073741824);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        int int2 = ClassExampleWithNoFailure.foo(10, (-1275068416));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 268435456 + "'", int2 == 268435456);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        int int2 = ClassExampleWithNoFailure.foo((-104857600), (-2240));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1610612736 + "'", int2 == 1610612736);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        int int2 = ClassExampleWithNoFailure.foo((-1853882368), (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 469762048 + "'", int2 == 469762048);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test428");
        int int2 = ClassExampleWithNoFailure.foo(612368384, (-2172800));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2147483648) + "'", int2 == (-2147483648));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        int int2 = ClassExampleWithNoFailure.foo((-1054474240), (-444596224));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        int int1 = ClassExampleWithNoFailure.twice((-346112));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-692224) + "'", int1 == (-692224));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        int int1 = ClassExampleWithNoFailure.twice((-1778384896));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 738197504 + "'", int1 == 738197504);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        int int2 = ClassExampleWithNoFailure.foo((-56000), (-465920000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-812646400) + "'", int2 == (-812646400));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        int int2 = ClassExampleWithNoFailure.foo((-1439432704), 1619001344);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        int int1 = ClassExampleWithNoFailure.twice((-1451098112));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1392771072 + "'", int1 == 1392771072);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test435");
        int int1 = ClassExampleWithNoFailure.twice((-1619001344));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1056964608 + "'", int1 == 1056964608);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test436");
        int int1 = ClassExampleWithNoFailure.twice(1732247552);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-830472192) + "'", int1 == (-830472192));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test437");
        int int2 = ClassExampleWithNoFailure.foo((-603979776), (-722632704));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test438");
        int int2 = ClassExampleWithNoFailure.foo((-1439170560), (-2147483648));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        int int1 = ClassExampleWithNoFailure.twice((-896000000));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1792000000) + "'", int1 == (-1792000000));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        int int2 = ClassExampleWithNoFailure.foo((-56000), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        int int2 = ClassExampleWithNoFailure.foo(388, (-2240000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1738240000) + "'", int2 == (-1738240000));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test442");
        int int2 = ClassExampleWithNoFailure.foo((int) '#', 812646400);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1050673152 + "'", int2 == 1050673152);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test443");
        int int2 = ClassExampleWithNoFailure.foo(885948416, 186368000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1073741824) + "'", int2 == (-1073741824));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test444");
        int int2 = ClassExampleWithNoFailure.foo((-57344000), (-65536000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test445");
        int int2 = ClassExampleWithNoFailure.foo(8960000, (-1056964608));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test446");
        int int1 = ClassExampleWithNoFailure.twice(69222400);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 138444800 + "'", int1 == 138444800);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test447");
        int int1 = ClassExampleWithNoFailure.twice(1635778560);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1023410176) + "'", int1 == (-1023410176));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test448");
        int int2 = ClassExampleWithNoFailure.foo(143360000, (-1086400));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-104857600) + "'", int2 == (-104857600));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test449");
        int int2 = ClassExampleWithNoFailure.foo(0, (-131072000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test450");
        int int2 = ClassExampleWithNoFailure.foo((-3200), (-1549271040));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1744830464) + "'", int2 == (-1744830464));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test451");
        int int2 = ClassExampleWithNoFailure.foo(50331648, 1322778624);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test452");
        int int2 = ClassExampleWithNoFailure.foo(0, 310378496);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test453");
        int int2 = ClassExampleWithNoFailure.foo((-654311424), (-478150656));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test454");
        int int2 = ClassExampleWithNoFailure.foo((-173056), 1322778624);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1073741824 + "'", int2 == 1073741824);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test455");
        int int2 = ClassExampleWithNoFailure.foo((-301989888), 798752768);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test456");
        int int1 = ClassExampleWithNoFailure.twice(710967296);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1421934592 + "'", int1 == 1421934592);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test457");
        int int2 = ClassExampleWithNoFailure.foo(280, (-1626079232));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-71303168) + "'", int2 == (-71303168));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test458");
        int int2 = ClassExampleWithNoFailure.foo((-286720000), 1392771072);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test459");
        int int2 = ClassExampleWithNoFailure.foo(442499072, 89600000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test460");
        int int2 = ClassExampleWithNoFailure.foo(17920000, 549191680);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2147483648) + "'", int2 == (-2147483648));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test461");
        int int1 = ClassExampleWithNoFailure.twice(22020096);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 44040192 + "'", int1 == 44040192);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test462");
        int int1 = ClassExampleWithNoFailure.twice(1863680000);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-567607296) + "'", int1 == (-567607296));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test463");
        int int2 = ClassExampleWithNoFailure.foo((int) 'a', 409600000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2141978624) + "'", int2 == (-2141978624));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test464");
        int int2 = ClassExampleWithNoFailure.foo((-2042036224), 1179648000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test465");
        int int1 = ClassExampleWithNoFailure.twice((-40960));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-81920) + "'", int1 == (-81920));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test466");
        int int1 = ClassExampleWithNoFailure.twice((-1392508928));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1509949440 + "'", int1 == 1509949440);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test467");
        int int2 = ClassExampleWithNoFailure.foo(1415315456, 780140544);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test468");
        int int2 = ClassExampleWithNoFailure.foo(0, (-20));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test469");
        int int1 = ClassExampleWithNoFailure.twice(210894848);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 421789696 + "'", int1 == 421789696);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test470");
        int int2 = ClassExampleWithNoFailure.foo((-939524096), (-885948416));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test471");
        int int2 = ClassExampleWithNoFailure.foo(2912000, (-1276116992));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 536870912 + "'", int2 == 536870912);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test472");
        int int1 = ClassExampleWithNoFailure.twice((-947912704));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1895825408) + "'", int1 == (-1895825408));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test473");
        int int2 = ClassExampleWithNoFailure.foo((-494927872), 570425344);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test474");
        int int1 = ClassExampleWithNoFailure.twice(2483200);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4966400 + "'", int1 == 4966400);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test475");
        int int2 = ClassExampleWithNoFailure.foo((-8691200), 488701952);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1140850688 + "'", int2 == 1140850688);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test476");
        int int2 = ClassExampleWithNoFailure.foo((-885948416), (-922746880));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test477");
        int int2 = ClassExampleWithNoFailure.foo((-20), (-6208));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 248320 + "'", int2 == 248320);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test478");
        int int1 = ClassExampleWithNoFailure.twice(1140850688);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-2013265920) + "'", int1 == (-2013265920));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test479");
        int int2 = ClassExampleWithNoFailure.foo(7168000, 885948416);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-536870912) + "'", int2 == (-536870912));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test480");
        int int2 = ClassExampleWithNoFailure.foo(20480000, 1211039744);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test481");
        int int2 = ClassExampleWithNoFailure.foo(8960, (-1157627904));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test482");
        int int2 = ClassExampleWithNoFailure.foo(445644800, 1879048192);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test483");
        int int2 = ClassExampleWithNoFailure.foo(1280, (-830472192));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test484");
        int int1 = ClassExampleWithNoFailure.twice(89600000);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 179200000 + "'", int1 == 179200000);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test485");
        int int2 = ClassExampleWithNoFailure.foo(8960000, 318767104);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test486");
        int int2 = ClassExampleWithNoFailure.foo((-2079850496), 2560);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1610612736) + "'", int2 == (-1610612736));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test487");
        int int2 = ClassExampleWithNoFailure.foo((-740130816), (-286720000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test488");
        int int2 = ClassExampleWithNoFailure.foo(1872183296, (-16));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 219676672 + "'", int2 == 219676672);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test489");
        int int1 = ClassExampleWithNoFailure.twice((-286720000));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-573440000) + "'", int1 == (-573440000));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test490");
        int int2 = ClassExampleWithNoFailure.foo((-885948416), (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-539099136) + "'", int2 == (-539099136));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test491");
        int int1 = ClassExampleWithNoFailure.twice(1392771072);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1509425152) + "'", int1 == (-1509425152));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test492");
        int int1 = ClassExampleWithNoFailure.twice(1879048192);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-536870912) + "'", int1 == (-536870912));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test493");
        int int2 = ClassExampleWithNoFailure.foo((-2172800), 1792000000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1673527296 + "'", int2 == 1673527296);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test494");
        int int2 = ClassExampleWithNoFailure.foo(458752000, 671088640);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test495");
        int int2 = ClassExampleWithNoFailure.foo((-128), 439353344);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-805306368) + "'", int2 == (-805306368));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test496");
        int int2 = ClassExampleWithNoFailure.foo(173056, (-1006632960));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test497");
        int int1 = ClassExampleWithNoFailure.twice(812646400);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1625292800 + "'", int1 == 1625292800);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test498");
        int int2 = ClassExampleWithNoFailure.foo((-346112), (-1073741824));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test499");
        int int2 = ClassExampleWithNoFailure.foo((-1918369792), 89600);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1610612736 + "'", int2 == 1610612736);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test500");
        int int2 = ClassExampleWithNoFailure.foo(819200000, (-367001600));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }
}

