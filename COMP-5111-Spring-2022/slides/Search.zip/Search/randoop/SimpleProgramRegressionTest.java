import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({ SimpleProgramRegressionTest0.class })
public class SimpleProgramRegressionTest {
}

