import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({ ClassExampleWithNoFailureRegressionTest0.class, ClassExampleWithNoFailureRegressionTest1.class, ClassExampleWithNoFailureRegressionTest2.class, ClassExampleWithNoFailureRegressionTest3.class, ClassExampleWithNoFailureRegressionTest4.class })
public class ClassExampleWithNoFailureRegressionTest {
}

