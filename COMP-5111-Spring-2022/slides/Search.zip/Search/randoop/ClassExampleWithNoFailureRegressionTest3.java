import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class ClassExampleWithNoFailureRegressionTest3 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test001");
        int int2 = ClassExampleWithNoFailure.foo(1879048192, 1775239168);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test002");
        int int2 = ClassExampleWithNoFailure.foo(1619001344, (-1845493760));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test003");
        int int1 = ClassExampleWithNoFailure.twice(143360000);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 286720000 + "'", int1 == 286720000);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test004");
        int int2 = ClassExampleWithNoFailure.foo(1625292800, (-400));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1140850688 + "'", int2 == 1140850688);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test005");
        int int2 = ClassExampleWithNoFailure.foo((-1509425152), (-34764800));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2147483648) + "'", int2 == (-2147483648));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test006");
        int int2 = ClassExampleWithNoFailure.foo(1322778624, 88080384);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test007");
        int int1 = ClassExampleWithNoFailure.twice((-4096000));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-8192000) + "'", int1 == (-8192000));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test008");
        int int2 = ClassExampleWithNoFailure.foo((-812646400), (-1021018112));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test009");
        int int2 = ClassExampleWithNoFailure.foo((-8000), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test010");
        int int2 = ClassExampleWithNoFailure.foo((-469762048), (-200));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1073741824) + "'", int2 == (-1073741824));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test011");
        int int2 = ClassExampleWithNoFailure.foo((-1), 6400);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-12800) + "'", int2 == (-12800));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test012");
        int int2 = ClassExampleWithNoFailure.foo((-1249902592), (-89600));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test013");
        int int2 = ClassExampleWithNoFailure.foo(1476395008, 358400000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test014");
        int int2 = ClassExampleWithNoFailure.foo((-1329594368), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test015");
        int int2 = ClassExampleWithNoFailure.foo((-887095296), 12800);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2147483648) + "'", int2 == (-2147483648));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test016");
        int int2 = ClassExampleWithNoFailure.foo((-2240), (-1409286144));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test017");
        int int2 = ClassExampleWithNoFailure.foo(69206016, 716800000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test018");
        int int1 = ClassExampleWithNoFailure.twice(1366294528);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1562378240) + "'", int1 == (-1562378240));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test019");
        int int2 = ClassExampleWithNoFailure.foo(1912602624, 882900992);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test020");
        int int2 = ClassExampleWithNoFailure.foo((-8), (-1439432704));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1556086784 + "'", int2 == 1556086784);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test021");
        int int2 = ClassExampleWithNoFailure.foo(1254400000, 1744830464);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test022");
        int int2 = ClassExampleWithNoFailure.foo(35840000, 1140850688);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test023");
        int int2 = ClassExampleWithNoFailure.foo((-3920000), (-103301120));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 272629760 + "'", int2 == 272629760);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test024");
        int int2 = ClassExampleWithNoFailure.foo(358400000, (-71680000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1610612736 + "'", int2 == 1610612736);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test025");
        int int2 = ClassExampleWithNoFailure.foo(2240, 1668808704);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1275068416) + "'", int2 == (-1275068416));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test026");
        int int1 = ClassExampleWithNoFailure.twice(1445265408);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1404436480) + "'", int1 == (-1404436480));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test027");
        int int2 = ClassExampleWithNoFailure.foo(805306368, (-1863680000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test028");
        int int2 = ClassExampleWithNoFailure.foo((-1486094336), (-570425344));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test029");
        int int2 = ClassExampleWithNoFailure.foo(1120, (-896000000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1290272768) + "'", int2 == (-1290272768));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test030");
        int int2 = ClassExampleWithNoFailure.foo(0, 880803840);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test031");
        int int2 = ClassExampleWithNoFailure.foo((-318898176), (-1468006400));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test032");
        int int2 = ClassExampleWithNoFailure.foo(692224, 1664);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1991245824) + "'", int2 == (-1991245824));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test033");
        int int2 = ClassExampleWithNoFailure.foo((-469762048), 605696000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test034");
        int int2 = ClassExampleWithNoFailure.foo((-1086400), (-1636974592));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1356857344 + "'", int2 == 1356857344);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test035");
        int int2 = ClassExampleWithNoFailure.foo((-469762048), (-496640000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test036");
        int int2 = ClassExampleWithNoFailure.foo((-44800000), 286720000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1342177280) + "'", int2 == (-1342177280));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test037");
        int int2 = ClassExampleWithNoFailure.foo(177209344, 1021018112);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test038");
        int int1 = ClassExampleWithNoFailure.twice(35840000);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 71680000 + "'", int1 == 71680000);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test039");
        int int2 = ClassExampleWithNoFailure.foo(973078528, (-887095296));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test040");
        int int2 = ClassExampleWithNoFailure.foo(160, 844890112);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-218103808) + "'", int2 == (-218103808));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test041");
        int int2 = ClassExampleWithNoFailure.foo(98566144, (-2042036224));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test042");
        int int2 = ClassExampleWithNoFailure.foo(484442112, (-10240));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test043");
        int int1 = ClassExampleWithNoFailure.twice((-2070020096));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 154927104 + "'", int1 == 154927104);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test044");
        int int1 = ClassExampleWithNoFailure.twice((-1860698112));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 573571072 + "'", int1 == 573571072);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test045");
        int int2 = ClassExampleWithNoFailure.foo((-710967296), (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-926154752) + "'", int2 == (-926154752));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test046");
        int int2 = ClassExampleWithNoFailure.foo(1024000, 1506803712);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test047");
        int int2 = ClassExampleWithNoFailure.foo((-9634816), 1976041472);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1073741824) + "'", int2 == (-1073741824));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test048");
        int int2 = ClassExampleWithNoFailure.foo(0, (-1636974592));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test049");
        int int2 = ClassExampleWithNoFailure.foo((-222298112), 6208000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test050");
        int int2 = ClassExampleWithNoFailure.foo((-248320), (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-48174080) + "'", int2 == (-48174080));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test051");
        int int2 = ClassExampleWithNoFailure.foo((int) (byte) -1, (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test052");
        int int2 = ClassExampleWithNoFailure.foo((-40), (-86528000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1667694592) + "'", int2 == (-1667694592));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test053");
        int int2 = ClassExampleWithNoFailure.foo((-1201668096), 406323200);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test054");
        int int2 = ClassExampleWithNoFailure.foo(8, (-1480261632));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2085617664 + "'", int2 == 2085617664);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test055");
        int int1 = ClassExampleWithNoFailure.twice(738197504);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1476395008 + "'", int1 == 1476395008);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test056");
        int int2 = ClassExampleWithNoFailure.foo((-65536000), 2001207296);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test057");
        int int2 = ClassExampleWithNoFailure.foo((-3276800), (-143360000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test058");
        int int2 = ClassExampleWithNoFailure.foo((-1738240000), 612368384);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test059");
        int int2 = ClassExampleWithNoFailure.foo(49664, 318767104);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test060");
        int int1 = ClassExampleWithNoFailure.twice(31784960);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 63569920 + "'", int1 == 63569920);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test061");
        int int2 = ClassExampleWithNoFailure.foo(1254400000, (-2071986176));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test062");
        int int2 = ClassExampleWithNoFailure.foo(294912000, 3104000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2013265920) + "'", int2 == (-2013265920));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test063");
        int int1 = ClassExampleWithNoFailure.twice(1885339648);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-524288000) + "'", int1 == (-524288000));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test064");
        int int1 = ClassExampleWithNoFailure.twice(3104000);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6208000 + "'", int1 == 6208000);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test065");
        int int1 = ClassExampleWithNoFailure.twice((-780140544));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1560281088) + "'", int1 == (-1560281088));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test066");
        int int2 = ClassExampleWithNoFailure.foo(1760231424, (-63569920));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test067");
        int int2 = ClassExampleWithNoFailure.foo((-1668808704), 11468800);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test068");
        int int1 = ClassExampleWithNoFailure.twice(1795162112);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-704643072) + "'", int1 == (-704643072));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test069");
        int int2 = ClassExampleWithNoFailure.foo(385875968, 173056);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test070");
        int int2 = ClassExampleWithNoFailure.foo(1731985408, 627200000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2147483648) + "'", int2 == (-2147483648));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test071");
        int int2 = ClassExampleWithNoFailure.foo((-1863680000), 143360000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2147483648) + "'", int2 == (-2147483648));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test072");
        int int2 = ClassExampleWithNoFailure.foo(866123776, (-35651584));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test073");
        int int2 = ClassExampleWithNoFailure.foo(64, 163840);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20971520 + "'", int2 == 20971520);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test074");
        int int2 = ClassExampleWithNoFailure.foo(1224736768, (-12416000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test075");
        int int2 = ClassExampleWithNoFailure.foo((-8192000), 1664);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1493172224) + "'", int2 == (-1493172224));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test076");
        int int2 = ClassExampleWithNoFailure.foo((-654311424), (-1764163584));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test077");
        int int2 = ClassExampleWithNoFailure.foo((-1056964608), 11468800);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test078");
        int int2 = ClassExampleWithNoFailure.foo(0, 116822144);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test079");
        int int1 = ClassExampleWithNoFailure.twice(1610612736);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1073741824) + "'", int1 == (-1073741824));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test080");
        int int2 = ClassExampleWithNoFailure.foo((-9634816), (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-192696320) + "'", int2 == (-192696320));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test081");
        int int2 = ClassExampleWithNoFailure.foo(7000, (-9634816));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1743437824) + "'", int2 == (-1743437824));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test082");
        int int2 = ClassExampleWithNoFailure.foo((-1792000000), (-124160));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 763363328 + "'", int2 == 763363328);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test083");
        int int1 = ClassExampleWithNoFailure.twice((-409600000));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-819200000) + "'", int1 == (-819200000));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test084");
        int int2 = ClassExampleWithNoFailure.foo((-69529600), (-2867200));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 134217728 + "'", int2 == 134217728);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test085");
        int int2 = ClassExampleWithNoFailure.foo(478150656, (-40960000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test086");
        int int2 = ClassExampleWithNoFailure.foo(1786167296, 2912000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-92274688) + "'", int2 == (-92274688));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test087");
        int int2 = ClassExampleWithNoFailure.foo((-716800000), 49664);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-637534208) + "'", int2 == (-637534208));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test088");
        int int2 = ClassExampleWithNoFailure.foo(163840, (-124160));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2030043136) + "'", int2 == (-2030043136));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test089");
        int int1 = ClassExampleWithNoFailure.twice(186368000);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 372736000 + "'", int1 == 372736000);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test090");
        int int2 = ClassExampleWithNoFailure.foo(64, (-16640));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2129920) + "'", int2 == (-2129920));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test091");
        int int2 = ClassExampleWithNoFailure.foo(124780544, (-63569920));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test092");
        int int2 = ClassExampleWithNoFailure.foo(872415232, 1509949440);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test093");
        int int2 = ClassExampleWithNoFailure.foo(1556086784, 570425344);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test094");
        int int2 = ClassExampleWithNoFailure.foo((-499122176), (-570425344));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test095");
        int int2 = ClassExampleWithNoFailure.foo(20480000, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-198967296) + "'", int2 == (-198967296));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test096");
        int int1 = ClassExampleWithNoFailure.twice(1224736768);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1845493760) + "'", int1 == (-1845493760));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test097");
        int int2 = ClassExampleWithNoFailure.foo(1111490560, (-567607296));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test098");
        int int2 = ClassExampleWithNoFailure.foo(1677721600, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 939524096 + "'", int2 == 939524096);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test099");
        int int2 = ClassExampleWithNoFailure.foo(1820327936, (-81920000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test100");
        int int2 = ClassExampleWithNoFailure.foo(406323200, 442499072);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test101");
        int int2 = ClassExampleWithNoFailure.foo((-22400), 280);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-12544000) + "'", int2 == (-12544000));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test102");
        int int2 = ClassExampleWithNoFailure.foo((-539099136), 1366294528);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test103");
        int int2 = ClassExampleWithNoFailure.foo(1589641216, 844890112);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test104");
        int int1 = ClassExampleWithNoFailure.twice((-170917888));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-341835776) + "'", int1 == (-341835776));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test105");
        int int2 = ClassExampleWithNoFailure.foo(1211392000, (-268435456));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test106");
        int int2 = ClassExampleWithNoFailure.foo((-1342177280), (-104857600));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test107");
        int int1 = ClassExampleWithNoFailure.twice(160000);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 320000 + "'", int1 == 320000);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test108");
        int int2 = ClassExampleWithNoFailure.foo((-1445265408), (-2097152000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test109");
        int int2 = ClassExampleWithNoFailure.foo((-16), (-1329594368));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-402653184) + "'", int2 == (-402653184));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test110");
        int int1 = ClassExampleWithNoFailure.twice(1760231424);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-774504448) + "'", int1 == (-774504448));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test111");
        int int2 = ClassExampleWithNoFailure.foo(977403904, 143360000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test112");
        int int2 = ClassExampleWithNoFailure.foo((-286720000), (-1044381696));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test113");
        int int2 = ClassExampleWithNoFailure.foo(2, (-1933574144));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 855638016 + "'", int2 == 855638016);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test114");
        int int2 = ClassExampleWithNoFailure.foo(239075328, 5408);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 268435456 + "'", int2 == 268435456);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test115");
        int int2 = ClassExampleWithNoFailure.foo(89600, (-605696000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1690304512 + "'", int2 == 1690304512);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test116");
        int int2 = ClassExampleWithNoFailure.foo((-1140850688), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test117");
        int int2 = ClassExampleWithNoFailure.foo((-496640000), (-413204480));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1073741824 + "'", int2 == 1073741824);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test118");
        int int1 = ClassExampleWithNoFailure.twice((-121139200));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-242278400) + "'", int1 == (-242278400));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test119");
        int int1 = ClassExampleWithNoFailure.twice((-32));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-64) + "'", int1 == (-64));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test120");
        int int2 = ClassExampleWithNoFailure.foo((-444596224), (-8000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1073741824 + "'", int2 == 1073741824);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test121");
        int int2 = ClassExampleWithNoFailure.foo((int) '#', (-800));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-56000) + "'", int2 == (-56000));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test122");
        int int2 = ClassExampleWithNoFailure.foo((-1433600000), (-192696320));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-536870912) + "'", int2 == (-536870912));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test123");
        int int2 = ClassExampleWithNoFailure.foo((-885948416), 851968000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test124");
        int int1 = ClassExampleWithNoFailure.twice((-1237319680));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1820327936 + "'", int1 == 1820327936);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test125");
        int int1 = ClassExampleWithNoFailure.twice((-1196425216));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1902116864 + "'", int1 == 1902116864);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test126");
        int int2 = ClassExampleWithNoFailure.foo(385875968, 1174405120);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test127");
        int int2 = ClassExampleWithNoFailure.foo(17920, 310378496);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test128");
        int int2 = ClassExampleWithNoFailure.foo(229376000, 738197504);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test129");
        int int2 = ClassExampleWithNoFailure.foo((-1786167296), 1893728256);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test130");
        int int2 = ClassExampleWithNoFailure.foo((-6208), (-28672000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-490733568) + "'", int2 == (-490733568));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test131");
        int int2 = ClassExampleWithNoFailure.foo(244350976, 734003200);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test132");
        int int2 = ClassExampleWithNoFailure.foo(854589440, 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-88080384) + "'", int2 == (-88080384));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test133");
        int int2 = ClassExampleWithNoFailure.foo((-8960000), (-402653184));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test134");
        int int2 = ClassExampleWithNoFailure.foo(1668808704, (-1567752192));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test135");
        int int1 = ClassExampleWithNoFailure.twice(484442112);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 968884224 + "'", int1 == 968884224);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test136");
        int int2 = ClassExampleWithNoFailure.foo(1893728256, 469762048);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test137");
        int int2 = ClassExampleWithNoFailure.foo(1366294528, 880803840);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test138");
        int int2 = ClassExampleWithNoFailure.foo((-1342177280), 819200000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test139");
        int int2 = ClassExampleWithNoFailure.foo(1742733312, 2048000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test140");
        int int2 = ClassExampleWithNoFailure.foo(2240, (-1433534464));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1258291200) + "'", int2 == (-1258291200));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test141");
        int int2 = ClassExampleWithNoFailure.foo(186368000, (-160));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 491782144 + "'", int2 == 491782144);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test142");
        int int1 = ClassExampleWithNoFailure.twice(411631616);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 823263232 + "'", int1 == 823263232);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test143");
        int int2 = ClassExampleWithNoFailure.foo((-5120), 1744830464);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test144");
        int int2 = ClassExampleWithNoFailure.foo(128, 233644288);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-316604416) + "'", int2 == (-316604416));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test145");
        int int2 = ClassExampleWithNoFailure.foo(5120, 956301312);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test146");
        int int2 = ClassExampleWithNoFailure.foo(247463936, 8960000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test147");
        int int2 = ClassExampleWithNoFailure.foo(1614807040, (-8320));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1073741824) + "'", int2 == (-1073741824));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test148");
        int int1 = ClassExampleWithNoFailure.twice((-605696000));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1211392000) + "'", int1 == (-1211392000));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test149");
        int int1 = ClassExampleWithNoFailure.twice(1021018112);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2042036224 + "'", int1 == 2042036224);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test150");
        int int2 = ClassExampleWithNoFailure.foo(1775239168, (-1560281088));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test151");
        int int2 = ClassExampleWithNoFailure.foo(0, (-342884352));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test152");
        int int2 = ClassExampleWithNoFailure.foo(1, (-1957691392));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 379584512 + "'", int2 == 379584512);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test153");
        int int1 = ClassExampleWithNoFailure.twice(379584512);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 759169024 + "'", int1 == 759169024);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test154");
        int int1 = ClassExampleWithNoFailure.twice((-64000));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-128000) + "'", int1 == (-128000));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test155");
        int int2 = ClassExampleWithNoFailure.foo(1120000, 2013265920);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test156");
        int int2 = ClassExampleWithNoFailure.foo((-64000), 866123776);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2147483648) + "'", int2 == (-2147483648));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test157");
        int int2 = ClassExampleWithNoFailure.foo((-369098752), (-805306368));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test158");
        int int2 = ClassExampleWithNoFailure.foo((-771751936), (-8000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test159");
        int int2 = ClassExampleWithNoFailure.foo((-1048576000), (-1924661248));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test160");
        int int2 = ClassExampleWithNoFailure.foo((-2001207296), (-1946157056));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test161");
        int int2 = ClassExampleWithNoFailure.foo(1799356416, 1597505536);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test162");
        int int2 = ClassExampleWithNoFailure.foo(88080384, 20971520);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test163");
        int int2 = ClassExampleWithNoFailure.foo(721420288, (-1416101888));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test164");
        int int2 = ClassExampleWithNoFailure.foo(0, 3104);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test165");
        int int2 = ClassExampleWithNoFailure.foo((-242278400), (-716800000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1610612736) + "'", int2 == (-1610612736));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test166");
        int int2 = ClassExampleWithNoFailure.foo((-654311424), 1140850688);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test167");
        int int2 = ClassExampleWithNoFailure.foo((-12416000), (-837025792));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1610612736) + "'", int2 == (-1610612736));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test168");
        int int2 = ClassExampleWithNoFailure.foo(247463936, 100663296);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test169");
        int int2 = ClassExampleWithNoFailure.foo((-2), (-1967128576));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-721420288) + "'", int2 == (-721420288));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test170");
        int int2 = ClassExampleWithNoFailure.foo((-222298112), 272629760);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test171");
        int int1 = ClassExampleWithNoFailure.twice(8);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 16 + "'", int1 == 16);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test172");
        int int2 = ClassExampleWithNoFailure.foo((-1), 484442112);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-968884224) + "'", int2 == (-968884224));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test173");
        int int1 = ClassExampleWithNoFailure.twice((-1207959552));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1879048192 + "'", int1 == 1879048192);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test174");
        int int1 = ClassExampleWithNoFailure.twice((-1682763776));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 929439744 + "'", int1 == 929439744);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test175");
        int int2 = ClassExampleWithNoFailure.foo((-704643072), 2105540608);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test176");
        int int2 = ClassExampleWithNoFailure.foo(409600000, (-496640000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2147483648) + "'", int2 == (-2147483648));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test177");
        int int2 = ClassExampleWithNoFailure.foo(49664, 13905920);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1732247552) + "'", int2 == (-1732247552));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test178");
        int int1 = ClassExampleWithNoFailure.twice((-887095296));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1774190592) + "'", int1 == (-1774190592));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test179");
        int int2 = ClassExampleWithNoFailure.foo((-89600), 5408);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-969113600) + "'", int2 == (-969113600));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test180");
        int int2 = ClassExampleWithNoFailure.foo(406323200, (-400));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1358954496 + "'", int2 == 1358954496);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test181");
        int int2 = ClassExampleWithNoFailure.foo((-318898176), 294912000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test182");
        int int2 = ClassExampleWithNoFailure.foo(28672000, 3276800);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test183");
        int int2 = ClassExampleWithNoFailure.foo((-32000), 917504000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 536870912 + "'", int2 == 536870912);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test184");
        int int2 = ClassExampleWithNoFailure.foo((-20), (-20480));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 819200 + "'", int2 == 819200);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test185");
        int int1 = ClassExampleWithNoFailure.twice((-819200000));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1638400000) + "'", int1 == (-1638400000));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test186");
        int int2 = ClassExampleWithNoFailure.foo(1363607552, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test187");
        int int2 = ClassExampleWithNoFailure.foo((-1541963776), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test188");
        int int2 = ClassExampleWithNoFailure.foo(1738240, (-12416));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-214302720) + "'", int2 == (-214302720));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test189");
        int int2 = ClassExampleWithNoFailure.foo(1885339648, (-35651584));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test190");
        int int2 = ClassExampleWithNoFailure.foo((-413204480), (-1196425216));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test191");
        int int2 = ClassExampleWithNoFailure.foo(70, 372736000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 643432448 + "'", int2 == 643432448);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test192");
        int int2 = ClassExampleWithNoFailure.foo(1786167296, (-1212153856));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test193");
        int int2 = ClassExampleWithNoFailure.foo(93184000, (-1668808704));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test194");
        int int2 = ClassExampleWithNoFailure.foo((-695296000), (-1668808704));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test195");
        int int2 = ClassExampleWithNoFailure.foo(0, 86912000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test196");
        int int1 = ClassExampleWithNoFailure.twice((-1439170560));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1416626176 + "'", int1 == 1416626176);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test197");
        int int2 = ClassExampleWithNoFailure.foo(440401920, (-1841299456));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test198");
        int int1 = ClassExampleWithNoFailure.twice((-1468006400));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1358954496 + "'", int1 == 1358954496);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test199");
        int int2 = ClassExampleWithNoFailure.foo((-114688000), (-285212672));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test200");
        int int2 = ClassExampleWithNoFailure.foo(810123264, (-1157627904));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test201");
        int int1 = ClassExampleWithNoFailure.twice(2013265920);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-268435456) + "'", int1 == (-268435456));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test202");
        int int2 = ClassExampleWithNoFailure.foo((-301989888), 1445265408);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test203");
        int int1 = ClassExampleWithNoFailure.twice(692224);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1384448 + "'", int1 == 1384448);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test204");
        int int2 = ClassExampleWithNoFailure.foo(247463936, (-1056964608));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test205");
        int int2 = ClassExampleWithNoFailure.foo((-81920), 2097152000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test206");
        int int1 = ClassExampleWithNoFailure.twice((-1258291200));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1778384896 + "'", int1 == 1778384896);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test207");
        int int1 = ClassExampleWithNoFailure.twice((-2071986176));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 150994944 + "'", int1 == 150994944);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test208");
        int int1 = ClassExampleWithNoFailure.twice((-1841299456));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 612368384 + "'", int1 == 612368384);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test209");
        int int2 = ClassExampleWithNoFailure.foo(1120, (-1021018112));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2136997888 + "'", int2 == 2136997888);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test210");
        int int2 = ClassExampleWithNoFailure.foo(1799356416, 310400);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1073741824 + "'", int2 == 1073741824);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test211");
        int int2 = ClassExampleWithNoFailure.foo((-316604416), (-11796480));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test212");
        int int2 = ClassExampleWithNoFailure.foo((-1905262592), 3880);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1560281088) + "'", int2 == (-1560281088));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test213");
        int int1 = ClassExampleWithNoFailure.twice((-131072000));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-262144000) + "'", int1 == (-262144000));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test214");
        int int2 = ClassExampleWithNoFailure.foo(93184000, 445644800);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test215");
        int int2 = ClassExampleWithNoFailure.foo(3104, 160000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 993280000 + "'", int2 == 993280000);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test216");
        int int2 = ClassExampleWithNoFailure.foo(1902116864, 1677721600);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test217");
        int int2 = ClassExampleWithNoFailure.foo(3104, 1107296256);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2147483648) + "'", int2 == (-2147483648));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test218");
        int int2 = ClassExampleWithNoFailure.foo((-3200), 1556086784);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1073741824 + "'", int2 == 1073741824);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test219");
        int int1 = ClassExampleWithNoFailure.twice((-637534208));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1275068416) + "'", int1 == (-1275068416));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test220");
        int int1 = ClassExampleWithNoFailure.twice((-5734400));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-11468800) + "'", int1 == (-11468800));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test221");
        int int1 = ClassExampleWithNoFailure.twice(496640);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 993280 + "'", int1 == 993280);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test222");
        int int2 = ClassExampleWithNoFailure.foo((-16), 86528);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2768896) + "'", int2 == (-2768896));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test223");
        int int2 = ClassExampleWithNoFailure.foo(1, 819200);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1638400 + "'", int2 == 1638400);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test224");
        int int2 = ClassExampleWithNoFailure.foo(605696000, (-774504448));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1073741824 + "'", int2 == 1073741824);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test225");
        int int1 = ClassExampleWithNoFailure.twice((-32000));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-64000) + "'", int1 == (-64000));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test226");
        int int1 = ClassExampleWithNoFailure.twice(385875968);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 771751936 + "'", int1 == 771751936);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test227");
        int int2 = ClassExampleWithNoFailure.foo((-320), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test228");
        int int2 = ClassExampleWithNoFailure.foo((-198967296), (-262144000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test229");
        int int2 = ClassExampleWithNoFailure.foo(176160768, (-12416000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test230");
        int int1 = ClassExampleWithNoFailure.twice((-346112000));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-692224000) + "'", int1 == (-692224000));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test231");
        int int1 = ClassExampleWithNoFailure.twice((-1044381696));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-2088763392) + "'", int1 == (-2088763392));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test232");
        int int2 = ClassExampleWithNoFailure.foo((-830472192), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test233");
        int int2 = ClassExampleWithNoFailure.foo(1597505536, 69529600);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test234");
        int int2 = ClassExampleWithNoFailure.foo((-160), (-819200000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 150994944 + "'", int2 == 150994944);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test235");
        int int2 = ClassExampleWithNoFailure.foo(2001207296, 2042036224);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test236");
        int int2 = ClassExampleWithNoFailure.foo((-1493172224), 310378496);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test237");
        int int2 = ClassExampleWithNoFailure.foo(1358954496, (-1872183296));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test238");
        int int1 = ClassExampleWithNoFailure.twice((-112000));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-224000) + "'", int1 == (-224000));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test239");
        int int2 = ClassExampleWithNoFailure.foo((-256000), 872415232);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test240");
        int int2 = ClassExampleWithNoFailure.foo((-81920000), 854589440);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test241");
        int int2 = ClassExampleWithNoFailure.foo((-327680000), 436207616);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test242");
        int int2 = ClassExampleWithNoFailure.foo(1502347264, 318767104);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test243");
        int int1 = ClassExampleWithNoFailure.twice((-1509425152));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1276116992 + "'", int1 == 1276116992);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test244");
        int int2 = ClassExampleWithNoFailure.foo((-1626079232), (-214302720));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test245");
        int int2 = ClassExampleWithNoFailure.foo(0, 721420288);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test246");
        int int1 = ClassExampleWithNoFailure.twice(43264);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 86528 + "'", int1 == 86528);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test247");
        int int2 = ClassExampleWithNoFailure.foo(40960, (-469762048));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test248");
        int int2 = ClassExampleWithNoFailure.foo((-64000), 854589440);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1073741824 + "'", int2 == 1073741824);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test249");
        int int1 = ClassExampleWithNoFailure.twice((-774504448));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1549008896) + "'", int1 == (-1549008896));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test250");
        int int1 = ClassExampleWithNoFailure.twice(847249408);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1694498816 + "'", int1 == 1694498816);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test251");
        int int2 = ClassExampleWithNoFailure.foo((-1562378240), 5600);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-939524096) + "'", int2 == (-939524096));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test252");
        int int2 = ClassExampleWithNoFailure.foo((-5600), (-2046820352));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2147483648) + "'", int2 == (-2147483648));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test253");
        int int2 = ClassExampleWithNoFailure.foo(1506803712, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test254");
        int int2 = ClassExampleWithNoFailure.foo((-603979776), (-49664000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test255");
        int int1 = ClassExampleWithNoFailure.twice((-1535115264));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1224736768 + "'", int1 == 1224736768);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test256");
        int int2 = ClassExampleWithNoFailure.foo(99328, (-1682763776));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-931135488) + "'", int2 == (-931135488));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test257");
        int int1 = ClassExampleWithNoFailure.twice((-692224000));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1384448000) + "'", int1 == (-1384448000));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test258");
        int int2 = ClassExampleWithNoFailure.foo(208, (-5120));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2129920) + "'", int2 == (-2129920));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test259");
        int int2 = ClassExampleWithNoFailure.foo(710967296, 605696000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 805306368 + "'", int2 == 805306368);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test260");
        int int2 = ClassExampleWithNoFailure.foo((-1384448000), 1619001344);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test261");
        int int2 = ClassExampleWithNoFailure.foo(11648000, (-22400000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-463470592) + "'", int2 == (-463470592));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test262");
        int int1 = ClassExampleWithNoFailure.twice(1384120320);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1526726656) + "'", int1 == (-1526726656));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test263");
        int int2 = ClassExampleWithNoFailure.foo(7168000, 1731985408);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test264");
        int int2 = ClassExampleWithNoFailure.foo(80, (-60569600));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1101201408) + "'", int2 == (-1101201408));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test265");
        int int2 = ClassExampleWithNoFailure.foo(855638016, 2560);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test266");
        int int2 = ClassExampleWithNoFailure.foo((-1946157056), 268435456);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test267");
        int int2 = ClassExampleWithNoFailure.foo((-722632704), 763363328);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test268");
        int int2 = ClassExampleWithNoFailure.foo((-1056964608), 2483200);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test269");
        int int2 = ClassExampleWithNoFailure.foo((-198967296), 369098752);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test270");
        int int2 = ClassExampleWithNoFailure.foo(1356857344, 13905920);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test271");
        int int2 = ClassExampleWithNoFailure.foo((-2141978624), (-463470592));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test272");
        int int2 = ClassExampleWithNoFailure.foo(3104, 7000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 43456000 + "'", int2 == 43456000);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test273");
        int int2 = ClassExampleWithNoFailure.foo(23296000, 603979776);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test274");
        int int2 = ClassExampleWithNoFailure.foo((-346112000), 567607296);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2147483648) + "'", int2 == (-2147483648));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test275");
        int int2 = ClassExampleWithNoFailure.foo(1416101888, 2163200);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1610612736) + "'", int2 == (-1610612736));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test276");
        int int2 = ClassExampleWithNoFailure.foo((-8960000), 1217134592);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1073741824) + "'", int2 == (-1073741824));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test277");
        int int1 = ClassExampleWithNoFailure.twice((-114688000));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-229376000) + "'", int1 == (-229376000));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test278");
        int int2 = ClassExampleWithNoFailure.foo((-573440000), 929439744);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2147483648) + "'", int2 == (-2147483648));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test279");
        int int2 = ClassExampleWithNoFailure.foo((-603979776), (-44800000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test280");
        int int2 = ClassExampleWithNoFailure.foo(0, (-721420288));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test281");
        int int2 = ClassExampleWithNoFailure.foo((-80), 201326592);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2147483648) + "'", int2 == (-2147483648));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test282");
        int int2 = ClassExampleWithNoFailure.foo((-655360000), (-805306368));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test283");
        int int2 = ClassExampleWithNoFailure.foo((-69529600), (-4480));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 214958080 + "'", int2 == 214958080);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test284");
        int int2 = ClassExampleWithNoFailure.foo(1120, (-2046820352));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2147483648) + "'", int2 == (-2147483648));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test285");
        int int1 = ClassExampleWithNoFailure.twice(1107296256);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-2080374784) + "'", int1 == (-2080374784));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test286");
        int int2 = ClassExampleWithNoFailure.foo(2240000, 1552);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1636974592) + "'", int2 == (-1636974592));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test287");
        int int1 = ClassExampleWithNoFailure.twice(780140544);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1560281088 + "'", int1 == 1560281088);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test288");
        int int1 = ClassExampleWithNoFailure.twice(1853882368);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-587202560) + "'", int1 == (-587202560));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test289");
        int int2 = ClassExampleWithNoFailure.foo((-1024000), (-1476395008));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test290");
        int int2 = ClassExampleWithNoFailure.foo((-192696320), 1620246528);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 536870912 + "'", int2 == 536870912);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test291");
        int int1 = ClassExampleWithNoFailure.twice((-23592960));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-47185920) + "'", int1 == (-47185920));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test292");
        int int2 = ClassExampleWithNoFailure.foo(570425344, (-524288000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test293");
        int int2 = ClassExampleWithNoFailure.foo(6400, 1237319680);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2147483648) + "'", int2 == (-2147483648));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test294");
        int int2 = ClassExampleWithNoFailure.foo(722632704, (-49664));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-167772160) + "'", int2 == (-167772160));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test295");
        int int2 = ClassExampleWithNoFailure.foo((-10240), 1506803712);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test296");
        int int1 = ClassExampleWithNoFailure.twice(1668808704);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-957349888) + "'", int1 == (-957349888));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test297");
        int int2 = ClassExampleWithNoFailure.foo((-6553600), 496640);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1610612736 + "'", int2 == 1610612736);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test298");
        int int2 = ClassExampleWithNoFailure.foo((-80), (-1464336384));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1929379840) + "'", int2 == (-1929379840));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test299");
        int int1 = ClassExampleWithNoFailure.twice(1855979520);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-583008256) + "'", int1 == (-583008256));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test300");
        int int2 = ClassExampleWithNoFailure.foo((-463470592), 812646400);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test301");
        int int2 = ClassExampleWithNoFailure.foo((-301989888), 881524736);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test302");
        int int2 = ClassExampleWithNoFailure.foo(63569920, 1532755968);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test303");
        int int1 = ClassExampleWithNoFailure.twice(372736000);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 745472000 + "'", int1 == 745472000);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test304");
        int int2 = ClassExampleWithNoFailure.foo(1502347264, 13107200);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test305");
        int int2 = ClassExampleWithNoFailure.foo((-830472192), 28000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-536870912) + "'", int2 == (-536870912));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test306");
        int int2 = ClassExampleWithNoFailure.foo(5824000, (-753369088));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2113929216 + "'", int2 == 2113929216);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test307");
        int int2 = ClassExampleWithNoFailure.foo((-1860698112), (-887095296));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test308");
        int int2 = ClassExampleWithNoFailure.foo(11648000, (-17920000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2088763392) + "'", int2 == (-2088763392));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test309");
        int int2 = ClassExampleWithNoFailure.foo((-567607296), (-499122176));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test310");
        int int2 = ClassExampleWithNoFailure.foo(1120000, 939524096);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test311");
        int int2 = ClassExampleWithNoFailure.foo((-342884352), (-1924661248));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test312");
        int int2 = ClassExampleWithNoFailure.foo(104857600, (-8000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1610612736 + "'", int2 == 1610612736);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test313");
        int int1 = ClassExampleWithNoFailure.twice((-2098200576));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 98566144 + "'", int1 == 98566144);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test314");
        int int1 = ClassExampleWithNoFailure.twice(973078528);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1946157056 + "'", int1 == 1946157056);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test315");
        int int1 = ClassExampleWithNoFailure.twice(957349888);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1914699776 + "'", int1 == 1914699776);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test316");
        int int2 = ClassExampleWithNoFailure.foo(1194852352, 780140544);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test317");
        int int2 = ClassExampleWithNoFailure.foo(335544320, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test318");
        int int1 = ClassExampleWithNoFailure.twice(268435456);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 536870912 + "'", int1 == 536870912);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test319");
        int int1 = ClassExampleWithNoFailure.twice((-956301312));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1912602624) + "'", int1 == (-1912602624));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test320");
        int int1 = ClassExampleWithNoFailure.twice(25600);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 51200 + "'", int1 == 51200);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test321");
        int int2 = ClassExampleWithNoFailure.foo((-12416000), 1392771072);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1610612736 + "'", int2 == 1610612736);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test322");
        int int2 = ClassExampleWithNoFailure.foo(1965367296, 14336000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 805306368 + "'", int2 == 805306368);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test323");
        int int1 = ClassExampleWithNoFailure.twice((-866123776));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1732247552) + "'", int1 == (-1732247552));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test324");
        int int2 = ClassExampleWithNoFailure.foo(11468800, (-346112000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2147483648) + "'", int2 == (-2147483648));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test325");
        int int2 = ClassExampleWithNoFailure.foo(1211039744, (-1229455360));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test326");
        int int1 = ClassExampleWithNoFailure.twice((-968884224));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1937768448) + "'", int1 == (-1937768448));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test327");
        int int2 = ClassExampleWithNoFailure.foo((-56000), (-1468006400));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1073741824 + "'", int2 == 1073741824);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test328");
        int int2 = ClassExampleWithNoFailure.foo(405061632, 214958080);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test329");
        int int1 = ClassExampleWithNoFailure.twice(369098752);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 738197504 + "'", int1 == 738197504);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test330");
        int int1 = ClassExampleWithNoFailure.twice(671088640);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1342177280 + "'", int1 == 1342177280);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test331");
        int int2 = ClassExampleWithNoFailure.foo((-3276800), (-2141978624));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test332");
        int int2 = ClassExampleWithNoFailure.foo(1620246528, (-931840000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2147483648) + "'", int2 == (-2147483648));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test333");
        int int2 = ClassExampleWithNoFailure.foo(1976041472, (-11468800));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test334");
        int int1 = ClassExampleWithNoFailure.twice(1690304512);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-914358272) + "'", int1 == (-914358272));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test335");
        int int2 = ClassExampleWithNoFailure.foo((-103301120), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test336");
        int int1 = ClassExampleWithNoFailure.twice(1050673152);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2101346304 + "'", int1 == 2101346304);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test337");
        int int1 = ClassExampleWithNoFailure.twice(823263232);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1646526464 + "'", int1 == 1646526464);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test338");
        int int1 = ClassExampleWithNoFailure.twice((-2088763392));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 117440512 + "'", int1 == 117440512);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test339");
        int int2 = ClassExampleWithNoFailure.foo((-233644288), 173056);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1447559168) + "'", int2 == (-1447559168));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test340");
        int int2 = ClassExampleWithNoFailure.foo(0, (-1732247552));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test341");
        int int2 = ClassExampleWithNoFailure.foo(70, 244350976);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-150601728) + "'", int2 == (-150601728));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test342");
        int int2 = ClassExampleWithNoFailure.foo(71680000, (-20480));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1744830464 + "'", int2 == 1744830464);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test343");
        int int1 = ClassExampleWithNoFailure.twice((-1567752192));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1159462912 + "'", int1 == 1159462912);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test344");
        int int1 = ClassExampleWithNoFailure.twice((-812646400));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1625292800) + "'", int1 == (-1625292800));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test345");
        int int1 = ClassExampleWithNoFailure.twice(1384448);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2768896 + "'", int1 == 2768896);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test346");
        int int2 = ClassExampleWithNoFailure.foo((-20480), (-1006632960));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test347");
        int int2 = ClassExampleWithNoFailure.foo((-1673527296), (-1073741824));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test348");
        int int2 = ClassExampleWithNoFailure.foo((-2147483648), 1086324736);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test349");
        int int1 = ClassExampleWithNoFailure.twice(1196425216);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1902116864) + "'", int1 == (-1902116864));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test350");
        int int2 = ClassExampleWithNoFailure.foo((-1619001344), (-499122176));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test351");
        int int2 = ClassExampleWithNoFailure.foo(14000, 440401920);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 402653184 + "'", int2 == 402653184);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test352");
        int int2 = ClassExampleWithNoFailure.foo((-810123264), 6208);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 322961408 + "'", int2 == 322961408);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test353");
        int int2 = ClassExampleWithNoFailure.foo(692224, 327680000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test354");
        int int2 = ClassExampleWithNoFailure.foo((-1115684864), 484442112);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test355");
        int int2 = ClassExampleWithNoFailure.foo((-1786167296), 1024000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 268435456 + "'", int2 == 268435456);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test356");
        int int2 = ClassExampleWithNoFailure.foo(692224, (-40960));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-872415232) + "'", int2 == (-872415232));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test357");
        int int1 = ClassExampleWithNoFailure.twice((-28000));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-56000) + "'", int1 == (-56000));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test358");
        int int2 = ClassExampleWithNoFailure.foo((-409600000), 25600);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 805306368 + "'", int2 == 805306368);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test359");
        int int2 = ClassExampleWithNoFailure.foo((-1535115264), (-956301312));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test360");
        int int2 = ClassExampleWithNoFailure.foo((-1291264), 80);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-206602240) + "'", int2 == (-206602240));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test361");
        int int2 = ClassExampleWithNoFailure.foo((-2079850496), 70);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 878706688 + "'", int2 == 878706688);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test362");
        int int2 = ClassExampleWithNoFailure.foo((-1937768448), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test363");
        int int1 = ClassExampleWithNoFailure.twice(3476480);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6952960 + "'", int1 == 6952960);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test364");
        int int2 = ClassExampleWithNoFailure.foo(6208, 239075328);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 536870912 + "'", int2 == 536870912);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test365");
        int int1 = ClassExampleWithNoFailure.twice((-209715200));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-419430400) + "'", int1 == (-419430400));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test366");
        int int2 = ClassExampleWithNoFailure.foo(5824000, (-1744830464));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test367");
        int int2 = ClassExampleWithNoFailure.foo((-63569920), (-114688000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test368");
        int int2 = ClassExampleWithNoFailure.foo((-567607296), (-11468800));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test369");
        int int1 = ClassExampleWithNoFailure.twice((-49664));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-99328) + "'", int1 == (-99328));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test370");
        int int1 = ClassExampleWithNoFailure.twice((-229376000));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-458752000) + "'", int1 == (-458752000));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test371");
        int int1 = ClassExampleWithNoFailure.twice((-1732247552));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 830472192 + "'", int1 == 830472192);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test372");
        int int2 = ClassExampleWithNoFailure.foo((-367001600), (-206602240));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test373");
        int int1 = ClassExampleWithNoFailure.twice((-1433600000));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1427767296 + "'", int1 == 1427767296);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test374");
        int int1 = ClassExampleWithNoFailure.twice((-1673527296));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 947912704 + "'", int1 == 947912704);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test375");
        int int2 = ClassExampleWithNoFailure.foo(280, (-4096000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2001207296 + "'", int2 == 2001207296);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test376");
        int int1 = ClassExampleWithNoFailure.twice(20480000);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 40960000 + "'", int1 == 40960000);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test377");
        int int1 = ClassExampleWithNoFailure.twice((-197132288));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-394264576) + "'", int1 == (-394264576));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test378");
        int int1 = ClassExampleWithNoFailure.twice(939524096);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1879048192 + "'", int1 == 1879048192);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test379");
        int int2 = ClassExampleWithNoFailure.foo(52428800, (-1667694592));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test380");
        int int1 = ClassExampleWithNoFailure.twice(318767104);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 637534208 + "'", int1 == 637534208);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test381");
        int int2 = ClassExampleWithNoFailure.foo((-86528), (-1308622848));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test382");
        int int2 = ClassExampleWithNoFailure.foo(34611200, 23296000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-570425344) + "'", int2 == (-570425344));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test383");
        int int2 = ClassExampleWithNoFailure.foo(524288000, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test384");
        int int2 = ClassExampleWithNoFailure.foo((-71303168), (-889192448));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test385");
        int int2 = ClassExampleWithNoFailure.foo(818487296, 1673527296);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test386");
        int int2 = ClassExampleWithNoFailure.foo(1392771072, 46592000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2147483648) + "'", int2 == (-2147483648));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test387");
        int int2 = ClassExampleWithNoFailure.foo((-192696320), 1552000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 653262848 + "'", int2 == 653262848);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test388");
        int int1 = ClassExampleWithNoFailure.twice(2042036224);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-210894848) + "'", int1 == (-210894848));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test389");
        int int2 = ClassExampleWithNoFailure.foo(10816, 587202560);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2147483648) + "'", int2 == (-2147483648));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test390");
        int int2 = ClassExampleWithNoFailure.foo((-567607296), (-20480));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 536870912 + "'", int2 == 536870912);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test391");
        int int2 = ClassExampleWithNoFailure.foo((-249561088), 179200000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test392");
        int int2 = ClassExampleWithNoFailure.foo(612368384, (-573440000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test393");
        int int2 = ClassExampleWithNoFailure.foo(6553600, 212992000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test394");
        int int1 = ClassExampleWithNoFailure.twice((-9634816));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-19269632) + "'", int1 == (-19269632));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test395");
        int int2 = ClassExampleWithNoFailure.foo(80, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test396");
        int int2 = ClassExampleWithNoFailure.foo(993280, (-1006632960));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test397");
        int int1 = ClassExampleWithNoFailure.twice(843579392);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1687158784 + "'", int1 == 1687158784);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test398");
        int int1 = ClassExampleWithNoFailure.twice((-341835776));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-683671552) + "'", int1 == (-683671552));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test399");
        int int1 = ClassExampleWithNoFailure.twice(1946157056);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-402653184) + "'", int1 == (-402653184));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test400");
        java.lang.Object obj0 = new java.lang.Object();
        java.lang.Class<?> wildcardClass1 = obj0.getClass();
        java.lang.Class<?> wildcardClass2 = obj0.getClass();
        java.lang.Class<?> wildcardClass3 = obj0.getClass();
        java.lang.Class<?> wildcardClass4 = obj0.getClass();
        java.lang.Class<?> wildcardClass5 = obj0.getClass();
        java.lang.Class<?> wildcardClass6 = obj0.getClass();
        java.lang.Class<?> wildcardClass7 = obj0.getClass();
        java.lang.Class<?> wildcardClass8 = obj0.getClass();
        java.lang.Class<?> wildcardClass9 = obj0.getClass();
        java.lang.Class<?> wildcardClass10 = obj0.getClass();
        java.lang.Class<?> wildcardClass11 = obj0.getClass();
        java.lang.Class<?> wildcardClass12 = obj0.getClass();
        java.lang.Class<?> wildcardClass13 = obj0.getClass();
        java.lang.Class<?> wildcardClass14 = obj0.getClass();
        java.lang.Class<?> wildcardClass15 = obj0.getClass();
        java.lang.Class<?> wildcardClass16 = obj0.getClass();
        java.lang.Class<?> wildcardClass17 = obj0.getClass();
        java.lang.Class<?> wildcardClass18 = obj0.getClass();
        java.lang.Class<?> wildcardClass19 = obj0.getClass();
        java.lang.Class<?> wildcardClass20 = obj0.getClass();
        java.lang.Class<?> wildcardClass21 = obj0.getClass();
        java.lang.Class<?> wildcardClass22 = obj0.getClass();
        java.lang.Class<?> wildcardClass23 = obj0.getClass();
        java.lang.Class<?> wildcardClass24 = obj0.getClass();
        java.lang.Class<?> wildcardClass25 = obj0.getClass();
        java.lang.Class<?> wildcardClass26 = obj0.getClass();
        java.lang.Class<?> wildcardClass27 = obj0.getClass();
        java.lang.Class<?> wildcardClass28 = obj0.getClass();
        java.lang.Class<?> wildcardClass29 = obj0.getClass();
        java.lang.Class<?> wildcardClass30 = obj0.getClass();
        java.lang.Class<?> wildcardClass31 = obj0.getClass();
        java.lang.Class<?> wildcardClass32 = obj0.getClass();
        java.lang.Class<?> wildcardClass33 = obj0.getClass();
        java.lang.Class<?> wildcardClass34 = obj0.getClass();
        java.lang.Class<?> wildcardClass35 = obj0.getClass();
        java.lang.Class<?> wildcardClass36 = obj0.getClass();
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertNotNull(wildcardClass30);
        org.junit.Assert.assertNotNull(wildcardClass31);
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertNotNull(wildcardClass33);
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertNotNull(wildcardClass35);
        org.junit.Assert.assertNotNull(wildcardClass36);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test401");
        int int2 = ClassExampleWithNoFailure.foo(1744830464, 603979776);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test402");
        int int1 = ClassExampleWithNoFailure.twice((-1281359872));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1732247552 + "'", int1 == 1732247552);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test403");
        int int2 = ClassExampleWithNoFailure.foo((-1433534464), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test404");
        int int2 = ClassExampleWithNoFailure.foo(1322778624, 409600);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test405");
        int int2 = ClassExampleWithNoFailure.foo(0, 280);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test406");
        int int2 = ClassExampleWithNoFailure.foo((-1610612736), (-1619001344));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test407");
        int int1 = ClassExampleWithNoFailure.twice(16);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 32 + "'", int1 == 32);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test408");
        int int1 = ClassExampleWithNoFailure.twice((-1201668096));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1891631104 + "'", int1 == 1891631104);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test409");
        int int2 = ClassExampleWithNoFailure.foo(872415232, (-1526726656));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test410");
        int int2 = ClassExampleWithNoFailure.foo((-71303168), 88080384);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test411");
        int int2 = ClassExampleWithNoFailure.foo(1356857344, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test412");
        int int2 = ClassExampleWithNoFailure.foo(1620246528, (-1845493760));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test413");
        int int2 = ClassExampleWithNoFailure.foo(560, 2013265920);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test414");
        int int2 = ClassExampleWithNoFailure.foo((int) (byte) 0, 210894848);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test415");
        int int2 = ClassExampleWithNoFailure.foo((-583008256), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test416");
        int int2 = ClassExampleWithNoFailure.foo((-3920000), 1893728256);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 536870912 + "'", int2 == 536870912);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test417");
        int int2 = ClassExampleWithNoFailure.foo(899678208, 176160768);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test418");
        int int2 = ClassExampleWithNoFailure.foo((-1600), 229376000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 436207616 + "'", int2 == 436207616);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test419");
        int int2 = ClassExampleWithNoFailure.foo((-1439170560), (-3200));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2013265920) + "'", int2 == (-2013265920));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test420");
        int int1 = ClassExampleWithNoFailure.twice(179200);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 358400 + "'", int1 == 358400);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test421");
        int int2 = ClassExampleWithNoFailure.foo((-947912704), (-1841299456));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test422");
        int int2 = ClassExampleWithNoFailure.foo(973078528, 993280000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test423");
        int int2 = ClassExampleWithNoFailure.foo((-753369088), 445644800);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test424");
        int int2 = ClassExampleWithNoFailure.foo(1560281088, (-369098752));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test425");
        int int2 = ClassExampleWithNoFailure.foo(1690304512, 603979776);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test426");
        int int2 = ClassExampleWithNoFailure.foo((-1771896832), 1384448);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1073741824) + "'", int2 == (-1073741824));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test427");
        int int2 = ClassExampleWithNoFailure.foo((-402653184), 843579392);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test428");
        int int2 = ClassExampleWithNoFailure.foo((-6553600), 12800);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-268435456) + "'", int2 == (-268435456));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test429");
        int int2 = ClassExampleWithNoFailure.foo(1050673152, (-1677721600));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test430");
        int int2 = ClassExampleWithNoFailure.foo((-1957691392), (-256));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1610612736 + "'", int2 == 1610612736);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test431");
        int int2 = ClassExampleWithNoFailure.foo((-1342177280), 5600);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test432");
        int int1 = ClassExampleWithNoFailure.twice((-837025792));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1674051584) + "'", int1 == (-1674051584));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test433");
        int int2 = ClassExampleWithNoFailure.foo(763363328, (-1560281088));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test434");
        int int2 = ClassExampleWithNoFailure.foo(878706688, 248320);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2147483648) + "'", int2 == (-2147483648));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test435");
        int int2 = ClassExampleWithNoFailure.foo(99328, (-587202560));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test436");
        int int1 = ClassExampleWithNoFailure.twice(139059200);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 278118400 + "'", int1 == 278118400);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test437");
        int int2 = ClassExampleWithNoFailure.foo((-1493172224), 400);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-536870912) + "'", int2 == (-536870912));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test438");
        int int2 = ClassExampleWithNoFailure.foo(335544320, 1660944384);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test439");
        int int2 = ClassExampleWithNoFailure.foo(247463936, (-8960000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test440");
        int int2 = ClassExampleWithNoFailure.foo(0, (-1404436480));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test441");
        int int1 = ClassExampleWithNoFailure.twice((-969113600));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1938227200) + "'", int1 == (-1938227200));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test442");
        int int1 = ClassExampleWithNoFailure.twice((-89600));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-179200) + "'", int1 == (-179200));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test443");
        int int2 = ClassExampleWithNoFailure.foo((-80), (-1933574144));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 134217728 + "'", int2 == 134217728);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test444");
        int int2 = ClassExampleWithNoFailure.foo(0, 89600000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test445");
        int int1 = ClassExampleWithNoFailure.twice(889192448);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1778384896 + "'", int1 == 1778384896);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test446");
        int int1 = ClassExampleWithNoFailure.twice((-1625292800));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1044381696 + "'", int1 == 1044381696);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test447");
        int int2 = ClassExampleWithNoFailure.foo(358400000, 4480000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1442840576) + "'", int2 == (-1442840576));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test448");
        int int2 = ClassExampleWithNoFailure.foo((-301989888), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test449");
        int int1 = ClassExampleWithNoFailure.twice((-419430400));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-838860800) + "'", int1 == (-838860800));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test450");
        int int2 = ClassExampleWithNoFailure.foo((-1743437824), (-805306368));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test451");
        int int1 = ClassExampleWithNoFailure.twice(20971520);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 41943040 + "'", int1 == 41943040);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test452");
        int int2 = ClassExampleWithNoFailure.foo((-926154752), 86912000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 536870912 + "'", int2 == 536870912);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test453");
        int int2 = ClassExampleWithNoFailure.foo((-1549008896), 807403520);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test454");
        int int1 = ClassExampleWithNoFailure.twice((-402653184));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-805306368) + "'", int1 == (-805306368));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test455");
        int int2 = ClassExampleWithNoFailure.foo(50331648, 560);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 536870912 + "'", int2 == 536870912);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test456");
        int int2 = ClassExampleWithNoFailure.foo((-1918369792), (-872415232));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test457");
        int int1 = ClassExampleWithNoFailure.twice(11468800);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 22937600 + "'", int1 == 22937600);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test458");
        int int2 = ClassExampleWithNoFailure.foo(1811939328, 1687158784);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test459");
        int int1 = ClassExampleWithNoFailure.twice((-1764163584));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 766640128 + "'", int1 == 766640128);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test460");
        int int2 = ClassExampleWithNoFailure.foo(51200, 1853882368);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test461");
        int int2 = ClassExampleWithNoFailure.foo((-3276800), (-346112));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 536870912 + "'", int2 == 536870912);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test462");
        int int2 = ClassExampleWithNoFailure.foo((-1967128576), (-124160));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2147483648) + "'", int2 == (-2147483648));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test463");
        int int2 = ClassExampleWithNoFailure.foo((-1237319680), 279969792);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test464");
        int int1 = ClassExampleWithNoFailure.twice(1073741824);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-2147483648) + "'", int1 == (-2147483648));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test465");
        int int2 = ClassExampleWithNoFailure.foo((-24832000), 163840);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2013265920 + "'", int2 == 2013265920);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test466");
        int int2 = ClassExampleWithNoFailure.foo((-342884352), 2048000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test467");
        int int2 = ClassExampleWithNoFailure.foo(1614807040, 1820327936);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test468");
        int int1 = ClassExampleWithNoFailure.twice(279969792);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 559939584 + "'", int1 == 559939584);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test469");
        int int2 = ClassExampleWithNoFailure.foo(1021018112, 17920000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 268435456 + "'", int2 == 268435456);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test470");
        int int2 = ClassExampleWithNoFailure.foo((-242278400), (-1677721600));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test471");
        int int1 = ClassExampleWithNoFailure.twice(448000);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 896000 + "'", int1 == 896000);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test472");
        int int2 = ClassExampleWithNoFailure.foo(154927104, (-1600));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1845493760) + "'", int2 == (-1845493760));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test473");
        int int2 = ClassExampleWithNoFailure.foo((-1416101888), 1224736768);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test474");
        int int2 = ClassExampleWithNoFailure.foo(176160768, (-1451098112));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test475");
        int int2 = ClassExampleWithNoFailure.foo(0, 1416626176);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test476");
        int int2 = ClassExampleWithNoFailure.foo(421789696, 1476395008);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test477");
        int int2 = ClassExampleWithNoFailure.foo((-198967296), (-478150656));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test478");
        int int1 = ClassExampleWithNoFailure.twice((-1115684864));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2063597568 + "'", int1 == 2063597568);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test479");
        int int2 = ClassExampleWithNoFailure.foo((-740130816), (-1486094336));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test480");
        int int1 = ClassExampleWithNoFailure.twice(1358954496);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1577058304) + "'", int1 == (-1577058304));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test481");
        int int2 = ClassExampleWithNoFailure.foo(50331648, 917504000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test482");
        int int2 = ClassExampleWithNoFailure.foo((-2097152000), 440401920);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test483");
        int int1 = ClassExampleWithNoFailure.twice((-128000));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-256000) + "'", int1 == (-256000));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test484");
        int int2 = ClassExampleWithNoFailure.foo(1281490944, 86528);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-939524096) + "'", int2 == (-939524096));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test485");
        int int2 = ClassExampleWithNoFailure.foo(21632, 896000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 109838336 + "'", int2 == 109838336);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test486");
        int int1 = ClassExampleWithNoFailure.twice(2080374784);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-134217728) + "'", int1 == (-134217728));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test487");
        int int2 = ClassExampleWithNoFailure.foo(208, (-16000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-6656000) + "'", int2 == (-6656000));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test488");
        int int2 = ClassExampleWithNoFailure.foo((-722632704), (-358400000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1073741824) + "'", int2 == (-1073741824));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test489");
        int int1 = ClassExampleWithNoFailure.twice(163840);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 327680 + "'", int1 == 327680);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test490");
        int int2 = ClassExampleWithNoFailure.foo((-1506738176), 798752768);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test491");
        int int1 = ClassExampleWithNoFailure.twice(1421934592);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1451098112) + "'", int1 == (-1451098112));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test492");
        int int2 = ClassExampleWithNoFailure.foo(1552000, (-1404436480));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-503316480) + "'", int2 == (-503316480));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test493");
        int int2 = ClassExampleWithNoFailure.foo(89600, (-692224));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 507510784 + "'", int2 == 507510784);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test494");
        int int1 = ClassExampleWithNoFailure.twice(956301312);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1912602624 + "'", int1 == 1912602624);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test495");
        int int2 = ClassExampleWithNoFailure.foo((-1276116992), 1620246528);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test496");
        int int1 = ClassExampleWithNoFailure.twice(6952960);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13905920 + "'", int1 == 13905920);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test497");
        int int1 = ClassExampleWithNoFailure.twice(1664);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3328 + "'", int1 == 3328);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test498");
        int int2 = ClassExampleWithNoFailure.foo(899678208, 1731985408);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test499");
        int int2 = ClassExampleWithNoFailure.foo(1636974592, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test500");
        int int2 = ClassExampleWithNoFailure.foo(24832, 416);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20660224 + "'", int2 == 20660224);
    }
}

