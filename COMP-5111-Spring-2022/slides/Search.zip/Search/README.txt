To install Evosuite plugin, enter http://www.evosuite.org/update at Install Software... under Help menu

http://www.evosuite.org/documentation/measuring-code-coverage/
To enable EclEmma coverage for evosuite-1.0.6.jar, change separate class loader attribute in evosuite-files/evosuite.properties or modify _ESTest.java file:
from
@RunWith(EvoRunner.class) @EvoRunnerParameters(useVNET = true, separateClassLoader = true, useJEE = true) 
to
@RunWith(EvoRunner.class) @EvoRunnerParameters(useVNET = true, separateClassLoader = false, useJEE = true) 

For evosuite-1.0.6.jar and evosuite-1.0.7.jar, comment out //@RunWith ...
The above is applicable to JUnit 5 NOT JUnit 4

If need to run evosuite in command line mode, modify CP=bin
Run line command at project directory of Search
e.g., 
cd e:\eclipse-workspace\Search\
Assuming Rectangle.class is available at e:\eclipse-workspace\Search\bin\
evosuite Rectangle
Otherwise use
evosuite Rectangle -projectCP <bin location relative to the current directory>
The tests will be generated under e:\eclipse-workspace\Search\evosuite-tests\
where evosuite is alias to: java -jar %evosuite_jar_home% -class %*
and define environment evosuite_jar_home to the directory containing evosuite-1.0.6.jar
OR simply alias evosuite to: java -jar "E:\demos\evosuite\evosuite-1.0.6.jar" -class %*

Remember to comment out //@RunWith in the generated xxx_ESTest.java file
** Important Note ** evosuite can be incompatible with Java 9 or above. So, please run evosuite and compile the concerned Java programs using Java 8. set the environment variable %JAVA_HOME% to the Java 8 SDK installed directory, and include the bin under the installed in %PATH%.