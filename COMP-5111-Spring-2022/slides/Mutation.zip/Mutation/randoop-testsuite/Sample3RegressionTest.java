import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({ Sample3RegressionTest0.class })
public class Sample3RegressionTest {
}

