import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({ TestLoopRegressionTest0.class, TestLoopRegressionTest1.class })
public class TestLoopRegressionTest {
}

