

public class TestLoop { 
	public static boolean testMe(int x, int[] y) {
		if (x == 90) {
			System.out.println("1T: Reach branch x == 90"); 
			for (int i = 0; i < y.length; i++) {
				System.out.println("2T: Reach i < y.length");
				if (y[i] == 15) {
					System.out.println("3T: Reach branch y[i] == 15");
					x++;
				} else {
					System.out.println("3F: Reach branch y[i] != 15");
				}
			}
			System.out.println("2F: Reach branch i >= y.length");
		} else {
			System.out.println("1F: Reach branch x != 90");
		}
		if (x == 110) {
			System.out.println("4T: Reach branch x == 110");
			assert (false);
		}
		System.out.println("4F: Reach branch x != 110");
		return false;
	}
}
