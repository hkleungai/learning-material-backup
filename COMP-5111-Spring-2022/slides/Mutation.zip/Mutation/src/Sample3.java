
public class Sample3 {
    public static void sample3(int y) {
        int sum = 0;
        boolean helloflag = false, boolflag = false;
        for (int i = y; i < 15; i=i+1) {
            sum = sum + i;
        }
        if (sum > 4 + y) {
            System.out.println("hello");
            helloflag = true;
        } if (sum < 2) {
            System.out.println("true");
            boolflag = true;
        } else {
            System.out.println("false");
            boolflag = false;
        }
        System.out.println("--");
    	if (helloflag && boolflag)
    		assert(false); 	// assert failure
    }
}
