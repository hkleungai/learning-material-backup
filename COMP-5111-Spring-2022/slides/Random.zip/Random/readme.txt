setup system environment variables:
JAVA_HOME to C:\Program Files\Java\jdk1.8.0_144
RANDOOP_PATH to E:\demos\randoop
RANDOOP_JAR to E:\demos\randoop\randoop-all-3.1.5.jar
PATH includes JAVA_HOME\bin  // must appear before JRE bin
Create a source folder randoop of the target project at Eclipse

open a command prompt window
cd to E:\demos\eclipse-workspace\Random\randoop
java -classpath ..\bin;%RANDOOP_JAR% randoop.main.Main gentests --unchecked-exception=error --testclass=Poly --timelimit=20
// if the Poly class is defined under a package say demo, use testclass=demo.Poly in the previous command.
After Randoop has generated JUnit tests, select test and click refresh F5 at Eclipse
may right click the RegressionTest.java and run it as JUnit at Eclipse

Other useful flags:
checked-exception=expected|error|invalid
unchecked-exception=expected|error|invalid // excluding out of memory and null pointer exception
oom-exception=invalid|expected|error  // out of memory error
sof-exception=invalid|expected|error  // stack overflow error
npe-on-null-input=expected|invalid|error  // null pointer exception upon a null argument
npe-on-non-null-input=invalid|expected|error  // null pointer exception upon only non-null arguments
https://randoop.github.io/randoop/manual/#generating_tests
