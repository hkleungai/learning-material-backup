
import static org.junit.Assert.*;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.*;

import java.util.*;

@RunWith(Parameterized.class)
public class Sample3PUTest {
	@Parameters(name="{index}: {0},{1},{2}") // describe a family of scenarios
	public static Collection<Object[]> parameters() {
		return Arrays.asList(new Object[][] {{0}, {-1}, {-2}, {-3}, {-4}, {-5}, {-6}, {-7}, {-8}, {-9}, {-10},
				{-11}, {-12}, {-13}, {-14}, {-15}, {-16}, {-17}, {-18}, {-19}});
    }
	
	@Parameter // default value=0
	public int y;
	/*
	@Parameter(value=1)
	public boolean expected;
	*/
	
	@Test
	public void testCompare() {
		Sample3.sample3(y);
		// assertEquals("compare fails", expected, result);
	}
}
