
import static org.junit.Assert.*;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.*;

import java.util.*;

@RunWith(Parameterized.class)
public class SimpleProgramPUTest {
	@Parameters(name="{index}: {0},{1},{2}") // describe a family of scenarios
	public static Collection<Object[]> parameters() {
		return Arrays.asList(new Object[][] {{1,2,false}, {0,0,true}});
    }
	
	@Parameter // default value=0
	public int x;
	
	@Parameter(value=1)
	public int y;
	
	@Parameter(value=2)
	public boolean expected;
	
	@Test
	public void testCompare() {
		boolean result = SimpleProgram.compare(x,  y);
		assertEquals("compare fails", expected, result);
	}
}
