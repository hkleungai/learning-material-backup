
import static org.junit.Assert.*;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.*;

import java.util.*;

@RunWith(Parameterized.class)
public class TestLoopPUTest {
	@Parameters(name="{index}: {0},{1},{2}") // describe a family of scenarios
	public static Collection<Object[]> parameters() {
		return Arrays.asList(new Object[][] {{0,0,0,false}, {110,0,0,false}, 
				{90,0,0,false}, {90,0,15,false}, {90,15,15,false}, {90,15,0,false}});
    }
	
	@Parameter // default value=0
	public int x;
	
	@Parameter(value=1)
	public int y0;
	
	@Parameter(value=2)
	public int y1;	
	
	@Parameter(value=3)
	public boolean expected;
	
	@Test
	public void testCompare() {
		  int [] y = {y0,y1};
		  boolean result = TestLoop.testMe(x,  y);
		  assertEquals("compare fails", expected, result);
	}
}
