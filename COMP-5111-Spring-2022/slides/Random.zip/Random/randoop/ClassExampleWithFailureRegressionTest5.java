import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class ClassExampleWithFailureRegressionTest5 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test001");
        int i2 = ClassExampleWithFailure.foo(1946157056, (-51200000));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test002");
        int i2 = ClassExampleWithFailure.foo(770703360, 96348160);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test003");
        int i2 = ClassExampleWithFailure.foo(32505856, 9175040);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test004");
        int i1 = ClassExampleWithFailure.twice(39845888);
        org.junit.Assert.assertTrue(i1 == 79691776);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test005");
        int i1 = ClassExampleWithFailure.twice(794624000);
        org.junit.Assert.assertTrue(i1 == 1589248000);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test006");
        int i2 = ClassExampleWithFailure.foo(402653184, 1);
        org.junit.Assert.assertTrue(i2 == 805306368);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test007");
        int i2 = ClassExampleWithFailure.foo((-1912602624), (-989855744));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test008");
        int i1 = ClassExampleWithFailure.twice((-1048576000));
        org.junit.Assert.assertTrue(i1 == (-2097152000));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test009");
        int i2 = ClassExampleWithFailure.foo((-1761607680), 1275068416);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test010");
        int i2 = ClassExampleWithFailure.foo((-2048000000), 248320);
        org.junit.Assert.assertTrue(i2 == (-1744830464));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test011");
        int i2 = ClassExampleWithFailure.foo((-35840000), 2662400);
        org.junit.Assert.assertTrue(i2 == 1744830464);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test012");
        int i1 = ClassExampleWithFailure.twice(1551892480);
        org.junit.Assert.assertTrue(i1 == (-1191182336));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test013");
        int i2 = ClassExampleWithFailure.foo(0, 1509949440);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test014");
        int i2 = ClassExampleWithFailure.foo((-401408000), (-1476395008));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test015");
        int i2 = ClassExampleWithFailure.foo(1056964608, (-16384));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test016");
        int i2 = ClassExampleWithFailure.foo(655360000, 754974720);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test017");
        int i2 = ClassExampleWithFailure.foo((-524288000), (-872415232));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test018");
        int i2 = ClassExampleWithFailure.foo(251658240, (-585105408));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test019");
        int i2 = ClassExampleWithFailure.foo(285212672, 1591738368);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test020");
        int i2 = ClassExampleWithFailure.foo(524288000, (-17920000));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test021");
        int i1 = ClassExampleWithFailure.twice(1912602624);
        org.junit.Assert.assertTrue(i1 == (-469762048));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test022");
        int i2 = ClassExampleWithFailure.foo(131072000, (-1140850688));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test023");
        int i2 = ClassExampleWithFailure.foo(11010048, (-2147483648));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test024");
        int i1 = ClassExampleWithFailure.twice(843055104);
        org.junit.Assert.assertTrue(i1 == 1686110208);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test025");
        int i2 = ClassExampleWithFailure.foo((-993280000), 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test026");
        int i2 = ClassExampleWithFailure.foo(1778384896, 494927872);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test027");
        int i2 = ClassExampleWithFailure.foo((-6400), 22020096);
        org.junit.Assert.assertTrue(i2 == 1610612736);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test028");
        int i1 = ClassExampleWithFailure.twice((-1024000));
        org.junit.Assert.assertTrue(i1 == (-2048000));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test029");
        int i2 = ClassExampleWithFailure.foo(671088640, (-1061158912));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test030");
        int i2 = ClassExampleWithFailure.foo(17920000, (-1140850688));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test031");
        int i2 = ClassExampleWithFailure.foo(1605632000, (-1600));
        org.junit.Assert.assertTrue(i2 == (-1241513984));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test032");
        int i2 = ClassExampleWithFailure.foo((-4), (int) (byte) 100);
        org.junit.Assert.assertTrue(i2 == (-800));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test033");
        int i2 = ClassExampleWithFailure.foo(1216768000, (-42598400));
        org.junit.Assert.assertTrue(i2 == (-536870912));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test034");
        int i2 = ClassExampleWithFailure.foo((-16384), 20480000);
        org.junit.Assert.assertTrue(i2 == (-1073741824));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test035");
        int i2 = ClassExampleWithFailure.foo((-8960000), (int) (short) 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test036");
        int i1 = ClassExampleWithFailure.twice((-920649728));
        org.junit.Assert.assertTrue(i1 == (-1841299456));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test037");
        int i2 = ClassExampleWithFailure.foo(859832320, (-65536000));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test038");
        int i2 = ClassExampleWithFailure.foo((-1224736768), 553648128);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test039");
        int i2 = ClassExampleWithFailure.foo(421789696, 166400);
        org.junit.Assert.assertTrue(i2 == (-805306368));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test040");
        int i2 = ClassExampleWithFailure.foo((-12800000), (-89600));
        org.junit.Assert.assertTrue(i2 == 247463936);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test041");
        int i2 = ClassExampleWithFailure.foo((-878182400), (-599785472));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test042");
        int i2 = ClassExampleWithFailure.foo((-570425344), 679215104);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test043");
        int i2 = ClassExampleWithFailure.foo(874053632, (-335544320));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test044");
        int i2 = ClassExampleWithFailure.foo((-179200), 35840);
        org.junit.Assert.assertTrue(i2 == 39845888);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test045");
        int i2 = ClassExampleWithFailure.foo(3584000, 5120);
        org.junit.Assert.assertTrue(i2 == (-1954545664));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test046");
        int i1 = ClassExampleWithFailure.twice((-1929379840));
        org.junit.Assert.assertTrue(i1 == 436207616);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test047");
        int i1 = ClassExampleWithFailure.twice(81920000);
        org.junit.Assert.assertTrue(i1 == 163840000);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test048");
        int i2 = ClassExampleWithFailure.foo(12800, 1224736768);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test049");
        int i2 = ClassExampleWithFailure.foo(795869184, (-25600000));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test050");
        int i2 = ClassExampleWithFailure.foo(0, (-140));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test051");
        int i2 = ClassExampleWithFailure.foo((-1042808832), (-1549271040));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test052");
        int i2 = ClassExampleWithFailure.foo(608384000, 855638016);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test053");
        int i1 = ClassExampleWithFailure.twice((-209715200));
        org.junit.Assert.assertTrue(i1 == (-419430400));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test054");
        int i2 = ClassExampleWithFailure.foo(795869184, 679215104);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test055");
        int i2 = ClassExampleWithFailure.foo(128, 624951296);
        org.junit.Assert.assertTrue(i2 == 1073741824);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test056");
        int i2 = ClassExampleWithFailure.foo(8960000, (-140));
        org.junit.Assert.assertTrue(i2 == 1786167296);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test057");
        int i2 = ClassExampleWithFailure.foo(294912000, 32);
        org.junit.Assert.assertTrue(i2 == 1694498816);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test058");
        int i2 = ClassExampleWithFailure.foo(5120, (-920649728));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test059");
        int i2 = ClassExampleWithFailure.foo(916455424, 602176);
        org.junit.Assert.assertTrue(i2 == 1342177280);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test060");
        int i2 = ClassExampleWithFailure.foo(608384000, 905969664);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test061");
        int i2 = ClassExampleWithFailure.foo((-905969664), 2046820352);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test062");
        int i2 = ClassExampleWithFailure.foo(301989888, (-1513783296));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test063");
        int i2 = ClassExampleWithFailure.foo((-1677721600), 32000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test064");
        int i1 = ClassExampleWithFailure.twice(1369440256);
        org.junit.Assert.assertTrue(i1 == (-1556086784));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test065");
        int i2 = ClassExampleWithFailure.foo(0, (-436207616));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test066");
        int i2 = ClassExampleWithFailure.foo((-1199570944), (-200));
        org.junit.Assert.assertTrue(i2 == (-1207959552));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test067");
        int i2 = ClassExampleWithFailure.foo((-209715200), 10485760);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test068");
        int i1 = ClassExampleWithFailure.twice((-478150656));
        org.junit.Assert.assertTrue(i1 == (-956301312));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test069");
        int i2 = ClassExampleWithFailure.foo((-409600), 436207616);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test070");
        int i1 = ClassExampleWithFailure.twice((-1123549184));
        org.junit.Assert.assertTrue(i1 == 2047868928);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test071");
        int i2 = ClassExampleWithFailure.foo((-10485760), (int) (short) 100);
        org.junit.Assert.assertTrue(i2 == (-2097152000));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test072");
        int i1 = ClassExampleWithFailure.twice((-6400));
        org.junit.Assert.assertTrue(i1 == (-12800));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test073");
        int i2 = ClassExampleWithFailure.foo(1954545664, 1929379840);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test074");
        int i2 = ClassExampleWithFailure.foo((-1756364800), 71680000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test075");
        int i2 = ClassExampleWithFailure.foo((int) (short) 0, (-1986560000));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test076");
        int i2 = ClassExampleWithFailure.foo(872415232, (-1874853888));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test077");
        int i2 = ClassExampleWithFailure.foo((-1061158912), 754974720);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test078");
        int i2 = ClassExampleWithFailure.foo((-1929379840), (-1071513600));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test079");
        int i2 = ClassExampleWithFailure.foo(496640000, (-494927872));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test080");
        int i2 = ClassExampleWithFailure.foo((-2329600), 1179648000);
        org.junit.Assert.assertTrue(i2 == (-2147483648));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test081");
        int i2 = ClassExampleWithFailure.foo((-204800000), 292552704);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test082");
        int i2 = ClassExampleWithFailure.foo(1048576000, 112000);
        org.junit.Assert.assertTrue(i2 == (-2147483648));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test083");
        int i2 = ClassExampleWithFailure.foo((-335544320), 1280000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test084");
        int i2 = ClassExampleWithFailure.foo(262144000, (-1132462080));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test085");
        int i2 = ClassExampleWithFailure.foo(1112473600, (-256000));
        org.junit.Assert.assertTrue(i2 == (-805306368));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test086");
        int i2 = ClassExampleWithFailure.foo(585105408, 1024000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test087");
        int i1 = ClassExampleWithFailure.twice((-1567752192));
        org.junit.Assert.assertTrue(i1 == 1159462912);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test088");
        int i1 = ClassExampleWithFailure.twice(2047868928);
        org.junit.Assert.assertTrue(i1 == (-199229440));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test089");
        int i2 = ClassExampleWithFailure.foo(1228406784, 124160);
        org.junit.Assert.assertTrue(i2 == 805306368);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test090");
        int i2 = ClassExampleWithFailure.foo((-4480000), (-1556086784));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test091");
        int i2 = ClassExampleWithFailure.foo(1179648000, (-1756160000));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test092");
        int i2 = ClassExampleWithFailure.foo(1267400704, (-4480000));
        org.junit.Assert.assertTrue(i2 == 402653184);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test093");
        int i2 = ClassExampleWithFailure.foo((-1416101888), 1442807808);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test094");
        int i1 = ClassExampleWithFailure.twice(372736000);
        org.junit.Assert.assertTrue(i1 == 745472000);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test095");
        int i1 = ClassExampleWithFailure.twice(1287389184);
        org.junit.Assert.assertTrue(i1 == (-1720188928));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test096");
        int i2 = ClassExampleWithFailure.foo(1404436480, (-1709178880));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test097");
        int i2 = ClassExampleWithFailure.foo((-989855744), 776);
        org.junit.Assert.assertTrue(i2 == 1342177280);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test098");
        int i2 = ClassExampleWithFailure.foo((-947912704), (-130023424));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test099");
        int i2 = ClassExampleWithFailure.foo(874053632, 1778384896);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test100");
        int i1 = ClassExampleWithFailure.twice(218103808);
        org.junit.Assert.assertTrue(i1 == 436207616);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test101");
        int i2 = ClassExampleWithFailure.foo(192696320, (-71680000));
        org.junit.Assert.assertTrue(i2 == 1744830464);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test102");
        int i2 = ClassExampleWithFailure.foo((-947912704), (-536870912));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test103");
        int i1 = ClassExampleWithFailure.twice(1870659584);
        org.junit.Assert.assertTrue(i1 == (-553648128));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test104");
        int i1 = ClassExampleWithFailure.twice(2097152000);
        org.junit.Assert.assertTrue(i1 == (-100663296));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test105");
        int i2 = ClassExampleWithFailure.foo((-1795162112), 624951296);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test106");
        int i1 = ClassExampleWithFailure.twice(562036736);
        org.junit.Assert.assertTrue(i1 == 1124073472);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test107");
        int i2 = ClassExampleWithFailure.foo((-3328000), (-1));
        org.junit.Assert.assertTrue(i2 == 6656000);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test108");
        int i1 = ClassExampleWithFailure.twice(10485760);
        org.junit.Assert.assertTrue(i1 == 20971520);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test109");
        int i2 = ClassExampleWithFailure.foo((-1111490560), 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test110");
        int i2 = ClassExampleWithFailure.foo(1310720, (-640));
        org.junit.Assert.assertTrue(i2 == (-1677721600));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test111");
        int i1 = ClassExampleWithFailure.twice(1146880000);
        org.junit.Assert.assertTrue(i1 == (-2001207296));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test112");
        int i2 = ClassExampleWithFailure.foo(222298112, (int) ' ');
        org.junit.Assert.assertTrue(i2 == 1342177280);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test113");
        int i2 = ClassExampleWithFailure.foo(1577058304, 939524096);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test114");
        int i2 = ClassExampleWithFailure.foo((int) (short) 0, 1188298752);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test115");
        int i1 = ClassExampleWithFailure.twice((-1280));
        org.junit.Assert.assertTrue(i1 == (-2560));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test116");
        int i2 = ClassExampleWithFailure.foo((-1067974656), (-22400));
        org.junit.Assert.assertTrue(i2 == (-671088640));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test117");
        int i2 = ClassExampleWithFailure.foo((-2046820352), 12416000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test118");
        int i2 = ClassExampleWithFailure.foo(443809792, (-1526726656));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test119");
        int i2 = ClassExampleWithFailure.foo(1040187392, 1581252608);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test120");
        int i2 = ClassExampleWithFailure.foo(0, 35840);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test121");
        int i1 = ClassExampleWithFailure.twice((-13312000));
        org.junit.Assert.assertTrue(i1 == (-26624000));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test122");
        int i2 = ClassExampleWithFailure.foo(896000, 2240);
        org.junit.Assert.assertTrue(i2 == (-280887296));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test123");
        int i2 = ClassExampleWithFailure.foo(0, 1600);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test124");
        int i1 = ClassExampleWithFailure.twice(5324800);
        org.junit.Assert.assertTrue(i1 == 10649600);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test125");
        int i2 = ClassExampleWithFailure.foo(10, 490733568);
        org.junit.Assert.assertTrue(i2 == 1224736768);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test126");
        int i2 = ClassExampleWithFailure.foo((-1308622848), (-809500672));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test127");
        int i2 = ClassExampleWithFailure.foo(32, 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test128");
        int i2 = ClassExampleWithFailure.foo(28672000, 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test129");
        int i2 = ClassExampleWithFailure.foo(1535115264, 1929379840);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test130");
        int i2 = ClassExampleWithFailure.foo(4096, 805306368);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test131");
        int i1 = ClassExampleWithFailure.twice((-458752000));
        org.junit.Assert.assertTrue(i1 == (-917504000));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test132");
        int i2 = ClassExampleWithFailure.foo(22937600, 397934592);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test133");
        int i2 = ClassExampleWithFailure.foo(1600, (-478150656));
        org.junit.Assert.assertTrue(i2 == (-1073741824));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test134");
        int i1 = ClassExampleWithFailure.twice(1740177408);
        org.junit.Assert.assertTrue(i1 == (-814612480));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test135");
        int i2 = ClassExampleWithFailure.foo((-1191182336), 2007040000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test136");
        int i2 = ClassExampleWithFailure.foo(32768000, 32);
        org.junit.Assert.assertTrue(i2 == 2097152000);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test137");
        int i2 = ClassExampleWithFailure.foo((-1756160000), (-1954545664));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test138");
        int i1 = ClassExampleWithFailure.twice((-1191182336));
        org.junit.Assert.assertTrue(i1 == 1912602624);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test139");
        int i1 = ClassExampleWithFailure.twice((-796917760));
        org.junit.Assert.assertTrue(i1 == (-1593835520));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test140");
        int i2 = ClassExampleWithFailure.foo((-16384), 1124073472);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test141");
        int i2 = ClassExampleWithFailure.foo(1188298752, 665600);
        org.junit.Assert.assertTrue(i2 == 1073741824);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test142");
        int i2 = ClassExampleWithFailure.foo(1104674816, 1083703296);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test143");
        int i2 = ClassExampleWithFailure.foo(1317011456, 388);
        org.junit.Assert.assertTrue(i2 == (-201326592));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test144");
        int i2 = ClassExampleWithFailure.foo((-1416101888), 1748107264);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test145");
        int i2 = ClassExampleWithFailure.foo(665600, (int) (short) 100);
        org.junit.Assert.assertTrue(i2 == 133120000);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test146");
        int i2 = ClassExampleWithFailure.foo(3104000, 2113929216);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test147");
        int i2 = ClassExampleWithFailure.foo(1832910848, (-1560281088));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test148");
        int i2 = ClassExampleWithFailure.foo(1786167296, 31784960);
        org.junit.Assert.assertTrue(i2 == (-2147483648));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test149");
        int i2 = ClassExampleWithFailure.foo(870088704, (-335544320));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test150");
        int i1 = ClassExampleWithFailure.twice((-1140457472));
        org.junit.Assert.assertTrue(i1 == 2014052352);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test151");
        int i2 = ClassExampleWithFailure.foo((-10485760), (-1929379840));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test152");
        int i1 = ClassExampleWithFailure.twice((-1071513600));
        org.junit.Assert.assertTrue(i1 == (-2143027200));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test153");
        int i2 = ClassExampleWithFailure.foo(838860800, 160);
        org.junit.Assert.assertTrue(i2 == (-2147483648));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test154");
        int i2 = ClassExampleWithFailure.foo(163840, 1073741824);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test155");
        int i2 = ClassExampleWithFailure.foo(123731968, (-573440000));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test156");
        int i2 = ClassExampleWithFailure.foo(854196224, 10240);
        org.junit.Assert.assertTrue(i2 == 536870912);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test157");
        int i1 = ClassExampleWithFailure.twice(444596224);
        org.junit.Assert.assertTrue(i1 == 889192448);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test158");
        int i1 = ClassExampleWithFailure.twice((-685768704));
        org.junit.Assert.assertTrue(i1 == (-1371537408));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test159");
        int i1 = ClassExampleWithFailure.twice(1112473600);
        org.junit.Assert.assertTrue(i1 == (-2070020096));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test160");
        int i2 = ClassExampleWithFailure.foo((-917504000), (-1660944384));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test161");
        int i2 = ClassExampleWithFailure.foo(49664, (-342884352));
        org.junit.Assert.assertTrue(i2 == 1073741824);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test162");
        int i2 = ClassExampleWithFailure.foo((-654311424), 322816);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test163");
        int i2 = ClassExampleWithFailure.foo(89600, 2014052352);
        org.junit.Assert.assertTrue(i2 == (-805306368));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test164");
        int i1 = ClassExampleWithFailure.twice((-956301312));
        org.junit.Assert.assertTrue(i1 == (-1912602624));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test165");
        int i1 = ClassExampleWithFailure.twice(1);
        org.junit.Assert.assertTrue(i1 == 2);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test166");
        int i2 = ClassExampleWithFailure.foo(496640000, (-123731968));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test167");
        int i2 = ClassExampleWithFailure.foo((-175636480), 1605632000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test168");
        int i2 = ClassExampleWithFailure.foo((-39845888), 35840);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test169");
        int i2 = ClassExampleWithFailure.foo(327680, 385351680);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test170");
        int i2 = ClassExampleWithFailure.foo((-1541406720), (-4096));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test171");
        int i2 = ClassExampleWithFailure.foo(11468800, 201326592);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test172");
        int i2 = ClassExampleWithFailure.foo(585105408, 28672000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test173");
        int i2 = ClassExampleWithFailure.foo((-1140850688), (-62720000));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test174");
        int i2 = ClassExampleWithFailure.foo(776, (-1526726656));
        org.junit.Assert.assertTrue(i2 == 1342177280);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test175");
        int i2 = ClassExampleWithFailure.foo(1803550720, 1076494336);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test176");
        int i1 = ClassExampleWithFailure.twice((-1556086784));
        org.junit.Assert.assertTrue(i1 == 1182793728);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test177");
        int i2 = ClassExampleWithFailure.foo((-3200), 166400);
        org.junit.Assert.assertTrue(i2 == (-1064960000));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test178");
        int i2 = ClassExampleWithFailure.foo(436207616, 2621440);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test179");
        int i2 = ClassExampleWithFailure.foo((-1879048192), 4096);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test180");
        int i2 = ClassExampleWithFailure.foo(421789696, 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test181");
        int i2 = ClassExampleWithFailure.foo(2662400, 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test182");
        int i2 = ClassExampleWithFailure.foo(8000, (-2013265920));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test183");
        int i2 = ClassExampleWithFailure.foo(1976041472, 443809792);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test184");
        int i2 = ClassExampleWithFailure.foo(1476395008, 1589248000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test185");
        int i2 = ClassExampleWithFailure.foo(218103808, (-2143027200));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test186");
        int i2 = ClassExampleWithFailure.foo(1275068416, 1404436480);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test187");
        int i2 = ClassExampleWithFailure.foo((-15520), 872415232);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test188");
        int i2 = ClassExampleWithFailure.foo((-1426079744), (-1392771072));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test189");
        int i2 = ClassExampleWithFailure.foo((-100663296), 1170210816);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test190");
        int i2 = ClassExampleWithFailure.foo(1509949440, 973078528);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test191");
        int i2 = ClassExampleWithFailure.foo((-10649600), 245891072);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test192");
        int i2 = ClassExampleWithFailure.foo((-163840), (-209715200));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test193");
        int i2 = ClassExampleWithFailure.foo(1331200, 1476395008);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test194");
        int i2 = ClassExampleWithFailure.foo((-280887296), (-1241513984));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test195");
        int i2 = ClassExampleWithFailure.foo(1740177408, 859832320);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test196");
        int i2 = ClassExampleWithFailure.foo((-624951296), 32505856);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test197");
        int i2 = ClassExampleWithFailure.foo(0, 800);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test198");
        int i2 = ClassExampleWithFailure.foo(128000, 1979711488);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test199");
        int i1 = ClassExampleWithFailure.twice(443809792);
        org.junit.Assert.assertTrue(i1 == 887619584);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test200");
        int i1 = ClassExampleWithFailure.twice(1786167296);
        org.junit.Assert.assertTrue(i1 == (-722632704));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test201");
        int i2 = ClassExampleWithFailure.foo(1179648000, 983564288);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test202");
        int i2 = ClassExampleWithFailure.foo((-286720000), 1744830464);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test203");
        int i2 = ClassExampleWithFailure.foo((-722632704), 767557632);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test204");
        int i2 = ClassExampleWithFailure.foo((-3200), 520093696);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test205");
        int i2 = ClassExampleWithFailure.foo(372736000, 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test206");
        int i2 = ClassExampleWithFailure.foo(560, 1280000);
        org.junit.Assert.assertTrue(i2 == 1433600000);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test207");
        int i2 = ClassExampleWithFailure.foo(280887296, (-130023424));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test208");
        int i2 = ClassExampleWithFailure.foo((-150994944), (-35840));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test209");
        int i2 = ClassExampleWithFailure.foo(880803840, 2030043136);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test210");
        int i1 = ClassExampleWithFailure.twice((-1509425152));
        org.junit.Assert.assertTrue(i1 == 1276116992);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test211");
        int i2 = ClassExampleWithFailure.foo((-2113929216), (-64));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test212");
        int i2 = ClassExampleWithFailure.foo((-1451098112), (-1322778624));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test213");
        int i2 = ClassExampleWithFailure.foo(1224736768, (-124160000));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test214");
        int i1 = ClassExampleWithFailure.twice(1828716544);
        org.junit.Assert.assertTrue(i1 == (-637534208));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test215");
        int i2 = ClassExampleWithFailure.foo(229376000, 32505856);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test216");
        int i2 = ClassExampleWithFailure.foo(218103808, 8192);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test217");
        int i2 = ClassExampleWithFailure.foo((-1064960000), 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test218");
        int i2 = ClassExampleWithFailure.foo(409600000, (-1111490560));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test219");
        int i2 = ClassExampleWithFailure.foo((-520093696), 322816);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test220");
        int i2 = ClassExampleWithFailure.foo(6208, (-1935671296));
        org.junit.Assert.assertTrue(i2 == 1342177280);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test221");
        int i2 = ClassExampleWithFailure.foo(1104674816, 280);
        org.junit.Assert.assertTrue(i2 == 142606336);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test222");
        int i2 = ClassExampleWithFailure.foo(80704, 372736000);
        org.junit.Assert.assertTrue(i2 == (-1329594368));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test223");
        int i2 = ClassExampleWithFailure.foo((-17382400), (-301989888));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test224");
        int i2 = ClassExampleWithFailure.foo((-1560281088), (-2097152000));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test225");
        int i2 = ClassExampleWithFailure.foo((-1054474240), 1626079232);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test226");
        int i2 = ClassExampleWithFailure.foo(1593835520, (-335544320));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test227");
        int i2 = ClassExampleWithFailure.foo((-1526726656), 1196425216);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test228");
        int i2 = ClassExampleWithFailure.foo(2662400, 19600);
        org.junit.Assert.assertTrue(i2 == 1286864896);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test229");
        int i2 = ClassExampleWithFailure.foo((-1123549184), 4);
        org.junit.Assert.assertTrue(i2 == (-398458880));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test230");
        int i2 = ClassExampleWithFailure.foo(16384, (-1728053248));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test231");
        int i2 = ClassExampleWithFailure.foo(562036736, (-917504000));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test232");
        int i2 = ClassExampleWithFailure.foo((-40), 545259520);
        org.junit.Assert.assertTrue(i2 == (-671088640));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test233");
        int i1 = ClassExampleWithFailure.twice(1929379840);
        org.junit.Assert.assertTrue(i1 == (-436207616));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test234");
        int i2 = ClassExampleWithFailure.foo((-896000), (-32000));
        org.junit.Assert.assertTrue(i2 == 1509425152);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test235");
        int i2 = ClassExampleWithFailure.foo(10, (-1392771072));
        org.junit.Assert.assertTrue(i2 == (-2085617664));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test236");
        int i2 = ClassExampleWithFailure.foo((-545259520), 20);
        org.junit.Assert.assertTrue(i2 == (-335544320));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test237");
        int i2 = ClassExampleWithFailure.foo((-6553600), 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test238");
        int i2 = ClassExampleWithFailure.foo((-40), (-143360));
        org.junit.Assert.assertTrue(i2 == 11468800);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test239");
        int i2 = ClassExampleWithFailure.foo(1740177408, 50331648);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test240");
        int i1 = ClassExampleWithFailure.twice(643694592);
        org.junit.Assert.assertTrue(i1 == 1287389184);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test241");
        int i1 = ClassExampleWithFailure.twice((-704643072));
        org.junit.Assert.assertTrue(i1 == (-1409286144));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test242");
        int i1 = ClassExampleWithFailure.twice(770785280);
        org.junit.Assert.assertTrue(i1 == 1541570560);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test243");
        int i2 = ClassExampleWithFailure.foo(146800640, 1708392448);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test244");
        int i2 = ClassExampleWithFailure.foo((-1709178880), 1287389184);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test245");
        int i2 = ClassExampleWithFailure.foo((-1935671296), 704643072);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test246");
        int i2 = ClassExampleWithFailure.foo((-685768704), 256);
        org.junit.Assert.assertTrue(i2 == 1073741824);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test247");
        int i2 = ClassExampleWithFailure.foo(65011712, 641728512);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test248");
        int i2 = ClassExampleWithFailure.foo(8000, (-256000));
        org.junit.Assert.assertTrue(i2 == 198967296);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test249");
        int i2 = ClassExampleWithFailure.foo(1708392448, 421789696);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test250");
        int i2 = ClassExampleWithFailure.foo((-1929379840), (-2560));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test251");
        int i2 = ClassExampleWithFailure.foo((-1462763520), 139059200);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test252");
        int i1 = ClassExampleWithFailure.twice(64563200);
        org.junit.Assert.assertTrue(i1 == 129126400);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test253");
        int i2 = ClassExampleWithFailure.foo(524288000, 810123264);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test254");
        int i1 = ClassExampleWithFailure.twice((-637534208));
        org.junit.Assert.assertTrue(i1 == (-1275068416));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test255");
        int i2 = ClassExampleWithFailure.foo(1713373184, 4480000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test256");
        int i2 = ClassExampleWithFailure.foo(993280000, 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test257");
        int i2 = ClassExampleWithFailure.foo((-16384), 10240000);
        org.junit.Assert.assertTrue(i2 == (-536870912));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test258");
        int i1 = ClassExampleWithFailure.twice(920649728);
        org.junit.Assert.assertTrue(i1 == 1841299456);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test259");
        int i1 = ClassExampleWithFailure.twice((-627200000));
        org.junit.Assert.assertTrue(i1 == (-1254400000));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test260");
        int i2 = ClassExampleWithFailure.foo(1434443776, 320000);
        org.junit.Assert.assertTrue(i2 == (-947912704));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test261");
        int i2 = ClassExampleWithFailure.foo(6208, (-31040));
        org.junit.Assert.assertTrue(i2 == (-385392640));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test262");
        int i2 = ClassExampleWithFailure.foo(16777216, 1083703296);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test263");
        int i2 = ClassExampleWithFailure.foo(218103808, 873463808);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test264");
        int i1 = ClassExampleWithFailure.twice(745472000);
        org.junit.Assert.assertTrue(i1 == 1490944000);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test265");
        int i2 = ClassExampleWithFailure.foo(3136000, 142606336);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test266");
        int i2 = ClassExampleWithFailure.foo((-478150656), (-1064960000));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test267");
        int i1 = ClassExampleWithFailure.twice(1581252608);
        org.junit.Assert.assertTrue(i1 == (-1132462080));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test268");
        int i2 = ClassExampleWithFailure.foo((-124160000), 4000);
        org.junit.Assert.assertTrue(i2 == (-1142554624));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test269");
        int i2 = ClassExampleWithFailure.foo(2000, 5734400);
        org.junit.Assert.assertTrue(i2 == 1462763520);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test270");
        int i2 = ClassExampleWithFailure.foo(771751936, (-469762048));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test271");
        int i2 = ClassExampleWithFailure.foo(880803840, 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test272");
        int i1 = ClassExampleWithFailure.twice(1280);
        org.junit.Assert.assertTrue(i1 == 2560);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test273");
        int i2 = ClassExampleWithFailure.foo(73400320, (-2047868928));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test274");
        int i2 = ClassExampleWithFailure.foo(11200, 1748107264);
        org.junit.Assert.assertTrue(i2 == 385875968);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test275");
        int i1 = ClassExampleWithFailure.twice((-1682763776));
        org.junit.Assert.assertTrue(i1 == 929439744);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test276");
        int i2 = ClassExampleWithFailure.foo(11468800, (-327680));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test277");
        int i2 = ClassExampleWithFailure.foo(5120000, 1358430208);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test278");
        int i2 = ClassExampleWithFailure.foo(268435456, (-545259520));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test279");
        int i2 = ClassExampleWithFailure.foo(6400000, (-1992294400));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test280");
        int i2 = ClassExampleWithFailure.foo(220200960, (-2113929216));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test281");
        int i2 = ClassExampleWithFailure.foo(1112473600, 10649600);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test282");
        int i2 = ClassExampleWithFailure.foo(388, (-2048));
        org.junit.Assert.assertTrue(i2 == (-1589248));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test283");
        int i2 = ClassExampleWithFailure.foo(32281600, (-818487296));
        org.junit.Assert.assertTrue(i2 == 1929379840);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test284");
        int i2 = ClassExampleWithFailure.foo(134217728, (-1042808832));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test285");
        int i2 = ClassExampleWithFailure.foo((-3200), (-1769996288));
        org.junit.Assert.assertTrue(i2 == (-2147483648));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test286");
        int i2 = ClassExampleWithFailure.foo(39200, (-1142554624));
        org.junit.Assert.assertTrue(i2 == (-444596224));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test287");
        int i2 = ClassExampleWithFailure.foo(1048576000, 1556086784);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test288");
        int i1 = ClassExampleWithFailure.twice((-1760165888));
        org.junit.Assert.assertTrue(i1 == 774635520);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test289");
        int i1 = ClassExampleWithFailure.twice(2560);
        org.junit.Assert.assertTrue(i1 == 5120);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test290");
        int i2 = ClassExampleWithFailure.foo(192696320, (-260046848));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test291");
        int i2 = ClassExampleWithFailure.foo(20971520, 1392508928);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test292");
        int i2 = ClassExampleWithFailure.foo(0, 294912000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test293");
        int i2 = ClassExampleWithFailure.foo((-1591738368), 1392771072);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test294");
        int i2 = ClassExampleWithFailure.foo((-896000), (-2113929216));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test295");
        int i2 = ClassExampleWithFailure.foo(771751936, 32281600);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test296");
        int i2 = ClassExampleWithFailure.foo(1371537408, 1792000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test297");
        int i2 = ClassExampleWithFailure.foo(3104000, (-165281792));
        org.junit.Assert.assertTrue(i2 == (-1677721600));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test298");
        int i2 = ClassExampleWithFailure.foo((-143360000), (-1610612736));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test299");
        int i2 = ClassExampleWithFailure.foo((-627200000), 3136000);
        org.junit.Assert.assertTrue(i2 == 801112064);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test300");
        int i2 = ClassExampleWithFailure.foo((-2329600), (-616562688));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test301");
        int i2 = ClassExampleWithFailure.foo(1358430208, 1040187392);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test302");
        int i2 = ClassExampleWithFailure.foo(80704, (int) '4');
        org.junit.Assert.assertTrue(i2 == 8393216);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test303");
        int i1 = ClassExampleWithFailure.twice((-553648128));
        org.junit.Assert.assertTrue(i1 == (-1107296256));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test304");
        int i2 = ClassExampleWithFailure.foo(981467136, (-2143027200));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test305");
        int i2 = ClassExampleWithFailure.foo((-585105408), 128);
        org.junit.Assert.assertTrue(i2 == 536870912);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test306");
        int i2 = ClassExampleWithFailure.foo(224000, 154157056);
        org.junit.Assert.assertTrue(i2 == (-713031680));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test307");
        int i2 = ClassExampleWithFailure.foo((int) (byte) 0, 1769996288);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test308");
        int i2 = ClassExampleWithFailure.foo(2013265920, 24832000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test309");
        int i2 = ClassExampleWithFailure.foo((-603979776), (-1832910848));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test310");
        int i2 = ClassExampleWithFailure.foo((-247463936), 1795162112);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test311");
        int i2 = ClassExampleWithFailure.foo(1660944384, 2048000000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test312");
        int i2 = ClassExampleWithFailure.foo((-671432704), 229376000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test313");
        int i2 = ClassExampleWithFailure.foo((-1841299456), 889192448);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test314");
        int i2 = ClassExampleWithFailure.foo((-2036334592), 155200);
        org.junit.Assert.assertTrue(i2 == (-805306368));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test315");
        int i2 = ClassExampleWithFailure.foo((-573440000), 79691776);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test316");
        int i2 = ClassExampleWithFailure.foo((-330563584), 7760);
        org.junit.Assert.assertTrue(i2 == 2139095040);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test317");
        int i2 = ClassExampleWithFailure.foo((-545259520), 1018167296);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test318");
        int i2 = ClassExampleWithFailure.foo((-131072000), 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test319");
        int i2 = ClassExampleWithFailure.foo(993280000, 6208000);
        org.junit.Assert.assertTrue(i2 == (-318767104));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test320");
        int i2 = ClassExampleWithFailure.foo(1600, 1713373184);
        org.junit.Assert.assertTrue(i2 == (-1879048192));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test321");
        int i2 = ClassExampleWithFailure.foo((-125440000), 655360000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test322");
        int i2 = ClassExampleWithFailure.foo(2621440, 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test323");
        int i2 = ClassExampleWithFailure.foo(332800, (-1224736768));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test324");
        int i2 = ClassExampleWithFailure.foo(139059200, (-1229455360));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test325");
        int i1 = ClassExampleWithFailure.twice((-722632704));
        org.junit.Assert.assertTrue(i1 == (-1445265408));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test326");
        int i2 = ClassExampleWithFailure.foo((-1006632960), 1090519040);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test327");
        int i1 = ClassExampleWithFailure.twice((-2097152000));
        org.junit.Assert.assertTrue(i1 == 100663296);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test328");
        int i2 = ClassExampleWithFailure.foo(939524096, 608384000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test329");
        int i2 = ClassExampleWithFailure.foo((-872415232), (-1371537408));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test330");
        int i2 = ClassExampleWithFailure.foo((-419430400), 25600000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test331");
        int i2 = ClassExampleWithFailure.foo((-209715200), 496640);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test332");
        int i1 = ClassExampleWithFailure.twice(1992294400);
        org.junit.Assert.assertTrue(i1 == (-310378496));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test333");
        int i2 = ClassExampleWithFailure.foo(140509184, (-1048576000));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test334");
        int i2 = ClassExampleWithFailure.foo((-795869184), (-770703360));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test335");
        int i2 = ClassExampleWithFailure.foo((-622854144), 1048576000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test336");
        int i1 = ClassExampleWithFailure.twice(1392508928);
        org.junit.Assert.assertTrue(i1 == (-1509949440));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test337");
        int i2 = ClassExampleWithFailure.foo(1042808832, 18350080);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test338");
        int i2 = ClassExampleWithFailure.foo((-1191182336), 1600000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test339");
        int i2 = ClassExampleWithFailure.foo((-814612480), 5734400);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test340");
        int i2 = ClassExampleWithFailure.foo(419430400, 1112473600);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test341");
        int i2 = ClassExampleWithFailure.foo(1687158784, 385875968);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test342");
        int i2 = ClassExampleWithFailure.foo(5120, 5734400);
        org.junit.Assert.assertTrue(i2 == (-1409286144));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test343");
        int i2 = ClassExampleWithFailure.foo(198656, 210894848);
        org.junit.Assert.assertTrue(i2 == 536870912);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test344");
        int i2 = ClassExampleWithFailure.foo(1714421760, 1979711488);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test345");
        int i2 = ClassExampleWithFailure.foo(1490944000, 9800);
        org.junit.Assert.assertTrue(i2 == (-455081984));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test346");
        int i2 = ClassExampleWithFailure.foo(0, 1358430208);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test347");
        int i1 = ClassExampleWithFailure.twice(310400);
        org.junit.Assert.assertTrue(i1 == 620800);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test348");
        int i2 = ClassExampleWithFailure.foo((-1275068416), (-1811939328));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test349");
        int i2 = ClassExampleWithFailure.foo((-574619648), (-878080000));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test350");
        int i2 = ClassExampleWithFailure.foo((-478150656), 512);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test351");
        int i1 = ClassExampleWithFailure.twice((-574619648));
        org.junit.Assert.assertTrue(i1 == (-1149239296));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test352");
        int i2 = ClassExampleWithFailure.foo(1577058304, (int) (short) 1);
        org.junit.Assert.assertTrue(i2 == (-1140850688));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test353");
        int i2 = ClassExampleWithFailure.foo((-369098752), (-685768704));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test354");
        int i1 = ClassExampleWithFailure.twice(49664000);
        org.junit.Assert.assertTrue(i1 == 99328000);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test355");
        int i2 = ClassExampleWithFailure.foo((-192937984), (-713031680));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test356");
        int i2 = ClassExampleWithFailure.foo(321847296, (-838860800));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test357");
        int i2 = ClassExampleWithFailure.foo((-160), 2127560704);
        org.junit.Assert.assertTrue(i2 == 2080374784);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test358");
        int i2 = ClassExampleWithFailure.foo(1073741824, (-603979776));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test359");
        int i2 = ClassExampleWithFailure.foo(310378496, 1216768000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test360");
        int i1 = ClassExampleWithFailure.twice(2139095040);
        org.junit.Assert.assertTrue(i1 == (-16777216));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test361");
        int i2 = ClassExampleWithFailure.foo((-310378496), (-301989888));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test362");
        int i2 = ClassExampleWithFailure.foo(2046820352, 1073741824);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test363");
        int i2 = ClassExampleWithFailure.foo((-2030043136), (-1760165888));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test364");
        int i2 = ClassExampleWithFailure.foo(859832320, 20971520);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test365");
        int i2 = ClassExampleWithFailure.foo(163840000, 262144000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test366");
        int i2 = ClassExampleWithFailure.foo(163840000, (-10485760));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test367");
        int i1 = ClassExampleWithFailure.twice(20971520);
        org.junit.Assert.assertTrue(i1 == 41943040);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test368");
        int i2 = ClassExampleWithFailure.foo(161408, 770703360);
        org.junit.Assert.assertTrue(i2 == 805306368);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test369");
        int i1 = ClassExampleWithFailure.twice((-2143027200));
        org.junit.Assert.assertTrue(i1 == 8912896);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test370");
        int i2 = ClassExampleWithFailure.foo((-1123549184), 1742733312);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test371");
        int i2 = ClassExampleWithFailure.foo((-3276800), 140);
        org.junit.Assert.assertTrue(i2 == (-917504000));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test372");
        int i2 = ClassExampleWithFailure.foo((-130023424), (-71680000));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test373");
        int i2 = ClassExampleWithFailure.foo(738197504, 1112473600);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test374");
        int i2 = ClassExampleWithFailure.foo((-545259520), (-192937984));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test375");
        int i1 = ClassExampleWithFailure.twice((-1409286144));
        org.junit.Assert.assertTrue(i1 == 1476395008);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test376");
        int i2 = ClassExampleWithFailure.foo(1593835520, 245891072);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test377");
        int i2 = ClassExampleWithFailure.foo(8, (-2071986176));
        org.junit.Assert.assertTrue(i2 == 1207959552);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test378");
        int i2 = ClassExampleWithFailure.foo(40960000, 1509949440);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test379");
        int i1 = ClassExampleWithFailure.twice(8393216);
        org.junit.Assert.assertTrue(i1 == 16786432);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test380");
        int i2 = ClassExampleWithFailure.foo(512, (-996147200));
        org.junit.Assert.assertTrue(i2 == (-2147483648));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test381");
        int i2 = ClassExampleWithFailure.foo(8960000, (-34764800));
        org.junit.Assert.assertTrue(i2 == (-209715200));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test382");
        int i2 = ClassExampleWithFailure.foo((-398458880), (-204800000));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test383");
        int i2 = ClassExampleWithFailure.foo(397934592, (-170393600));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test384");
        int i2 = ClassExampleWithFailure.foo((-1199570944), (-85196800));
        org.junit.Assert.assertTrue(i2 == 0);
    }
}

