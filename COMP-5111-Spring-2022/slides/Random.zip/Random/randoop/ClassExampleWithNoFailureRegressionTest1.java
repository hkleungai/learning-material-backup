import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class ClassExampleWithNoFailureRegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        int i2 = ClassExampleWithNoFailure.foo((-1773933103), (-1829002240));
        org.junit.Assert.assertTrue(i2 == 760357888);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        int i2 = ClassExampleWithNoFailure.foo(88529281, 1484264289);
        org.junit.Assert.assertTrue(i2 == 2111055457);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        int i2 = ClassExampleWithNoFailure.foo((-234364416), (-2090160319));
        org.junit.Assert.assertTrue(i2 == 1082392576);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        int i1 = ClassExampleWithNoFailure.twice(2111055457);
        org.junit.Assert.assertTrue(i1 == 1349054657);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        int i2 = ClassExampleWithNoFailure.foo(177209344, 177209344);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        int i2 = ClassExampleWithNoFailure.foo(0, 1630994432);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        int i2 = ClassExampleWithNoFailure.foo((-1928331264), 167772160);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        int i2 = ClassExampleWithNoFailure.foo(520000, (-771751936));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        int i2 = ClassExampleWithNoFailure.foo(150062500, (-1272840192));
        org.junit.Assert.assertTrue(i2 == 69206016);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        int i2 = ClassExampleWithNoFailure.foo(1430155920, 520000);
        org.junit.Assert.assertTrue(i2 == 2072199168);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        int i2 = ClassExampleWithNoFailure.foo((-1690089263), (-466980608));
        org.junit.Assert.assertTrue(i2 == 2018185472);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        int i2 = ClassExampleWithNoFailure.foo(656466081, 1212153856);
        org.junit.Assert.assertTrue(i2 == (-1740636160));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        int i2 = ClassExampleWithNoFailure.foo(1672151040, 1589638544);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        int i2 = ClassExampleWithNoFailure.foo(1895825408, 167772160);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        int i2 = ClassExampleWithNoFailure.foo((-771751936), (-16252928));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        int i1 = ClassExampleWithNoFailure.twice((-597622784));
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        int i1 = ClassExampleWithNoFailure.twice((-2090160319));
        org.junit.Assert.assertTrue(i1 == 533589633);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        int i2 = ClassExampleWithNoFailure.foo(150062500, (-193842912));
        org.junit.Assert.assertTrue(i2 == 970863104);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        int i1 = ClassExampleWithNoFailure.twice((-1601175552));
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        int i1 = ClassExampleWithNoFailure.twice((-944177152));
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        int i2 = ClassExampleWithNoFailure.foo((int) (short) 1, 2111055457);
        org.junit.Assert.assertTrue(i2 == 2111055457);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        int i2 = ClassExampleWithNoFailure.foo((-790364160), 38797312);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        int i2 = ClassExampleWithNoFailure.foo(0, (-1056964608));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        int i2 = ClassExampleWithNoFailure.foo((-1272840192), 1599192833);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        int i2 = ClassExampleWithNoFailure.foo(94090, (-679215104));
        org.junit.Assert.assertTrue(i2 == 126877696);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        int i2 = ClassExampleWithNoFailure.foo((-785317888), (-1));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        int i1 = ClassExampleWithNoFailure.twice(69206016);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        int i1 = ClassExampleWithNoFailure.twice((-318010624));
        org.junit.Assert.assertTrue(i1 == 1031340032);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        int i1 = ClassExampleWithNoFailure.twice(39911424);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        int i1 = ClassExampleWithNoFailure.twice(760357888);
        org.junit.Assert.assertTrue(i1 == 353370112);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        int i2 = ClassExampleWithNoFailure.foo(0, (-1269760000));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        int i1 = ClassExampleWithNoFailure.twice(2015410609);
        org.junit.Assert.assertTrue(i1 == (-487502751));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        int i1 = ClassExampleWithNoFailure.twice((-654311424));
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        int i1 = ClassExampleWithNoFailure.twice((-1161530727));
        org.junit.Assert.assertTrue(i1 == 26517361);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        int i2 = ClassExampleWithNoFailure.foo((-1593835520), 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        int i2 = ClassExampleWithNoFailure.foo((-510254796), (-192901823));
        org.junit.Assert.assertTrue(i2 == (-1846253936));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        int i1 = ClassExampleWithNoFailure.twice((-1906605312));
        org.junit.Assert.assertTrue(i1 == 1695088640);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        int i2 = ClassExampleWithNoFailure.foo((-1543503872), 520000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        int i2 = ClassExampleWithNoFailure.foo(2072199168, (-714715136));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        int i2 = ClassExampleWithNoFailure.foo((-1269760000), 102400);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        int i2 = ClassExampleWithNoFailure.foo(535423488, (-577914096));
        org.junit.Assert.assertTrue(i2 == 708837376);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        int i2 = ClassExampleWithNoFailure.foo((-402345728), (-939458560));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        int i2 = ClassExampleWithNoFailure.foo(973340672, 88529281);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        int i2 = ClassExampleWithNoFailure.foo(520000, 953810944);
        org.junit.Assert.assertTrue(i2 == (-1610612736));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        int i2 = ClassExampleWithNoFailure.foo(1048576, 3500);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        int i1 = ClassExampleWithNoFailure.twice((-1262013696));
        org.junit.Assert.assertTrue(i1 == 1411973120);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        int i2 = ClassExampleWithNoFailure.foo(38797312, 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        int i2 = ClassExampleWithNoFailure.foo(262993508, 262993508);
        org.junit.Assert.assertTrue(i2 == (-635739584));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        int i2 = ClassExampleWithNoFailure.foo((-1543503872), (-1610612736));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        int i2 = ClassExampleWithNoFailure.foo(1671043328, (-1148954864));
        org.junit.Assert.assertTrue(i2 == (-837812224));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        int i2 = ClassExampleWithNoFailure.foo(1638465536, 1881215232);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        int i2 = ClassExampleWithNoFailure.foo((-544210944), 27040000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        int i1 = ClassExampleWithNoFailure.twice(1409286144);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        int i1 = ClassExampleWithNoFailure.twice(2018185472);
        org.junit.Assert.assertTrue(i1 == (-148832256));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        int i2 = ClassExampleWithNoFailure.foo(39911424, (-1827602432));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        int i2 = ClassExampleWithNoFailure.foo(1000000, 16777216);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        int i1 = ClassExampleWithNoFailure.twice((-1416091135));
        org.junit.Assert.assertTrue(i1 == 1041519617);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        int i1 = ClassExampleWithNoFailure.twice(1342177280);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        int i1 = ClassExampleWithNoFailure.twice(656466081);
        org.junit.Assert.assertTrue(i1 == (-77978303));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        int i2 = ClassExampleWithNoFailure.foo(1074186825, 872415232);
        org.junit.Assert.assertTrue(i2 == 1946157056);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        int i1 = ClassExampleWithNoFailure.twice((-1996488704));
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        int i2 = ClassExampleWithNoFailure.foo((-1559101440), 1874919424);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        int i2 = ClassExampleWithNoFailure.foo((-660003840), 944791808);
        org.junit.Assert.assertTrue(i2 == 268435456);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        int i1 = ClassExampleWithNoFailure.twice(10);
        org.junit.Assert.assertTrue(i1 == 100);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        int i2 = ClassExampleWithNoFailure.foo(26517361, (-1610612736));
        org.junit.Assert.assertTrue(i2 == (-1610612736));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        int i1 = ClassExampleWithNoFailure.twice((-1740636160));
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        int i2 = ClassExampleWithNoFailure.foo(2040135680, 1312527521);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        int i2 = ClassExampleWithNoFailure.foo(1094254592, (int) (short) 1);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        int i1 = ClassExampleWithNoFailure.twice(239144052);
        org.junit.Assert.assertTrue(i1 == 58922128);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        int i2 = ClassExampleWithNoFailure.foo((-1325400064), (-771751936));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        int i2 = ClassExampleWithNoFailure.foo(0, (-595853312));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        int i1 = ClassExampleWithNoFailure.twice(1946157056);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        int i2 = ClassExampleWithNoFailure.foo(1312527521, (-1559101440));
        org.junit.Assert.assertTrue(i2 == 1368522752);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        int i2 = ClassExampleWithNoFailure.foo((-1214017143), (-548798464));
        org.junit.Assert.assertTrue(i2 == 879362048);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        int i2 = ClassExampleWithNoFailure.foo((-469762048), (-381616128));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        int i2 = ClassExampleWithNoFailure.foo(0, 1159790592);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        int i2 = ClassExampleWithNoFailure.foo(1874919424, 1430155920);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        int i2 = ClassExampleWithNoFailure.foo((int) (byte) 100, 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        int i2 = ClassExampleWithNoFailure.foo(760357888, 693061888);
        org.junit.Assert.assertTrue(i2 == (-1879048192));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        int i2 = ClassExampleWithNoFailure.foo(270400000, 708837376);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        int i2 = ClassExampleWithNoFailure.foo((-55975424), (-719535004));
        org.junit.Assert.assertTrue(i2 == 261095424);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        int i2 = ClassExampleWithNoFailure.foo(100, (-1740636160));
        org.junit.Assert.assertTrue(i2 == 1140850688);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        int i2 = ClassExampleWithNoFailure.foo(127991808, (int) 'a');
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        int i2 = ClassExampleWithNoFailure.foo((-654311424), 403410875);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        int i2 = ClassExampleWithNoFailure.foo(2069423617, 1140850688);
        org.junit.Assert.assertTrue(i2 == 1140850688);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        int i2 = ClassExampleWithNoFailure.foo((-1269760000), 52521875);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        int i2 = ClassExampleWithNoFailure.foo((-1559101440), (-466980608));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        int i2 = ClassExampleWithNoFailure.foo(1895825408, (int) (byte) -1);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        int i2 = ClassExampleWithNoFailure.foo((-727379968), 1589638544);
        org.junit.Assert.assertTrue(i2 == (-1879048192));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        int i2 = ClassExampleWithNoFailure.foo((-2057043968), (-1));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        int i1 = ClassExampleWithNoFailure.twice((-381616128));
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        int i2 = ClassExampleWithNoFailure.foo(507510784, 1002504192);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        int i2 = ClassExampleWithNoFailure.foo(5200, 879362048);
        org.junit.Assert.assertTrue(i2 == 1509949440);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        int i1 = ClassExampleWithNoFailure.twice(1159790592);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        int i2 = ClassExampleWithNoFailure.foo((-1740636160), 1572929536);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        int i1 = ClassExampleWithNoFailure.twice((-548798464));
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        int i2 = ClassExampleWithNoFailure.foo((int) 'a', 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        int i1 = ClassExampleWithNoFailure.twice((-635739584));
        org.junit.Assert.assertTrue(i1 == (-550170624));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        int i1 = ClassExampleWithNoFailure.twice((-1829002240));
        org.junit.Assert.assertTrue(i1 == 17825792);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        int i2 = ClassExampleWithNoFailure.foo((-1773933103), 7311616);
        org.junit.Assert.assertTrue(i2 == 823013632);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        int i1 = ClassExampleWithNoFailure.twice((-2054946816));
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        int i2 = ClassExampleWithNoFailure.foo((-1252527359), (-597622784));
        org.junit.Assert.assertTrue(i2 == 39911424);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        int i2 = ClassExampleWithNoFailure.foo(1411973120, 1881215232);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        int i1 = ClassExampleWithNoFailure.twice(823013632);
        org.junit.Assert.assertTrue(i1 == 1700855808);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        int i2 = ClassExampleWithNoFailure.foo(0, 39911424);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        int i1 = ClassExampleWithNoFailure.twice(262237011);
        org.junit.Assert.assertTrue(i1 == (-446399255));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        int i2 = ClassExampleWithNoFailure.foo(1073741824, 1159790592);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        int i2 = ClassExampleWithNoFailure.foo(195563520, 353370112);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        int i2 = ClassExampleWithNoFailure.foo(711477504, 1234478737);
        org.junit.Assert.assertTrue(i2 == (-1604255744));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        int i2 = ClassExampleWithNoFailure.foo((-2001666048), 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        int i2 = ClassExampleWithNoFailure.foo((-1102839808), 94090);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        int i2 = ClassExampleWithNoFailure.foo(1090519040, 69206016);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        int i1 = ClassExampleWithNoFailure.twice(813760512);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        int i2 = ClassExampleWithNoFailure.foo((int) (byte) 0, (-993984512));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        int i2 = ClassExampleWithNoFailure.foo((-381616128), 588251136);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        int i1 = ClassExampleWithNoFailure.twice(1411973120);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        int i2 = ClassExampleWithNoFailure.foo(1930428416, 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        int i1 = ClassExampleWithNoFailure.twice(1040449536);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        int i2 = ClassExampleWithNoFailure.foo((-469762048), 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        int i2 = ClassExampleWithNoFailure.foo(39911424, 270400000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        int i1 = ClassExampleWithNoFailure.twice(1589638544);
        org.junit.Assert.assertTrue(i1 == 409792768);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        int i2 = ClassExampleWithNoFailure.foo(100, (-993984512));
        org.junit.Assert.assertTrue(i2 == (-1290797056));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        int i2 = ClassExampleWithNoFailure.foo((-1009971200), (int) (byte) -1);
        org.junit.Assert.assertTrue(i2 == 1593835520);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        int i2 = ClassExampleWithNoFailure.foo(140608, 1744830464);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        int i2 = ClassExampleWithNoFailure.foo(1048576, (-1906605312));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        int i2 = ClassExampleWithNoFailure.foo(1652621312, (-1879048192));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        int i2 = ClassExampleWithNoFailure.foo(1048576, 122500);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        int i2 = ClassExampleWithNoFailure.foo(104857600, (-532611072));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        int i2 = ClassExampleWithNoFailure.foo((-487502751), (-55975424));
        org.junit.Assert.assertTrue(i2 == (-1274322432));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        int i1 = ClassExampleWithNoFailure.twice((-16252928));
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        int i2 = ClassExampleWithNoFailure.foo(100, 1051361296);
        org.junit.Assert.assertTrue(i2 == (-466980608));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        int i2 = ClassExampleWithNoFailure.foo((-1102839808), (-595853312));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        int i2 = ClassExampleWithNoFailure.foo(258970881, (-1690089263));
        org.junit.Assert.assertTrue(i2 == 2085458641);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        int i2 = ClassExampleWithNoFailure.foo((-144846576), (-1918156733));
        org.junit.Assert.assertTrue(i2 == 991535872);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        int i2 = ClassExampleWithNoFailure.foo((-1325400064), 1209809569);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        int i2 = ClassExampleWithNoFailure.foo((-837812224), (-577914096));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        int i2 = ClassExampleWithNoFailure.foo((-1593835520), 991535872);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        int i2 = ClassExampleWithNoFailure.foo(991535872, 2072199168);
        org.junit.Assert.assertTrue(i2 == 1073741824);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        int i2 = ClassExampleWithNoFailure.foo(1041519617, 1342177280);
        org.junit.Assert.assertTrue(i2 == 1342177280);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        int i1 = ClassExampleWithNoFailure.twice(1663107072);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        int i2 = ClassExampleWithNoFailure.foo((-234364416), (-1773933103));
        org.junit.Assert.assertTrue(i2 == 851705856);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        int i2 = ClassExampleWithNoFailure.foo((-1290797056), 1930428416);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        int i2 = ClassExampleWithNoFailure.foo(1124073472, 669749248);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        int i2 = ClassExampleWithNoFailure.foo(0, 239144052);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        int i2 = ClassExampleWithNoFailure.foo(302162176, (-2090160319));
        org.junit.Assert.assertTrue(i2 == (-1467940864));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        int i2 = ClassExampleWithNoFailure.foo((-1269760000), 1430155920);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        int i1 = ClassExampleWithNoFailure.twice((-771751936));
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        int i2 = ClassExampleWithNoFailure.foo((-1102839808), 1073741824);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        int i1 = ClassExampleWithNoFailure.twice((-225443840));
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        int i1 = ClassExampleWithNoFailure.twice((-55975424));
        org.junit.Assert.assertTrue(i1 == 730071040);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        int i2 = ClassExampleWithNoFailure.foo((-1543503872), 1172373504);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        int i2 = ClassExampleWithNoFailure.foo((-1920729088), (-654311424));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        int i1 = ClassExampleWithNoFailure.twice((-1861554271));
        org.junit.Assert.assertTrue(i1 == (-85851327));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        int i1 = ClassExampleWithNoFailure.twice((-837812224));
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        int i2 = ClassExampleWithNoFailure.foo((-1274322432), 760357888);
        org.junit.Assert.assertTrue(i2 == (-1879048192));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        int i2 = ClassExampleWithNoFailure.foo(1509949440, (-381616128));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        int i2 = ClassExampleWithNoFailure.foo((-1214017143), 1090519040);
        org.junit.Assert.assertTrue(i2 == (-1862270976));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        int i2 = ClassExampleWithNoFailure.foo((-2120548352), (-1056964608));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        int i2 = ClassExampleWithNoFailure.foo(140608, (-1918156733));
        org.junit.Assert.assertTrue(i2 == 2116464640);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        int i2 = ClassExampleWithNoFailure.foo(177209344, 1073741824);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        int i1 = ClassExampleWithNoFailure.twice((-1773933103));
        org.junit.Assert.assertTrue(i1 == 1146266785);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        int i2 = ClassExampleWithNoFailure.foo((-1495471856), 10);
        org.junit.Assert.assertTrue(i2 == (-1932703232));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        int i1 = ClassExampleWithNoFailure.twice(1031340032);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        int i2 = ClassExampleWithNoFailure.foo((-944177152), 476496528);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        int i2 = ClassExampleWithNoFailure.foo((-2090160319), 1276116992);
        org.junit.Assert.assertTrue(i2 == 873463808);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        int i2 = ClassExampleWithNoFailure.foo((-1262013696), 1074186825);
        org.junit.Assert.assertTrue(i2 == 1504772096);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        int i1 = ClassExampleWithNoFailure.twice(3312400);
        org.junit.Assert.assertTrue(i1 == (-1647681280));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        int i2 = ClassExampleWithNoFailure.foo(1095192832, (-1932703232));
        org.junit.Assert.assertTrue(i2 == (-1979711488));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        int i1 = ClassExampleWithNoFailure.twice(409792768);
        org.junit.Assert.assertTrue(i1 == 987824128);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        int i1 = ClassExampleWithNoFailure.twice(1140850688);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        int i2 = ClassExampleWithNoFailure.foo(592384000, 535423488);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        int i2 = ClassExampleWithNoFailure.foo((-1846253936), 376504320);
        org.junit.Assert.assertTrue(i2 == (-2130706432));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        int i2 = ClassExampleWithNoFailure.foo((-447362047), 302162176);
        org.junit.Assert.assertTrue(i2 == (-1130716928));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        int i2 = ClassExampleWithNoFailure.foo((int) (byte) 0, 2040135680);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        int i2 = ClassExampleWithNoFailure.foo(0, 195563520);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        int i2 = ClassExampleWithNoFailure.foo(1411973120, (-1148954864));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        int i1 = ClassExampleWithNoFailure.twice(533589633);
        org.junit.Assert.assertTrue(i1 == 382606593);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        int i2 = ClassExampleWithNoFailure.foo(1504772096, 104857600);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        int i2 = ClassExampleWithNoFailure.foo(0, 118825);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        int i2 = ClassExampleWithNoFailure.foo(127991808, (-544210944));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        int i2 = ClassExampleWithNoFailure.foo((-1704226816), (-993984512));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        int i2 = ClassExampleWithNoFailure.foo(2121348112, 268435456);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        int i1 = ClassExampleWithNoFailure.twice(1368522752);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        int i2 = ClassExampleWithNoFailure.foo((-1495471856), 403410875);
        org.junit.Assert.assertTrue(i2 == (-1415505152));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        int i2 = ClassExampleWithNoFailure.foo(1411973120, (-1495471856));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        int i2 = ClassExampleWithNoFailure.foo(1146266785, 1995483777);
        org.junit.Assert.assertTrue(i2 == 341211073);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        int i2 = ClassExampleWithNoFailure.foo((-747569152), 730071040);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        int i2 = ClassExampleWithNoFailure.foo(7311616, 1946157056);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        int i2 = ClassExampleWithNoFailure.foo((-713421407), (-182939648));
        org.junit.Assert.assertTrue(i2 == (-559116288));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        int i2 = ClassExampleWithNoFailure.foo(0, 271608009);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        int i2 = ClassExampleWithNoFailure.foo(1090519040, (-1240965599));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        int i2 = ClassExampleWithNoFailure.foo(1396899840, 100);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        int i1 = ClassExampleWithNoFailure.twice(1276116992);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        int i1 = ClassExampleWithNoFailure.twice(1430155920);
        org.junit.Assert.assertTrue(i1 == 1359253760);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        int i2 = ClassExampleWithNoFailure.foo(1409286144, (-532611072));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        int i2 = ClassExampleWithNoFailure.foo((-653262848), 1225);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        int i2 = ClassExampleWithNoFailure.foo((-510254796), (-713421407));
        org.junit.Assert.assertTrue(i2 == 817323152);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        int i1 = ClassExampleWithNoFailure.twice((-532611072));
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        int i2 = ClassExampleWithNoFailure.foo((int) '#', (int) '#');
        org.junit.Assert.assertTrue(i2 == 42875);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        int i2 = ClassExampleWithNoFailure.foo(2015410609, 126877696);
        org.junit.Assert.assertTrue(i2 == (-1651507200));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        int i1 = ClassExampleWithNoFailure.twice(991535872);
        org.junit.Assert.assertTrue(i1 == 1036582912);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        int i2 = ClassExampleWithNoFailure.foo(987824128, 953810944);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        int i2 = ClassExampleWithNoFailure.foo(1041519617, 9409);
        org.junit.Assert.assertTrue(i2 == 2044120257);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        int i1 = ClassExampleWithNoFailure.twice(1378902772);
        org.junit.Assert.assertTrue(i1 == (-1849706352));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        int i2 = ClassExampleWithNoFailure.foo((int) (byte) -1, (-381616128));
        org.junit.Assert.assertTrue(i2 == (-381616128));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        int i2 = ClassExampleWithNoFailure.foo((-1773933103), 987824128);
        org.junit.Assert.assertTrue(i2 == 729874432);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        int i2 = ClassExampleWithNoFailure.foo((-1009971200), 1500625);
        org.junit.Assert.assertTrue(i2 == 1895825408);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        int i2 = ClassExampleWithNoFailure.foo((-1290797056), (-487502751));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        int i1 = ClassExampleWithNoFailure.twice((-1425583260));
        org.junit.Assert.assertTrue(i1 == 1117912848);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        int i1 = ClassExampleWithNoFailure.twice(1349054657);
        org.junit.Assert.assertTrue(i1 == 523923841);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        int i2 = ClassExampleWithNoFailure.foo(1663107072, (-192901823));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        int i2 = ClassExampleWithNoFailure.foo((-1704226816), (-550170624));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        int i2 = ClassExampleWithNoFailure.foo(0, (-1148954864));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        int i2 = ClassExampleWithNoFailure.foo((-85851327), 729874432);
        org.junit.Assert.assertTrue(i2 == (-2113863680));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        int i2 = ClassExampleWithNoFailure.foo(1234478737, 1349054657);
        org.junit.Assert.assertTrue(i2 == (-1577720095));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        int i2 = ClassExampleWithNoFailure.foo(1638465536, 382606593);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        int i1 = ClassExampleWithNoFailure.twice((-1846253936));
        org.junit.Assert.assertTrue(i1 == (-879292160));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        int i2 = ClassExampleWithNoFailure.foo((int) (short) -1, 1946157056);
        org.junit.Assert.assertTrue(i2 == 1946157056);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        int i2 = ClassExampleWithNoFailure.foo(1209809569, (-1996488704));
        org.junit.Assert.assertTrue(i2 == (-922746880));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        int i1 = ClassExampleWithNoFailure.twice((-1290797056));
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        int i2 = ClassExampleWithNoFailure.foo(2044120257, (-1));
        org.junit.Assert.assertTrue(i2 == (-1752181121));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        int i2 = ClassExampleWithNoFailure.foo(1358954496, 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        int i2 = ClassExampleWithNoFailure.foo((int) '4', (-1495471856));
        org.junit.Assert.assertTrue(i2 == 2103294208);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        int i2 = ClassExampleWithNoFailure.foo((-2001666048), (-318418688));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        int i2 = ClassExampleWithNoFailure.foo(1881215232, 9409);
        org.junit.Assert.assertTrue(i2 == 1608581120);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        int i2 = ClassExampleWithNoFailure.foo(1368522752, 1608581120);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        int i2 = ClassExampleWithNoFailure.foo(1946157056, (int) (short) 10);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        int i1 = ClassExampleWithNoFailure.twice((-879292160));
        org.junit.Assert.assertTrue(i1 == 253820928);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        int i2 = ClassExampleWithNoFailure.foo((-1), 1430155920);
        org.junit.Assert.assertTrue(i2 == 1430155920);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        int i1 = ClassExampleWithNoFailure.twice(1036582912);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        int i2 = ClassExampleWithNoFailure.foo((-653262848), 2085458641);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        int i1 = ClassExampleWithNoFailure.twice((-550170624));
        org.junit.Assert.assertTrue(i1 == (-1593835520));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        int i2 = ClassExampleWithNoFailure.foo(195563520, 1368522752);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        int i1 = ClassExampleWithNoFailure.twice(1358954496);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        int i2 = ClassExampleWithNoFailure.foo((-939458560), 1426063360);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        int i1 = ClassExampleWithNoFailure.twice((-487502751));
        org.junit.Assert.assertTrue(i1 == 694926529);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        int i1 = ClassExampleWithNoFailure.twice(1214017143);
        org.junit.Assert.assertTrue(i1 == (-2060289199));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        int i2 = ClassExampleWithNoFailure.foo((int) (short) 10, (-1928331264));
        org.junit.Assert.assertTrue(i2 == 440401920);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        int i2 = ClassExampleWithNoFailure.foo(126877696, 361775360);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        int i2 = ClassExampleWithNoFailure.foo((-1861554271), 52521875);
        org.junit.Assert.assertTrue(i2 == (-1249572525));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        int i2 = ClassExampleWithNoFailure.foo((-719535004), (-1932703232));
        org.junit.Assert.assertTrue(i2 == 1448779776);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        int i1 = ClassExampleWithNoFailure.twice((-1467940864));
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        int i1 = ClassExampleWithNoFailure.twice(26517361);
        org.junit.Assert.assertTrue(i1 == (-1611296799));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        int i2 = ClassExampleWithNoFailure.foo((int) (short) 10, (-1849706352));
        org.junit.Assert.assertTrue(i2 == (-287041472));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        int i2 = ClassExampleWithNoFailure.foo((-225443840), 1691418624);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        int i2 = ClassExampleWithNoFailure.foo(2111055457, (-1252527359));
        org.junit.Assert.assertTrue(i2 == 864494529);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        int i2 = ClassExampleWithNoFailure.foo((int) (short) 1, 17825792);
        org.junit.Assert.assertTrue(i2 == 17825792);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        int i2 = ClassExampleWithNoFailure.foo((-1249572525), 1946157056);
        org.junit.Assert.assertTrue(i2 == (-1811939328));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        int i2 = ClassExampleWithNoFailure.foo((-771751936), 1396899840);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        int i2 = ClassExampleWithNoFailure.foo(0, (-713421407));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        int i2 = ClassExampleWithNoFailure.foo(1234478737, 302162176);
        org.junit.Assert.assertTrue(i2 == 1366606080);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        int i2 = ClassExampleWithNoFailure.foo(2069423617, (int) (byte) -1);
        org.junit.Assert.assertTrue(i2 == 447362047);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        int i2 = ClassExampleWithNoFailure.foo(0, (-182939648));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        int i2 = ClassExampleWithNoFailure.foo((-939458560), 1002504192);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        int i1 = ClassExampleWithNoFailure.twice(1396899840);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        int i1 = ClassExampleWithNoFailure.twice(584122368);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        int i2 = ClassExampleWithNoFailure.foo((-193842912), 1672151040);
        org.junit.Assert.assertTrue(i2 == 1811939328);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        int i2 = ClassExampleWithNoFailure.foo((-1862270976), 1040449536);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        int i2 = ClassExampleWithNoFailure.foo(729874432, 1638465536);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        int i2 = ClassExampleWithNoFailure.foo((-469762048), 261095424);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        int i2 = ClassExampleWithNoFailure.foo(58922128, 1024);
        org.junit.Assert.assertTrue(i2 == 457441280);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        int i2 = ClassExampleWithNoFailure.foo(1276116992, 1509949440);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        int i2 = ClassExampleWithNoFailure.foo(1593835520, 100);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        int i2 = ClassExampleWithNoFailure.foo(1359253760, 1074186825);
        org.junit.Assert.assertTrue(i2 == 1030291456);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        int i2 = ClassExampleWithNoFailure.foo((-466980608), 58922128);
        org.junit.Assert.assertTrue(i2 == (-493879296));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        int i1 = ClassExampleWithNoFailure.twice((-713421407));
        org.junit.Assert.assertTrue(i1 == (-399655103));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        int i2 = ClassExampleWithNoFailure.foo((-234364416), 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        int i1 = ClassExampleWithNoFailure.twice(1117912848);
        org.junit.Assert.assertTrue(i1 == 272687360);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        int i1 = ClassExampleWithNoFailure.twice(1094254592);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        int i2 = ClassExampleWithNoFailure.foo((-1647681280), (-1249572525));
        org.junit.Assert.assertTrue(i2 == 798162944);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        int i1 = ClassExampleWithNoFailure.twice((-399655103));
        org.junit.Assert.assertTrue(i1 == (-1682174335));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        int i2 = ClassExampleWithNoFailure.foo((-1773933103), 1638465536);
        org.junit.Assert.assertTrue(i2 == (-1354170368));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        int i2 = ClassExampleWithNoFailure.foo((-1979711488), 447362047);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        int i2 = ClassExampleWithNoFailure.foo(851705856, 1528444521);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        int i1 = ClassExampleWithNoFailure.twice((-1647681280));
        org.junit.Assert.assertTrue(i1 == 952172544);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        int i2 = ClassExampleWithNoFailure.foo((-1773933103), 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        int i2 = ClassExampleWithNoFailure.foo(302162176, 1744830464);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        int i1 = ClassExampleWithNoFailure.twice(1695088640);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        int i1 = ClassExampleWithNoFailure.twice(1234478737);
        org.junit.Assert.assertTrue(i1 == (-1240965599));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        int i2 = ClassExampleWithNoFailure.foo((-122093568), 507510784);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        int i2 = ClassExampleWithNoFailure.foo(1359253760, 1948516352);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        int i2 = ClassExampleWithNoFailure.foo((-2054946816), 101715968);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        int i1 = ClassExampleWithNoFailure.twice((-1434278527));
        org.junit.Assert.assertTrue(i1 == (-704410879));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        int i2 = ClassExampleWithNoFailure.foo((-837812224), (-907804672));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        int i1 = ClassExampleWithNoFailure.twice(1359253760);
        org.junit.Assert.assertTrue(i1 == (-635371520));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        int i2 = ClassExampleWithNoFailure.foo((int) (short) 1, 1349054657);
        org.junit.Assert.assertTrue(i2 == 1349054657);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        int i2 = ClassExampleWithNoFailure.foo((-1130716928), 1073741824);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        int i2 = ClassExampleWithNoFailure.foo((-1467940864), 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        int i2 = ClassExampleWithNoFailure.foo(9409, (-1611296799));
        org.junit.Assert.assertTrue(i2 == 2117679457);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        int i2 = ClassExampleWithNoFailure.foo(9437184, (-1240965599));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        int i2 = ClassExampleWithNoFailure.foo(637645056, (-1601175552));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        int i2 = ClassExampleWithNoFailure.foo(12250000, 1663107072);
        org.junit.Assert.assertTrue(i2 == (-788529152));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        int i2 = ClassExampleWithNoFailure.foo(12250, 1124073472);
        org.junit.Assert.assertTrue(i2 == (-335544320));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        int i2 = ClassExampleWithNoFailure.foo(2116464640, (-1148954864));
        org.junit.Assert.assertTrue(i2 == (-1879048192));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        int i2 = ClassExampleWithNoFailure.foo(10000, (-1979711488));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        int i2 = ClassExampleWithNoFailure.foo((-314376192), (-16252928));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        int i2 = ClassExampleWithNoFailure.foo(1812512641, 1048576);
        org.junit.Assert.assertTrue(i2 == (-267386880));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        int i2 = ClassExampleWithNoFailure.foo(694926529, 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        int i1 = ClassExampleWithNoFailure.twice(708837376);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        int i2 = ClassExampleWithNoFailure.foo(637645056, 669749248);
        org.junit.Assert.assertTrue(i2 == (-1879048192));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        int i2 = ClassExampleWithNoFailure.foo(1051361296, (-1434278527));
        org.junit.Assert.assertTrue(i2 == (-805994240));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        int i1 = ClassExampleWithNoFailure.twice(476496528);
        org.junit.Assert.assertTrue(i1 == 513708288);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        int i1 = ClassExampleWithNoFailure.twice(1572929536);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        int i2 = ClassExampleWithNoFailure.foo(1172373504, (-318418688));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        int i2 = ClassExampleWithNoFailure.foo((-466980608), 262237011);
        org.junit.Assert.assertTrue(i2 == (-1292697600));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        int i1 = ClassExampleWithNoFailure.twice((-719535004));
        org.junit.Assert.assertTrue(i1 == (-192329968));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        int i1 = ClassExampleWithNoFailure.twice(523923841);
        org.junit.Assert.assertTrue(i1 == (-557374719));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        int i2 = ClassExampleWithNoFailure.foo(730071040, 35);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        int i1 = ClassExampleWithNoFailure.twice((-2060289199));
        org.junit.Assert.assertTrue(i1 == (-1861554271));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        int i1 = ClassExampleWithNoFailure.twice(1146266785);
        org.junit.Assert.assertTrue(i1 == 1761783105);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        int i2 = ClassExampleWithNoFailure.foo((-1879048192), 268435456);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        int i2 = ClassExampleWithNoFailure.foo((-1891234076), (-446399255));
        org.junit.Assert.assertTrue(i2 == (-1361378928));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        int i2 = ClassExampleWithNoFailure.foo(1663107072, (-1416091135));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        int i2 = ClassExampleWithNoFailure.foo(1885020416, 122500);
        org.junit.Assert.assertTrue(i2 == 1736704000);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        int i2 = ClassExampleWithNoFailure.foo(1409286144, 270400000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        int i2 = ClassExampleWithNoFailure.foo(1359253760, (-1467940864));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        int i2 = ClassExampleWithNoFailure.foo((-2113863680), (int) (short) 10);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        int i2 = ClassExampleWithNoFailure.foo(1509949440, 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        int i2 = ClassExampleWithNoFailure.foo(694926529, (-548798464));
        org.junit.Assert.assertTrue(i2 == 508166144);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        int i2 = ClassExampleWithNoFailure.foo((-1920729088), (-939458560));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        int i2 = ClassExampleWithNoFailure.foo(1744830464, (-1249572525));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        int i1 = ClassExampleWithNoFailure.twice(953810944);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        int i2 = ClassExampleWithNoFailure.foo((-148832256), (-2001666048));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        int i2 = ClassExampleWithNoFailure.foo(1359253760, (-1632132864));
        org.junit.Assert.assertTrue(i2 == (-1056964608));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        int i1 = ClassExampleWithNoFailure.twice(1448779776);
        org.junit.Assert.assertTrue(i1 == (-469762048));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        int i2 = ClassExampleWithNoFailure.foo((-660003840), 1225);
        org.junit.Assert.assertTrue(i2 == 26214400);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        int i2 = ClassExampleWithNoFailure.foo((-597194047), (-1846253936));
        org.junit.Assert.assertTrue(i2 == (-949846384));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        int i2 = ClassExampleWithNoFailure.foo(817323152, 10);
        org.junit.Assert.assertTrue(i2 == (-1452398080));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        int i2 = ClassExampleWithNoFailure.foo(1599192833, (-267386880));
        org.junit.Assert.assertTrue(i2 == (-804257792));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        int i2 = ClassExampleWithNoFailure.foo((-1262013696), 10000);
        org.junit.Assert.assertTrue(i2 == (-2121269248));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        int i1 = ClassExampleWithNoFailure.twice((-1979711488));
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        int i1 = ClassExampleWithNoFailure.twice(1504772096);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        int i1 = ClassExampleWithNoFailure.twice((-1325400064));
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        int i1 = ClassExampleWithNoFailure.twice(270400000);
        org.junit.Assert.assertTrue(i1 == (-1742471168));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        int i2 = ClassExampleWithNoFailure.foo(1146266785, 1342177280);
        org.junit.Assert.assertTrue(i2 == 1342177280);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        int i2 = ClassExampleWithNoFailure.foo(12250, 195563520);
        org.junit.Assert.assertTrue(i2 == (-604356608));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        int i1 = ClassExampleWithNoFailure.twice((-192329968));
        org.junit.Assert.assertTrue(i1 == (-1562779392));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        int i2 = ClassExampleWithNoFailure.foo((int) (byte) 10, 1930428416);
        org.junit.Assert.assertTrue(i2 == (-230686720));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        int i2 = ClassExampleWithNoFailure.foo((-1290797056), 329315);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        int i2 = ClassExampleWithNoFailure.foo(272687360, 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        int i1 = ClassExampleWithNoFailure.twice(382606593);
        org.junit.Assert.assertTrue(i1 == (-588957183));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        int i1 = ClassExampleWithNoFailure.twice(457441280);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        int i1 = ClassExampleWithNoFailure.twice(508166144);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        int i1 = ClassExampleWithNoFailure.twice((-447362047));
        org.junit.Assert.assertTrue(i1 == (-449079295));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        int i2 = ClassExampleWithNoFailure.foo((-1773933103), (-2057043968));
        org.junit.Assert.assertTrue(i2 == (-203161600));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        int i1 = ClassExampleWithNoFailure.twice((-122093568));
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        int i2 = ClassExampleWithNoFailure.foo(872415232, 1094254592);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        int i2 = ClassExampleWithNoFailure.foo(440401920, (int) (byte) 1);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        int i2 = ClassExampleWithNoFailure.foo((-1262013696), (-635371520));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        int i1 = ClassExampleWithNoFailure.twice((-193842912));
        org.junit.Assert.assertTrue(i1 == (-907197440));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        int i2 = ClassExampleWithNoFailure.foo(27040000, (-318418688));
        org.junit.Assert.assertTrue(i2 == (-1056964608));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        int i2 = ClassExampleWithNoFailure.foo(0, (-2057043968));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        int i1 = ClassExampleWithNoFailure.twice(513708288);
        org.junit.Assert.assertTrue(i1 == 1310785536);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        int i1 = ClassExampleWithNoFailure.twice((-318418688));
        org.junit.Assert.assertTrue(i1 == 1134624768);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        int i2 = ClassExampleWithNoFailure.foo(1124073472, (-1979711488));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        int i2 = ClassExampleWithNoFailure.foo((-1740636160), 10);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        int i2 = ClassExampleWithNoFailure.foo(1599192833, 1885020416);
        org.junit.Assert.assertTrue(i2 == (-291954432));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        int i2 = ClassExampleWithNoFailure.foo((-1610612736), 1073741824);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        int i1 = ClassExampleWithNoFailure.twice(1696858112);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        int i2 = ClassExampleWithNoFailure.foo((-1056964608), (-771751936));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        int i2 = ClassExampleWithNoFailure.foo(0, (-1161530727));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        int i1 = ClassExampleWithNoFailure.twice((-1543503872));
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        int i2 = ClassExampleWithNoFailure.foo(67108864, (-1056964608));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        int i2 = ClassExampleWithNoFailure.foo((-182939648), 1946157056);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        int i2 = ClassExampleWithNoFailure.foo((-182939648), 27040000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        int i1 = ClassExampleWithNoFailure.twice(261095424);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        int i2 = ClassExampleWithNoFailure.foo(879362048, (-635739584));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        int i2 = ClassExampleWithNoFailure.foo(1159790592, 1500625);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        int i2 = ClassExampleWithNoFailure.foo(353370112, 1638465536);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        int i2 = ClassExampleWithNoFailure.foo(261095424, 403410875);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        int i2 = ClassExampleWithNoFailure.foo(10, (-604356608));
        org.junit.Assert.assertTrue(i2 == (-306118656));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        int i1 = ClassExampleWithNoFailure.twice((-557374719));
        org.junit.Assert.assertTrue(i1 == 743917057);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        int i2 = ClassExampleWithNoFailure.foo((-1092323567), 177209344);
        org.junit.Assert.assertTrue(i2 == (-862978048));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        int i2 = ClassExampleWithNoFailure.foo(637645056, 262993508);
        org.junit.Assert.assertTrue(i2 == 1273233408);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        int i2 = ClassExampleWithNoFailure.foo((-1862270976), 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        int i2 = ClassExampleWithNoFailure.foo(0, (-1092323567));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        int i2 = ClassExampleWithNoFailure.foo((-588957183), 52521875);
        org.junit.Assert.assertTrue(i2 == 1753876371);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        int i2 = ClassExampleWithNoFailure.foo((-1647681280), 9409);
        org.junit.Assert.assertTrue(i2 == (-310312960));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        int i2 = ClassExampleWithNoFailure.foo((-597194047), 533589633);
        org.junit.Assert.assertTrue(i2 == (-1996467199));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        int i1 = ClassExampleWithNoFailure.twice(1948516352);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        int i2 = ClassExampleWithNoFailure.foo((-719535004), 270400000);
        org.junit.Assert.assertTrue(i2 == 473276416);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        int i2 = ClassExampleWithNoFailure.foo(1695088640, 35);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        int i1 = ClassExampleWithNoFailure.twice(1002504192);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        int i2 = ClassExampleWithNoFailure.foo(1031340032, 1359253760);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        int i2 = ClassExampleWithNoFailure.foo((int) '4', 1234478737);
        org.junit.Assert.assertTrue(i2 == 840915856);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        int i1 = ClassExampleWithNoFailure.twice(1030291456);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        int i2 = ClassExampleWithNoFailure.foo((-1740636160), (-862978048));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        int i1 = ClassExampleWithNoFailure.twice(17825792);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        int i1 = ClassExampleWithNoFailure.twice(817323152);
        org.junit.Assert.assertTrue(i1 == 2002243840);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        int i2 = ClassExampleWithNoFailure.foo((-1690089263), 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        int i2 = ClassExampleWithNoFailure.foo(26517361, 26517361);
        org.junit.Assert.assertTrue(i2 == 785727825);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        int i2 = ClassExampleWithNoFailure.foo(1310785536, 239144052);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        int i1 = ClassExampleWithNoFailure.twice((-1452398080));
        org.junit.Assert.assertTrue(i1 == 518258688);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        int i2 = ClassExampleWithNoFailure.foo(268435456, (-1272840192));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        int i2 = ClassExampleWithNoFailure.foo((-747569152), (-1467940864));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        int i2 = ClassExampleWithNoFailure.foo((-1272840192), 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        int i1 = ClassExampleWithNoFailure.twice(694926529);
        org.junit.Assert.assertTrue(i1 == 646056321);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        int i2 = ClassExampleWithNoFailure.foo((-55975424), 10000);
        org.junit.Assert.assertTrue(i2 == (-734003200));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        int i1 = ClassExampleWithNoFailure.twice(2072199168);
        org.junit.Assert.assertTrue(i1 == (-1879048192));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        int i2 = ClassExampleWithNoFailure.foo(987824128, (-653262848));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        int i2 = ClassExampleWithNoFailure.foo((-862978048), 669749248);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        int i2 = ClassExampleWithNoFailure.foo((-805994240), (-1593835520));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        int i2 = ClassExampleWithNoFailure.foo(1593835520, (-1861554271));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        int i1 = ClassExampleWithNoFailure.twice(1761783105);
        org.junit.Assert.assertTrue(i1 == 2084891265);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        int i2 = ClassExampleWithNoFailure.foo(262237011, 69206016);
        org.junit.Assert.assertTrue(i2 == 1092616192);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        int i2 = ClassExampleWithNoFailure.foo((-790364160), 1761783105);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        int i2 = ClassExampleWithNoFailure.foo(970000, 1630994432);
        org.junit.Assert.assertTrue(i2 == (-1761607680));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        int i2 = ClassExampleWithNoFailure.foo(1342177280, 693061888);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        int i2 = ClassExampleWithNoFailure.foo(1930428416, 1736704000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        int i1 = ClassExampleWithNoFailure.twice((-446399255));
        org.junit.Assert.assertTrue(i1 == (-1392866287));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        int i2 = ClassExampleWithNoFailure.foo(262993508, (-1354170368));
        org.junit.Assert.assertTrue(i2 == (-1013972992));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        int i2 = ClassExampleWithNoFailure.foo((-790364160), 2015410609);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        int i2 = ClassExampleWithNoFailure.foo(0, (-944177152));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        int i1 = ClassExampleWithNoFailure.twice((-1013972992));
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        int i2 = ClassExampleWithNoFailure.foo((-734003200), (-1102839808));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        int i2 = ClassExampleWithNoFailure.foo(1188250000, (-1996467199));
        org.junit.Assert.assertTrue(i2 == (-784436992));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        int i2 = ClassExampleWithNoFailure.foo((-310312960), (int) (byte) -1);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        int i2 = ClassExampleWithNoFailure.foo((-225443840), 592384000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        int i2 = ClassExampleWithNoFailure.foo((-1918156733), (-1056964608));
        org.junit.Assert.assertTrue(i2 == 1224736768);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        int i2 = ClassExampleWithNoFailure.foo((-713421407), (int) (byte) -1);
        org.junit.Assert.assertTrue(i2 == 399655103);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        int i2 = ClassExampleWithNoFailure.foo(533589633, 760357888);
        org.junit.Assert.assertTrue(i2 == 1936073728);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        int i2 = ClassExampleWithNoFailure.foo((-1434278527), (-532611072));
        org.junit.Assert.assertTrue(i2 == 725680128);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        int i2 = ClassExampleWithNoFailure.foo((-1918156733), 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        int i1 = ClassExampleWithNoFailure.twice((-77978303));
        org.junit.Assert.assertTrue(i1 == (-1390421375));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        int i1 = ClassExampleWithNoFailure.twice(725680128);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        int i2 = ClassExampleWithNoFailure.foo(58922128, 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        int i1 = ClassExampleWithNoFailure.twice(1366606080);
        org.junit.Assert.assertTrue(i1 == 2038497280);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test428");
        int i2 = ClassExampleWithNoFailure.foo((-2057043968), 1234478737);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        int i1 = ClassExampleWithNoFailure.twice((-1240965599));
        org.junit.Assert.assertTrue(i1 == (-257146815));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        int i1 = ClassExampleWithNoFailure.twice(2002243840);
        org.junit.Assert.assertTrue(i1 == (-1197408256));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        int i2 = ClassExampleWithNoFailure.foo(1212153856, 1930428416);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        int i2 = ClassExampleWithNoFailure.foo((-257146815), (-77978303));
        org.junit.Assert.assertTrue(i2 == (-623290943));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        int i2 = ClassExampleWithNoFailure.foo((-493879296), 743917057);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        int i2 = ClassExampleWithNoFailure.foo((-1996467199), 473276416);
        org.junit.Assert.assertTrue(i2 == 1295360000);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test435");
        int i2 = ClassExampleWithNoFailure.foo(409792768, 817323152);
        org.junit.Assert.assertTrue(i2 == (-91226112));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test436");
        int i2 = ClassExampleWithNoFailure.foo(341211073, 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test437");
        int i2 = ClassExampleWithNoFailure.foo((-1996467199), (-2060289199));
        org.junit.Assert.assertTrue(i2 == 1085252433);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test438");
        int i2 = ClassExampleWithNoFailure.foo((-318418688), 813760512);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        int i2 = ClassExampleWithNoFailure.foo(0, 1930428416);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        int i2 = ClassExampleWithNoFailure.foo((-2121269248), (-788529152));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        int i1 = ClassExampleWithNoFailure.twice((-1611296799));
        org.junit.Assert.assertTrue(i1 == 864494529);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test442");
        int i1 = ClassExampleWithNoFailure.twice(1700855808);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test443");
        int i2 = ClassExampleWithNoFailure.foo((-1392443392), 987824128);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test444");
        int i2 = ClassExampleWithNoFailure.foo((-2121269248), 382606593);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test445");
        int i1 = ClassExampleWithNoFailure.twice((-1932703232));
        org.junit.Assert.assertTrue(i1 == (-1721499648));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test446");
        int i2 = ClassExampleWithNoFailure.foo((-381616128), (-2090160319));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test447");
        int i2 = ClassExampleWithNoFailure.foo(1812512641, 122500);
        org.junit.Assert.assertTrue(i2 == (-926262652));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test448");
        int i2 = ClassExampleWithNoFailure.foo((-713421407), (-559116288));
        org.junit.Assert.assertTrue(i2 == (-1723822080));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test449");
        int i2 = ClassExampleWithNoFailure.foo(2085458641, (-1920729088));
        org.junit.Assert.assertTrue(i2 == 939786240);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test450");
        int i2 = ClassExampleWithNoFailure.foo(122500, (-487502751));
        org.junit.Assert.assertTrue(i2 == (-1486259696));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test451");
        int i2 = ClassExampleWithNoFailure.foo(102400, (-1392866287));
        org.junit.Assert.assertTrue(i2 == (-2130706432));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test452");
        int i2 = ClassExampleWithNoFailure.foo((-1651507200), 970863104);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test453");
        int i2 = ClassExampleWithNoFailure.foo(1599192833, 2040135680);
        org.junit.Assert.assertTrue(i2 == 1167720448);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test454");
        int i1 = ClassExampleWithNoFailure.twice((-1721499648));
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test455");
        int i2 = ClassExampleWithNoFailure.foo(94090, 1744830464);
        org.junit.Assert.assertTrue(i2 == (-1610612736));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test456");
        int i2 = ClassExampleWithNoFailure.foo((-1392443392), (-441168832));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test457");
        int i1 = ClassExampleWithNoFailure.twice(1295360000);
        org.junit.Assert.assertTrue(i1 == (-1543503872));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test458");
        int i1 = ClassExampleWithNoFailure.twice(1753876371);
        org.junit.Assert.assertTrue(i1 == (-1699389847));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test459");
        int i2 = ClassExampleWithNoFailure.foo(2704, 1312527521);
        org.junit.Assert.assertTrue(i2 == 821965056);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test460");
        int i2 = ClassExampleWithNoFailure.foo((-1699389847), 1234478737);
        org.junit.Assert.assertTrue(i2 == (-796113247));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test461");
        int i1 = ClassExampleWithNoFailure.twice((-1092323567));
        org.junit.Assert.assertTrue(i1 == (-1985425631));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test462");
        int i1 = ClassExampleWithNoFailure.twice(1209809569);
        org.junit.Assert.assertTrue(i1 == 1889884481);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test463");
        int i2 = ClassExampleWithNoFailure.foo((-1996488704), 409792768);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test464");
        int i2 = ClassExampleWithNoFailure.foo(1031340032, (-949846384));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test465");
        int i2 = ClassExampleWithNoFailure.foo(1212153856, (-1690089263));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test466");
        int i2 = ClassExampleWithNoFailure.foo(1696858112, 69206016);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test467");
        int i2 = ClassExampleWithNoFailure.foo(479748608, 1448779776);
        org.junit.Assert.assertTrue(i2 == (-2147483648));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test468");
        int i1 = ClassExampleWithNoFailure.twice((-287041472));
        org.junit.Assert.assertTrue(i1 == 877400064);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test469");
        int i1 = ClassExampleWithNoFailure.twice(851705856);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test470");
        int i2 = ClassExampleWithNoFailure.foo((-1651507200), (-193842912));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test471");
        int i1 = ClassExampleWithNoFailure.twice(1082392576);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test472");
        int i2 = ClassExampleWithNoFailure.foo((-1056964608), 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test473");
        int i2 = ClassExampleWithNoFailure.foo((-653262848), 1276116992);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test474");
        int i2 = ClassExampleWithNoFailure.foo((-993984512), (-510254796));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test475");
        int i2 = ClassExampleWithNoFailure.foo((-1651507200), (-713421407));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test476");
        int i2 = ClassExampleWithNoFailure.foo(1744830464, (-747569152));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test477");
        int i1 = ClassExampleWithNoFailure.twice(864494529);
        org.junit.Assert.assertTrue(i1 == (-1601415295));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test478");
        int i1 = ClassExampleWithNoFailure.twice((-91226112));
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test479");
        int i2 = ClassExampleWithNoFailure.foo(42875, 970000);
        org.junit.Assert.assertTrue(i2 == 1853773456);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test480");
        int i2 = ClassExampleWithNoFailure.foo((-182939648), 584122368);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test481");
        int i2 = ClassExampleWithNoFailure.foo(2117679457, 1396899840);
        org.junit.Assert.assertTrue(i2 == 1199767552);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test482");
        int i2 = ClassExampleWithNoFailure.foo((-595853312), 729874432);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test483");
        int i2 = ClassExampleWithNoFailure.foo(195563520, 952172544);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test484");
        int i2 = ClassExampleWithNoFailure.foo(167772160, 239144052);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test485");
        int i2 = ClassExampleWithNoFailure.foo(2111055457, 1031340032);
        org.junit.Assert.assertTrue(i2 == (-935788544));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test486");
        int i2 = ClassExampleWithNoFailure.foo(0, (-796113247));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test487");
        int i2 = ClassExampleWithNoFailure.foo(1881215232, 1095192832);
        org.junit.Assert.assertTrue(i2 == 1895825408);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test488");
        int i1 = ClassExampleWithNoFailure.twice((-148832256));
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test489");
        int i1 = ClassExampleWithNoFailure.twice((-335544320));
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test490");
        int i1 = ClassExampleWithNoFailure.twice(7311616);
        org.junit.Assert.assertTrue(i1 == 270598144);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test491");
        int i2 = ClassExampleWithNoFailure.foo((-993984512), (-1682174335));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test492");
        int i2 = ClassExampleWithNoFailure.foo(1736704000, (-1811939328));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test493");
        int i2 = ClassExampleWithNoFailure.foo(1041519617, (-1102839808));
        org.junit.Assert.assertTrue(i2 == 1581514752);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test494");
        int i2 = ClassExampleWithNoFailure.foo((-623290943), (-1543503872));
        org.junit.Assert.assertTrue(i2 == (-1543503872));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test495");
        int i1 = ClassExampleWithNoFailure.twice(1509949440);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test496");
        int i1 = ClassExampleWithNoFailure.twice(2103294208);
        org.junit.Assert.assertTrue(i1 == (-273612800));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test497");
        int i1 = ClassExampleWithNoFailure.twice(1853773456);
        org.junit.Assert.assertTrue(i1 == 319099136);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test498");
        int i2 = ClassExampleWithNoFailure.foo((-1392443392), 2117679457);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test499");
        int i2 = ClassExampleWithNoFailure.foo((-314376192), 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test500");
        int i2 = ClassExampleWithNoFailure.foo((-1416091135), (-1811939328));
        org.junit.Assert.assertTrue(i2 == (-1811939328));
    }
}

