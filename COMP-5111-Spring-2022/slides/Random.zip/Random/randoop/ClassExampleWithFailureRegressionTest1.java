import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class ClassExampleWithFailureRegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        int i1 = ClassExampleWithFailure.twice(4000);
        org.junit.Assert.assertTrue(i1 == 8000);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        int i2 = ClassExampleWithFailure.foo(1552000, 536870912);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        int i1 = ClassExampleWithFailure.twice((-1795162112));
        org.junit.Assert.assertTrue(i1 == 704643072);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        int i1 = ClassExampleWithFailure.twice((-1902116864));
        org.junit.Assert.assertTrue(i1 == 490733568);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        int i2 = ClassExampleWithFailure.foo(20, 1207959552);
        org.junit.Assert.assertTrue(i2 == 1073741824);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        int i1 = ClassExampleWithFailure.twice(1342177280);
        org.junit.Assert.assertTrue(i1 == (-1610612736));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        int i2 = ClassExampleWithFailure.foo(123731968, 1249902592);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        int i2 = ClassExampleWithFailure.foo(251658240, (-22400));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        int i1 = ClassExampleWithFailure.twice(905969664);
        org.junit.Assert.assertTrue(i1 == 1811939328);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        int i1 = ClassExampleWithFailure.twice(201326592);
        org.junit.Assert.assertTrue(i1 == 402653184);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        int i2 = ClassExampleWithFailure.foo((-520093696), (-1170210816));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        int i2 = ClassExampleWithFailure.foo((-260046848), (-1363607552));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        int i1 = ClassExampleWithFailure.twice((-57344000));
        org.junit.Assert.assertTrue(i1 == (-114688000));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        int i2 = ClassExampleWithFailure.foo(704643072, 1120);
        org.junit.Assert.assertTrue(i2 == (-2147483648));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        int i1 = ClassExampleWithFailure.twice((-1310720));
        org.junit.Assert.assertTrue(i1 == (-2621440));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        int i2 = ClassExampleWithFailure.foo((int) (short) 10, (int) (short) -1);
        org.junit.Assert.assertTrue(i2 == (-20));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        int i2 = ClassExampleWithFailure.foo(0, 1073741824);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        int i2 = ClassExampleWithFailure.foo(1578106880, 24832);
        org.junit.Assert.assertTrue(i2 == 536870912);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        int i2 = ClassExampleWithFailure.foo((-654311424), 140);
        org.junit.Assert.assertTrue(i2 == 1476395008);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        int i2 = ClassExampleWithFailure.foo(4480000, 1262485504);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        int i2 = ClassExampleWithFailure.foo((-1486094336), 8000);
        org.junit.Assert.assertTrue(i2 == (-570425344));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        int i2 = ClassExampleWithFailure.foo(0, (-1111490560));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        int i1 = ClassExampleWithFailure.twice(124160000);
        org.junit.Assert.assertTrue(i1 == 248320000);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        int i1 = ClassExampleWithFailure.twice(2013265920);
        org.junit.Assert.assertTrue(i1 == (-268435456));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        int i2 = ClassExampleWithFailure.foo((-150994944), 20);
        org.junit.Assert.assertTrue(i2 == (-1744830464));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        int i2 = ClassExampleWithFailure.foo(1976041472, (-2129920000));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        int i2 = ClassExampleWithFailure.foo((-397934592), 400);
        org.junit.Assert.assertTrue(i2 == (-520093696));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        int i2 = ClassExampleWithFailure.foo(1744830464, 327680);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        int i2 = ClassExampleWithFailure.foo((-520093696), 872415232);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        int i1 = ClassExampleWithFailure.twice(256);
        org.junit.Assert.assertTrue(i1 == 512);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        int i2 = ClassExampleWithFailure.foo(624951296, (-200));
        org.junit.Assert.assertTrue(i2 == (-872415232));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        int i2 = ClassExampleWithFailure.foo(0, 2000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        int i2 = ClassExampleWithFailure.foo(1421934592, (-1040187392));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        int i1 = ClassExampleWithFailure.twice((-1912602624));
        org.junit.Assert.assertTrue(i1 == 469762048);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        int i2 = ClassExampleWithFailure.foo((int) (short) 100, (-1363607552));
        org.junit.Assert.assertTrue(i2 == (-2138570752));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        int i2 = ClassExampleWithFailure.foo((-1111490560), (-587202560));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        int i2 = ClassExampleWithFailure.foo(128, (-2048000000));
        org.junit.Assert.assertTrue(i2 == (-301989888));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        int i2 = ClassExampleWithFailure.foo((-1111490560), (-671088640));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        int i2 = ClassExampleWithFailure.foo((-738197504), 1439432704);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        int i2 = ClassExampleWithFailure.foo(1006632960, 251658240);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        int i2 = ClassExampleWithFailure.foo((-12800000), 2);
        org.junit.Assert.assertTrue(i2 == (-51200000));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        int i2 = ClassExampleWithFailure.foo((-512), (-1132462080));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        int i1 = ClassExampleWithFailure.twice(1188298752);
        org.junit.Assert.assertTrue(i1 == (-1918369792));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        int i1 = ClassExampleWithFailure.twice((-247463936));
        org.junit.Assert.assertTrue(i1 == (-494927872));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        int i2 = ClassExampleWithFailure.foo((-1462763520), (-44800));
        org.junit.Assert.assertTrue(i2 == (-1610612736));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        int i1 = ClassExampleWithFailure.twice(9175040);
        org.junit.Assert.assertTrue(i1 == 18350080);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        int i2 = ClassExampleWithFailure.foo(2017460224, (-795869184));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        int i2 = ClassExampleWithFailure.foo(160, (-2042036224));
        org.junit.Assert.assertTrue(i2 == (-616562688));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        int i2 = ClassExampleWithFailure.foo(0, 40);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        int i2 = ClassExampleWithFailure.foo((-71680000), 160);
        org.junit.Assert.assertTrue(i2 == (-1462763520));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        int i2 = ClassExampleWithFailure.foo(2071986176, 5734400);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        int i2 = ClassExampleWithFailure.foo((-587202560), (-1811939328));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        int i1 = ClassExampleWithFailure.twice(704643072);
        org.junit.Assert.assertTrue(i1 == 1409286144);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        int i1 = ClassExampleWithFailure.twice((int) (byte) 1);
        org.junit.Assert.assertTrue(i1 == 2);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        int i1 = ClassExampleWithFailure.twice((-17920));
        org.junit.Assert.assertTrue(i1 == (-35840));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        int i2 = ClassExampleWithFailure.foo(0, 5734400);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        int i1 = ClassExampleWithFailure.twice((-587202560));
        org.junit.Assert.assertTrue(i1 == (-1174405120));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        int i2 = ClassExampleWithFailure.foo((-8000), 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        int i2 = ClassExampleWithFailure.foo((-1811939328), (-8960));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        int i2 = ClassExampleWithFailure.foo((-22400), 294912000);
        org.junit.Assert.assertTrue(i2 == (-738197504));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        int i2 = ClassExampleWithFailure.foo(560, (-1845493760));
        org.junit.Assert.assertTrue(i2 == (-1073741824));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        int i2 = ClassExampleWithFailure.foo(704643072, (-1416101888));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        int i1 = ClassExampleWithFailure.twice(17920000);
        org.junit.Assert.assertTrue(i1 == 35840000);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        int i2 = ClassExampleWithFailure.foo((-616562688), (-4096));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        int i1 = ClassExampleWithFailure.twice(71680000);
        org.junit.Assert.assertTrue(i1 == 143360000);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        int i1 = ClassExampleWithFailure.twice((-738197504));
        org.junit.Assert.assertTrue(i1 == (-1476395008));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        int i1 = ClassExampleWithFailure.twice((-320));
        org.junit.Assert.assertTrue(i1 == (-640));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        int i2 = ClassExampleWithFailure.foo(1, 1552000);
        org.junit.Assert.assertTrue(i2 == 3104000);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        int i2 = ClassExampleWithFailure.foo((int) (byte) 0, (-286720000));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        int i2 = ClassExampleWithFailure.foo(1462763520, 3136000);
        org.junit.Assert.assertTrue(i2 == (-1073741824));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        int i2 = ClassExampleWithFailure.foo(143360000, 256000);
        org.junit.Assert.assertTrue(i2 == (-671088640));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        int i1 = ClassExampleWithFailure.twice((-35840));
        org.junit.Assert.assertTrue(i1 == (-71680));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        int i2 = ClassExampleWithFailure.foo((-17920), 1940);
        org.junit.Assert.assertTrue(i2 == (-69529600));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        int i2 = ClassExampleWithFailure.foo(1649410048, (-1462763520));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        int i2 = ClassExampleWithFailure.foo((-1795162112), (-35840));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        int i2 = ClassExampleWithFailure.foo(17920000, 870088704);
        org.junit.Assert.assertTrue(i2 == (-268435456));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        int i1 = ClassExampleWithFailure.twice(6272000);
        org.junit.Assert.assertTrue(i1 == 12544000);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        int i2 = ClassExampleWithFailure.foo((int) (short) 10, 3880);
        org.junit.Assert.assertTrue(i2 == 77600);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        int i2 = ClassExampleWithFailure.foo((-1024), 133120000);
        org.junit.Assert.assertTrue(i2 == (-2046820352));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        int i1 = ClassExampleWithFailure.twice((-200));
        org.junit.Assert.assertTrue(i1 == (-400));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        int i1 = ClassExampleWithFailure.twice(6400);
        org.junit.Assert.assertTrue(i1 == 12800);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        int i1 = ClassExampleWithFailure.twice(1605632000);
        org.junit.Assert.assertTrue(i1 == (-1083703296));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        int i2 = ClassExampleWithFailure.foo(665600, (int) (byte) 1);
        org.junit.Assert.assertTrue(i2 == 1331200);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        int i2 = ClassExampleWithFailure.foo((-64000), (-1610612736));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        int i1 = ClassExampleWithFailure.twice((-939524096));
        org.junit.Assert.assertTrue(i1 == (-1879048192));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        int i1 = ClassExampleWithFailure.twice(536870912);
        org.junit.Assert.assertTrue(i1 == 1073741824);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        int i2 = ClassExampleWithFailure.foo((-1174405120), 280);
        org.junit.Assert.assertTrue(i2 == (-536870912));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        int i1 = ClassExampleWithFailure.twice((-2046820352));
        org.junit.Assert.assertTrue(i1 == 201326592);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        int i1 = ClassExampleWithFailure.twice(6400000);
        org.junit.Assert.assertTrue(i1 == 12800000);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        int i2 = ClassExampleWithFailure.foo((-570425344), 1191182336);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        int i2 = ClassExampleWithFailure.foo(1578106880, 1552000);
        org.junit.Assert.assertTrue(i2 == (-805306368));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        int i1 = ClassExampleWithFailure.twice(567607296);
        org.junit.Assert.assertTrue(i1 == 1135214592);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        int i1 = ClassExampleWithFailure.twice((-570425344));
        org.junit.Assert.assertTrue(i1 == (-1140850688));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        int i2 = ClassExampleWithFailure.foo((-102400000), 1040187392);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        int i2 = ClassExampleWithFailure.foo(201326592, 939524096);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        int i2 = ClassExampleWithFailure.foo(140, (-738197504));
        org.junit.Assert.assertTrue(i2 == (-536870912));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        int i1 = ClassExampleWithFailure.twice((-1732247552));
        org.junit.Assert.assertTrue(i1 == 830472192);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        int i2 = ClassExampleWithFailure.foo(2000, 80);
        org.junit.Assert.assertTrue(i2 == 320000);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        int i2 = ClassExampleWithFailure.foo(0, 251658240);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        int i2 = ClassExampleWithFailure.foo(2007040000, 810123264);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        int i2 = ClassExampleWithFailure.foo(1426063360, 3880);
        org.junit.Assert.assertTrue(i2 == (-1879048192));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        int i2 = ClassExampleWithFailure.foo((-64), (-268435456));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        int i1 = ClassExampleWithFailure.twice((-1369440256));
        org.junit.Assert.assertTrue(i1 == 1556086784);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        int i1 = ClassExampleWithFailure.twice((-4096));
        org.junit.Assert.assertTrue(i1 == (-8192));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        int i1 = ClassExampleWithFailure.twice(260046848);
        org.junit.Assert.assertTrue(i1 == 520093696);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        int i2 = ClassExampleWithFailure.foo(0, (-1322778624));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        int i2 = ClassExampleWithFailure.foo(262144000, (-1021018112));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        int i2 = ClassExampleWithFailure.foo((-905969664), 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        int i1 = ClassExampleWithFailure.twice((-150994944));
        org.junit.Assert.assertTrue(i1 == (-301989888));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        int i1 = ClassExampleWithFailure.twice(18350080);
        org.junit.Assert.assertTrue(i1 == 36700160);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        int i2 = ClassExampleWithFailure.foo(1120, (-1619001344));
        org.junit.Assert.assertTrue(i2 == (-1610612736));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        int i2 = ClassExampleWithFailure.foo(1308622848, 1006632960);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        int i2 = ClassExampleWithFailure.foo(22400, (-400));
        org.junit.Assert.assertTrue(i2 == (-17920000));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        int i2 = ClassExampleWithFailure.foo((-671088640), 2017460224);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        int i2 = ClassExampleWithFailure.foo(81920, 102400000);
        org.junit.Assert.assertTrue(i2 == 1073741824);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        int i2 = ClassExampleWithFailure.foo((-123731968), (-1619001344));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        int i2 = ClassExampleWithFailure.foo(2017460224, 194);
        org.junit.Assert.assertTrue(i2 == 1090519040);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        int i2 = ClassExampleWithFailure.foo((-1549271040), (-1024));
        org.junit.Assert.assertTrue(i2 == (-1073741824));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        int i1 = ClassExampleWithFailure.twice((-2036334592));
        org.junit.Assert.assertTrue(i1 == 222298112);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        int i2 = ClassExampleWithFailure.foo(3880, 8000);
        org.junit.Assert.assertTrue(i2 == 62080000);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        int i2 = ClassExampleWithFailure.foo(150994944, 872415232);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        int i2 = ClassExampleWithFailure.foo((-2048), (-64000));
        org.junit.Assert.assertTrue(i2 == 262144000);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        int i2 = ClassExampleWithFailure.foo((-51200000), (-1));
        org.junit.Assert.assertTrue(i2 == 102400000);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        int i1 = ClassExampleWithFailure.twice((-1083703296));
        org.junit.Assert.assertTrue(i1 == 2127560704);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        int i1 = ClassExampleWithFailure.twice(251658240);
        org.junit.Assert.assertTrue(i1 == 503316480);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        int i2 = ClassExampleWithFailure.foo((-8960), (-1442840576));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        int i2 = ClassExampleWithFailure.foo(2085617664, 1556086784);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        int i2 = ClassExampleWithFailure.foo(872415232, 589824000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        int i1 = ClassExampleWithFailure.twice(62080000);
        org.junit.Assert.assertTrue(i1 == 124160000);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        int i1 = ClassExampleWithFailure.twice(767557632);
        org.junit.Assert.assertTrue(i1 == 1535115264);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        int i2 = ClassExampleWithFailure.foo(320, 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        int i2 = ClassExampleWithFailure.foo(1439432704, 872415232);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        int i1 = ClassExampleWithFailure.twice(1976041472);
        org.junit.Assert.assertTrue(i1 == (-342884352));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        int i2 = ClassExampleWithFailure.foo(166400, (-1476395008));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        int i2 = ClassExampleWithFailure.foo(7760, 2240000);
        org.junit.Assert.assertTrue(i2 == 405061632);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        int i1 = ClassExampleWithFailure.twice((-1845493760));
        org.junit.Assert.assertTrue(i1 == 603979776);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        int i2 = ClassExampleWithFailure.foo(0, (-1619001344));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        int i1 = ClassExampleWithFailure.twice(1535115264);
        org.junit.Assert.assertTrue(i1 == (-1224736768));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        int i2 = ClassExampleWithFailure.foo((-397934592), 2007040000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        int i2 = ClassExampleWithFailure.foo((-35840), (-866123776));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        int i2 = ClassExampleWithFailure.foo(1476395008, 1111490560);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        int i2 = ClassExampleWithFailure.foo(1649410048, 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        int i2 = ClassExampleWithFailure.foo(1090519040, 327680);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        int i2 = ClassExampleWithFailure.foo((int) (short) 0, (-1140850688));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        int i2 = ClassExampleWithFailure.foo(160, (-1308622848));
        org.junit.Assert.assertTrue(i2 == (-2147483648));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        int i2 = ClassExampleWithFailure.foo((-17920000), (-738197504));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        int i1 = ClassExampleWithFailure.twice(15520);
        org.junit.Assert.assertTrue(i1 == 31040);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        int i2 = ClassExampleWithFailure.foo((-1040187392), 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        int i1 = ClassExampleWithFailure.twice(36700160);
        org.junit.Assert.assertTrue(i1 == 73400320);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        int i2 = ClassExampleWithFailure.foo(224000, 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        int i2 = ClassExampleWithFailure.foo(1836056576, 62080000);
        org.junit.Assert.assertTrue(i2 == (-2147483648));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        int i1 = ClassExampleWithFailure.twice(110100480);
        org.junit.Assert.assertTrue(i1 == 220200960);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        int i2 = ClassExampleWithFailure.foo((-114688000), (-280));
        org.junit.Assert.assertTrue(i2 == (-199229440));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        int i2 = ClassExampleWithFailure.foo((-409600), (-1170210816));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        int i2 = ClassExampleWithFailure.foo(51200000, 194);
        org.junit.Assert.assertTrue(i2 == (-1609236480));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        int i2 = ClassExampleWithFailure.foo((-1416101888), 251658240);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        int i1 = ClassExampleWithFailure.twice((-67108864));
        org.junit.Assert.assertTrue(i1 == (-134217728));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        int i1 = ClassExampleWithFailure.twice((-2042036224));
        org.junit.Assert.assertTrue(i1 == 210894848);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        int i2 = ClassExampleWithFailure.foo((int) (byte) 0, (-1486094336));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        int i2 = ClassExampleWithFailure.foo((-654311424), 4);
        org.junit.Assert.assertTrue(i2 == (-939524096));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        int i2 = ClassExampleWithFailure.foo(704643072, 256000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        int i1 = ClassExampleWithFailure.twice(134217728);
        org.junit.Assert.assertTrue(i1 == 268435456);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        int i2 = ClassExampleWithFailure.foo(4, (int) (short) 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        int i2 = ClassExampleWithFailure.foo((-128), 256000);
        org.junit.Assert.assertTrue(i2 == (-65536000));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        int i2 = ClassExampleWithFailure.foo((-34764800), (-234881024));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        int i2 = ClassExampleWithFailure.foo((-1619001344), 4480000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        int i2 = ClassExampleWithFailure.foo(268435456, 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        int i2 = ClassExampleWithFailure.foo((-1732247552), (int) (short) -1);
        org.junit.Assert.assertTrue(i2 == (-830472192));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        int i2 = ClassExampleWithFailure.foo((-80), (-67108864));
        org.junit.Assert.assertTrue(i2 == (-2147483648));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        int i2 = ClassExampleWithFailure.foo((-4000), 1111490560);
        org.junit.Assert.assertTrue(i2 == (-1342177280));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        int i2 = ClassExampleWithFailure.foo(1426063360, (-2036334592));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        int i2 = ClassExampleWithFailure.foo((-1369440256), 210894848);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        int i2 = ClassExampleWithFailure.foo(1543503872, 8960000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        int i2 = ClassExampleWithFailure.foo((-260046848), 1879048192);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        int i1 = ClassExampleWithFailure.twice(12800000);
        org.junit.Assert.assertTrue(i1 == 25600000);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        int i1 = ClassExampleWithFailure.twice((-1146880000));
        org.junit.Assert.assertTrue(i1 == 2001207296);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        int i2 = ClassExampleWithFailure.foo(1556086784, 603979776);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        int i2 = ClassExampleWithFailure.foo(143360000, 12800000);
        org.junit.Assert.assertTrue(i2 == 805306368);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        int i2 = ClassExampleWithFailure.foo(0, 1006632960);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        int i2 = ClassExampleWithFailure.foo((-1918369792), (-1732247552));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        int i2 = ClassExampleWithFailure.foo((-67108864), 222298112);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        int i1 = ClassExampleWithFailure.twice(1308622848);
        org.junit.Assert.assertTrue(i1 == (-1677721600));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        int i2 = ClassExampleWithFailure.foo(494927872, (-397934592));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        int i1 = ClassExampleWithFailure.twice((-204800000));
        org.junit.Assert.assertTrue(i1 == (-409600000));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        int i1 = ClassExampleWithFailure.twice((-1174405120));
        org.junit.Assert.assertTrue(i1 == 1946157056);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        int i1 = ClassExampleWithFailure.twice((-89600));
        org.junit.Assert.assertTrue(i1 == (-179200));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        int i2 = ClassExampleWithFailure.foo((-1224736768), 327680);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        int i2 = ClassExampleWithFailure.foo((-400), 1196425216);
        org.junit.Assert.assertTrue(i2 == 637534208);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        int i2 = ClassExampleWithFailure.foo(939524096, (-199229440));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        int i2 = ClassExampleWithFailure.foo(3136000, (-160));
        org.junit.Assert.assertTrue(i2 == (-1003520000));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        int i2 = ClassExampleWithFailure.foo((-570425344), 1040187392);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        int i2 = ClassExampleWithFailure.foo((-32000), 2240);
        org.junit.Assert.assertTrue(i2 == (-143360000));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        int i1 = ClassExampleWithFailure.twice((-8000));
        org.junit.Assert.assertTrue(i1 == (-16000));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        int i1 = ClassExampleWithFailure.twice(1280000);
        org.junit.Assert.assertTrue(i1 == 2560000);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        int i2 = ClassExampleWithFailure.foo((int) (byte) 10, (-4096));
        org.junit.Assert.assertTrue(i2 == (-81920));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        int i2 = ClassExampleWithFailure.foo((-1845493760), (-67108864));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        int i2 = ClassExampleWithFailure.foo((-545259520), (-1677721600));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        int i2 = ClassExampleWithFailure.foo((-1732247552), 77600);
        org.junit.Assert.assertTrue(i2 == (-1342177280));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        int i2 = ClassExampleWithFailure.foo(260046848, 1135214592);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        int i2 = ClassExampleWithFailure.foo(6400000, (-8000));
        org.junit.Assert.assertTrue(i2 == 679215104);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        int i1 = ClassExampleWithFailure.twice((-1276116992));
        org.junit.Assert.assertTrue(i1 == 1742733312);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        int i2 = ClassExampleWithFailure.foo((-102400000), 81920);
        org.junit.Assert.assertTrue(i2 == (-1073741824));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        int i1 = ClassExampleWithFailure.twice((-1638400));
        org.junit.Assert.assertTrue(i1 == (-3276800));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        int i2 = ClassExampleWithFailure.foo(776, (int) '4');
        org.junit.Assert.assertTrue(i2 == 80704);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        int i2 = ClassExampleWithFailure.foo(134217728, 1940);
        org.junit.Assert.assertTrue(i2 == 1073741824);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        int i2 = ClassExampleWithFailure.foo((-199229440), (int) (short) 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        int i2 = ClassExampleWithFailure.foo(6400, 150994944);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        int i1 = ClassExampleWithFailure.twice(1135214592);
        org.junit.Assert.assertTrue(i1 == (-2024538112));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        int i2 = ClassExampleWithFailure.foo(1196425216, 2085617664);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        int i2 = ClassExampleWithFailure.foo(754974720, 320);
        org.junit.Assert.assertTrue(i2 == (-2147483648));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        int i2 = ClassExampleWithFailure.foo(0, 140);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        int i1 = ClassExampleWithFailure.twice((-1476395008));
        org.junit.Assert.assertTrue(i1 == 1342177280);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        int i2 = ClassExampleWithFailure.foo((-286720000), 905969664);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        int i2 = ClassExampleWithFailure.foo((-671088640), 73400320);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        int i2 = ClassExampleWithFailure.foo((-1619001344), 44800);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        int i1 = ClassExampleWithFailure.twice((-1600));
        org.junit.Assert.assertTrue(i1 == (-3200));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        int i2 = ClassExampleWithFailure.foo(327680, 64000);
        org.junit.Assert.assertTrue(i2 == (-1006632960));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        int i2 = ClassExampleWithFailure.foo(1556086784, (-622854144));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        int i2 = ClassExampleWithFailure.foo((-2621440), (-1140850688));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        int i2 = ClassExampleWithFailure.foo((int) ' ', (-536870912));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        int i2 = ClassExampleWithFailure.foo(9175040, 1392771072);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        int i2 = ClassExampleWithFailure.foo((-1902116864), (-342884352));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        int i1 = ClassExampleWithFailure.twice((-65536000));
        org.junit.Assert.assertTrue(i1 == (-131072000));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        int i2 = ClassExampleWithFailure.foo(0, 143360000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        int i2 = ClassExampleWithFailure.foo(0, 222298112);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        int i2 = ClassExampleWithFailure.foo((-905969664), 112000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        int i2 = ClassExampleWithFailure.foo(12800000, 1946157056);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        int i2 = ClassExampleWithFailure.foo(143360000, 805306368);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        int i2 = ClassExampleWithFailure.foo((-1042808832), (-397934592));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        int i2 = ClassExampleWithFailure.foo(2240, (-200));
        org.junit.Assert.assertTrue(i2 == (-896000));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        int i1 = ClassExampleWithFailure.twice(256000);
        org.junit.Assert.assertTrue(i1 == 512000);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        int i2 = ClassExampleWithFailure.foo(77600, (-738197504));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        int i1 = ClassExampleWithFailure.twice(2240);
        org.junit.Assert.assertTrue(i1 == 4480);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        int i2 = ClassExampleWithFailure.foo((-20), 3104000);
        org.junit.Assert.assertTrue(i2 == (-124160000));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        int i1 = ClassExampleWithFailure.twice(1552000);
        org.junit.Assert.assertTrue(i1 == 3104000);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        int i2 = ClassExampleWithFailure.foo((-805306368), 16000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        int i1 = ClassExampleWithFailure.twice((-1462763520));
        org.junit.Assert.assertTrue(i1 == 1369440256);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        int i2 = ClassExampleWithFailure.foo((-134217728), (-35840000));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        int i2 = ClassExampleWithFailure.foo((-280), (-260046848));
        org.junit.Assert.assertTrue(i2 == (-402653184));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        int i2 = ClassExampleWithFailure.foo(9800, (-22400));
        org.junit.Assert.assertTrue(i2 == (-439040000));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        int i2 = ClassExampleWithFailure.foo((-1174405120), 102400000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        int i2 = ClassExampleWithFailure.foo(1371537408, (-1083703296));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        int i1 = ClassExampleWithFailure.twice((-2085617664));
        org.junit.Assert.assertTrue(i1 == 123731968);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        int i1 = ClassExampleWithFailure.twice(1742733312);
        org.junit.Assert.assertTrue(i1 == (-809500672));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        int i1 = ClassExampleWithFailure.twice(1946157056);
        org.junit.Assert.assertTrue(i1 == (-402653184));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        int i1 = ClassExampleWithFailure.twice((-616562688));
        org.junit.Assert.assertTrue(i1 == (-1233125376));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        int i2 = ClassExampleWithFailure.foo(800, (-67108864));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        int i2 = ClassExampleWithFailure.foo((-35840), 1358430208);
        org.junit.Assert.assertTrue(i2 == (-1073741824));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        int i2 = ClassExampleWithFailure.foo(0, (-1744830464));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        int i1 = ClassExampleWithFailure.twice(1552);
        org.junit.Assert.assertTrue(i1 == 3104);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        int i2 = ClassExampleWithFailure.foo(5734400, 1610612736);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        int i1 = ClassExampleWithFailure.twice((-1342177280));
        org.junit.Assert.assertTrue(i1 == 1610612736);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        int i1 = ClassExampleWithFailure.twice(1358430208);
        org.junit.Assert.assertTrue(i1 == (-1578106880));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        int i2 = ClassExampleWithFailure.foo(1677721600, 4480000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        int i2 = ClassExampleWithFailure.foo(1940, 24832);
        org.junit.Assert.assertTrue(i2 == 96348160);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        int i1 = ClassExampleWithFailure.twice((-16000));
        org.junit.Assert.assertTrue(i1 == (-32000));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        int i2 = ClassExampleWithFailure.foo(3104000, (-320));
        org.junit.Assert.assertTrue(i2 == (-1986560000));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        int i2 = ClassExampleWithFailure.foo((-143360000), (int) (short) 1);
        org.junit.Assert.assertTrue(i2 == (-286720000));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        int i2 = ClassExampleWithFailure.foo(2017460224, (-1486094336));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        int i2 = ClassExampleWithFailure.foo((-2036334592), 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        int i2 = ClassExampleWithFailure.foo(128, (-1140850688));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        int i1 = ClassExampleWithFailure.twice(123731968);
        org.junit.Assert.assertTrue(i1 == 247463936);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        int i2 = ClassExampleWithFailure.foo(71680000, (-738197504));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        int i1 = ClassExampleWithFailure.twice(1392771072);
        org.junit.Assert.assertTrue(i1 == (-1509425152));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        int i2 = ClassExampleWithFailure.foo(1090519040, (-17382400));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        int i2 = ClassExampleWithFailure.foo(567607296, 150994944);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        int i1 = ClassExampleWithFailure.twice(1262485504);
        org.junit.Assert.assertTrue(i1 == (-1769996288));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        int i1 = ClassExampleWithFailure.twice((-81920));
        org.junit.Assert.assertTrue(i1 == (-163840));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        int i2 = ClassExampleWithFailure.foo(1591738368, 32000);
        org.junit.Assert.assertTrue(i2 == (-1073741824));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        int i2 = ClassExampleWithFailure.foo(112000, 1249902592);
        org.junit.Assert.assertTrue(i2 == (-2147483648));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        int i1 = ClassExampleWithFailure.twice(1578106880);
        org.junit.Assert.assertTrue(i1 == (-1138753536));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        int i1 = ClassExampleWithFailure.twice(1421934592);
        org.junit.Assert.assertTrue(i1 == (-1451098112));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        int i2 = ClassExampleWithFailure.foo(71680000, 248320000);
        org.junit.Assert.assertTrue(i2 == 939524096);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        int i1 = ClassExampleWithFailure.twice(49664);
        org.junit.Assert.assertTrue(i1 == 99328);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        int i2 = ClassExampleWithFailure.foo(1280000, 11200);
        org.junit.Assert.assertTrue(i2 == (-1392771072));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        int i1 = ClassExampleWithFailure.twice(490733568);
        org.junit.Assert.assertTrue(i1 == 981467136);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        int i2 = ClassExampleWithFailure.foo((-1073741824), (-1310720));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        int i1 = ClassExampleWithFailure.twice(9800);
        org.junit.Assert.assertTrue(i1 == 19600);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        int i1 = ClassExampleWithFailure.twice((-1879048192));
        org.junit.Assert.assertTrue(i1 == 536870912);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        int i1 = ClassExampleWithFailure.twice((-1392771072));
        org.junit.Assert.assertTrue(i1 == 1509425152);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        int i2 = ClassExampleWithFailure.foo(7760, 1462763520);
        org.junit.Assert.assertTrue(i2 == (-1107296256));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        int i2 = ClassExampleWithFailure.foo(12800000, (-17382400));
        org.junit.Assert.assertTrue(i2 == (-763363328));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        int i1 = ClassExampleWithFailure.twice(1556086784);
        org.junit.Assert.assertTrue(i1 == (-1182793728));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        int i2 = ClassExampleWithFailure.foo(1677721600, (-409600000));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        int i2 = ClassExampleWithFailure.foo((-1308622848), 1224736768);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        int i2 = ClassExampleWithFailure.foo(12800, (-64000));
        org.junit.Assert.assertTrue(i2 == (-1638400000));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        int i2 = ClassExampleWithFailure.foo(1392771072, (-1609236480));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        int i2 = ClassExampleWithFailure.foo((-1578106880), (-1006632960));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        int i2 = ClassExampleWithFailure.foo((-44800), 124160000);
        org.junit.Assert.assertTrue(i2 == (-770703360));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        int i2 = ClassExampleWithFailure.foo((-763363328), (-545259520));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        int i2 = ClassExampleWithFailure.foo(1224736768, 2127560704);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        int i2 = ClassExampleWithFailure.foo((-866123776), 1426063360);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        int i2 = ClassExampleWithFailure.foo(0, 51200000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        int i2 = ClassExampleWithFailure.foo((-4096), 1241513984);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        int i2 = ClassExampleWithFailure.foo((-81920), (-4000));
        org.junit.Assert.assertTrue(i2 == 655360000);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        int i2 = ClassExampleWithFailure.foo(0, 10);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        int i2 = ClassExampleWithFailure.foo(64000, 262144000);
        org.junit.Assert.assertTrue(i2 == (-2147483648));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        int i1 = ClassExampleWithFailure.twice(301989888);
        org.junit.Assert.assertTrue(i1 == 603979776);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        int i2 = ClassExampleWithFailure.foo(1331200, 1188298752);
        org.junit.Assert.assertTrue(i2 == (-2147483648));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        int i1 = ClassExampleWithFailure.twice(19600);
        org.junit.Assert.assertTrue(i1 == 39200);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        int i2 = ClassExampleWithFailure.foo((-2036334592), 1191182336);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        int i2 = ClassExampleWithFailure.foo(767557632, (-204800000));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        int i2 = ClassExampleWithFailure.foo(1439432704, (-4000));
        org.junit.Assert.assertTrue(i2 == (-654311424));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        int i2 = ClassExampleWithFailure.foo(2127560704, (-81920));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        int i1 = ClassExampleWithFailure.twice((-2621440));
        org.junit.Assert.assertTrue(i1 == (-5242880));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        int i2 = ClassExampleWithFailure.foo(1591738368, 194);
        org.junit.Assert.assertTrue(i2 == (-880803840));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        int i2 = ClassExampleWithFailure.foo((-1369440256), (-67108864));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        int i2 = ClassExampleWithFailure.foo((-163840), 18350080);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        int i2 = ClassExampleWithFailure.foo(3136000, 1946157056);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        int i2 = ClassExampleWithFailure.foo(641728512, 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        int i1 = ClassExampleWithFailure.twice((-1677721600));
        org.junit.Assert.assertTrue(i1 == 939524096);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        int i2 = ClassExampleWithFailure.foo(44800, 124160000);
        org.junit.Assert.assertTrue(i2 == 770703360);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        int i2 = ClassExampleWithFailure.foo(12544000, 567607296);
        org.junit.Assert.assertTrue(i2 == 268435456);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        int i2 = ClassExampleWithFailure.foo(15520, (-163840));
        org.junit.Assert.assertTrue(i2 == (-790626304));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        int i2 = ClassExampleWithFailure.foo((-2048), 1591738368);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        int i2 = ClassExampleWithFailure.foo((-1371537408), 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        int i1 = ClassExampleWithFailure.twice((-880803840));
        org.junit.Assert.assertTrue(i1 == (-1761607680));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        int i2 = ClassExampleWithFailure.foo(24832, 16000);
        org.junit.Assert.assertTrue(i2 == 794624000);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        int i2 = ClassExampleWithFailure.foo((-1744830464), 1552);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        int i2 = ClassExampleWithFailure.foo((-640), 12544000);
        org.junit.Assert.assertTrue(i2 == 1123549184);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        int i1 = ClassExampleWithFailure.twice((-1170210816));
        org.junit.Assert.assertTrue(i1 == 1954545664);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        int i2 = ClassExampleWithFailure.foo((-3200), 9800);
        org.junit.Assert.assertTrue(i2 == (-62720000));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        int i2 = ClassExampleWithFailure.foo(1003520000, 905969664);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        int i1 = ClassExampleWithFailure.twice(1649410048);
        org.junit.Assert.assertTrue(i1 == (-996147200));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        int i1 = ClassExampleWithFailure.twice((-163840));
        org.junit.Assert.assertTrue(i1 == (-327680));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        int i1 = ClassExampleWithFailure.twice((-20));
        org.junit.Assert.assertTrue(i1 == (-40));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        int i2 = ClassExampleWithFailure.foo(810123264, (-616562688));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        int i2 = ClassExampleWithFailure.foo(201326592, 1567752192);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        int i1 = ClassExampleWithFailure.twice((-134217728));
        org.junit.Assert.assertTrue(i1 == (-268435456));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        int i2 = ClassExampleWithFailure.foo(1006632960, 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        int i1 = ClassExampleWithFailure.twice((-1744830464));
        org.junit.Assert.assertTrue(i1 == 805306368);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        int i2 = ClassExampleWithFailure.foo((-20), 1744830464);
        org.junit.Assert.assertTrue(i2 == (-1073741824));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        int i2 = ClassExampleWithFailure.foo((-494927872), 1742733312);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        int i2 = ClassExampleWithFailure.foo((-1310720), 262144000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        int i2 = ClassExampleWithFailure.foo((-409600), 704643072);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        int i2 = ClassExampleWithFailure.foo((-996147200), 16000);
        org.junit.Assert.assertTrue(i2 == 536870912);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        int i2 = ClassExampleWithFailure.foo((-520093696), 1077936128);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        int i2 = ClassExampleWithFailure.foo((-1083703296), (-1462763520));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        int i2 = ClassExampleWithFailure.foo((-200), (-1021018112));
        org.junit.Assert.assertTrue(i2 == 385351680);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        int i2 = ClassExampleWithFailure.foo((-622854144), (-939524096));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        int i2 = ClassExampleWithFailure.foo((-1549271040), 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        int i2 = ClassExampleWithFailure.foo(1836056576, (-2147483648));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        int i2 = ClassExampleWithFailure.foo((-1619001344), (-1451098112));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        int i1 = ClassExampleWithFailure.twice(1954545664);
        org.junit.Assert.assertTrue(i1 == (-385875968));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        int i2 = ClassExampleWithFailure.foo(388, (-1342177280));
        org.junit.Assert.assertTrue(i2 == (-2147483648));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        int i2 = ClassExampleWithFailure.foo((-939524096), (-160));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        int i2 = ClassExampleWithFailure.foo((-114688000), (-738197504));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        int i2 = ClassExampleWithFailure.foo((-124160000), 1552);
        org.junit.Assert.assertTrue(i2 == 1154416640);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        int i2 = ClassExampleWithFailure.foo((-1486094336), 11200);
        org.junit.Assert.assertTrue(i2 == 1778384896);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        int i2 = ClassExampleWithFailure.foo((-738197504), (-124160000));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        int i1 = ClassExampleWithFailure.twice(102400000);
        org.junit.Assert.assertTrue(i1 == 204800000);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        int i2 = ClassExampleWithFailure.foo(51200000, (-4096));
        org.junit.Assert.assertTrue(i2 == 1476395008);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        int i2 = ClassExampleWithFailure.foo(3104000, 1954545664);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        int i2 = ClassExampleWithFailure.foo((-1912602624), (-17920000));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        int i2 = ClassExampleWithFailure.foo((-1619001344), 7760);
        org.junit.Assert.assertTrue(i2 == (-1342177280));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        int i2 = ClassExampleWithFailure.foo((-1024), 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        int i2 = ClassExampleWithFailure.foo((-2147483648), 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        int i2 = ClassExampleWithFailure.foo(402653184, 1135214592);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        int i2 = ClassExampleWithFailure.foo(1073741824, 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        int i1 = ClassExampleWithFailure.twice(655360000);
        org.junit.Assert.assertTrue(i1 == 1310720000);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        int i2 = ClassExampleWithFailure.foo((-301989888), 11200);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        int i2 = ClassExampleWithFailure.foo(830472192, 71680000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        int i1 = ClassExampleWithFailure.twice(5734400);
        org.junit.Assert.assertTrue(i1 == 11468800);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        int i2 = ClassExampleWithFailure.foo((-1111490560), (-1451098112));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        int i2 = ClassExampleWithFailure.foo((-2138570752), 1154416640);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        int i2 = ClassExampleWithFailure.foo((-2), 1543503872);
        org.junit.Assert.assertTrue(i2 == (-1879048192));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        int i2 = ClassExampleWithFailure.foo((-1), 939524096);
        org.junit.Assert.assertTrue(i2 == (-1879048192));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        int i2 = ClassExampleWithFailure.foo(1123549184, (-401408000));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        int i1 = ClassExampleWithFailure.twice((-199229440));
        org.junit.Assert.assertTrue(i1 == (-398458880));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        int i1 = ClassExampleWithFailure.twice((-5242880));
        org.junit.Assert.assertTrue(i1 == (-10485760));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        int i2 = ClassExampleWithFailure.foo((-640), 440401920);
        org.junit.Assert.assertTrue(i2 == (-1073741824));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        int i2 = ClassExampleWithFailure.foo(981467136, 3136000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        int i1 = ClassExampleWithFailure.twice(637534208);
        org.junit.Assert.assertTrue(i1 == 1275068416);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        int i2 = ClassExampleWithFailure.foo(194, (-62720000));
        org.junit.Assert.assertTrue(i2 == 1434443776);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        int i2 = ClassExampleWithFailure.foo((-65536000), (-1042808832));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        int i2 = ClassExampleWithFailure.foo((-1619001344), 128);
        org.junit.Assert.assertTrue(i2 == (-2147483648));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        int i1 = ClassExampleWithFailure.twice((-1451098112));
        org.junit.Assert.assertTrue(i1 == 1392771072);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        int i1 = ClassExampleWithFailure.twice(3104000);
        org.junit.Assert.assertTrue(i1 == 6208000);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        int i2 = ClassExampleWithFailure.foo(1404436480, 1003520000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        int i2 = ClassExampleWithFailure.foo(679215104, 44800);
        org.junit.Assert.assertTrue(i2 == (-2013265920));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        int i2 = ClassExampleWithFailure.foo(800, 1836056576);
        org.junit.Assert.assertTrue(i2 == (-67108864));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        int i1 = ClassExampleWithFailure.twice((-385875968));
        org.junit.Assert.assertTrue(i1 == (-771751936));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        int i2 = ClassExampleWithFailure.foo((-234881024), (-28672000));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        int i2 = ClassExampleWithFailure.foo(0, (-397934592));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        int i1 = ClassExampleWithFailure.twice((-1111490560));
        org.junit.Assert.assertTrue(i1 == 2071986176);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        int i2 = ClassExampleWithFailure.foo(327680, (-143360000));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        int i2 = ClassExampleWithFailure.foo(71680000, (-1233125376));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        int i2 = ClassExampleWithFailure.foo(44800, (-1918369792));
        org.junit.Assert.assertTrue(i2 == (-1342177280));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        int i2 = ClassExampleWithFailure.foo((-830472192), 800);
        org.junit.Assert.assertTrue(i2 == (-1610612736));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        int i1 = ClassExampleWithFailure.twice(805306368);
        org.junit.Assert.assertTrue(i1 == 1610612736);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        int i1 = ClassExampleWithFailure.twice((-622854144));
        org.junit.Assert.assertTrue(i1 == (-1245708288));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        int i2 = ClassExampleWithFailure.foo(512, 6400000);
        org.junit.Assert.assertTrue(i2 == (-2036334592));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        int i2 = ClassExampleWithFailure.foo(0, (int) (short) 100);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        int i2 = ClassExampleWithFailure.foo(19600, 1462763520);
        org.junit.Assert.assertTrue(i2 == (-1778384896));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        int i2 = ClassExampleWithFailure.foo((-51200000), (-301989888));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        int i2 = ClassExampleWithFailure.foo((-2071986176), 220200960);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        int i2 = ClassExampleWithFailure.foo((-409600), 51200000);
        org.junit.Assert.assertTrue(i2 == 1610612736);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        int i2 = ClassExampleWithFailure.foo(1976041472, 704643072);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        int i2 = ClassExampleWithFailure.foo((-2042036224), (-616562688));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        int i2 = ClassExampleWithFailure.foo((-400), 2080374784);
        org.junit.Assert.assertTrue(i2 == (-2147483648));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        int i2 = ClassExampleWithFailure.foo(294912000, 6400);
        org.junit.Assert.assertTrue(i2 == (-402653184));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        int i2 = ClassExampleWithFailure.foo((-10485760), (-199229440));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        int i2 = ClassExampleWithFailure.foo(1610612736, (-654311424));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        int i2 = ClassExampleWithFailure.foo((-2013265920), 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        int i2 = ClassExampleWithFailure.foo(0, 624951296);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        int i2 = ClassExampleWithFailure.foo((-89600), (-790626304));
        org.junit.Assert.assertTrue(i2 == (-2147483648));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        int i2 = ClassExampleWithFailure.foo(99328, 143360000);
        org.junit.Assert.assertTrue(i2 == (-603979776));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        int i2 = ClassExampleWithFailure.foo(1409286144, (-17920000));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        int i1 = ClassExampleWithFailure.twice((-3276800));
        org.junit.Assert.assertTrue(i1 == (-6553600));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        int i2 = ClassExampleWithFailure.foo(2662400, (-671088640));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        int i2 = ClassExampleWithFailure.foo(794624000, (-1761607680));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        int i2 = ClassExampleWithFailure.foo((-1276116992), 469762048);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        int i2 = ClassExampleWithFailure.foo((-2138570752), 1976041472);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        int i1 = ClassExampleWithFailure.twice(870088704);
        org.junit.Assert.assertTrue(i1 == 1740177408);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        int i2 = ClassExampleWithFailure.foo((-2042036224), 1040187392);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        int i1 = ClassExampleWithFailure.twice((-640));
        org.junit.Assert.assertTrue(i1 == (-1280));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        int i1 = ClassExampleWithFailure.twice((-1224736768));
        org.junit.Assert.assertTrue(i1 == 1845493760);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        int i2 = ClassExampleWithFailure.foo(767557632, 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        int i2 = ClassExampleWithFailure.foo(31040, (-1159462912));
        org.junit.Assert.assertTrue(i2 == (-100663296));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        int i2 = ClassExampleWithFailure.foo(163840, (-8192));
        org.junit.Assert.assertTrue(i2 == 1610612736);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        int i2 = ClassExampleWithFailure.foo((-65536000), (-1778384896));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        int i1 = ClassExampleWithFailure.twice(405061632);
        org.junit.Assert.assertTrue(i1 == 810123264);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        int i2 = ClassExampleWithFailure.foo(8000, 100);
        org.junit.Assert.assertTrue(i2 == 1600000);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        int i2 = ClassExampleWithFailure.foo(1836056576, 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        int i1 = ClassExampleWithFailure.twice((-1619001344));
        org.junit.Assert.assertTrue(i1 == 1056964608);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        int i2 = ClassExampleWithFailure.foo(77600, (-71680000));
        org.junit.Assert.assertTrue(i2 == (-770703360));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        int i2 = ClassExampleWithFailure.foo(1879048192, (-8960000));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test428");
        int i2 = ClassExampleWithFailure.foo((int) (byte) 100, (-545259520));
        org.junit.Assert.assertTrue(i2 == (-1677721600));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        int i2 = ClassExampleWithFailure.foo((-795869184), 2017460224);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        int i2 = ClassExampleWithFailure.foo((-71680000), 5734400);
        org.junit.Assert.assertTrue(i2 == (-1073741824));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        int i2 = ClassExampleWithFailure.foo((-160), (-1146880000));
        org.junit.Assert.assertTrue(i2 == 1929379840);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        int i2 = ClassExampleWithFailure.foo((-143360000), (-81920));
        org.junit.Assert.assertTrue(i2 == (-1073741824));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        int i2 = ClassExampleWithFailure.foo(16000, (int) (byte) 1);
        org.junit.Assert.assertTrue(i2 == 32000);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        int i2 = ClassExampleWithFailure.foo((-763363328), (-179200));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test435");
        int i2 = ClassExampleWithFailure.foo(4587520, (int) (short) 100);
        org.junit.Assert.assertTrue(i2 == 917504000);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test436");
        int i2 = ClassExampleWithFailure.foo(25600000, 17920000);
        org.junit.Assert.assertTrue(i2 == 201326592);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test437");
        int i2 = ClassExampleWithFailure.foo(388, 1207959552);
        org.junit.Assert.assertTrue(i2 == 1073741824);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test438");
        int i2 = ClassExampleWithFailure.foo(0, (-809500672));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        int i1 = ClassExampleWithFailure.twice((-1986560000));
        org.junit.Assert.assertTrue(i1 == 321847296);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        int i2 = ClassExampleWithFailure.foo((-64), (-1591738368));
        org.junit.Assert.assertTrue(i2 == 1879048192);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        int i2 = ClassExampleWithFailure.foo((-795869184), (int) (byte) -1);
        org.junit.Assert.assertTrue(i2 == 1591738368);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test442");
        int i2 = ClassExampleWithFailure.foo(4000, 1392771072);
        org.junit.Assert.assertTrue(i2 == 1023410176);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test443");
        int i2 = ClassExampleWithFailure.foo(220200960, 256000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test444");
        int i2 = ClassExampleWithFailure.foo((-1207959552), 1056964608);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test445");
        int i1 = ClassExampleWithFailure.twice((-131072000));
        org.junit.Assert.assertTrue(i1 == (-262144000));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test446");
        int i2 = ClassExampleWithFailure.foo(624951296, 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test447");
        int i2 = ClassExampleWithFailure.foo((-1207959552), (-1233125376));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test448");
        int i2 = ClassExampleWithFailure.foo(490733568, 1778384896);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test449");
        int i1 = ClassExampleWithFailure.twice(2127560704);
        org.junit.Assert.assertTrue(i1 == (-39845888));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test450");
        int i2 = ClassExampleWithFailure.foo(17920000, 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test451");
        int i2 = ClassExampleWithFailure.foo((-409600), 870088704);
        org.junit.Assert.assertTrue(i2 == (-1073741824));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test452");
        int i2 = ClassExampleWithFailure.foo((-81920), 685768704);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test453");
        int i1 = ClassExampleWithFailure.twice(8);
        org.junit.Assert.assertTrue(i1 == 16);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test454");
        int i1 = ClassExampleWithFailure.twice((-1371537408));
        org.junit.Assert.assertTrue(i1 == 1551892480);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test455");
        int i2 = ClassExampleWithFailure.foo(679215104, 22400);
        org.junit.Assert.assertTrue(i2 == (-1006632960));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test456");
        int i2 = ClassExampleWithFailure.foo(1976041472, 1073741824);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test457");
        int i2 = ClassExampleWithFailure.foo(134217728, (-1902116864));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test458");
        int i2 = ClassExampleWithFailure.foo((-67108864), 163840);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test459");
        int i2 = ClassExampleWithFailure.foo(1552000, 301989888);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test460");
        int i2 = ClassExampleWithFailure.foo(603979776, (-342884352));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test461");
        int i2 = ClassExampleWithFailure.foo((-260046848), (-880803840));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test462");
        int i2 = ClassExampleWithFailure.foo((-64), (-536870912));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test463");
        int i1 = ClassExampleWithFailure.twice((-2129920000));
        org.junit.Assert.assertTrue(i1 == 35127296);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test464");
        int i1 = ClassExampleWithFailure.twice(520093696);
        org.junit.Assert.assertTrue(i1 == 1040187392);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test465");
        int i2 = ClassExampleWithFailure.foo(0, 320);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test466");
        int i2 = ClassExampleWithFailure.foo(39200, (-268435456));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test467");
        int i2 = ClassExampleWithFailure.foo(1462763520, 35840000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test468");
        int i2 = ClassExampleWithFailure.foo((-805306368), (-301989888));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test469");
        int i2 = ClassExampleWithFailure.foo((-2621440), 134217728);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test470");
        int i2 = ClassExampleWithFailure.foo(905969664, (-247463936));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test471");
        int i2 = ClassExampleWithFailure.foo(1744830464, (-131072000));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test472");
        int i2 = ClassExampleWithFailure.foo((-1918369792), 1120);
        org.junit.Assert.assertTrue(i2 == 2113929216);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test473");
        int i2 = ClassExampleWithFailure.foo((-268435456), 268435456);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test474");
        int i2 = ClassExampleWithFailure.foo((-1677721600), 1135214592);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test475");
        int i2 = ClassExampleWithFailure.foo(11200, 3104);
        org.junit.Assert.assertTrue(i2 == 69529600);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test476");
        int i2 = ClassExampleWithFailure.foo(1439432704, (-2013265920));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test477");
        int i2 = ClassExampleWithFailure.foo((-1769996288), 641728512);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test478");
        int i2 = ClassExampleWithFailure.foo((-795869184), 1006632960);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test479");
        int i1 = ClassExampleWithFailure.twice(2662400);
        org.junit.Assert.assertTrue(i1 == 5324800);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test480");
        int i2 = ClassExampleWithFailure.foo((-2129920000), 1154416640);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test481");
        int i2 = ClassExampleWithFailure.foo(31040, (int) (short) 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test482");
        int i1 = ClassExampleWithFailure.twice(2001207296);
        org.junit.Assert.assertTrue(i1 == (-292552704));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test483");
        int i2 = ClassExampleWithFailure.foo(494927872, (-1308622848));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test484");
        int i2 = ClassExampleWithFailure.foo(704643072, 1371537408);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test485");
        int i2 = ClassExampleWithFailure.foo((-1744830464), (-2024538112));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test486");
        int i2 = ClassExampleWithFailure.foo((-1083703296), 18350080);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test487");
        int i2 = ClassExampleWithFailure.foo((-2048), (-654311424));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test488");
        int i1 = ClassExampleWithFailure.twice((-1138753536));
        org.junit.Assert.assertTrue(i1 == 2017460224);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test489");
        int i1 = ClassExampleWithFailure.twice((-286720000));
        org.junit.Assert.assertTrue(i1 == (-573440000));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test490");
        int i2 = ClassExampleWithFailure.foo((int) (byte) 1, 2007040000);
        org.junit.Assert.assertTrue(i2 == (-280887296));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test491");
        int i1 = ClassExampleWithFailure.twice(1708392448);
        org.junit.Assert.assertTrue(i1 == (-878182400));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test492");
        int i2 = ClassExampleWithFailure.foo((-62720000), 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test493");
        int i2 = ClassExampleWithFailure.foo(268435456, 6208000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test494");
        int i2 = ClassExampleWithFailure.foo((-397934592), 1578106880);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test495");
        int i2 = ClassExampleWithFailure.foo((-234881024), (-1605632000));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test496");
        int i2 = ClassExampleWithFailure.foo(637534208, (-1174405120));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test497");
        int i2 = ClassExampleWithFailure.foo((-200), (-1245708288));
        org.junit.Assert.assertTrue(i2 == 67108864);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test498");
        int i2 = ClassExampleWithFailure.foo(1073741824, (-1986560000));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test499");
        int i1 = ClassExampleWithFailure.twice(1077936128);
        org.junit.Assert.assertTrue(i1 == (-2139095040));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test500");
        int i2 = ClassExampleWithFailure.foo((-400), (-1392771072));
        org.junit.Assert.assertTrue(i2 == 1820327936);
    }
}

