import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class ClassExampleWithFailureRegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        int i2 = ClassExampleWithFailure.foo((-520093696), (-268435456));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        int i2 = ClassExampleWithFailure.foo(1708392448, (-2621440));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        int i2 = ClassExampleWithFailure.foo((-1769996288), (-1));
        org.junit.Assert.assertTrue(i2 == (-754974720));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        int i2 = ClassExampleWithFailure.foo(51200000, 503316480);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        int i2 = ClassExampleWithFailure.foo(0, 1120);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test006");
        int i2 = ClassExampleWithFailure.foo((-280887296), 560);
        org.junit.Assert.assertTrue(i2 == (-1061158912));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test007");
        int i1 = ClassExampleWithFailure.twice(44800);
        org.junit.Assert.assertTrue(i1 == 89600);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        int i2 = ClassExampleWithFailure.foo(1509425152, 1600);
        org.junit.Assert.assertTrue(i2 == (-1677721600));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        int i2 = ClassExampleWithFailure.foo((-292552704), 262144000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        int i1 = ClassExampleWithFailure.twice(917504000);
        org.junit.Assert.assertTrue(i1 == 1835008000);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        int i2 = ClassExampleWithFailure.foo((-17382400), 3104);
        org.junit.Assert.assertTrue(i2 == (-535756800));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        int i2 = ClassExampleWithFailure.foo(5734400, 20);
        org.junit.Assert.assertTrue(i2 == 229376000);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        int i1 = ClassExampleWithFailure.twice(494927872);
        org.junit.Assert.assertTrue(i1 == 989855744);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test014");
        int i2 = ClassExampleWithFailure.foo((-28672000), 1552);
        org.junit.Assert.assertTrue(i2 == 1196425216);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        int i2 = ClassExampleWithFailure.foo((-1600), 1462763520);
        org.junit.Assert.assertTrue(i2 == 671088640);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        int i2 = ClassExampleWithFailure.foo((-22400), 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        int i2 = ClassExampleWithFailure.foo(1476395008, 220200960);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test018");
        int i1 = ClassExampleWithFailure.twice((-1778384896));
        org.junit.Assert.assertTrue(i1 == 738197504);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test019");
        int i2 = ClassExampleWithFailure.foo((-71680), (-17382400));
        org.junit.Assert.assertTrue(i2 == 859832320);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        int i1 = ClassExampleWithFailure.twice((-770703360));
        org.junit.Assert.assertTrue(i1 == (-1541406720));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        int i2 = ClassExampleWithFailure.foo(1056964608, 12544000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test022");
        int i2 = ClassExampleWithFailure.foo(24832, 388);
        org.junit.Assert.assertTrue(i2 == 19269632);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        int i1 = ClassExampleWithFailure.twice((-71680));
        org.junit.Assert.assertTrue(i1 == (-143360));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test024");
        int i2 = ClassExampleWithFailure.foo(2, (-67108864));
        org.junit.Assert.assertTrue(i2 == (-268435456));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        int i2 = ClassExampleWithFailure.foo(0, 32000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        int i2 = ClassExampleWithFailure.foo(268435456, (-800));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        int i2 = ClassExampleWithFailure.foo(2000, 15520);
        org.junit.Assert.assertTrue(i2 == 62080000);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        int i2 = ClassExampleWithFailure.foo((-2013265920), 166400);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        int i2 = ClassExampleWithFailure.foo((-896000), 15520);
        org.junit.Assert.assertTrue(i2 == (-2042036224));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        int i2 = ClassExampleWithFailure.foo((-8192), 405061632);
        org.junit.Assert.assertTrue(i2 == (-805306368));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test031");
        int i2 = ClassExampleWithFailure.foo(1409286144, 1);
        org.junit.Assert.assertTrue(i2 == (-1476395008));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        int i1 = ClassExampleWithFailure.twice(469762048);
        org.junit.Assert.assertTrue(i1 == 939524096);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        int i2 = ClassExampleWithFailure.foo((-1371537408), (-163840));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        int i2 = ClassExampleWithFailure.foo((-1308622848), 2007040000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        int i2 = ClassExampleWithFailure.foo(671088640, 3880);
        org.junit.Assert.assertTrue(i2 == (-2147483648));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        int i2 = ClassExampleWithFailure.foo(1249902592, 1003520000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        int i2 = ClassExampleWithFailure.foo((-131072000), (-2621440));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        int i2 = ClassExampleWithFailure.foo(80704, (-1024));
        org.junit.Assert.assertTrue(i2 == (-165281792));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        int i2 = ClassExampleWithFailure.foo((-40), (-939524096));
        org.junit.Assert.assertTrue(i2 == (-2147483648));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        int i2 = ClassExampleWithFailure.foo(1135214592, 124160000);
        org.junit.Assert.assertTrue(i2 == (-1610612736));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        int i2 = ClassExampleWithFailure.foo((-1451098112), (-880803840));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        int i1 = ClassExampleWithFailure.twice(1123549184);
        org.junit.Assert.assertTrue(i1 == (-2047868928));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        int i1 = ClassExampleWithFailure.twice((-494927872));
        org.junit.Assert.assertTrue(i1 == (-989855744));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test044");
        int i2 = ClassExampleWithFailure.foo(1946157056, (-805306368));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        int i2 = ClassExampleWithFailure.foo(124160000, 35840000);
        org.junit.Assert.assertTrue(i2 == (-1912602624));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        int i2 = ClassExampleWithFailure.foo(0, 512);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        int i2 = ClassExampleWithFailure.foo((-1006632960), (-2147483648));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        int i2 = ClassExampleWithFailure.foo(194, (-1073741824));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test049");
        int i2 = ClassExampleWithFailure.foo(655360, 1426063360);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test050");
        int i2 = ClassExampleWithFailure.foo((-12800000), (int) (byte) 10);
        org.junit.Assert.assertTrue(i2 == (-256000000));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        int i2 = ClassExampleWithFailure.foo(1742733312, (-4000));
        org.junit.Assert.assertTrue(i2 == (-402653184));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        int i2 = ClassExampleWithFailure.foo(665600, 1820327936);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        int i2 = ClassExampleWithFailure.foo(1111490560, (-2071986176));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        int i2 = ClassExampleWithFailure.foo((-1), 5324800);
        org.junit.Assert.assertTrue(i2 == (-10649600));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        int i2 = ClassExampleWithFailure.foo(989855744, (-8192));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        int i2 = ClassExampleWithFailure.foo((-1111490560), (-57344000));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        int i2 = ClassExampleWithFailure.foo(24832, 10);
        org.junit.Assert.assertTrue(i2 == 496640);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        int i2 = ClassExampleWithFailure.foo((-1392771072), 1740177408);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        int i2 = ClassExampleWithFailure.foo((int) (short) 1, 224000);
        org.junit.Assert.assertTrue(i2 == 448000);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        int i1 = ClassExampleWithFailure.twice(1835008000);
        org.junit.Assert.assertTrue(i1 == (-624951296));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        int i1 = ClassExampleWithFailure.twice(210894848);
        org.junit.Assert.assertTrue(i1 == 421789696);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        int i2 = ClassExampleWithFailure.foo((-989855744), (-1322778624));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        int i1 = ClassExampleWithFailure.twice((-301989888));
        org.junit.Assert.assertTrue(i1 == (-603979776));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        int i2 = ClassExampleWithFailure.foo((-512), (-1003520000));
        org.junit.Assert.assertTrue(i2 == 1107296256);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test065");
        int i1 = ClassExampleWithFailure.twice(503316480);
        org.junit.Assert.assertTrue(i1 == 1006632960);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test066");
        int i2 = ClassExampleWithFailure.foo((-1986560000), (-989855744));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test067");
        int i1 = ClassExampleWithFailure.twice((-10649600));
        org.junit.Assert.assertTrue(i1 == (-21299200));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        int i1 = ClassExampleWithFailure.twice(31040);
        org.junit.Assert.assertTrue(i1 == 62080);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        int i2 = ClassExampleWithFailure.foo((-32000), (-763363328));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test070");
        int i2 = ClassExampleWithFailure.foo((-1845493760), 1626079232);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        int i2 = ClassExampleWithFailure.foo((-1322778624), (int) '4');
        org.junit.Assert.assertTrue(i2 == (-130023424));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        int i2 = ClassExampleWithFailure.foo((int) (byte) 100, (-89600));
        org.junit.Assert.assertTrue(i2 == (-17920000));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test073");
        int i2 = ClassExampleWithFailure.foo((-199229440), (-17382400));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        int i2 = ClassExampleWithFailure.foo(872415232, 112000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        int i2 = ClassExampleWithFailure.foo((-2138570752), 49664);
        org.junit.Assert.assertTrue(i2 == 536870912);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        int i1 = ClassExampleWithFailure.twice(448000);
        org.junit.Assert.assertTrue(i1 == 896000);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test077");
        int i2 = ClassExampleWithFailure.foo((-128), (-123731968));
        org.junit.Assert.assertTrue(i2 == 1610612736);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        int i2 = ClassExampleWithFailure.foo(1600, (-1024));
        org.junit.Assert.assertTrue(i2 == (-3276800));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        int i2 = ClassExampleWithFailure.foo(0, 1191182336);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test080");
        int i2 = ClassExampleWithFailure.foo((int) ' ', 64000);
        org.junit.Assert.assertTrue(i2 == 4096000);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        int i2 = ClassExampleWithFailure.foo((-1986560000), 810123264);
        org.junit.Assert.assertTrue(i2 == (-2147483648));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        int i1 = ClassExampleWithFailure.twice(641728512);
        org.junit.Assert.assertTrue(i1 == 1283457024);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        int i2 = ClassExampleWithFailure.foo(49664, 1280000);
        org.junit.Assert.assertTrue(i2 == (-1709178880));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test084");
        int i2 = ClassExampleWithFailure.foo((-64000), 490733568);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test085");
        int i1 = ClassExampleWithFailure.twice(1811939328);
        org.junit.Assert.assertTrue(i1 == (-671088640));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        int i2 = ClassExampleWithFailure.foo(754974720, 268435456);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        int i2 = ClassExampleWithFailure.foo(805306368, 81920);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test088");
        int i2 = ClassExampleWithFailure.foo(1649410048, (-165281792));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        int i1 = ClassExampleWithFailure.twice((-1040187392));
        org.junit.Assert.assertTrue(i1 == (-2080374784));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test090");
        int i2 = ClassExampleWithFailure.foo(8, (-770703360));
        org.junit.Assert.assertTrue(i2 == 553648128);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        int i2 = ClassExampleWithFailure.foo(800, 12544000);
        org.junit.Assert.assertTrue(i2 == (-1404436480));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        int i2 = ClassExampleWithFailure.foo(1224736768, (-1146880000));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        int i2 = ClassExampleWithFailure.foo(201326592, 102400000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test094");
        int i1 = ClassExampleWithFailure.twice(4096000);
        org.junit.Assert.assertTrue(i1 == 8192000);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        int i2 = ClassExampleWithFailure.foo(1090519040, 800);
        org.junit.Assert.assertTrue(i2 == 1073741824);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        int i2 = ClassExampleWithFailure.foo(3104000, (-1042808832));
        org.junit.Assert.assertTrue(i2 == (-268435456));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test097");
        int i2 = ClassExampleWithFailure.foo(134217728, (-1245708288));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        int i1 = ClassExampleWithFailure.twice((-763363328));
        org.junit.Assert.assertTrue(i1 == (-1526726656));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test099");
        int i2 = ClassExampleWithFailure.foo((-150994944), 163840);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        int i2 = ClassExampleWithFailure.foo((-1795162112), 160);
        org.junit.Assert.assertTrue(i2 == 1073741824);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        int i2 = ClassExampleWithFailure.foo((-671088640), 637534208);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        int i2 = ClassExampleWithFailure.foo((-1024), 70);
        org.junit.Assert.assertTrue(i2 == (-143360));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        int i2 = ClassExampleWithFailure.foo((-830472192), (-996147200));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        int i2 = ClassExampleWithFailure.foo((-2024538112), (int) '#');
        org.junit.Assert.assertTrue(i2 == 16252928);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        int i2 = ClassExampleWithFailure.foo(3880, 24832);
        org.junit.Assert.assertTrue(i2 == 192696320);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test106");
        int i1 = ClassExampleWithFailure.twice((-603979776));
        org.junit.Assert.assertTrue(i1 == (-1207959552));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        int i2 = ClassExampleWithFailure.foo(25600000, (-1073741824));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test108");
        int i2 = ClassExampleWithFailure.foo(794624000, 1708392448);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        int i2 = ClassExampleWithFailure.foo((-160), 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test110");
        int i2 = ClassExampleWithFailure.foo((-198967296), (-123731968));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test111");
        int i2 = ClassExampleWithFailure.foo((-2046820352), 200);
        org.junit.Assert.assertTrue(i2 == 1610612736);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test112");
        int i2 = ClassExampleWithFailure.foo(4096000, (-67108864));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        int i2 = ClassExampleWithFailure.foo((-114688000), (-1132462080));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        int i2 = ClassExampleWithFailure.foo(35840000, (-2013265920));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test115");
        int i2 = ClassExampleWithFailure.foo(1740177408, 1120);
        org.junit.Assert.assertTrue(i2 == (-1832910848));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test116");
        int i2 = ClassExampleWithFailure.foo(0, 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test117");
        int i2 = ClassExampleWithFailure.foo((-8000), (-1795162112));
        org.junit.Assert.assertTrue(i2 == (-2147483648));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test118");
        int i2 = ClassExampleWithFailure.foo(1742733312, 870088704);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test119");
        int i2 = ClassExampleWithFailure.foo(32000, (-57344000));
        org.junit.Assert.assertTrue(i2 == (-2113929216));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test120");
        int i2 = ClassExampleWithFailure.foo((-587202560), (-34764800));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test121");
        int i2 = ClassExampleWithFailure.foo(4480000, 12800);
        org.junit.Assert.assertTrue(i2 == (-1276116992));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test122");
        int i1 = ClassExampleWithFailure.twice(6208000);
        org.junit.Assert.assertTrue(i1 == 12416000);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test123");
        int i1 = ClassExampleWithFailure.twice(981467136);
        org.junit.Assert.assertTrue(i1 == 1962934272);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test124");
        int i2 = ClassExampleWithFailure.foo((-5242880), 494927872);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test125");
        int i1 = ClassExampleWithFailure.twice(133120000);
        org.junit.Assert.assertTrue(i1 == 266240000);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test126");
        int i2 = ClassExampleWithFailure.foo(1023410176, (-2080374784));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test127");
        int i2 = ClassExampleWithFailure.foo(1191182336, (-67108864));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test128");
        int i2 = ClassExampleWithFailure.foo(8960000, 194);
        org.junit.Assert.assertTrue(i2 == (-818487296));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test129");
        int i2 = ClassExampleWithFailure.foo((-385875968), (-40));
        org.junit.Assert.assertTrue(i2 == 805306368);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test130");
        int i2 = ClassExampleWithFailure.foo(1308622848, (-2048));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test131");
        int i1 = ClassExampleWithFailure.twice(770703360);
        org.junit.Assert.assertTrue(i1 == 1541406720);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test132");
        int i2 = ClassExampleWithFailure.foo(7760, 1744830464);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test133");
        int i2 = ClassExampleWithFailure.foo(1073741824, (-616562688));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test134");
        int i2 = ClassExampleWithFailure.foo(16252928, 2001207296);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test135");
        int i1 = ClassExampleWithFailure.twice(69529600);
        org.junit.Assert.assertTrue(i1 == 139059200);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test136");
        int i2 = ClassExampleWithFailure.foo((-2), (-1761607680));
        org.junit.Assert.assertTrue(i2 == (-1543503872));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test137");
        int i2 = ClassExampleWithFailure.foo(0, 1552);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test138");
        int i1 = ClassExampleWithFailure.twice(440401920);
        org.junit.Assert.assertTrue(i1 == 880803840);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test139");
        int i2 = ClassExampleWithFailure.foo(99328, 2127560704);
        org.junit.Assert.assertTrue(i2 == (-2147483648));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test140");
        int i2 = ClassExampleWithFailure.foo(1040187392, (-1912602624));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test141");
        int i2 = ClassExampleWithFailure.foo(388, 872415232);
        org.junit.Assert.assertTrue(i2 == (-1610612736));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test142");
        int i2 = ClassExampleWithFailure.foo(641728512, (int) (byte) 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test143");
        int i2 = ClassExampleWithFailure.foo(7760, 1188298752);
        org.junit.Assert.assertTrue(i2 == (-192937984));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test144");
        int i2 = ClassExampleWithFailure.foo((-2048000000), 268435456);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test145");
        int i2 = ClassExampleWithFailure.foo((-199229440), 1120);
        org.junit.Assert.assertTrue(i2 == 402653184);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test146");
        int i2 = ClassExampleWithFailure.foo((-2621440), (-1132462080));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test147");
        int i2 = ClassExampleWithFailure.foo(1042808832, 81920);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test148");
        int i2 = ClassExampleWithFailure.foo((-204800000), (-247463936));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test149");
        int i1 = ClassExampleWithFailure.twice(589824000);
        org.junit.Assert.assertTrue(i1 == 1179648000);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test150");
        int i1 = ClassExampleWithFailure.twice(512000);
        org.junit.Assert.assertTrue(i1 == 1024000);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test151");
        int i2 = ClassExampleWithFailure.foo((-3328000), (-234881024));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test152");
        int i2 = ClassExampleWithFailure.foo(166400, (-1006632960));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test153");
        int i2 = ClassExampleWithFailure.foo(0, (-327680));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test154");
        int i2 = ClassExampleWithFailure.foo((-2621440), 448000);
        org.junit.Assert.assertTrue(i2 == 536870912);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test155");
        int i2 = ClassExampleWithFailure.foo(1331200, (-1107296256));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test156");
        int i2 = ClassExampleWithFailure.foo(62080000, 1954545664);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test157");
        int i1 = ClassExampleWithFailure.twice((-1404436480));
        org.junit.Assert.assertTrue(i1 == 1486094336);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test158");
        int i2 = ClassExampleWithFailure.foo(16, 704643072);
        org.junit.Assert.assertTrue(i2 == 1073741824);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test159");
        int i2 = ClassExampleWithFailure.foo((-67108864), (int) (byte) 100);
        org.junit.Assert.assertTrue(i2 == (-536870912));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test160");
        int i2 = ClassExampleWithFailure.foo((-1486094336), (-301989888));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test161");
        int i2 = ClassExampleWithFailure.foo((-2085617664), 16);
        org.junit.Assert.assertTrue(i2 == 1979711488);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test162");
        int i2 = ClassExampleWithFailure.foo(2007040000, (-165281792));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test163");
        int i2 = ClassExampleWithFailure.foo((-2042036224), 192696320);
        org.junit.Assert.assertTrue(i2 == (-1610612736));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test164");
        int i2 = ClassExampleWithFailure.foo(102400000, (-128));
        org.junit.Assert.assertTrue(i2 == (-444596224));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test165");
        int i1 = ClassExampleWithFailure.twice(1778384896);
        org.junit.Assert.assertTrue(i1 == (-738197504));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test166");
        int i2 = ClassExampleWithFailure.foo(402653184, (-790626304));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test167");
        int i2 = ClassExampleWithFailure.foo(1836056576, (-1442840576));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test168");
        int i2 = ClassExampleWithFailure.foo((-130023424), (-1310720));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test169");
        int i2 = ClassExampleWithFailure.foo((-1541406720), 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test170");
        int i2 = ClassExampleWithFailure.foo(1404436480, (-1146880000));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test171");
        int i2 = ClassExampleWithFailure.foo(685768704, 1578106880);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test172");
        int i2 = ClassExampleWithFailure.foo(266240000, (-1543503872));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test173");
        int i2 = ClassExampleWithFailure.foo((-385875968), (-292552704));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test174");
        int i2 = ClassExampleWithFailure.foo(71680000, 5324800);
        org.junit.Assert.assertTrue(i2 == 1610612736);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test175");
        int i2 = ClassExampleWithFailure.foo(2240000, 123731968);
        org.junit.Assert.assertTrue(i2 == (-2147483648));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test176");
        int i2 = ClassExampleWithFailure.foo(10, (-22400));
        org.junit.Assert.assertTrue(i2 == (-448000));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test177");
        int i2 = ClassExampleWithFailure.foo((-64), (-1551892480));
        org.junit.Assert.assertTrue(i2 == 1073741824);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test178");
        int i2 = ClassExampleWithFailure.foo(0, 1369440256);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test179");
        int i2 = ClassExampleWithFailure.foo((-256000000), 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test180");
        int i2 = ClassExampleWithFailure.foo(1196425216, (-234881024));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test181");
        int i2 = ClassExampleWithFailure.foo((-1040187392), (-1132462080));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test182");
        int i2 = ClassExampleWithFailure.foo((-1832910848), 1331200);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test183");
        int i2 = ClassExampleWithFailure.foo(1551892480, (-896000));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test184");
        int i1 = ClassExampleWithFailure.twice(73400320);
        org.junit.Assert.assertTrue(i1 == 146800640);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test185");
        int i2 = ClassExampleWithFailure.foo((-2042036224), (-896000));
        org.junit.Assert.assertTrue(i2 == (-402653184));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test186");
        int i2 = ClassExampleWithFailure.foo(2080374784, (-1610612736));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test187");
        int i2 = ClassExampleWithFailure.foo(665600, 1224736768);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test188");
        int i2 = ClassExampleWithFailure.foo((-2), 1392771072);
        org.junit.Assert.assertTrue(i2 == (-1276116992));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test189");
        int i2 = ClassExampleWithFailure.foo((-3200), 19269632);
        org.junit.Assert.assertTrue(i2 == 1228406784);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test190");
        int i1 = ClassExampleWithFailure.twice(1845493760);
        org.junit.Assert.assertTrue(i1 == (-603979776));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test191");
        int i2 = ClassExampleWithFailure.foo((-8000), (-2129920000));
        org.junit.Assert.assertTrue(i2 == (-1845493760));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test192");
        int i2 = ClassExampleWithFailure.foo((-2113929216), (-140));
        org.junit.Assert.assertTrue(i2 == (-805306368));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test193");
        int i2 = ClassExampleWithFailure.foo((-1224736768), 146800640);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test194");
        int i2 = ClassExampleWithFailure.foo(100, 4480);
        org.junit.Assert.assertTrue(i2 == 896000);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test195");
        int i2 = ClassExampleWithFailure.foo(436207616, 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test196");
        int i2 = ClassExampleWithFailure.foo((-1619001344), (-2080374784));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test197");
        int i1 = ClassExampleWithFailure.twice((-1182793728));
        org.junit.Assert.assertTrue(i1 == 1929379840);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test198");
        int i1 = ClassExampleWithFailure.twice((-256000000));
        org.junit.Assert.assertTrue(i1 == (-512000000));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test199");
        int i2 = ClassExampleWithFailure.foo(0, (-770703360));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test200");
        int i1 = ClassExampleWithFailure.twice(62080);
        org.junit.Assert.assertTrue(i1 == 124160);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test201");
        int i1 = ClassExampleWithFailure.twice(2080374784);
        org.junit.Assert.assertTrue(i1 == (-134217728));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test202");
        int i2 = ClassExampleWithFailure.foo(294912000, (-81920));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test203");
        int i2 = ClassExampleWithFailure.foo((-1342177280), 767557632);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test204");
        int i2 = ClassExampleWithFailure.foo(260046848, 247463936);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test205");
        int i2 = ClassExampleWithFailure.foo(332800, 1591738368);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test206");
        int i1 = ClassExampleWithFailure.twice((-896000));
        org.junit.Assert.assertTrue(i1 == (-1792000));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test207");
        int i2 = ClassExampleWithFailure.foo((-1392771072), (-1795162112));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test208");
        int i1 = ClassExampleWithFailure.twice((-1609236480));
        org.junit.Assert.assertTrue(i1 == 1076494336);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test209");
        int i2 = ClassExampleWithFailure.foo(405061632, (-2085617664));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test210");
        int i1 = ClassExampleWithFailure.twice((-878182400));
        org.junit.Assert.assertTrue(i1 == (-1756364800));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test211");
        int i2 = ClassExampleWithFailure.foo((-64000), (-1073741824));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test212");
        int i2 = ClassExampleWithFailure.foo(3200000, 6208000);
        org.junit.Assert.assertTrue(i2 == (-1542455296));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test213");
        int i2 = ClassExampleWithFailure.foo((-989855744), (-256000000));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test214");
        int i1 = ClassExampleWithFailure.twice((-114688000));
        org.junit.Assert.assertTrue(i1 == (-229376000));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test215");
        int i2 = ClassExampleWithFailure.foo((-570425344), 2013265920);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test216");
        int i2 = ClassExampleWithFailure.foo(0, 520093696);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test217");
        int i2 = ClassExampleWithFailure.foo(22400, 80);
        org.junit.Assert.assertTrue(i2 == 3584000);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test218");
        int i1 = ClassExampleWithFailure.twice(2560000);
        org.junit.Assert.assertTrue(i1 == 5120000);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test219");
        int i2 = ClassExampleWithFailure.foo(128000, 770703360);
        org.junit.Assert.assertTrue(i2 == (-2147483648));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test220");
        int i2 = ClassExampleWithFailure.foo((-320), 4587520);
        org.junit.Assert.assertTrue(i2 == 1358954496);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test221");
        int i1 = ClassExampleWithFailure.twice(939524096);
        org.junit.Assert.assertTrue(i1 == 1879048192);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test222");
        int i2 = ClassExampleWithFailure.foo((-1744830464), 80704);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test223");
        int i1 = ClassExampleWithFailure.twice((-124160000));
        org.junit.Assert.assertTrue(i1 == (-248320000));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test224");
        int i2 = ClassExampleWithFailure.foo((-1761607680), (-21299200));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test225");
        int i2 = ClassExampleWithFailure.foo(1224736768, 6400000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test226");
        int i2 = ClassExampleWithFailure.foo((-1486094336), 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test227");
        int i1 = ClassExampleWithFailure.twice((-1756364800));
        org.junit.Assert.assertTrue(i1 == 782237696);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test228");
        int i2 = ClassExampleWithFailure.foo((-385875968), 3104);
        org.junit.Assert.assertTrue(i2 == 1073741824);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test229");
        int i2 = ClassExampleWithFailure.foo((-1486094336), 18350080);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test230");
        int i2 = ClassExampleWithFailure.foo((-1795162112), 560);
        org.junit.Assert.assertTrue(i2 == (-536870912));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test231");
        int i1 = ClassExampleWithFailure.twice(124160);
        org.junit.Assert.assertTrue(i1 == 248320);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test232");
        int i2 = ClassExampleWithFailure.foo(1509425152, 80704);
        org.junit.Assert.assertTrue(i2 == 1275068416);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test233");
        int i2 = ClassExampleWithFailure.foo(89600, (-1769996288));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test234");
        int i2 = ClassExampleWithFailure.foo((-1549271040), 458227712);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test235");
        int i2 = ClassExampleWithFailure.foo((-2024538112), (-1986560000));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test236");
        int i2 = ClassExampleWithFailure.foo(520093696, 512);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test237");
        int i2 = ClassExampleWithFailure.foo((-10649600), (-124160000));
        org.junit.Assert.assertTrue(i2 == (-1476395008));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test238");
        int i2 = ClassExampleWithFailure.foo((-1073741824), 2071986176);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test239");
        int i2 = ClassExampleWithFailure.foo((-573440000), 5324800);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test240");
        int i2 = ClassExampleWithFailure.foo(0, 220200960);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test241");
        int i2 = ClassExampleWithFailure.foo(0, (-409600000));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test242");
        int i2 = ClassExampleWithFailure.foo(1262485504, 12800);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test243");
        int i2 = ClassExampleWithFailure.foo(1421934592, 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test244");
        int i2 = ClassExampleWithFailure.foo((-200), 1742733312);
        org.junit.Assert.assertTrue(i2 == (-1308622848));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test245");
        int i1 = ClassExampleWithFailure.twice(512);
        org.junit.Assert.assertTrue(i1 == 1024);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test246");
        int i2 = ClassExampleWithFailure.foo(251658240, (-44800));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test247");
        int i2 = ClassExampleWithFailure.foo((-143360000), 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test248");
        int i2 = ClassExampleWithFailure.foo((-520093696), 1742733312);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test249");
        int i2 = ClassExampleWithFailure.foo(1929379840, 385351680);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test250");
        int i2 = ClassExampleWithFailure.foo(12800, 89600);
        org.junit.Assert.assertTrue(i2 == (-2001207296));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test251");
        int i1 = ClassExampleWithFailure.twice((-1308622848));
        org.junit.Assert.assertTrue(i1 == 1677721600);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test252");
        int i2 = ClassExampleWithFailure.foo(224000, 44800);
        org.junit.Assert.assertTrue(i2 == (-1404436480));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test253");
        int i1 = ClassExampleWithFailure.twice((-1541406720));
        org.junit.Assert.assertTrue(i1 == 1212153856);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test254");
        int i2 = ClassExampleWithFailure.foo(0, (-1276116992));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test255");
        int i2 = ClassExampleWithFailure.foo(24832, (-830472192));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test256");
        int i2 = ClassExampleWithFailure.foo((-327680), 112000);
        org.junit.Assert.assertTrue(i2 == (-385875968));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test257");
        int i2 = ClassExampleWithFailure.foo(1740177408, 3104);
        org.junit.Assert.assertTrue(i2 == 1178599424);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test258");
        int i1 = ClassExampleWithFailure.twice(1744830464);
        org.junit.Assert.assertTrue(i1 == (-805306368));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test259");
        int i2 = ClassExampleWithFailure.foo(1677721600, (-1107296256));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test260");
        int i1 = ClassExampleWithFailure.twice((-1526726656));
        org.junit.Assert.assertTrue(i1 == 1241513984);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test261");
        int i2 = ClassExampleWithFailure.foo((-1073741824), 1042808832);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test262");
        int i2 = ClassExampleWithFailure.foo((-3276800), 671088640);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test263");
        int i2 = ClassExampleWithFailure.foo(1371537408, 1740177408);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test264");
        int i2 = ClassExampleWithFailure.foo((-1462763520), (-204800000));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test265");
        int i2 = ClassExampleWithFailure.foo((-39845888), 1207959552);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test266");
        int i2 = ClassExampleWithFailure.foo(201326592, 1207959552);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test267");
        int i2 = ClassExampleWithFailure.foo(503316480, (-1549271040));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test268");
        int i1 = ClassExampleWithFailure.twice((-1605632000));
        org.junit.Assert.assertTrue(i1 == 1083703296);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test269");
        int i1 = ClassExampleWithFailure.twice((-409600000));
        org.junit.Assert.assertTrue(i1 == (-819200000));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test270");
        int i2 = ClassExampleWithFailure.foo((-1578106880), (int) ' ');
        org.junit.Assert.assertTrue(i2 == 2080374784);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test271");
        int i2 = ClassExampleWithFailure.foo(2001207296, (-25600000));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test272");
        int i2 = ClassExampleWithFailure.foo((-1174405120), (-199229440));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test273");
        int i2 = ClassExampleWithFailure.foo(400, (-905969664));
        org.junit.Assert.assertTrue(i2 == 1073741824);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test274");
        int i1 = ClassExampleWithFailure.twice(146800640);
        org.junit.Assert.assertTrue(i1 == 293601280);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test275");
        int i1 = ClassExampleWithFailure.twice((-192937984));
        org.junit.Assert.assertTrue(i1 == (-385875968));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test276");
        int i2 = ClassExampleWithFailure.foo(293601280, (int) (short) -1);
        org.junit.Assert.assertTrue(i2 == (-587202560));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test277");
        int i2 = ClassExampleWithFailure.foo(1135214592, 1179648000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test278");
        int i2 = ClassExampleWithFailure.foo((-1174405120), 229376000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test279");
        int i1 = ClassExampleWithFailure.twice(293601280);
        org.junit.Assert.assertTrue(i1 == 587202560);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test280");
        int i2 = ClassExampleWithFailure.foo(1811939328, (int) (short) 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test281");
        int i1 = ClassExampleWithFailure.twice((-248320000));
        org.junit.Assert.assertTrue(i1 == (-496640000));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test282");
        int i2 = ClassExampleWithFailure.foo((-8000), (-1280));
        org.junit.Assert.assertTrue(i2 == 20480000);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test283");
        int i1 = ClassExampleWithFailure.twice(35127296);
        org.junit.Assert.assertTrue(i1 == 70254592);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test284");
        int i2 = ClassExampleWithFailure.foo(166400, 1605632000);
        org.junit.Assert.assertTrue(i2 == 268435456);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test285");
        int i2 = ClassExampleWithFailure.foo((-8192), 220200960);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test286");
        int i2 = ClassExampleWithFailure.foo(1740177408, 77600);
        org.junit.Assert.assertTrue(i2 == (-599785472));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test287");
        int i2 = ClassExampleWithFailure.foo((-496640000), 1188298752);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test288");
        int i2 = ClassExampleWithFailure.foo((int) (short) 1, 201326592);
        org.junit.Assert.assertTrue(i2 == 402653184);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test289");
        int i2 = ClassExampleWithFailure.foo(35127296, 2);
        org.junit.Assert.assertTrue(i2 == 140509184);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test290");
        int i1 = ClassExampleWithFailure.twice((-64000));
        org.junit.Assert.assertTrue(i1 == (-128000));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test291");
        int i2 = ClassExampleWithFailure.foo((-67108864), (-512));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test292");
        int i1 = ClassExampleWithFailure.twice((-1832910848));
        org.junit.Assert.assertTrue(i1 == 629145600);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test293");
        int i1 = ClassExampleWithFailure.twice((-128000));
        org.junit.Assert.assertTrue(i1 == (-256000));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test294");
        int i2 = ClassExampleWithFailure.foo((-1140850688), 1107296256);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test295");
        int i1 = ClassExampleWithFailure.twice((-21299200));
        org.junit.Assert.assertTrue(i1 == (-42598400));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test296");
        int i2 = ClassExampleWithFailure.foo(1371537408, 222298112);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test297");
        int i2 = ClassExampleWithFailure.foo((-795869184), 133120000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test298");
        int i1 = ClassExampleWithFailure.twice(16);
        org.junit.Assert.assertTrue(i1 == 32);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test299");
        int i1 = ClassExampleWithFailure.twice((-1003520000));
        org.junit.Assert.assertTrue(i1 == (-2007040000));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test300");
        int i1 = ClassExampleWithFailure.twice((-2138570752));
        org.junit.Assert.assertTrue(i1 == 17825792);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test301");
        int i2 = ClassExampleWithFailure.foo(448000, (-570425344));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test302");
        int i2 = ClassExampleWithFailure.foo((int) 'a', 3136000);
        org.junit.Assert.assertTrue(i2 == 608384000);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test303");
        int i2 = ClassExampleWithFailure.foo((-28672000), 62080000);
        org.junit.Assert.assertTrue(i2 == (-1811939328));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test304");
        int i1 = ClassExampleWithFailure.twice(1024);
        org.junit.Assert.assertTrue(i1 == 2048);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test305");
        int i2 = ClassExampleWithFailure.foo((-192937984), (-1591738368));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test306");
        int i2 = ClassExampleWithFailure.foo(0, (-20));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test307");
        int i2 = ClassExampleWithFailure.foo(1845493760, 1249902592);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test308");
        int i2 = ClassExampleWithFailure.foo(80, 18350080);
        org.junit.Assert.assertTrue(i2 == (-1358954496));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test309");
        int i2 = ClassExampleWithFailure.foo(641728512, (-1276116992));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test310");
        int i2 = ClassExampleWithFailure.foo(494927872, (-1207959552));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test311");
        int i2 = ClassExampleWithFailure.foo(1371537408, 11468800);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test312");
        int i2 = ClassExampleWithFailure.foo(294912000, 989855744);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test313");
        int i2 = ClassExampleWithFailure.foo((-1462763520), 1083703296);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test314");
        int i1 = ClassExampleWithFailure.twice((-2139095040));
        org.junit.Assert.assertTrue(i1 == 16777216);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test315");
        int i2 = ClassExampleWithFailure.foo((int) (short) 100, (-1182793728));
        org.junit.Assert.assertTrue(i2 == (-335544320));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test316");
        int i2 = ClassExampleWithFailure.foo((-2139095040), 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test317");
        int i2 = ClassExampleWithFailure.foo((-81920), 32);
        org.junit.Assert.assertTrue(i2 == (-5242880));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test318");
        int i2 = ClassExampleWithFailure.foo(44800, (-1761607680));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test319");
        int i1 = ClassExampleWithFailure.twice(1283457024);
        org.junit.Assert.assertTrue(i1 == (-1728053248));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test320");
        int i1 = ClassExampleWithFailure.twice(738197504);
        org.junit.Assert.assertTrue(i1 == 1476395008);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test321");
        int i2 = ClassExampleWithFailure.foo(70, 405061632);
        org.junit.Assert.assertTrue(i2 == 874053632);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test322");
        int i2 = ClassExampleWithFailure.foo(35127296, 1358954496);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test323");
        int i2 = ClassExampleWithFailure.foo(139059200, 2240);
        org.junit.Assert.assertTrue(i2 == 214958080);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test324");
        int i2 = ClassExampleWithFailure.foo(1107296256, 12800);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test325");
        int i2 = ClassExampleWithFailure.foo((-2047868928), 36700160);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test326");
        int i1 = ClassExampleWithFailure.twice((-2001207296));
        org.junit.Assert.assertTrue(i1 == 292552704);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test327");
        int i2 = ClassExampleWithFailure.foo((-342884352), 2000);
        org.junit.Assert.assertTrue(i2 == (-1442840576));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test328");
        int i2 = ClassExampleWithFailure.foo(327680, (-21299200));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test329");
        int i2 = ClassExampleWithFailure.foo((-1207959552), 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test330");
        int i2 = ClassExampleWithFailure.foo(4480, (-1541406720));
        org.junit.Assert.assertTrue(i2 == 1610612736);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test331");
        int i2 = ClassExampleWithFailure.foo((-2), 679215104);
        org.junit.Assert.assertTrue(i2 == 1578106880);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test332");
        int i2 = ClassExampleWithFailure.foo((-1761607680), 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test333");
        int i2 = ClassExampleWithFailure.foo((-1609236480), (-1021018112));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test334");
        int i2 = ClassExampleWithFailure.foo(1310720000, 870088704);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test335");
        int i2 = ClassExampleWithFailure.foo((-260046848), 1578106880);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test336");
        int i2 = ClassExampleWithFailure.foo(1426063360, (-128000));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test337");
        int i2 = ClassExampleWithFailure.foo(248320000, 24832);
        org.junit.Assert.assertTrue(i2 == 1713373184);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test338");
        int i1 = ClassExampleWithFailure.twice(421789696);
        org.junit.Assert.assertTrue(i1 == 843579392);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test339");
        int i1 = ClassExampleWithFailure.twice(655360);
        org.junit.Assert.assertTrue(i1 == 1310720);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test340");
        int i2 = ClassExampleWithFailure.foo((-16000), (-1174405120));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test341");
        int i2 = ClassExampleWithFailure.foo(12800000, (-878182400));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test342");
        int i1 = ClassExampleWithFailure.twice((-256000));
        org.junit.Assert.assertTrue(i1 == (-512000));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test343");
        int i2 = ClassExampleWithFailure.foo(0, (-130023424));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test344");
        int i1 = ClassExampleWithFailure.twice((-268435456));
        org.junit.Assert.assertTrue(i1 == (-536870912));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test345");
        int i2 = ClassExampleWithFailure.foo((-320), 767557632);
        org.junit.Assert.assertTrue(i2 == (-1610612736));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test346");
        int i2 = ClassExampleWithFailure.foo(12800000, (-1061158912));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test347");
        int i2 = ClassExampleWithFailure.foo(1979711488, (-2147483648));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test348");
        int i2 = ClassExampleWithFailure.foo((-402653184), 1845493760);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test349");
        int i2 = ClassExampleWithFailure.foo(1954545664, 12800000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test350");
        int i2 = ClassExampleWithFailure.foo(1708392448, (-42598400));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test351");
        int i2 = ClassExampleWithFailure.foo(3104, 448000);
        org.junit.Assert.assertTrue(i2 == (-1513783296));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test352");
        int i2 = ClassExampleWithFailure.foo(20480000, (-16000));
        org.junit.Assert.assertTrue(i2 == 1769996288);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test353");
        int i1 = ClassExampleWithFailure.twice((-1769996288));
        org.junit.Assert.assertTrue(i1 == 754974720);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test354");
        int i2 = ClassExampleWithFailure.foo(1836056576, 73400320);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test355");
        int i2 = ClassExampleWithFailure.foo(754974720, 214958080);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test356");
        int i1 = ClassExampleWithFailure.twice((-1006632960));
        org.junit.Assert.assertTrue(i1 == (-2013265920));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test357");
        int i2 = ClassExampleWithFailure.foo((-1638400000), 1024000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test358");
        int i2 = ClassExampleWithFailure.foo(469762048, 1249902592);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test359");
        int i2 = ClassExampleWithFailure.foo(490733568, 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test360");
        int i2 = ClassExampleWithFailure.foo(1310720000, (-28672000));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test361");
        int i2 = ClassExampleWithFailure.foo((int) (short) 10, 36700160);
        org.junit.Assert.assertTrue(i2 == 734003200);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test362");
        int i2 = ClassExampleWithFailure.foo(20, (-1526726656));
        org.junit.Assert.assertTrue(i2 == (-939524096));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test363");
        int i2 = ClassExampleWithFailure.foo(608384000, 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test364");
        int i2 = ClassExampleWithFailure.foo((-654311424), (int) (byte) 100);
        org.junit.Assert.assertTrue(i2 == (-2013265920));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test365");
        int i2 = ClassExampleWithFailure.foo(2240000, 1610612736);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test366");
        int i2 = ClassExampleWithFailure.foo(874053632, 1111490560);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test367");
        int i2 = ClassExampleWithFailure.foo(496640, 1083703296);
        org.junit.Assert.assertTrue(i2 == (-1073741824));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test368");
        int i1 = ClassExampleWithFailure.twice((-2113929216));
        org.junit.Assert.assertTrue(i1 == 67108864);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test369");
        int i2 = ClassExampleWithFailure.foo((-4000), (-1912602624));
        org.junit.Assert.assertTrue(i2 == (-2147483648));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test370");
        int i2 = ClassExampleWithFailure.foo(1421934592, (-1363607552));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test371");
        int i1 = ClassExampleWithFailure.twice(16000);
        org.junit.Assert.assertTrue(i1 == 32000);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test372");
        int i2 = ClassExampleWithFailure.foo(1421934592, (-1233125376));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test373");
        int i1 = ClassExampleWithFailure.twice(32);
        org.junit.Assert.assertTrue(i1 == 64);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test374");
        int i2 = ClassExampleWithFailure.foo((-286720000), (-22400));
        org.junit.Assert.assertTrue(i2 == (-1191182336));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test375");
        int i2 = ClassExampleWithFailure.foo((int) (byte) 1, 1845493760);
        org.junit.Assert.assertTrue(i2 == (-603979776));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test376");
        int i2 = ClassExampleWithFailure.foo((-8192), 80);
        org.junit.Assert.assertTrue(i2 == (-1310720));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test377");
        int i2 = ClassExampleWithFailure.foo(1073741824, (-545259520));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test378");
        int i2 = ClassExampleWithFailure.foo((int) '4', 896000);
        org.junit.Assert.assertTrue(i2 == 93184000);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test379");
        int i2 = ClassExampleWithFailure.foo(0, (-114688000));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test380");
        int i2 = ClassExampleWithFailure.foo((-1061158912), 655360000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test381");
        int i2 = ClassExampleWithFailure.foo(2017460224, 8);
        org.junit.Assert.assertTrue(i2 == (-2080374784));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test382");
        int i2 = ClassExampleWithFailure.foo((-2024538112), 292552704);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test383");
        int i2 = ClassExampleWithFailure.foo((-8192), 160);
        org.junit.Assert.assertTrue(i2 == (-2621440));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test384");
        int i2 = ClassExampleWithFailure.foo(293601280, 256000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test385");
        int i2 = ClassExampleWithFailure.foo((-2024538112), (-439040000));
        org.junit.Assert.assertTrue(i2 == 1073741824);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test386");
        int i2 = ClassExampleWithFailure.foo(11468800, (-1132462080));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test387");
        int i1 = ClassExampleWithFailure.twice((-1132462080));
        org.junit.Assert.assertTrue(i1 == 2030043136);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test388");
        int i2 = ClassExampleWithFailure.foo(1929379840, 896000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test389");
        int i1 = ClassExampleWithFailure.twice(16777216);
        org.junit.Assert.assertTrue(i1 == 33554432);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test390");
        int i2 = ClassExampleWithFailure.foo((-280887296), 830472192);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test391");
        int i2 = ClassExampleWithFailure.foo((-229376000), 7760);
        org.junit.Assert.assertTrue(i2 == 612368384);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test392");
        int i1 = ClassExampleWithFailure.twice((-1073741824));
        org.junit.Assert.assertTrue(i1 == (-2147483648));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test393");
        int i1 = ClassExampleWithFailure.twice((-1578106880));
        org.junit.Assert.assertTrue(i1 == 1138753536);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test394");
        int i1 = ClassExampleWithFailure.twice((-292552704));
        org.junit.Assert.assertTrue(i1 == (-585105408));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test395");
        int i2 = ClassExampleWithFailure.foo(0, 1249902592);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test396");
        int i1 = ClassExampleWithFailure.twice((-3200));
        org.junit.Assert.assertTrue(i1 == (-6400));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test397");
        int i2 = ClassExampleWithFailure.foo((-2621440), (-301989888));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test398");
        int i2 = ClassExampleWithFailure.foo((-1138753536), 19600);
        org.junit.Assert.assertTrue(i2 == (-1543503872));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test399");
        int i2 = ClassExampleWithFailure.foo(939524096, 194);
        org.junit.Assert.assertTrue(i2 == (-536870912));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test400");
        int i2 = ClassExampleWithFailure.foo((-28672000), 8192000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test401");
        int i2 = ClassExampleWithFailure.foo(260046848, (-150994944));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test402");
        int i2 = ClassExampleWithFailure.foo(2, (int) ' ');
        org.junit.Assert.assertTrue(i2 == 128);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test403");
        int i1 = ClassExampleWithFailure.twice(140509184);
        org.junit.Assert.assertTrue(i1 == 281018368);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test404");
        int i2 = ClassExampleWithFailure.foo(128000, 1439432704);
        org.junit.Assert.assertTrue(i2 == (-536870912));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test405");
        int i2 = ClassExampleWithFailure.foo(1946157056, (-1732247552));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test406");
        int i2 = ClassExampleWithFailure.foo(80, 32);
        org.junit.Assert.assertTrue(i2 == 5120);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test407");
        int i2 = ClassExampleWithFailure.foo(1090519040, 2013265920);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test408");
        int i2 = ClassExampleWithFailure.foo(70254592, (-6553600));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test409");
        int i2 = ClassExampleWithFailure.foo(248320000, (-2138570752));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test410");
        int i2 = ClassExampleWithFailure.foo(5734400, 1649410048);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test411");
        int i2 = ClassExampleWithFailure.foo(1138753536, (-1207959552));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test412");
        int i1 = ClassExampleWithFailure.twice((-830472192));
        org.junit.Assert.assertTrue(i1 == (-1660944384));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test413");
        int i2 = ClassExampleWithFailure.foo(2080374784, (-439040000));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test414");
        int i2 = ClassExampleWithFailure.foo((-1042808832), 36700160);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test415");
        int i1 = ClassExampleWithFailure.twice(33554432);
        org.junit.Assert.assertTrue(i1 == 67108864);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test416");
        int i2 = ClassExampleWithFailure.foo(321847296, 1392771072);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test417");
        int i2 = ClassExampleWithFailure.foo((-1140850688), (-1761607680));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test418");
        int i2 = ClassExampleWithFailure.foo((-17920), (-69529600));
        org.junit.Assert.assertTrue(i2 == 859832320);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test419");
        int i2 = ClassExampleWithFailure.foo(16252928, 655360000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test420");
        int i2 = ClassExampleWithFailure.foo((-1358954496), (int) (short) 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test421");
        int i2 = ClassExampleWithFailure.foo(981467136, (-1138753536));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test422");
        int i2 = ClassExampleWithFailure.foo(1605632000, 248320);
        org.junit.Assert.assertTrue(i2 == 268435456);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test423");
        int i2 = ClassExampleWithFailure.foo(671088640, 536870912);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test424");
        int i2 = ClassExampleWithFailure.foo((-896000), 6208000);
        org.junit.Assert.assertTrue(i2 == (-770703360));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test425");
        int i1 = ClassExampleWithFailure.twice(1275068416);
        org.junit.Assert.assertTrue(i1 == (-1744830464));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test426");
        int i1 = ClassExampleWithFailure.twice(1056964608);
        org.junit.Assert.assertTrue(i1 == 2113929216);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test427");
        int i2 = ClassExampleWithFailure.foo(192696320, 1111490560);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test428");
        int i2 = ClassExampleWithFailure.foo(1331200, (-2047868928));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test429");
        int i1 = ClassExampleWithFailure.twice((-1761607680));
        org.junit.Assert.assertTrue(i1 == 771751936);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test430");
        int i1 = ClassExampleWithFailure.twice(587202560);
        org.junit.Assert.assertTrue(i1 == 1174405120);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test431");
        int i2 = ClassExampleWithFailure.foo((-247463936), (-192937984));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test432");
        int i1 = ClassExampleWithFailure.twice(830472192);
        org.junit.Assert.assertTrue(i1 == 1660944384);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test433");
        int i2 = ClassExampleWithFailure.foo(629145600, (-494927872));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test434");
        int i2 = ClassExampleWithFailure.foo(1179648000, (-573440000));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test435");
        int i2 = ClassExampleWithFailure.foo(1056964608, 1191182336);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test436");
        int i2 = ClassExampleWithFailure.foo(1174405120, 1836056576);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test437");
        int i1 = ClassExampleWithFailure.twice(458227712);
        org.junit.Assert.assertTrue(i1 == 916455424);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test438");
        int i2 = ClassExampleWithFailure.foo(12544000, 608384000);
        org.junit.Assert.assertTrue(i2 == 843055104);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test439");
        int i2 = ClassExampleWithFailure.foo(62080000, 35840000);
        org.junit.Assert.assertTrue(i2 == (-956301312));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test440");
        int i2 = ClassExampleWithFailure.foo(281018368, 3104);
        org.junit.Assert.assertTrue(i2 == 805306368);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test441");
        int i2 = ClassExampleWithFailure.foo(771751936, (-44800));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test442");
        int i1 = ClassExampleWithFailure.twice(1083703296);
        org.junit.Assert.assertTrue(i1 == (-2127560704));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test443");
        int i2 = ClassExampleWithFailure.foo((-2013265920), (-1769996288));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test444");
        int i2 = ClassExampleWithFailure.foo((-4000), (-1486094336));
        org.junit.Assert.assertTrue(i2 == 285212672);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test445");
        int i1 = ClassExampleWithFailure.twice((-1358954496));
        org.junit.Assert.assertTrue(i1 == 1577058304);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test446");
        int i2 = ClassExampleWithFailure.foo((-520093696), 4096000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test447");
        int i1 = ClassExampleWithFailure.twice(5120);
        org.junit.Assert.assertTrue(i1 == 10240);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test448");
        int i2 = ClassExampleWithFailure.foo((-1526726656), 2113929216);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test449");
        int i1 = ClassExampleWithFailure.twice(67108864);
        org.junit.Assert.assertTrue(i1 == 134217728);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test450");
        int i1 = ClassExampleWithFailure.twice((-771751936));
        org.junit.Assert.assertTrue(i1 == (-1543503872));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test451");
        int i2 = ClassExampleWithFailure.foo(2127560704, (-17920));
        org.junit.Assert.assertTrue(i2 == 1073741824);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test452");
        int i2 = ClassExampleWithFailure.foo(123731968, 12800000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test453");
        int i2 = ClassExampleWithFailure.foo((-1769996288), 163840);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test454");
        int i1 = ClassExampleWithFailure.twice(754974720);
        org.junit.Assert.assertTrue(i1 == 1509949440);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test455");
        int i2 = ClassExampleWithFailure.foo((-1182793728), 1954545664);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test456");
        int i2 = ClassExampleWithFailure.foo(49664, (-866123776));
        org.junit.Assert.assertTrue(i2 == (-2147483648));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test457");
        int i2 = ClassExampleWithFailure.foo((-280), (-102400000));
        org.junit.Assert.assertTrue(i2 == 1509425152);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test458");
        int i2 = ClassExampleWithFailure.foo(19269632, (-640));
        org.junit.Assert.assertTrue(i2 == 1104674816);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test459");
        int i2 = ClassExampleWithFailure.foo(124160, (-494927872));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test460");
        int i2 = ClassExampleWithFailure.foo(704643072, (-143360));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test461");
        int i2 = ClassExampleWithFailure.foo(1188298752, (-1462763520));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test462");
        int i2 = ClassExampleWithFailure.foo((-198967296), 7760);
        org.junit.Assert.assertTrue(i2 == 109051904);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test463");
        int i2 = ClassExampleWithFailure.foo((-268435456), (-439040000));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test464");
        int i2 = ClassExampleWithFailure.foo(247463936, (-89600));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test465");
        int i1 = ClassExampleWithFailure.twice((-1542455296));
        org.junit.Assert.assertTrue(i1 == 1210056704);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test466");
        int i1 = ClassExampleWithFailure.twice((-512000));
        org.junit.Assert.assertTrue(i1 == (-1024000));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test467");
        int i2 = ClassExampleWithFailure.foo((-2013265920), 1543503872);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test468");
        int i1 = ClassExampleWithFailure.twice((-165281792));
        org.junit.Assert.assertTrue(i1 == (-330563584));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test469");
        int i2 = ClassExampleWithFailure.foo((-599785472), (-1369440256));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test470");
        int i1 = ClassExampleWithFailure.twice(143360000);
        org.junit.Assert.assertTrue(i1 == 286720000);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test471");
        int i2 = ClassExampleWithFailure.foo((-2127560704), 402653184);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test472");
        int i2 = ClassExampleWithFailure.foo((-2080374784), 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test473");
        int i2 = ClassExampleWithFailure.foo((-114688000), 10240);
        org.junit.Assert.assertTrue(i2 == 536870912);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test474");
        int i2 = ClassExampleWithFailure.foo(405061632, (-622854144));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test475");
        int i2 = ClassExampleWithFailure.foo(248320, (-409600));
        org.junit.Assert.assertTrue(i2 == (-1560281088));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test476");
        int i2 = ClassExampleWithFailure.foo(810123264, 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test477");
        int i1 = ClassExampleWithFailure.twice(248320);
        org.junit.Assert.assertTrue(i1 == 496640);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test478");
        int i1 = ClassExampleWithFailure.twice((-2080374784));
        org.junit.Assert.assertTrue(i1 == 134217728);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test479");
        int i1 = ClassExampleWithFailure.twice((-819200000));
        org.junit.Assert.assertTrue(i1 == (-1638400000));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test480");
        int i2 = ClassExampleWithFailure.foo((-12800000), 1077936128);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test481");
        int i1 = ClassExampleWithFailure.twice(214958080);
        org.junit.Assert.assertTrue(i1 == 429916160);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test482");
        int i2 = ClassExampleWithFailure.foo(1742733312, 385351680);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test483");
        int i2 = ClassExampleWithFailure.foo((-44800), 770703360);
        org.junit.Assert.assertTrue(i2 == (-536870912));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test484");
        int i2 = ClassExampleWithFailure.foo((-165281792), (-1308622848));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test485");
        int i2 = ClassExampleWithFailure.foo((-114688000), (-89600));
        org.junit.Assert.assertTrue(i2 == 671088640);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test486");
        int i2 = ClassExampleWithFailure.foo(400, (-260046848));
        org.junit.Assert.assertTrue(i2 == (-1879048192));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test487");
        int i2 = ClassExampleWithFailure.foo(16, (-1778384896));
        org.junit.Assert.assertTrue(i2 == (-1073741824));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test488");
        int i2 = ClassExampleWithFailure.foo(133120000, 24832);
        org.junit.Assert.assertTrue(i2 == 1317011456);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test489");
        int i2 = ClassExampleWithFailure.foo(16, (-1619001344));
        org.junit.Assert.assertTrue(i2 == (-268435456));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test490");
        int i2 = ClassExampleWithFailure.foo((-585105408), 587202560);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test491");
        int i1 = ClassExampleWithFailure.twice(3880);
        org.junit.Assert.assertTrue(i1 == 7760);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test492");
        int i2 = ClassExampleWithFailure.foo(80704, (int) (byte) 1);
        org.junit.Assert.assertTrue(i2 == 161408);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test493");
        int i2 = ClassExampleWithFailure.foo((-134217728), 1207959552);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test494");
        int i2 = ClassExampleWithFailure.foo(262144000, (-1526726656));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test495");
        int i1 = ClassExampleWithFailure.twice(1358954496);
        org.junit.Assert.assertTrue(i1 == (-1577058304));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test496");
        int i2 = ClassExampleWithFailure.foo(794624000, (-1792000));
        org.junit.Assert.assertTrue(i2 == 268435456);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test497");
        int i2 = ClassExampleWithFailure.foo((-1795162112), 1107296256);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test498");
        int i2 = ClassExampleWithFailure.foo(0, 18350080);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test499");
        int i1 = ClassExampleWithFailure.twice(1541406720);
        org.junit.Assert.assertTrue(i1 == (-1212153856));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test500");
        int i2 = ClassExampleWithFailure.foo(469762048, 201326592);
        org.junit.Assert.assertTrue(i2 == 0);
    }
}

