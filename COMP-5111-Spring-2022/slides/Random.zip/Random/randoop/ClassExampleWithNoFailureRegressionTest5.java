import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class ClassExampleWithNoFailureRegressionTest5 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test001");
        int i2 = ClassExampleWithNoFailure.foo(162004992, 17825792);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test002");
        int i2 = ClassExampleWithNoFailure.foo((-523390976), 1811939328);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test003");
        int i2 = ClassExampleWithNoFailure.foo(2069423617, 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test004");
        int i1 = ClassExampleWithNoFailure.twice((-1591668736));
        org.junit.Assert.assertTrue(i1 == 553648128);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test005");
        int i2 = ClassExampleWithNoFailure.foo(0, 1589638544);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test006");
        int i2 = ClassExampleWithNoFailure.foo((-1428083935), 357564672);
        org.junit.Assert.assertTrue(i2 == (-815120128));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test007");
        int i2 = ClassExampleWithNoFailure.foo((-1849706352), (-2147483648));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test008");
        int i2 = ClassExampleWithNoFailure.foo((-862978048), (-2103930880));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test009");
        int i1 = ClassExampleWithNoFailure.twice((-1130716928));
        org.junit.Assert.assertTrue(i1 == 423690240);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test010");
        int i1 = ClassExampleWithNoFailure.twice(1035286657);
        org.junit.Assert.assertTrue(i1 == 1826795777);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test011");
        int i1 = ClassExampleWithNoFailure.twice((-1850218879));
        org.junit.Assert.assertTrue(i1 == 2113539329);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test012");
        int i1 = ClassExampleWithNoFailure.twice(824501248);
        org.junit.Assert.assertTrue(i1 == (-351272960));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test013");
        int i2 = ClassExampleWithNoFailure.foo(1234478737, 1696858112);
        org.junit.Assert.assertTrue(i2 == 1101266944);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test014");
        int i2 = ClassExampleWithNoFailure.foo((-635371520), 1368522752);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test015");
        int i1 = ClassExampleWithNoFailure.twice(1428226048);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test016");
        int i2 = ClassExampleWithNoFailure.foo((-1361378928), 989855744);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test017");
        int i2 = ClassExampleWithNoFailure.foo(261095424, 1586316288);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test018");
        int i2 = ClassExampleWithNoFailure.foo(197787648, 1504772096);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test019");
        int i1 = ClassExampleWithNoFailure.twice((-1525678080));
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test020");
        int i2 = ClassExampleWithNoFailure.foo((-552599552), (-1484173664));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test021");
        int i2 = ClassExampleWithNoFailure.foo(5200, (int) 'a');
        org.junit.Assert.assertTrue(i2 == (-1672087296));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test022");
        int i2 = ClassExampleWithNoFailure.foo(318828289, 9437184);
        org.junit.Assert.assertTrue(i2 == (-527433728));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test023");
        int i1 = ClassExampleWithNoFailure.twice(1771835392);
        org.junit.Assert.assertTrue(i1 == (-2130706432));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test024");
        int i2 = ClassExampleWithNoFailure.foo(730071040, 1616513409);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test025");
        int i2 = ClassExampleWithNoFailure.foo(262993508, 3500);
        org.junit.Assert.assertTrue(i2 == (-1252634944));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test026");
        int i2 = ClassExampleWithNoFailure.foo((-770703360), 1421123584);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test027");
        int i1 = ClassExampleWithNoFailure.twice((-1042251199));
        org.junit.Assert.assertTrue(i1 == 906368129);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test028");
        int i2 = ClassExampleWithNoFailure.foo(126877696, (-1116667904));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test029");
        int i2 = ClassExampleWithNoFailure.foo(227672064, (-1214017143));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test030");
        int i2 = ClassExampleWithNoFailure.foo(1586316288, (-251658240));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test031");
        int i2 = ClassExampleWithNoFailure.foo(260636672, (-1740636160));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test032");
        int i2 = ClassExampleWithNoFailure.foo((-815120128), (-612289887));
        org.junit.Assert.assertTrue(i2 == (-417267712));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test033");
        int i1 = ClassExampleWithNoFailure.twice(2070525089);
        org.junit.Assert.assertTrue(i1 == 1636093249);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test034");
        int i2 = ClassExampleWithNoFailure.foo(35, 982515712);
        org.junit.Assert.assertTrue(i2 == 990904320);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test035");
        int i2 = ClassExampleWithNoFailure.foo(1752181121, 851705856);
        org.junit.Assert.assertTrue(i2 == (-1094451200));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test036");
        int i2 = ClassExampleWithNoFailure.foo(1722810368, (-550170624));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test037");
        int i2 = ClassExampleWithNoFailure.foo(0, (int) ' ');
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test038");
        int i2 = ClassExampleWithNoFailure.foo((-832684032), 2145204480);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test039");
        int i1 = ClassExampleWithNoFailure.twice(1594963201);
        org.junit.Assert.assertTrue(i1 == (-753178111));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test040");
        int i2 = ClassExampleWithNoFailure.foo((-2024982476), 1946157056);
        org.junit.Assert.assertTrue(i2 == 1073741824);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test041");
        int i2 = ClassExampleWithNoFailure.foo(26517361, 937689088);
        org.junit.Assert.assertTrue(i2 == 2070151168);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test042");
        int i2 = ClassExampleWithNoFailure.foo(1778974720, 1094254592);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test043");
        int i2 = ClassExampleWithNoFailure.foo((-1092323567), (-435093504));
        org.junit.Assert.assertTrue(i2 == 1731264512);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test044");
        int i1 = ClassExampleWithNoFailure.twice((-1996467199));
        org.junit.Assert.assertTrue(i1 == 764454913);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test045");
        int i2 = ClassExampleWithNoFailure.foo((-369813248), 1030291456);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test046");
        int i2 = ClassExampleWithNoFailure.foo((-406241039), 325452032);
        org.junit.Assert.assertTrue(i2 == 67690752);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test047");
        int i2 = ClassExampleWithNoFailure.foo((-788492288), 2051080192);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test048");
        int i1 = ClassExampleWithNoFailure.twice(1751718432);
        org.junit.Assert.assertTrue(i1 == 1894417408);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test049");
        int i2 = ClassExampleWithNoFailure.foo(1214017143, (-304021504));
        org.junit.Assert.assertTrue(i2 == 1597046784);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test050");
        int i2 = ClassExampleWithNoFailure.foo((-438499664), 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test051");
        int i2 = ClassExampleWithNoFailure.foo(1201513025, 262237011);
        org.junit.Assert.assertTrue(i2 == 507400403);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test052");
        int i2 = ClassExampleWithNoFailure.foo(614440979, (-1407188992));
        org.junit.Assert.assertTrue(i2 == (-1189085184));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test053");
        int i2 = ClassExampleWithNoFailure.foo((int) (short) 1, (-243728384));
        org.junit.Assert.assertTrue(i2 == (-243728384));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test054");
        int i2 = ClassExampleWithNoFailure.foo(67690752, (-679215104));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test055");
        int i2 = ClassExampleWithNoFailure.foo(513708288, (-926567471));
        org.junit.Assert.assertTrue(i2 == (-604962816));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test056");
        int i2 = ClassExampleWithNoFailure.foo(90898432, 90898432);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test057");
        int i2 = ClassExampleWithNoFailure.foo((-1610612736), (-257146815));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test058");
        int i2 = ClassExampleWithNoFailure.foo((-1484173664), (-1249572525));
        org.junit.Assert.assertTrue(i2 == (-687019008));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test059");
        int i2 = ClassExampleWithNoFailure.foo(2131296256, 42875);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test060");
        int i2 = ClassExampleWithNoFailure.foo((-2057847615), (-1029033728));
        org.junit.Assert.assertTrue(i2 == 1299951872);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test061");
        int i2 = ClassExampleWithNoFailure.foo(426508288, 764454913);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test062");
        int i2 = ClassExampleWithNoFailure.foo(953554305, 1000);
        org.junit.Assert.assertTrue(i2 == 1714551784);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test063");
        int i2 = ClassExampleWithNoFailure.foo(1199767552, (-1560281088));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test064");
        int i2 = ClassExampleWithNoFailure.foo((-552599552), (-1861554271));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test065");
        int i2 = ClassExampleWithNoFailure.foo(513708288, (-579585119));
        org.junit.Assert.assertTrue(i2 == (-1111425024));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test066");
        int i2 = ClassExampleWithNoFailure.foo((-2118381568), (-1765801984));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test067");
        int i1 = ClassExampleWithNoFailure.twice(614440979);
        org.junit.Assert.assertTrue(i1 == (-1817067159));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test068");
        int i1 = ClassExampleWithNoFailure.twice((-576513884));
        org.junit.Assert.assertTrue(i1 == (-1959319280));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test069");
        int i2 = ClassExampleWithNoFailure.foo(1714551784, (-1668284416));
        org.junit.Assert.assertTrue(i2 == 1140850688);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test070");
        int i2 = ClassExampleWithNoFailure.foo(1183944704, 987824128);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test071");
        int i1 = ClassExampleWithNoFailure.twice((-553648128));
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test072");
        int i2 = ClassExampleWithNoFailure.foo(1470169088, (-958967552));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test073");
        int i2 = ClassExampleWithNoFailure.foo((-565641216), 260636672);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test074");
        int i2 = ClassExampleWithNoFailure.foo(0, (-804257792));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test075");
        int i2 = ClassExampleWithNoFailure.foo((-1601175552), 172244992);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test076");
        int i2 = ClassExampleWithNoFailure.foo((-173693439), (-1463262976));
        org.junit.Assert.assertTrue(i2 == (-1265344256));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test077");
        int i1 = ClassExampleWithNoFailure.twice(222122240);
        org.junit.Assert.assertTrue(i1 == (-1281294336));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test078");
        int i1 = ClassExampleWithNoFailure.twice(314541809);
        org.junit.Assert.assertTrue(i1 == (-2034290975));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test079");
        int i2 = ClassExampleWithNoFailure.foo((-2121269248), 102400);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test080");
        int i2 = ClassExampleWithNoFailure.foo(989855744, (-746520576));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test081");
        int i1 = ClassExampleWithNoFailure.twice(723811841);
        org.junit.Assert.assertTrue(i1 == 72154113);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test082");
        int i2 = ClassExampleWithNoFailure.foo((-1058996224), (int) (byte) 100);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test083");
        int i2 = ClassExampleWithNoFailure.foo(1542656000, (-199791359));
        org.junit.Assert.assertTrue(i2 == 1627389952);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test084");
        int i2 = ClassExampleWithNoFailure.foo(1579603082, (-771751936));
        org.junit.Assert.assertTrue(i2 == 134217728);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test085");
        int i2 = ClassExampleWithNoFailure.foo(2030043136, (-595853312));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test086");
        int i1 = ClassExampleWithNoFailure.twice((-1817067159));
        org.junit.Assert.assertTrue(i1 == (-1689158383));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test087");
        int i2 = ClassExampleWithNoFailure.foo((-203161600), (-230424576));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test088");
        int i2 = ClassExampleWithNoFailure.foo(52, (-57671680));
        org.junit.Assert.assertTrue(i2 == (-1325400064));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test089");
        int i1 = ClassExampleWithNoFailure.twice(847529872);
        org.junit.Assert.assertTrue(i1 == 545337600);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test090");
        int i2 = ClassExampleWithNoFailure.foo(162004992, 1343225856);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test091");
        int i2 = ClassExampleWithNoFailure.foo((-1163076720), (-861863936));
        org.junit.Assert.assertTrue(i2 == 1358954496);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test092");
        int i2 = ClassExampleWithNoFailure.foo(0, (-523390976));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test093");
        int i2 = ClassExampleWithNoFailure.foo((-632646527), 3312400);
        org.junit.Assert.assertTrue(i2 == 2043419408);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test094");
        int i2 = ClassExampleWithNoFailure.foo(1538326528, (-597194047));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test095");
        int i1 = ClassExampleWithNoFailure.twice((-884998144));
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test096");
        int i2 = ClassExampleWithNoFailure.foo((-1407188992), (-88691952));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test097");
        int i1 = ClassExampleWithNoFailure.twice((-469762048));
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test098");
        int i1 = ClassExampleWithNoFailure.twice((-2103930880));
        org.junit.Assert.assertTrue(i1 == 1358954496);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test099");
        int i2 = ClassExampleWithNoFailure.foo((-2040332288), 1031340032);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test100");
        int i2 = ClassExampleWithNoFailure.foo((-1861554271), (-1632132864));
        org.junit.Assert.assertTrue(i2 == (-1786584832));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test101");
        int i2 = ClassExampleWithNoFailure.foo((-1214017143), (-1354170368));
        org.junit.Assert.assertTrue(i2 == (-1994850304));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test102");
        int i2 = ClassExampleWithNoFailure.foo((-2057043968), (-199791359));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test103");
        int i1 = ClassExampleWithNoFailure.twice(1202671265);
        org.junit.Assert.assertTrue(i1 == (-431718079));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test104");
        int i2 = ClassExampleWithNoFailure.foo((-612289887), (-1428083935));
        org.junit.Assert.assertTrue(i2 == 2120047713);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test105");
        int i1 = ClassExampleWithNoFailure.twice(820920225);
        org.junit.Assert.assertTrue(i1 == (-1087593663));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test106");
        int i1 = ClassExampleWithNoFailure.twice((-1257242624));
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test107");
        int i2 = ClassExampleWithNoFailure.foo((-2054946816), (-1773933103));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test108");
        int i2 = ClassExampleWithNoFailure.foo(1352663040, 2131296256);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test109");
        int i1 = ClassExampleWithNoFailure.twice((-770703360));
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test110");
        int i2 = ClassExampleWithNoFailure.foo((-77978303), (-94224639));
        org.junit.Assert.assertTrue(i2 == 591894913);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test111");
        int i2 = ClassExampleWithNoFailure.foo((-907197440), (-788492288));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test112");
        int i2 = ClassExampleWithNoFailure.foo(1426407121, 1182286848);
        org.junit.Assert.assertTrue(i2 == 1790624768);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test113");
        int i2 = ClassExampleWithNoFailure.foo((-417267712), (-225443840));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test114");
        int i1 = ClassExampleWithNoFailure.twice(2073501569);
        org.junit.Assert.assertTrue(i1 == 604929793);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test115");
        int i2 = ClassExampleWithNoFailure.foo((-1354694656), (-118791455));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test116");
        int i2 = ClassExampleWithNoFailure.foo(1484873985, (-922746880));
        org.junit.Assert.assertTrue(i2 == (-922746880));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test117");
        int i2 = ClassExampleWithNoFailure.foo(3312400, 72154113);
        org.junit.Assert.assertTrue(i2 == (-1589223168));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test118");
        int i2 = ClassExampleWithNoFailure.foo((-511938304), (-2113863680));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test119");
        int i1 = ClassExampleWithNoFailure.twice(38797312);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test120");
        int i1 = ClassExampleWithNoFailure.twice((-1201602560));
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test121");
        int i2 = ClassExampleWithNoFailure.foo((-1694957568), 361775360);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test122");
        int i2 = ClassExampleWithNoFailure.foo(1720010625, (-597070255));
        org.junit.Assert.assertTrue(i2 == (-448860847));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test123");
        int i2 = ClassExampleWithNoFailure.foo((-287041472), 424718336);
        org.junit.Assert.assertTrue(i2 == 1258291200);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test124");
        int i2 = ClassExampleWithNoFailure.foo((-831455232), (-2118381568));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test125");
        int i2 = ClassExampleWithNoFailure.foo((-2103930880), 507400403);
        org.junit.Assert.assertTrue(i2 == (-1023410176));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test126");
        int i2 = ClassExampleWithNoFailure.foo(15006250, (-1029033728));
        org.junit.Assert.assertTrue(i2 == 339846144);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test127");
        int i2 = ClassExampleWithNoFailure.foo(101715968, 936742912);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test128");
        int i2 = ClassExampleWithNoFailure.foo((-251658240), 1426063360);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test129");
        int i2 = ClassExampleWithNoFailure.foo((-881171968), 1275330560);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test130");
        int i2 = ClassExampleWithNoFailure.foo(1580204032, (-208375487));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test131");
        int i1 = ClassExampleWithNoFailure.twice(1538326528);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test132");
        int i1 = ClassExampleWithNoFailure.twice(1889884481);
        org.junit.Assert.assertTrue(i1 == 216547969);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test133");
        int i2 = ClassExampleWithNoFailure.foo(88013056, 1700855808);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test134");
        int i1 = ClassExampleWithNoFailure.twice((-1265344256));
        org.junit.Assert.assertTrue(i1 == 1287716864);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test135");
        int i2 = ClassExampleWithNoFailure.foo((-503316480), (-2035568319));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test136");
        int i1 = ClassExampleWithNoFailure.twice(260636672);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test137");
        int i1 = ClassExampleWithNoFailure.twice((-1776222208));
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test138");
        int i2 = ClassExampleWithNoFailure.foo(168268032, 1040449536);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test139");
        int i1 = ClassExampleWithNoFailure.twice(399179776);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test140");
        int i2 = ClassExampleWithNoFailure.foo(1771835392, 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test141");
        int i2 = ClassExampleWithNoFailure.foo(1995483777, 1184130048);
        org.junit.Assert.assertTrue(i2 == 13132800);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test142");
        int i2 = ClassExampleWithNoFailure.foo((-323944448), (-907197440));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test143");
        int i2 = ClassExampleWithNoFailure.foo((-1189085184), 989855744);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test144");
        int i2 = ClassExampleWithNoFailure.foo((-2062569216), (-1918278384));
        org.junit.Assert.assertTrue(i2 == (-888143872));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test145");
        int i1 = ClassExampleWithNoFailure.twice((-1065840384));
        org.junit.Assert.assertTrue(i1 == 1109458944);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test146");
        int i1 = ClassExampleWithNoFailure.twice((-926567471));
        org.junit.Assert.assertTrue(i1 == (-839389023));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test147");
        int i1 = ClassExampleWithNoFailure.twice(90078337);
        org.junit.Assert.assertTrue(i1 == (-1253492479));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test148");
        int i2 = ClassExampleWithNoFailure.foo((-753178111), (-1604255744));
        org.junit.Assert.assertTrue(i2 == (-194969600));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test149");
        int i1 = ClassExampleWithNoFailure.twice((-1560281088));
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test150");
        int i2 = ClassExampleWithNoFailure.foo(560781924, 1361604097);
        org.junit.Assert.assertTrue(i2 == 1750554384);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test151");
        int i2 = ClassExampleWithNoFailure.foo((-527433728), 302162176);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test152");
        int i1 = ClassExampleWithNoFailure.twice((-199791359));
        org.junit.Assert.assertTrue(i1 == (-1399334399));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test153");
        int i2 = ClassExampleWithNoFailure.foo((-771751936), 1751958048);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test154");
        int i2 = ClassExampleWithNoFailure.foo((-1298976512), 1731264512);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test155");
        int i2 = ClassExampleWithNoFailure.foo(1306719553, 529727488);
        org.junit.Assert.assertTrue(i2 == (-149749760));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test156");
        int i2 = ClassExampleWithNoFailure.foo(1528444521, (-1423900672));
        org.junit.Assert.assertTrue(i2 == (-1271857152));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test157");
        int i2 = ClassExampleWithNoFailure.foo(813760512, 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test158");
        int i2 = ClassExampleWithNoFailure.foo((-435093504), 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test159");
        int i2 = ClassExampleWithNoFailure.foo((-2057043968), 1630230625);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test160");
        int i2 = ClassExampleWithNoFailure.foo(1994653696, 1352663040);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test161");
        int i2 = ClassExampleWithNoFailure.foo((int) (byte) 0, 1736704000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test162");
        int i1 = ClassExampleWithNoFailure.twice((-1200762624));
        org.junit.Assert.assertTrue(i1 == (-1532952576));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test163");
        int i2 = ClassExampleWithNoFailure.foo((-1281605632), (-1114636288));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test164");
        int i1 = ClassExampleWithNoFailure.twice(216547969);
        org.junit.Assert.assertTrue(i1 == (-1290353407));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test165");
        int i2 = ClassExampleWithNoFailure.foo((-273612800), (-605814784));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test166");
        int i1 = ClassExampleWithNoFailure.twice(1277427712);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test167");
        int i2 = ClassExampleWithNoFailure.foo((-1102839808), 879362048);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test168");
        int i2 = ClassExampleWithNoFailure.foo(1163984896, 27040000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test169");
        int i1 = ClassExampleWithNoFailure.twice(545337600);
        org.junit.Assert.assertTrue(i1 == 1801519104);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test170");
        int i2 = ClassExampleWithNoFailure.foo(1214017143, 1753876371);
        org.junit.Assert.assertTrue(i2 == 1057359491);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test171");
        int i2 = ClassExampleWithNoFailure.foo((-714715136), (-1611296799));
        org.junit.Assert.assertTrue(i2 == (-1191182336));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test172");
        int i2 = ClassExampleWithNoFailure.foo(1630994432, (int) '4');
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test173");
        int i2 = ClassExampleWithNoFailure.foo((-888143872), (-1425583260));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test174");
        int i2 = ClassExampleWithNoFailure.foo((-1918156733), (-449079295));
        org.junit.Assert.assertTrue(i2 == (-308287095));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test175");
        int i2 = ClassExampleWithNoFailure.foo(1493172224, 931397632);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test176");
        int i1 = ClassExampleWithNoFailure.twice(951553808);
        org.junit.Assert.assertTrue(i1 == (-657268480));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test177");
        int i2 = ClassExampleWithNoFailure.foo((-318010624), 1761783105);
        org.junit.Assert.assertTrue(i2 == 1622736896);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test178");
        int i2 = ClassExampleWithNoFailure.foo(1095192832, 902037504);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test179");
        int i2 = ClassExampleWithNoFailure.foo(262237011, (-1532952576));
        org.junit.Assert.assertTrue(i2 == (-762773504));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test180");
        int i2 = ClassExampleWithNoFailure.foo(1916019264, 2704);
        org.junit.Assert.assertTrue(i2 == 108593152);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test181");
        int i1 = ClassExampleWithNoFailure.twice((-230424576));
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test182");
        int i2 = ClassExampleWithNoFailure.foo((-173693439), (-605814784));
        org.junit.Assert.assertTrue(i2 == (-1947992064));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test183");
        int i1 = ClassExampleWithNoFailure.twice(122022739);
        org.junit.Assert.assertTrue(i1 == 1024425193);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test184");
        int i2 = ClassExampleWithNoFailure.foo((int) (short) 10, (-1023410176));
        org.junit.Assert.assertTrue(i2 == 738197504);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test185");
        int i2 = ClassExampleWithNoFailure.foo((-475791360), (-2096103424));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test186");
        int i2 = ClassExampleWithNoFailure.foo(1636827136, (-1577058304));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test187");
        int i2 = ClassExampleWithNoFailure.foo((-43471919), 140608);
        org.junit.Assert.assertTrue(i2 == 1240558912);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test188");
        int i2 = ClassExampleWithNoFailure.foo(195563520, (-747569152));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test189");
        int i1 = ClassExampleWithNoFailure.twice((-2113863680));
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test190");
        int i1 = ClassExampleWithNoFailure.twice(1518457985);
        org.junit.Assert.assertTrue(i1 == (-1905792767));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test191");
        int i2 = ClassExampleWithNoFailure.foo(1124073472, (int) (byte) 1);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test192");
        int i2 = ClassExampleWithNoFailure.foo((-1457520640), 1277427712);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test193");
        int i2 = ClassExampleWithNoFailure.foo((-2113863680), 150994944);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test194");
        int i2 = ClassExampleWithNoFailure.foo(560781924, 399655103);
        org.junit.Assert.assertTrue(i2 == (-183577360));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test195");
        int i1 = ClassExampleWithNoFailure.twice(88013056);
        org.junit.Assert.assertTrue(i1 == (-1909391360));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test196");
        int i1 = ClassExampleWithNoFailure.twice((-1786584832));
        org.junit.Assert.assertTrue(i1 == 1237385216);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test197");
        int i2 = ClassExampleWithNoFailure.foo(925131264, (-788492288));
        org.junit.Assert.assertTrue(i2 == 1073741824);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test198");
        int i2 = ClassExampleWithNoFailure.foo((-1457520640), (-149946368));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test199");
        int i1 = ClassExampleWithNoFailure.twice((-1334771712));
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test200");
        int i2 = ClassExampleWithNoFailure.foo(1811939328, (-747569152));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test201");
        int i2 = ClassExampleWithNoFailure.foo(817323152, (-1061781248));
        org.junit.Assert.assertTrue(i2 == (-699334656));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test202");
        int i2 = ClassExampleWithNoFailure.foo((-2034290975), 16777216);
        org.junit.Assert.assertTrue(i2 == (-1056964608));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test203");
        int i2 = ClassExampleWithNoFailure.foo((-1909391360), (-588957183));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test204");
        int i2 = ClassExampleWithNoFailure.foo((-1089716815), 1140850688);
        org.junit.Assert.assertTrue(i2 == (-1006632960));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test205");
        int i2 = ClassExampleWithNoFailure.foo(1594963201, 454033408);
        org.junit.Assert.assertTrue(i2 == (-1156579328));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test206");
        int i1 = ClassExampleWithNoFailure.twice((-2096103424));
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test207");
        int i2 = ClassExampleWithNoFailure.foo((-192329968), 1370554368);
        org.junit.Assert.assertTrue(i2 == (-1862270976));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test208");
        int i2 = ClassExampleWithNoFailure.foo(1073741824, 996409344);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test209");
        int i1 = ClassExampleWithNoFailure.twice(318828289);
        org.junit.Assert.assertTrue(i1 == 86171137);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test210");
        int i2 = ClassExampleWithNoFailure.foo((-438499664), 1845013123);
        org.junit.Assert.assertTrue(i2 == (-178476288));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test211");
        int i2 = ClassExampleWithNoFailure.foo((-458949744), (-1601415295));
        org.junit.Assert.assertTrue(i2 == 2125672704);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test212");
        int i2 = ClassExampleWithNoFailure.foo(258970881, (-2057043968));
        org.junit.Assert.assertTrue(i2 == (-312213504));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test213");
        int i2 = ClassExampleWithNoFailure.foo((-527433728), 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test214");
        int i2 = ClassExampleWithNoFailure.foo((-1505513215), 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test215");
        int i2 = ClassExampleWithNoFailure.foo((-1517289472), (-1632132864));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test216");
        int i2 = ClassExampleWithNoFailure.foo((-1861554271), 325124096);
        org.junit.Assert.assertTrue(i2 == 245432320);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test217");
        int i2 = ClassExampleWithNoFailure.foo(1874919424, (-926262652));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test218");
        int i2 = ClassExampleWithNoFailure.foo(426508288, 1085252433);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test219");
        int i2 = ClassExampleWithNoFailure.foo(1838265625, (-2024982476));
        org.junit.Assert.assertTrue(i2 == 1604353780);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test220");
        int i2 = ClassExampleWithNoFailure.foo(1744830464, (-1829002240));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test221");
        int i2 = ClassExampleWithNoFailure.foo((-148832256), (-1521891072));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test222");
        int i1 = ClassExampleWithNoFailure.twice(2038497280);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test223");
        int i2 = ClassExampleWithNoFailure.foo(945881088, (-2113863680));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test224");
        int i2 = ClassExampleWithNoFailure.foo(139903232, (-653262848));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test225");
        int i1 = ClassExampleWithNoFailure.twice(1370554368);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test226");
        int i1 = ClassExampleWithNoFailure.twice(1224736768);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test227");
        int i2 = ClassExampleWithNoFailure.foo((-323944448), 813760512);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test228");
        int i2 = ClassExampleWithNoFailure.foo((-1161530727), (-1257242624));
        org.junit.Assert.assertTrue(i2 == (-602931200));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test229");
        int i2 = ClassExampleWithNoFailure.foo(1500625000, (-192329968));
        org.junit.Assert.assertTrue(i2 == 416441344);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test230");
        int i1 = ClassExampleWithNoFailure.twice(1013006592);
        org.junit.Assert.assertTrue(i1 == 1384185856);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test231");
        int i2 = ClassExampleWithNoFailure.foo((-964543103), 1898708992);
        org.junit.Assert.assertTrue(i2 == (-1792278528));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test232");
        int i2 = ClassExampleWithNoFailure.foo(423690240, 1549088097);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test233");
        int i2 = ClassExampleWithNoFailure.foo((-1752181121), 730071040);
        org.junit.Assert.assertTrue(i2 == (-142344192));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test234");
        int i2 = ClassExampleWithNoFailure.foo(0, (-1744163599));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test235");
        int i1 = ClassExampleWithNoFailure.twice(1292894208);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test236");
        int i2 = ClassExampleWithNoFailure.foo(1366606080, (-904437248));
        org.junit.Assert.assertTrue(i2 == 1644167168);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test237");
        int i1 = ClassExampleWithNoFailure.twice(1035468432);
        org.junit.Assert.assertTrue(i1 == (-1895689984));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test238");
        int i1 = ClassExampleWithNoFailure.twice(1352663040);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test239");
        int i1 = ClassExampleWithNoFailure.twice(2113539329);
        org.junit.Assert.assertTrue(i1 == 1620908545);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test240");
        int i2 = ClassExampleWithNoFailure.foo((-510254796), 1677721600);
        org.junit.Assert.assertTrue(i2 == 1073741824);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test241");
        int i2 = ClassExampleWithNoFailure.foo(113101777, (-1682174335));
        org.junit.Assert.assertTrue(i2 == 1970552609);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test242");
        int i2 = ClassExampleWithNoFailure.foo((-4328191), (-1970240447));
        org.junit.Assert.assertTrue(i2 == 476573249);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test243");
        int i2 = ClassExampleWithNoFailure.foo((-1253492479), (-727379968));
        org.junit.Assert.assertTrue(i2 == (-2050682880));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test244");
        int i2 = ClassExampleWithNoFailure.foo(1173917952, 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test245");
        int i1 = ClassExampleWithNoFailure.twice((-511938304));
        org.junit.Assert.assertTrue(i1 == (-1444872192));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test246");
        int i2 = ClassExampleWithNoFailure.foo((-318010624), 17825792);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test247");
        int i2 = ClassExampleWithNoFailure.foo((-2121269248), (-597194047));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test248");
        int i2 = ClassExampleWithNoFailure.foo(339846144, (-1240965599));
        org.junit.Assert.assertTrue(i2 == (-1290797056));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test249");
        int i1 = ClassExampleWithNoFailure.twice((-1423900672));
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test250");
        int i2 = ClassExampleWithNoFailure.foo((-335544320), (-1399334399));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test251");
        int i2 = ClassExampleWithNoFailure.foo((-1343160320), 1580204032);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test252");
        int i2 = ClassExampleWithNoFailure.foo((-839389023), (-1971257344));
        org.junit.Assert.assertTrue(i2 == (-272564224));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test253");
        int i1 = ClassExampleWithNoFailure.twice(906035200);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test254");
        int i2 = ClassExampleWithNoFailure.foo(1636827136, (-1533187072));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test255");
        int i2 = ClassExampleWithNoFailure.foo(1500625000, 74186752);
        org.junit.Assert.assertTrue(i2 == (-754974720));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test256");
        int i2 = ClassExampleWithNoFailure.foo((-884998144), 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test257");
        int i2 = ClassExampleWithNoFailure.foo((-544210944), 604929793);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test258");
        int i1 = ClassExampleWithNoFailure.twice((-1114636288));
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test259");
        int i2 = ClassExampleWithNoFailure.foo(1214017143, (-10099712));
        org.junit.Assert.assertTrue(i2 == 1271473152);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test260");
        int i2 = ClassExampleWithNoFailure.foo((-895418368), 1894417408);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test261");
        int i2 = ClassExampleWithNoFailure.foo(52521875, 1753876371);
        org.junit.Assert.assertTrue(i2 == 69475659);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test262");
        int i2 = ClassExampleWithNoFailure.foo(1604353780, 1134624768);
        org.junit.Assert.assertTrue(i2 == 579862528);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test263");
        int i2 = ClassExampleWithNoFailure.foo(1885020416, (-804257792));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test264");
        int i2 = ClassExampleWithNoFailure.foo((-734003200), 1237385216);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test265");
        int i2 = ClassExampleWithNoFailure.foo((int) (byte) 10, 74186752);
        org.junit.Assert.assertTrue(i2 == (-1171259392));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test266");
        int i1 = ClassExampleWithNoFailure.twice((-2094989312));
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test267");
        int i2 = ClassExampleWithNoFailure.foo((-510254796), (-10099712));
        org.junit.Assert.assertTrue(i2 == 1087913984);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test268");
        int i2 = ClassExampleWithNoFailure.foo((-1905792767), (-1811939328));
        org.junit.Assert.assertTrue(i2 == (-1811939328));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test269");
        int i2 = ClassExampleWithNoFailure.foo((-1895689984), 75433104);
        org.junit.Assert.assertTrue(i2 == 1720713216);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test270");
        int i2 = ClassExampleWithNoFailure.foo(1421307209, (-2052034783));
        org.junit.Assert.assertTrue(i2 == 10074097);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test271");
        int i1 = ClassExampleWithNoFailure.twice((-1171259392));
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test272");
        int i2 = ClassExampleWithNoFailure.foo((-385875968), 26214400);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test273");
        int i2 = ClassExampleWithNoFailure.foo((-1026555904), 1040449536);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test274");
        int i2 = ClassExampleWithNoFailure.foo((-1484173664), 1995483777);
        org.junit.Assert.assertTrue(i2 == 465560576);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test275");
        int i1 = ClassExampleWithNoFailure.twice((-1672087296));
        org.junit.Assert.assertTrue(i1 == 1278279680);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test276");
        int i2 = ClassExampleWithNoFailure.foo(285212672, (-425530304));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test277");
        int i2 = ClassExampleWithNoFailure.foo(1057359491, (-194772992));
        org.junit.Assert.assertTrue(i2 == (-746323968));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test278");
        int i2 = ClassExampleWithNoFailure.foo((-1092323567), (-1786584832));
        org.junit.Assert.assertTrue(i2 == (-1043463936));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test279");
        int i2 = ClassExampleWithNoFailure.foo((-291445760), 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test280");
        int i2 = ClassExampleWithNoFailure.foo(798162944, 448987136);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test281");
        int i2 = ClassExampleWithNoFailure.foo((-2050770688), (-832684032));
        org.junit.Assert.assertTrue(i2 == 1073741824);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test282");
        int i1 = ClassExampleWithNoFailure.twice(730071040);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test283");
        int i2 = ClassExampleWithNoFailure.foo((-1274019840), (-1354694656));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test284");
        int i2 = ClassExampleWithNoFailure.foo((-304021504), 492896256);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test285");
        int i2 = ClassExampleWithNoFailure.foo((-2001666048), 1370554368);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test286");
        int i2 = ClassExampleWithNoFailure.foo(1002504192, 88013056);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test287");
        int i2 = ClassExampleWithNoFailure.foo(88013056, 1209809569);
        org.junit.Assert.assertTrue(i2 == (-2033123328));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test288");
        int i2 = ClassExampleWithNoFailure.foo((-1913566464), (-784436992));
        org.junit.Assert.assertTrue(i2 == (-385875968));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test289");
        int i2 = ClassExampleWithNoFailure.foo((-964543103), (-1415505152));
        org.junit.Assert.assertTrue(i2 == (-1470489856));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test290");
        int i2 = ClassExampleWithNoFailure.foo((-1932703232), (-1964084223));
        org.junit.Assert.assertTrue(i2 == (-379322368));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test291");
        int i2 = ClassExampleWithNoFailure.foo((-1290353407), (-318010624));
        org.junit.Assert.assertTrue(i2 == (-1476818176));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test292");
        int i1 = ClassExampleWithNoFailure.twice((-1765801984));
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test293");
        int i2 = ClassExampleWithNoFailure.foo((-149749760), (-1298976512));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test294");
        int i2 = ClassExampleWithNoFailure.foo(448987136, 813760512);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test295");
        int i2 = ClassExampleWithNoFailure.foo(1167720448, (-1476818176));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test296");
        int i1 = ClassExampleWithNoFailure.twice(838860800);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test297");
        int i2 = ClassExampleWithNoFailure.foo(67108864, (-149502976));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test298");
        int i2 = ClassExampleWithNoFailure.foo(1477443584, (-576513884));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test299");
        int i1 = ClassExampleWithNoFailure.twice((-1493172224));
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test300");
        int i2 = ClassExampleWithNoFailure.foo((-527433728), 139903232);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test301");
        int i2 = ClassExampleWithNoFailure.foo((-1392443392), 132845824);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test302");
        int i2 = ClassExampleWithNoFailure.foo(1175453696, (-1781989376));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test303");
        int i1 = ClassExampleWithNoFailure.twice((-448860847));
        org.junit.Assert.assertTrue(i1 == (-1187310687));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test304");
        int i2 = ClassExampleWithNoFailure.foo((-935788544), (-1243545600));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test305");
        int i1 = ClassExampleWithNoFailure.twice((-1293680640));
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test306");
        int i2 = ClassExampleWithNoFailure.foo((-1543503872), 69206016);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test307");
        int i2 = ClassExampleWithNoFailure.foo((-1293680640), 1752181121);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test308");
        int i2 = ClassExampleWithNoFailure.foo((-234364416), 2060289199);
        org.junit.Assert.assertTrue(i2 == 1463549952);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test309");
        int i2 = ClassExampleWithNoFailure.foo(118825, 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test310");
        int i2 = ClassExampleWithNoFailure.foo((-194969600), (-1459617792));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test311");
        int i2 = ClassExampleWithNoFailure.foo(0, 1349054657);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test312");
        int i1 = ClassExampleWithNoFailure.twice((-689755839));
        org.junit.Assert.assertTrue(i1 == (-605298047));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test313");
        int i2 = ClassExampleWithNoFailure.foo((-1061781248), 1124073472);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test314");
        int i1 = ClassExampleWithNoFailure.twice(1736704000);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test315");
        int i2 = ClassExampleWithNoFailure.foo((-1148954864), 1771835392);
        org.junit.Assert.assertTrue(i2 == (-636485632));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test316");
        int i2 = ClassExampleWithNoFailure.foo(239928529, (-1290353407));
        org.junit.Assert.assertTrue(i2 == (-1432545375));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test317");
        int i2 = ClassExampleWithNoFailure.foo((-148832256), 35);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test318");
        int i1 = ClassExampleWithNoFailure.twice((-1694957568));
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test319");
        int i2 = ClassExampleWithNoFailure.foo((-2052034783), (-1026555904));
        org.junit.Assert.assertTrue(i2 == 382730240);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test320");
        int i2 = ClassExampleWithNoFailure.foo((-1470489856), (-1419182080));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test321");
        int i2 = ClassExampleWithNoFailure.foo((-1913566464), 939786240);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test322");
        int i2 = ClassExampleWithNoFailure.foo((-511938304), (-1742471168));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test323");
        int i2 = ClassExampleWithNoFailure.foo((-1029033728), 1124715575);
        org.junit.Assert.assertTrue(i2 == (-1680408576));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test324");
        int i2 = ClassExampleWithNoFailure.foo((-1176629248), 515141888);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test325");
        int i2 = ClassExampleWithNoFailure.foo((-925057023), (-597070255));
        org.junit.Assert.assertTrue(i2 == (-1122308527));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test326");
        int i2 = ClassExampleWithNoFailure.foo((-586313728), 3500);
        org.junit.Assert.assertTrue(i2 == (-335544320));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test327");
        int i2 = ClassExampleWithNoFailure.foo(7311616, (-226657520));
        org.junit.Assert.assertTrue(i2 == (-586153984));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test328");
        int i2 = ClassExampleWithNoFailure.foo((int) (byte) -1, (-1130716928));
        org.junit.Assert.assertTrue(i2 == (-1130716928));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test329");
        int i2 = ClassExampleWithNoFailure.foo(2125672704, 1278279680);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test330");
        int i2 = ClassExampleWithNoFailure.foo(0, (-317976576));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test331");
        int i2 = ClassExampleWithNoFailure.foo(88013056, (-1543503872));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test332");
        int i2 = ClassExampleWithNoFailure.foo((-308287095), 1597046784);
        org.junit.Assert.assertTrue(i2 == (-645857280));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test333");
        int i2 = ClassExampleWithNoFailure.foo(1994653696, (-901775360));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test334");
        int i2 = ClassExampleWithNoFailure.foo(1167720448, 1691418624);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test335");
        int i2 = ClassExampleWithNoFailure.foo((-1094451200), 591894913);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test336");
        int i2 = ClassExampleWithNoFailure.foo((-704410879), (-1994850304));
        org.junit.Assert.assertTrue(i2 == (-1357316096));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test337");
        int i2 = ClassExampleWithNoFailure.foo(764454913, 788529152);
        org.junit.Assert.assertTrue(i2 == 788529152);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test338");
        int i2 = ClassExampleWithNoFailure.foo((-907197440), (-1970240447));
        org.junit.Assert.assertTrue(i2 == (-1106247680));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test339");
        int i2 = ClassExampleWithNoFailure.foo(2043419408, 1804795904);
        org.junit.Assert.assertTrue(i2 == (-1291845632));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test340");
        int i2 = ClassExampleWithNoFailure.foo((-784541439), (-458949744));
        org.junit.Assert.assertTrue(i2 == (-449897584));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test341");
        int i2 = ClassExampleWithNoFailure.foo((-1296891904), 1207040576);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test342");
        int i2 = ClassExampleWithNoFailure.foo(35, 1461063440);
        org.junit.Assert.assertTrue(i2 == (-1198648432));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test343");
        int i2 = ClassExampleWithNoFailure.foo(1448779776, 1625235617);
        org.junit.Assert.assertTrue(i2 == 1677721600);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test344");
        int i2 = ClassExampleWithNoFailure.foo(1484873985, (-709820543));
        org.junit.Assert.assertTrue(i2 == (-1382825599));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test345");
        int i2 = ClassExampleWithNoFailure.foo((-1087593663), 1182286848);
        org.junit.Assert.assertTrue(i2 == (-1754119168));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test346");
        int i2 = ClassExampleWithNoFailure.foo(177209344, 1542954929);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test347");
        int i2 = ClassExampleWithNoFailure.foo(1493172224, (-1792278528));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test348");
        int i2 = ClassExampleWithNoFailure.foo(1426407121, 382730240);
        org.junit.Assert.assertTrue(i2 == 953155584);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test349");
        int i2 = ClassExampleWithNoFailure.foo((-30284800), (-727379968));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test350");
        int i2 = ClassExampleWithNoFailure.foo(591894913, 140608);
        org.junit.Assert.assertTrue(i2 == (-100801216));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test351");
        int i2 = ClassExampleWithNoFailure.foo(2044120257, (-1632132864));
        org.junit.Assert.assertTrue(i2 == (-749657856));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test352");
        int i2 = ClassExampleWithNoFailure.foo((-687019008), (-313413567));
        org.junit.Assert.assertTrue(i2 == 1569718272);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test353");
        int i2 = ClassExampleWithNoFailure.foo(1745879040, 1620908545);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test354");
        int i1 = ClassExampleWithNoFailure.twice(1666716929);
        org.junit.Assert.assertTrue(i1 == 946416129);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test355");
        int i2 = ClassExampleWithNoFailure.foo(1415573760, 1936073728);
        org.junit.Assert.assertTrue(i2 == (-1543503872));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test356");
        int i2 = ClassExampleWithNoFailure.foo((-57671680), (-1036451840));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test357");
        int i2 = ClassExampleWithNoFailure.foo((-714715136), 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test358");
        int i1 = ClassExampleWithNoFailure.twice((-1959319280));
        org.junit.Assert.assertTrue(i1 == 192291072);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test359");
        int i1 = ClassExampleWithNoFailure.twice(1994653696);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test360");
        int i2 = ClassExampleWithNoFailure.foo(1035286657, (-438499664));
        org.junit.Assert.assertTrue(i2 == (-555960656));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test361");
        int i2 = ClassExampleWithNoFailure.foo(1430155920, 1638465536);
        org.junit.Assert.assertTrue(i2 == (-1191182336));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test362");
        int i1 = ClassExampleWithNoFailure.twice((-1689158383));
        org.junit.Assert.assertTrue(i1 == (-136602847));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test363");
        int i1 = ClassExampleWithNoFailure.twice(1829163264);
        org.junit.Assert.assertTrue(i1 == 1990262784);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test364");
        int i2 = ClassExampleWithNoFailure.foo((-317976576), (-1947992064));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test365");
        int i2 = ClassExampleWithNoFailure.foo(1597046784, 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test366");
        int i1 = ClassExampleWithNoFailure.twice((-385875968));
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test367");
        int i2 = ClassExampleWithNoFailure.foo(1368391680, (-1444872192));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test368");
        int i2 = ClassExampleWithNoFailure.foo((-612289887), (-118791455));
        org.junit.Assert.assertTrue(i2 == (-1080343519));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test369");
        int i2 = ClassExampleWithNoFailure.foo(1167720448, 1630230625);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test370");
        int i2 = ClassExampleWithNoFailure.foo(1898708992, 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test371");
        int i1 = ClassExampleWithNoFailure.twice(1636827136);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test372");
        int i1 = ClassExampleWithNoFailure.twice(1350385664);
        org.junit.Assert.assertTrue(i1 == (-1879048192));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test373");
        int i2 = ClassExampleWithNoFailure.foo(1804795904, (-1740570624));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test374");
        int i2 = ClassExampleWithNoFailure.foo(1801519104, 1377894400);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test375");
        int i2 = ClassExampleWithNoFailure.foo(2085458641, 262993508);
        org.junit.Assert.assertTrue(i2 == (-1076597532));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test376");
        int i1 = ClassExampleWithNoFailure.twice((-449897584));
        org.junit.Assert.assertTrue(i1 == (-1042829056));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test377");
        int i2 = ClassExampleWithNoFailure.foo((-173693439), (-861863936));
        org.junit.Assert.assertTrue(i2 == (-1734279168));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test378");
        int i2 = ClassExampleWithNoFailure.foo(1178664960, 298498817);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test379");
        int i2 = ClassExampleWithNoFailure.foo(1349054657, 502075041);
        org.junit.Assert.assertTrue(i2 == (-2023526367));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test380");
        int i1 = ClassExampleWithNoFailure.twice(1624171649);
        org.junit.Assert.assertTrue(i1 == 1267861761);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test381");
        int i2 = ClassExampleWithNoFailure.foo(1751958048, 664441601);
        org.junit.Assert.assertTrue(i2 == (-301956096));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test382");
        int i1 = ClassExampleWithNoFailure.twice(2043419408);
        org.junit.Assert.assertTrue(i1 == 1146904832);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test383");
        int i2 = ClassExampleWithNoFailure.foo(1411973120, (-1829002240));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test384");
        int i2 = ClassExampleWithNoFailure.foo((-660003840), (-402345728));
        org.junit.Assert.assertTrue(i2 == 268435456);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test385");
        int i2 = ClassExampleWithNoFailure.foo((-1484173664), (-1042251199));
        org.junit.Assert.assertTrue(i2 == 380036096);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test386");
        int i1 = ClassExampleWithNoFailure.twice(764454913);
        org.junit.Assert.assertTrue(i1 == (-916369407));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test387");
        int i2 = ClassExampleWithNoFailure.foo(260636672, (-199791359));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test388");
        int i2 = ClassExampleWithNoFailure.foo(1415573760, (int) 'a');
        org.junit.Assert.assertTrue(i2 == 356581376);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test389");
        int i2 = ClassExampleWithNoFailure.foo((-88691952), 840915856);
        org.junit.Assert.assertTrue(i2 == 865177600);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test390");
        int i2 = ClassExampleWithNoFailure.foo((-523390976), 139903232);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test391");
        int i1 = ClassExampleWithNoFailure.twice((-645857280));
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test392");
        int i2 = ClassExampleWithNoFailure.foo((-1604255744), 1415573760);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test393");
        int i2 = ClassExampleWithNoFailure.foo((-448860847), 1312746945);
        org.junit.Assert.assertTrue(i2 == 632543585);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test394");
        int i2 = ClassExampleWithNoFailure.foo(0, 1838265625);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test395");
        int i1 = ClassExampleWithNoFailure.twice((-1744163599));
        org.junit.Assert.assertTrue(i1 == (-1162364191));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test396");
        int i2 = ClassExampleWithNoFailure.foo(325452032, (-1290797056));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test397");
        int i1 = ClassExampleWithNoFailure.twice((-149946368));
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test398");
        int i2 = ClassExampleWithNoFailure.foo(1207040576, (-1562779392));
        org.junit.Assert.assertTrue(i2 == (-1626341376));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test399");
        int i1 = ClassExampleWithNoFailure.twice((-1905792767));
        org.junit.Assert.assertTrue(i1 == 1860227585);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test400");
        int i2 = ClassExampleWithNoFailure.foo((-1214017143), (-1626341376));
        org.junit.Assert.assertTrue(i2 == 68157440);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test401");
        int i2 = ClassExampleWithNoFailure.foo(122500, 1378902772);
        org.junit.Assert.assertTrue(i2 == (-1126973632));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test402");
        int i2 = ClassExampleWithNoFailure.foo((-504299520), 16777216);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test403");
        int i2 = ClassExampleWithNoFailure.foo((-687019008), (-1036451840));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test404");
        int i2 = ClassExampleWithNoFailure.foo(523923841, 3276800);
        org.junit.Assert.assertTrue(i2 == (-701366272));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test405");
        int i2 = ClassExampleWithNoFailure.foo(15006250, 1700855808);
        org.junit.Assert.assertTrue(i2 == (-1738276864));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test406");
        int i2 = ClassExampleWithNoFailure.foo(1, 260636672);
        org.junit.Assert.assertTrue(i2 == 260636672);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test407");
        int i2 = ClassExampleWithNoFailure.foo(1234478737, (-1533187072));
        org.junit.Assert.assertTrue(i2 == 1710418944);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test408");
        int i2 = ClassExampleWithNoFailure.foo(1366606080, (-213843968));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test409");
        int i2 = ClassExampleWithNoFailure.foo((-449079295), (-85851327));
        org.junit.Assert.assertTrue(i2 == (-487247039));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test410");
        int i2 = ClassExampleWithNoFailure.foo(906368129, 1350385664);
        org.junit.Assert.assertTrue(i2 == (-1346551808));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test411");
        int i2 = ClassExampleWithNoFailure.foo((-1116667904), 1087913984);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test412");
        int i2 = ClassExampleWithNoFailure.foo((-234364416), (-553648128));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test413");
        int i2 = ClassExampleWithNoFailure.foo(1995483777, 382606593);
        org.junit.Assert.assertTrue(i2 == (-1340165631));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test414");
        int i2 = ClassExampleWithNoFailure.foo(572311825, (-586153984));
        org.junit.Assert.assertTrue(i2 == (-1357905920));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test415");
        int i2 = ClassExampleWithNoFailure.foo(65536, 382606593);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test416");
        int i2 = ClassExampleWithNoFailure.foo((-1206738944), 1278279680);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test417");
        int i2 = ClassExampleWithNoFailure.foo(150062500, 67690752);
        org.junit.Assert.assertTrue(i2 == 1027543040);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test418");
        int i2 = ClassExampleWithNoFailure.foo(1000000, 454033408);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test419");
        int i2 = ClassExampleWithNoFailure.foo((-1125969471), 1310785536);
        org.junit.Assert.assertTrue(i2 == (-241106944));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test420");
        int i2 = ClassExampleWithNoFailure.foo(353370112, 492896256);
        org.junit.Assert.assertTrue(i2 == 0);
    }
}

