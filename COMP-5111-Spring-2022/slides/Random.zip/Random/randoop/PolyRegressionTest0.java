import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class PolyRegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test01");
        Poly poly0 = new Poly();
        Poly poly1 = new Poly();
        Poly poly2 = poly0.mult(poly1);
        Mono mono3 = null;
        try {
            Poly poly4 = poly0.multMono(mono3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(poly2);
    }

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test02");
        Poly poly0 = new Poly();
        Poly poly1 = new Poly();
        Poly poly2 = poly0.mult(poly1);
        Mono[] mono_array3 = new Mono[] {};
        poly0.elements = mono_array3;
        try {
            java.lang.String str5 = poly0.toString();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(poly2);
        org.junit.Assert.assertNotNull(mono_array3);
    }

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test03");
        Poly poly0 = new Poly();
        Poly poly1 = new Poly();
        Poly poly2 = poly0.mult(poly1);
        Poly poly3 = new Poly();
        Poly poly4 = new Poly();
        Poly poly5 = poly3.mult(poly4);
        Poly poly6 = poly0.mult(poly5);
        java.lang.String str7 = poly6.toString();
        org.junit.Assert.assertNotNull(poly2);
        org.junit.Assert.assertNotNull(poly5);
        org.junit.Assert.assertNotNull(poly6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "(0/1)x^0 + (0/1)x^1 + (0/1)x^2 + (0/1)x^3 + (0/1)x^4 + (0/1)x^5 + (0/1)x^6 + (0/1)x^7 + (0/1)x^8 + (0/1)x^9" + "'", str7.equals("(0/1)x^0 + (0/1)x^1 + (0/1)x^2 + (0/1)x^3 + (0/1)x^4 + (0/1)x^5 + (0/1)x^6 + (0/1)x^7 + (0/1)x^8 + (0/1)x^9"));
    }

    @Test
    public void test04() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test04");
        Poly poly0 = new Poly();
        Poly poly1 = new Poly();
        Poly poly2 = poly0.mult(poly1);
        Poly poly3 = new Poly();
        Poly poly4 = new Poly();
        Poly poly5 = poly3.mult(poly4);
        Poly poly6 = poly0.mult(poly5);
        Mono mono7 = null;
        try {
            Poly poly8 = poly0.multMono(mono7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(poly2);
        org.junit.Assert.assertNotNull(poly5);
        org.junit.Assert.assertNotNull(poly6);
    }

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test05");
        Poly poly0 = new Poly();
        Poly poly1 = new Poly();
        Poly poly2 = poly0.mult(poly1);
        Poly poly3 = new Poly();
        Poly poly4 = new Poly();
        Poly poly5 = poly3.mult(poly4);
        Poly poly6 = poly0.mult(poly5);
        Poly poly7 = new Poly();
        Poly poly8 = new Poly();
        Poly poly9 = poly7.mult(poly8);
        Mono[] mono_array10 = new Mono[] {};
        poly7.elements = mono_array10;
        Poly poly12 = poly6.mult(poly7);
        Mono mono13 = null;
        try {
            Poly poly14 = poly6.multMono(mono13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(poly2);
        org.junit.Assert.assertNotNull(poly5);
        org.junit.Assert.assertNotNull(poly6);
        org.junit.Assert.assertNotNull(poly9);
        org.junit.Assert.assertNotNull(mono_array10);
        org.junit.Assert.assertNotNull(poly12);
    }

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test06");
        Poly poly0 = new Poly();
        Poly poly1 = new Poly();
        Poly poly2 = poly0.mult(poly1);
        Poly poly3 = new Poly();
        Poly poly4 = new Poly();
        Poly poly5 = poly3.mult(poly4);
        Poly poly6 = poly0.mult(poly5);
        Poly poly7 = new Poly();
        Poly poly8 = new Poly();
        Poly poly9 = poly7.mult(poly8);
        Mono[] mono_array10 = new Mono[] {};
        poly7.elements = mono_array10;
        Poly poly12 = poly6.mult(poly7);
        Mono[] mono_array13 = poly12.elements;
        Mono mono14 = null;
        try {
            Poly poly15 = poly12.plus(mono14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(poly2);
        org.junit.Assert.assertNotNull(poly5);
        org.junit.Assert.assertNotNull(poly6);
        org.junit.Assert.assertNotNull(poly9);
        org.junit.Assert.assertNotNull(mono_array10);
        org.junit.Assert.assertNotNull(poly12);
        org.junit.Assert.assertNotNull(mono_array13);
    }

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test07");
        Poly poly0 = new Poly();
        Poly poly1 = new Poly();
        Poly poly2 = poly0.mult(poly1);
        Mono mono3 = null;
        try {
            Poly poly4 = poly2.multMono(mono3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(poly2);
    }

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test08");
        Poly poly0 = new Poly();
        Poly poly1 = new Poly();
        Poly poly2 = poly0.mult(poly1);
        Poly poly3 = new Poly();
        Poly poly4 = new Poly();
        Poly poly5 = poly3.mult(poly4);
        Poly poly6 = poly0.mult(poly5);
        Poly poly7 = new Poly();
        Poly poly8 = new Poly();
        Poly poly9 = poly7.mult(poly8);
        Mono[] mono_array10 = new Mono[] {};
        poly7.elements = mono_array10;
        Poly poly12 = poly6.mult(poly7);
        Poly poly13 = poly12.clone();
        Poly poly14 = null;
        try {
            Poly poly15 = poly12.mult(poly14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(poly2);
        org.junit.Assert.assertNotNull(poly5);
        org.junit.Assert.assertNotNull(poly6);
        org.junit.Assert.assertNotNull(poly9);
        org.junit.Assert.assertNotNull(mono_array10);
        org.junit.Assert.assertNotNull(poly12);
        org.junit.Assert.assertNotNull(poly13);
    }

    @Test
    public void test09() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test09");
        Poly poly0 = new Poly();
        Poly poly1 = new Poly();
        Poly poly2 = poly0.mult(poly1);
        Poly poly3 = new Poly();
        Poly poly4 = new Poly();
        Poly poly5 = poly3.mult(poly4);
        Poly poly6 = poly0.mult(poly5);
        Poly poly7 = new Poly();
        Poly poly8 = new Poly();
        Poly poly9 = poly7.mult(poly8);
        Mono[] mono_array10 = new Mono[] {};
        poly7.elements = mono_array10;
        Poly poly12 = poly6.mult(poly7);
        Mono mono13 = null;
        try {
            Poly poly14 = poly6.plus(mono13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(poly2);
        org.junit.Assert.assertNotNull(poly5);
        org.junit.Assert.assertNotNull(poly6);
        org.junit.Assert.assertNotNull(poly9);
        org.junit.Assert.assertNotNull(mono_array10);
        org.junit.Assert.assertNotNull(poly12);
    }

    @Test
    public void test10() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test10");
        Poly poly0 = new Poly();
        Poly poly1 = new Poly();
        Poly poly2 = poly0.mult(poly1);
        Poly poly3 = new Poly();
        Poly poly4 = new Poly();
        Poly poly5 = poly3.mult(poly4);
        Poly poly6 = poly0.mult(poly5);
        Poly poly7 = new Poly();
        Poly poly8 = new Poly();
        Poly poly9 = poly7.mult(poly8);
        Mono[] mono_array10 = new Mono[] {};
        poly7.elements = mono_array10;
        Poly poly12 = poly6.mult(poly7);
        Mono[] mono_array13 = poly12.elements;
        Mono[] mono_array14 = poly12.elements;
        org.junit.Assert.assertNotNull(poly2);
        org.junit.Assert.assertNotNull(poly5);
        org.junit.Assert.assertNotNull(poly6);
        org.junit.Assert.assertNotNull(poly9);
        org.junit.Assert.assertNotNull(mono_array10);
        org.junit.Assert.assertNotNull(poly12);
        org.junit.Assert.assertNotNull(mono_array13);
        org.junit.Assert.assertNotNull(mono_array14);
    }

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test11");
        Poly poly0 = new Poly();
        Poly poly1 = new Poly();
        Poly poly2 = poly0.mult(poly1);
        Poly poly3 = poly2.clone();
        Mono mono4 = null;
        try {
            Poly poly5 = poly3.multMono(mono4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(poly2);
        org.junit.Assert.assertNotNull(poly3);
    }

    @Test
    public void test12() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test12");
        Poly poly0 = new Poly();
        Mono mono1 = null;
        Mono[] mono_array2 = new Mono[] { mono1 };
        poly0.elements = mono_array2;
        Mono mono4 = null;
        Mono[] mono_array5 = new Mono[] { mono4 };
        poly0.elements = mono_array5;
        Mono[] mono_array7 = poly0.elements;
        Poly poly8 = new Poly();
        Poly poly9 = new Poly();
        Poly poly10 = poly8.mult(poly9);
        Mono mono11 = null;
        Mono[] mono_array12 = new Mono[] { mono11 };
        poly8.elements = mono_array12;
        poly0.elements = mono_array12;
        org.junit.Assert.assertNotNull(mono_array2);
        org.junit.Assert.assertNotNull(mono_array5);
        org.junit.Assert.assertNotNull(mono_array7);
        org.junit.Assert.assertNotNull(poly10);
        org.junit.Assert.assertNotNull(mono_array12);
    }

    @Test
    public void test13() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test13");
        Poly poly0 = new Poly();
        Poly poly1 = new Poly();
        Poly poly2 = poly0.mult(poly1);
        Poly poly3 = poly2.clone();
        java.lang.String str4 = poly3.toString();
        org.junit.Assert.assertNotNull(poly2);
        org.junit.Assert.assertNotNull(poly3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "(0/1)x^0 + (0/1)x^1 + (0/1)x^2 + (0/1)x^3 + (0/1)x^4 + (0/1)x^5 + (0/1)x^6 + (0/1)x^7 + (0/1)x^8 + (0/1)x^9" + "'", str4.equals("(0/1)x^0 + (0/1)x^1 + (0/1)x^2 + (0/1)x^3 + (0/1)x^4 + (0/1)x^5 + (0/1)x^6 + (0/1)x^7 + (0/1)x^8 + (0/1)x^9"));
    }

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test14");
        Poly poly0 = new Poly();
        Mono mono1 = null;
        try {
            Poly poly2 = poly0.multMono(mono1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test15() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test15");
        Poly poly0 = new Poly();
        Poly poly1 = new Poly();
        Poly poly2 = poly0.mult(poly1);
        Mono[] mono_array3 = poly0.elements;
        java.lang.String str4 = poly0.toString();
        Mono mono5 = null;
        try {
            Poly poly6 = poly0.multMono(mono5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(poly2);
        org.junit.Assert.assertNotNull(mono_array3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "(0/1)x^0 + (0/1)x^1 + (0/1)x^2 + (0/1)x^3 + (0/1)x^4 + (0/1)x^5 + (0/1)x^6 + (0/1)x^7 + (0/1)x^8 + (0/1)x^9" + "'", str4.equals("(0/1)x^0 + (0/1)x^1 + (0/1)x^2 + (0/1)x^3 + (0/1)x^4 + (0/1)x^5 + (0/1)x^6 + (0/1)x^7 + (0/1)x^8 + (0/1)x^9"));
    }

    @Test
    public void test16() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test16");
        Poly poly0 = new Poly();
        Poly poly1 = new Poly();
        Poly poly2 = poly0.mult(poly1);
        Poly poly3 = new Poly();
        Poly poly4 = new Poly();
        Poly poly5 = poly3.mult(poly4);
        Poly poly6 = poly0.mult(poly5);
        Poly poly7 = new Poly();
        Poly poly8 = new Poly();
        Poly poly9 = poly7.mult(poly8);
        Mono[] mono_array10 = new Mono[] {};
        poly7.elements = mono_array10;
        Poly poly12 = poly6.mult(poly7);
        Poly poly13 = poly12.clone();
        Poly poly14 = poly12.clone();
        Mono mono15 = null;
        try {
            Poly poly16 = poly12.multMono(mono15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(poly2);
        org.junit.Assert.assertNotNull(poly5);
        org.junit.Assert.assertNotNull(poly6);
        org.junit.Assert.assertNotNull(poly9);
        org.junit.Assert.assertNotNull(mono_array10);
        org.junit.Assert.assertNotNull(poly12);
        org.junit.Assert.assertNotNull(poly13);
        org.junit.Assert.assertNotNull(poly14);
    }

    @Test
    public void test17() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test17");
        Poly poly0 = new Poly();
        Poly poly1 = new Poly();
        Poly poly2 = poly0.mult(poly1);
        Poly poly3 = new Poly();
        Poly poly4 = new Poly();
        Poly poly5 = poly3.mult(poly4);
        Poly poly6 = poly0.mult(poly5);
        Poly poly7 = new Poly();
        Poly poly8 = new Poly();
        Poly poly9 = poly7.mult(poly8);
        Mono[] mono_array10 = new Mono[] {};
        poly7.elements = mono_array10;
        Poly poly12 = poly6.mult(poly7);
        Poly poly13 = poly6.clone();
        Mono mono14 = null;
        try {
            Poly poly15 = poly6.plus(mono14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(poly2);
        org.junit.Assert.assertNotNull(poly5);
        org.junit.Assert.assertNotNull(poly6);
        org.junit.Assert.assertNotNull(poly9);
        org.junit.Assert.assertNotNull(mono_array10);
        org.junit.Assert.assertNotNull(poly12);
        org.junit.Assert.assertNotNull(poly13);
    }

    @Test
    public void test18() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test18");
        Poly poly0 = new Poly();
        Mono mono1 = null;
        Mono[] mono_array2 = new Mono[] { mono1 };
        poly0.elements = mono_array2;
        Mono mono4 = null;
        Mono[] mono_array5 = new Mono[] { mono4 };
        poly0.elements = mono_array5;
        Mono[] mono_array7 = poly0.elements;
        Mono mono8 = null;
        try {
            Poly poly9 = poly0.multMono(mono8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(mono_array2);
        org.junit.Assert.assertNotNull(mono_array5);
        org.junit.Assert.assertNotNull(mono_array7);
    }

    @Test
    public void test19() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test19");
        Poly poly0 = new Poly();
        Poly poly1 = new Poly();
        Poly poly2 = poly0.mult(poly1);
        Mono[] mono_array3 = new Mono[] {};
        poly0.elements = mono_array3;
        Poly poly5 = poly0.clone();
        Mono mono6 = null;
        try {
            Poly poly7 = poly0.plus(mono6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(poly2);
        org.junit.Assert.assertNotNull(mono_array3);
        org.junit.Assert.assertNotNull(poly5);
    }

    @Test
    public void test20() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test20");
        Poly poly0 = new Poly();
        Poly poly1 = new Poly();
        Poly poly2 = poly0.mult(poly1);
        Poly poly3 = new Poly();
        Poly poly4 = new Poly();
        Poly poly5 = poly3.mult(poly4);
        Poly poly6 = poly0.mult(poly5);
        Poly poly7 = new Poly();
        Poly poly8 = new Poly();
        Poly poly9 = poly7.mult(poly8);
        Mono[] mono_array10 = new Mono[] {};
        poly7.elements = mono_array10;
        Poly poly12 = poly6.mult(poly7);
        Mono[] mono_array13 = poly12.elements;
        java.lang.String str14 = poly12.toString();
        org.junit.Assert.assertNotNull(poly2);
        org.junit.Assert.assertNotNull(poly5);
        org.junit.Assert.assertNotNull(poly6);
        org.junit.Assert.assertNotNull(poly9);
        org.junit.Assert.assertNotNull(mono_array10);
        org.junit.Assert.assertNotNull(poly12);
        org.junit.Assert.assertNotNull(mono_array13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "(0/1)x^0 + (0/1)x^1 + (0/1)x^2 + (0/1)x^3 + (0/1)x^4 + (0/1)x^5 + (0/1)x^6 + (0/1)x^7 + (0/1)x^8 + (0/1)x^9" + "'", str14.equals("(0/1)x^0 + (0/1)x^1 + (0/1)x^2 + (0/1)x^3 + (0/1)x^4 + (0/1)x^5 + (0/1)x^6 + (0/1)x^7 + (0/1)x^8 + (0/1)x^9"));
    }

    @Test
    public void test21() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test21");
        Poly poly0 = new Poly();
        Poly poly1 = new Poly();
        Poly poly2 = poly0.mult(poly1);
        Poly poly3 = new Poly();
        Poly poly4 = new Poly();
        Poly poly5 = poly3.mult(poly4);
        Poly poly6 = poly0.mult(poly5);
        Mono mono7 = null;
        try {
            Poly poly8 = poly6.plus(mono7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(poly2);
        org.junit.Assert.assertNotNull(poly5);
        org.junit.Assert.assertNotNull(poly6);
    }

    @Test
    public void test22() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test22");
        Poly poly0 = new Poly();
        Poly poly1 = new Poly();
        Poly poly2 = poly0.mult(poly1);
        Mono[] mono_array3 = new Mono[] {};
        poly0.elements = mono_array3;
        Poly poly5 = poly0.clone();
        Mono[] mono_array6 = poly0.elements;
        Mono mono7 = null;
        try {
            Poly poly8 = poly0.multMono(mono7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(poly2);
        org.junit.Assert.assertNotNull(mono_array3);
        org.junit.Assert.assertNotNull(poly5);
        org.junit.Assert.assertNotNull(mono_array6);
    }

    @Test
    public void test23() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test23");
        Poly poly0 = new Poly();
        Poly poly1 = new Poly();
        Poly poly2 = poly0.mult(poly1);
        Poly poly3 = new Poly();
        Poly poly4 = new Poly();
        Poly poly5 = poly3.mult(poly4);
        Poly poly6 = poly0.mult(poly5);
        Poly poly7 = new Poly();
        Poly poly8 = new Poly();
        Poly poly9 = poly7.mult(poly8);
        Mono[] mono_array10 = new Mono[] {};
        poly7.elements = mono_array10;
        Poly poly12 = poly6.mult(poly7);
        Poly poly13 = poly12.clone();
        java.lang.String str14 = poly12.toString();
        Mono mono15 = null;
        try {
            Poly poly16 = poly12.multMono(mono15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(poly2);
        org.junit.Assert.assertNotNull(poly5);
        org.junit.Assert.assertNotNull(poly6);
        org.junit.Assert.assertNotNull(poly9);
        org.junit.Assert.assertNotNull(mono_array10);
        org.junit.Assert.assertNotNull(poly12);
        org.junit.Assert.assertNotNull(poly13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "(0/1)x^0 + (0/1)x^1 + (0/1)x^2 + (0/1)x^3 + (0/1)x^4 + (0/1)x^5 + (0/1)x^6 + (0/1)x^7 + (0/1)x^8 + (0/1)x^9" + "'", str14.equals("(0/1)x^0 + (0/1)x^1 + (0/1)x^2 + (0/1)x^3 + (0/1)x^4 + (0/1)x^5 + (0/1)x^6 + (0/1)x^7 + (0/1)x^8 + (0/1)x^9"));
    }

    @Test
    public void test24() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test24");
        Poly poly0 = new Poly();
        Poly poly1 = new Poly();
        Poly poly2 = poly0.mult(poly1);
        Mono[] mono_array3 = new Mono[] {};
        poly0.elements = mono_array3;
        Poly poly5 = new Poly();
        Poly poly6 = new Poly();
        Poly poly7 = poly5.mult(poly6);
        Poly poly8 = poly7.clone();
        Poly poly9 = poly0.mult(poly8);
        Mono mono10 = null;
        try {
            Poly poly11 = poly0.plus(mono10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(poly2);
        org.junit.Assert.assertNotNull(mono_array3);
        org.junit.Assert.assertNotNull(poly7);
        org.junit.Assert.assertNotNull(poly8);
        org.junit.Assert.assertNotNull(poly9);
    }

    @Test
    public void test25() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test25");
        Poly poly0 = new Poly();
        Poly poly1 = poly0.clone();
        Mono mono2 = null;
        try {
            Poly poly3 = poly1.plus(mono2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(poly1);
    }

    @Test
    public void test26() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test26");
        Poly poly0 = new Poly();
        Poly poly1 = new Poly();
        Poly poly2 = poly0.mult(poly1);
        Mono[] mono_array3 = new Mono[] {};
        poly0.elements = mono_array3;
        Poly poly5 = poly0.clone();
        Mono[] mono_array6 = poly0.elements;
        Mono mono7 = null;
        try {
            Poly poly8 = poly0.plus(mono7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(poly2);
        org.junit.Assert.assertNotNull(mono_array3);
        org.junit.Assert.assertNotNull(poly5);
        org.junit.Assert.assertNotNull(mono_array6);
    }

    @Test
    public void test27() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test27");
        Poly poly0 = new Poly();
        Poly poly1 = new Poly();
        Poly poly2 = poly0.mult(poly1);
        Mono[] mono_array3 = poly0.elements;
        java.lang.String str4 = poly0.toString();
        Mono mono5 = null;
        try {
            Poly poly6 = poly0.plus(mono5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(poly2);
        org.junit.Assert.assertNotNull(mono_array3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "(0/1)x^0 + (0/1)x^1 + (0/1)x^2 + (0/1)x^3 + (0/1)x^4 + (0/1)x^5 + (0/1)x^6 + (0/1)x^7 + (0/1)x^8 + (0/1)x^9" + "'", str4.equals("(0/1)x^0 + (0/1)x^1 + (0/1)x^2 + (0/1)x^3 + (0/1)x^4 + (0/1)x^5 + (0/1)x^6 + (0/1)x^7 + (0/1)x^8 + (0/1)x^9"));
    }

    @Test
    public void test28() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test28");
        Poly poly0 = new Poly();
        Poly poly1 = new Poly();
        Poly poly2 = poly0.mult(poly1);
        Poly poly3 = new Poly();
        Poly poly4 = new Poly();
        Poly poly5 = poly3.mult(poly4);
        Poly poly6 = poly0.mult(poly5);
        Poly poly7 = new Poly();
        Poly poly8 = new Poly();
        Poly poly9 = poly7.mult(poly8);
        Mono[] mono_array10 = new Mono[] {};
        poly7.elements = mono_array10;
        Poly poly12 = poly6.mult(poly7);
        Poly poly13 = poly7.clone();
        Poly poly14 = new Poly();
        Poly poly15 = new Poly();
        Poly poly16 = poly14.mult(poly15);
        Poly poly17 = new Poly();
        Poly poly18 = new Poly();
        Poly poly19 = poly17.mult(poly18);
        Poly poly20 = new Poly();
        Poly poly21 = new Poly();
        Poly poly22 = poly20.mult(poly21);
        Poly poly23 = poly17.mult(poly22);
        Poly poly24 = new Poly();
        Poly poly25 = new Poly();
        Poly poly26 = poly24.mult(poly25);
        Mono[] mono_array27 = new Mono[] {};
        poly24.elements = mono_array27;
        Poly poly29 = poly23.mult(poly24);
        Mono[] mono_array30 = poly29.elements;
        poly14.elements = mono_array30;
        Poly poly32 = poly7.mult(poly14);
        Poly poly33 = new Poly();
        Poly poly34 = new Poly();
        Poly poly35 = poly33.mult(poly34);
        Poly poly36 = new Poly();
        Poly poly37 = new Poly();
        Poly poly38 = poly36.mult(poly37);
        Poly poly39 = new Poly();
        Poly poly40 = new Poly();
        Poly poly41 = poly39.mult(poly40);
        Poly poly42 = poly36.mult(poly41);
        Poly poly43 = new Poly();
        Poly poly44 = new Poly();
        Poly poly45 = poly43.mult(poly44);
        Mono[] mono_array46 = new Mono[] {};
        poly43.elements = mono_array46;
        Poly poly48 = poly42.mult(poly43);
        Mono[] mono_array49 = poly48.elements;
        poly33.elements = mono_array49;
        poly32.elements = mono_array49;
        org.junit.Assert.assertNotNull(poly2);
        org.junit.Assert.assertNotNull(poly5);
        org.junit.Assert.assertNotNull(poly6);
        org.junit.Assert.assertNotNull(poly9);
        org.junit.Assert.assertNotNull(mono_array10);
        org.junit.Assert.assertNotNull(poly12);
        org.junit.Assert.assertNotNull(poly13);
        org.junit.Assert.assertNotNull(poly16);
        org.junit.Assert.assertNotNull(poly19);
        org.junit.Assert.assertNotNull(poly22);
        org.junit.Assert.assertNotNull(poly23);
        org.junit.Assert.assertNotNull(poly26);
        org.junit.Assert.assertNotNull(mono_array27);
        org.junit.Assert.assertNotNull(poly29);
        org.junit.Assert.assertNotNull(mono_array30);
        org.junit.Assert.assertNotNull(poly32);
        org.junit.Assert.assertNotNull(poly35);
        org.junit.Assert.assertNotNull(poly38);
        org.junit.Assert.assertNotNull(poly41);
        org.junit.Assert.assertNotNull(poly42);
        org.junit.Assert.assertNotNull(poly45);
        org.junit.Assert.assertNotNull(mono_array46);
        org.junit.Assert.assertNotNull(poly48);
        org.junit.Assert.assertNotNull(mono_array49);
    }

    @Test
    public void test29() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test29");
        Poly poly0 = new Poly();
        Mono mono1 = null;
        Mono[] mono_array2 = new Mono[] { mono1 };
        poly0.elements = mono_array2;
        Mono mono4 = null;
        Mono[] mono_array5 = new Mono[] { mono4 };
        poly0.elements = mono_array5;
        Mono[] mono_array7 = poly0.elements;
        Poly poly8 = new Poly();
        Mono mono9 = null;
        Mono[] mono_array10 = new Mono[] { mono9 };
        poly8.elements = mono_array10;
        Mono mono12 = null;
        Mono[] mono_array13 = new Mono[] { mono12 };
        poly8.elements = mono_array13;
        poly0.elements = mono_array13;
        Mono[] mono_array16 = poly0.elements;
        Poly poly17 = poly0.clone();
        org.junit.Assert.assertNotNull(mono_array2);
        org.junit.Assert.assertNotNull(mono_array5);
        org.junit.Assert.assertNotNull(mono_array7);
        org.junit.Assert.assertNotNull(mono_array10);
        org.junit.Assert.assertNotNull(mono_array13);
        org.junit.Assert.assertNotNull(mono_array16);
        org.junit.Assert.assertNotNull(poly17);
    }

    @Test
    public void test30() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test30");
        Poly poly0 = new Poly();
        Mono mono1 = null;
        Mono[] mono_array2 = new Mono[] { mono1 };
        poly0.elements = mono_array2;
        Poly poly4 = poly0.clone();
        org.junit.Assert.assertNotNull(mono_array2);
        org.junit.Assert.assertNotNull(poly4);
    }

    @Test
    public void test31() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test31");
        Poly poly0 = new Poly();
        Poly poly1 = new Poly();
        Poly poly2 = poly0.mult(poly1);
        Mono[] mono_array3 = new Mono[] {};
        poly0.elements = mono_array3;
        Poly poly5 = poly0.clone();
        Mono mono6 = null;
        try {
            Poly poly7 = poly5.multMono(mono6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(poly2);
        org.junit.Assert.assertNotNull(mono_array3);
        org.junit.Assert.assertNotNull(poly5);
    }

    @Test
    public void test32() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test32");
        Poly poly0 = new Poly();
        Poly poly1 = new Poly();
        Poly poly2 = poly0.mult(poly1);
        Poly poly3 = new Poly();
        Poly poly4 = new Poly();
        Poly poly5 = poly3.mult(poly4);
        Poly poly6 = poly0.mult(poly5);
        Poly poly7 = poly0.clone();
        Mono mono8 = null;
        try {
            Poly poly9 = poly7.plus(mono8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(poly2);
        org.junit.Assert.assertNotNull(poly5);
        org.junit.Assert.assertNotNull(poly6);
        org.junit.Assert.assertNotNull(poly7);
    }

    @Test
    public void test33() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test33");
        Poly poly0 = new Poly();
        Poly poly1 = new Poly();
        Poly poly2 = new Poly();
        Poly poly3 = poly1.mult(poly2);
        Poly poly4 = poly0.mult(poly3);
        Mono[] mono_array5 = poly4.elements;
        org.junit.Assert.assertNotNull(poly3);
        org.junit.Assert.assertNotNull(poly4);
        org.junit.Assert.assertNotNull(mono_array5);
    }

    @Test
    public void test34() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test34");
        Poly poly0 = new Poly();
        Poly poly1 = new Poly();
        Poly poly2 = poly0.mult(poly1);
        Poly poly3 = new Poly();
        Poly poly4 = new Poly();
        Poly poly5 = poly3.mult(poly4);
        Poly poly6 = poly0.mult(poly5);
        Poly poly7 = poly0.clone();
        Poly poly8 = new Poly();
        Poly poly9 = new Poly();
        Poly poly10 = poly8.mult(poly9);
        Mono[] mono_array11 = new Mono[] {};
        poly8.elements = mono_array11;
        Poly poly13 = poly8.clone();
        Mono[] mono_array14 = poly8.elements;
        poly0.elements = mono_array14;
        org.junit.Assert.assertNotNull(poly2);
        org.junit.Assert.assertNotNull(poly5);
        org.junit.Assert.assertNotNull(poly6);
        org.junit.Assert.assertNotNull(poly7);
        org.junit.Assert.assertNotNull(poly10);
        org.junit.Assert.assertNotNull(mono_array11);
        org.junit.Assert.assertNotNull(poly13);
        org.junit.Assert.assertNotNull(mono_array14);
    }

    @Test
    public void test35() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test35");
        Poly poly0 = new Poly();
        Poly poly1 = new Poly();
        Poly poly2 = poly0.mult(poly1);
        Poly poly3 = new Poly();
        Poly poly4 = new Poly();
        Poly poly5 = poly3.mult(poly4);
        Poly poly6 = poly0.mult(poly5);
        java.lang.String str7 = poly5.toString();
        Poly poly8 = new Poly();
        Mono mono9 = null;
        Mono[] mono_array10 = new Mono[] { mono9 };
        poly8.elements = mono_array10;
        try {
            Poly poly12 = poly5.mult(poly8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(poly2);
        org.junit.Assert.assertNotNull(poly5);
        org.junit.Assert.assertNotNull(poly6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "(0/1)x^0 + (0/1)x^1 + (0/1)x^2 + (0/1)x^3 + (0/1)x^4 + (0/1)x^5 + (0/1)x^6 + (0/1)x^7 + (0/1)x^8 + (0/1)x^9" + "'", str7.equals("(0/1)x^0 + (0/1)x^1 + (0/1)x^2 + (0/1)x^3 + (0/1)x^4 + (0/1)x^5 + (0/1)x^6 + (0/1)x^7 + (0/1)x^8 + (0/1)x^9"));
        org.junit.Assert.assertNotNull(mono_array10);
    }

    @Test
    public void test36() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test36");
        Poly poly0 = new Poly();
        Poly poly1 = new Poly();
        Poly poly2 = poly0.mult(poly1);
        Mono mono3 = null;
        Mono[] mono_array4 = new Mono[] { mono3 };
        poly0.elements = mono_array4;
        Mono[] mono_array6 = poly0.elements;
        Poly poly7 = poly0.clone();
        Poly poly8 = new Poly();
        Poly poly9 = new Poly();
        Poly poly10 = poly8.mult(poly9);
        Poly poly11 = new Poly();
        Poly poly12 = new Poly();
        Poly poly13 = poly11.mult(poly12);
        Poly poly14 = poly8.mult(poly13);
        try {
            Poly poly15 = poly0.mult(poly13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(poly2);
        org.junit.Assert.assertNotNull(mono_array4);
        org.junit.Assert.assertNotNull(mono_array6);
        org.junit.Assert.assertNotNull(poly7);
        org.junit.Assert.assertNotNull(poly10);
        org.junit.Assert.assertNotNull(poly13);
        org.junit.Assert.assertNotNull(poly14);
    }

    @Test
    public void test37() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test37");
        Poly poly0 = new Poly();
        java.lang.String str1 = poly0.toString();
        java.lang.String str2 = poly0.toString();
        Poly poly3 = null;
        try {
            Poly poly4 = poly0.mult(poly3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "(0/1)x^0 + (0/1)x^1 + (0/1)x^2 + (0/1)x^3 + (0/1)x^4 + (0/1)x^5 + (0/1)x^6 + (0/1)x^7 + (0/1)x^8 + (0/1)x^9" + "'", str1.equals("(0/1)x^0 + (0/1)x^1 + (0/1)x^2 + (0/1)x^3 + (0/1)x^4 + (0/1)x^5 + (0/1)x^6 + (0/1)x^7 + (0/1)x^8 + (0/1)x^9"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "(0/1)x^0 + (0/1)x^1 + (0/1)x^2 + (0/1)x^3 + (0/1)x^4 + (0/1)x^5 + (0/1)x^6 + (0/1)x^7 + (0/1)x^8 + (0/1)x^9" + "'", str2.equals("(0/1)x^0 + (0/1)x^1 + (0/1)x^2 + (0/1)x^3 + (0/1)x^4 + (0/1)x^5 + (0/1)x^6 + (0/1)x^7 + (0/1)x^8 + (0/1)x^9"));
    }

    @Test
    public void test38() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test38");
        Poly poly0 = new Poly();
        Poly poly1 = new Poly();
        Poly poly2 = poly0.mult(poly1);
        Mono[] mono_array3 = new Mono[] {};
        poly0.elements = mono_array3;
        Poly poly5 = poly0.clone();
        Mono[] mono_array6 = poly0.elements;
        try {
            java.lang.String str7 = poly0.toString();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(poly2);
        org.junit.Assert.assertNotNull(mono_array3);
        org.junit.Assert.assertNotNull(poly5);
        org.junit.Assert.assertNotNull(mono_array6);
    }

    @Test
    public void test39() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test39");
        Poly poly0 = new Poly();
        Poly poly1 = new Poly();
        Poly poly2 = poly0.mult(poly1);
        Poly poly3 = new Poly();
        Poly poly4 = new Poly();
        Poly poly5 = poly3.mult(poly4);
        Poly poly6 = poly0.mult(poly5);
        Poly poly7 = new Poly();
        Poly poly8 = new Poly();
        Poly poly9 = new Poly();
        Poly poly10 = poly8.mult(poly9);
        Poly poly11 = poly7.mult(poly10);
        Poly poly12 = poly6.mult(poly11);
        Mono[] mono_array13 = null;
        poly12.elements = mono_array13;
        org.junit.Assert.assertNotNull(poly2);
        org.junit.Assert.assertNotNull(poly5);
        org.junit.Assert.assertNotNull(poly6);
        org.junit.Assert.assertNotNull(poly10);
        org.junit.Assert.assertNotNull(poly11);
        org.junit.Assert.assertNotNull(poly12);
    }

    @Test
    public void test40() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test40");
        Poly poly0 = new Poly();
        Poly poly1 = poly0.clone();
        Mono mono2 = null;
        try {
            Poly poly3 = poly0.plus(mono2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(poly1);
    }

    @Test
    public void test41() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test41");
        Poly poly0 = new Poly();
        Poly poly1 = new Poly();
        Poly poly2 = poly0.mult(poly1);
        Poly poly3 = new Poly();
        Poly poly4 = new Poly();
        Poly poly5 = poly3.mult(poly4);
        Poly poly6 = poly0.mult(poly5);
        Poly poly7 = new Poly();
        Poly poly8 = new Poly();
        Poly poly9 = poly7.mult(poly8);
        Mono[] mono_array10 = new Mono[] {};
        poly7.elements = mono_array10;
        Poly poly12 = poly6.mult(poly7);
        Poly poly13 = poly6.clone();
        Mono mono14 = null;
        try {
            Poly poly15 = poly6.multMono(mono14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(poly2);
        org.junit.Assert.assertNotNull(poly5);
        org.junit.Assert.assertNotNull(poly6);
        org.junit.Assert.assertNotNull(poly9);
        org.junit.Assert.assertNotNull(mono_array10);
        org.junit.Assert.assertNotNull(poly12);
        org.junit.Assert.assertNotNull(poly13);
    }

    @Test
    public void test42() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test42");
        Poly poly0 = new Poly();
        Poly poly1 = new Poly();
        Poly poly2 = poly0.mult(poly1);
        Mono[] mono_array3 = poly0.elements;
        Poly poly4 = new Poly();
        Poly poly5 = new Poly();
        Poly poly6 = poly4.mult(poly5);
        Poly poly7 = poly0.mult(poly6);
        Mono mono8 = null;
        try {
            Poly poly9 = poly7.multMono(mono8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(poly2);
        org.junit.Assert.assertNotNull(mono_array3);
        org.junit.Assert.assertNotNull(poly6);
        org.junit.Assert.assertNotNull(poly7);
    }

    @Test
    public void test43() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test43");
        Poly poly0 = new Poly();
        Mono mono1 = null;
        Mono[] mono_array2 = new Mono[] { mono1 };
        poly0.elements = mono_array2;
        Mono mono4 = null;
        Mono[] mono_array5 = new Mono[] { mono4 };
        poly0.elements = mono_array5;
        Mono[] mono_array7 = poly0.elements;
        Poly poly8 = new Poly();
        Poly poly9 = new Poly();
        Poly poly10 = poly8.mult(poly9);
        Poly poly11 = new Poly();
        Poly poly12 = new Poly();
        Poly poly13 = poly11.mult(poly12);
        Poly poly14 = poly8.mult(poly13);
        Mono[] mono_array15 = poly14.elements;
        poly0.elements = mono_array15;
        Mono mono17 = null;
        try {
            Poly poly18 = poly0.multMono(mono17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(mono_array2);
        org.junit.Assert.assertNotNull(mono_array5);
        org.junit.Assert.assertNotNull(mono_array7);
        org.junit.Assert.assertNotNull(poly10);
        org.junit.Assert.assertNotNull(poly13);
        org.junit.Assert.assertNotNull(poly14);
        org.junit.Assert.assertNotNull(mono_array15);
    }

    @Test
    public void test44() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test44");
        Poly poly0 = new Poly();
        Poly poly1 = new Poly();
        Poly poly2 = poly0.mult(poly1);
        Poly poly3 = new Poly();
        Poly poly4 = new Poly();
        Poly poly5 = poly3.mult(poly4);
        Poly poly6 = poly0.mult(poly5);
        Poly poly7 = new Poly();
        Poly poly8 = new Poly();
        Poly poly9 = poly7.mult(poly8);
        Mono[] mono_array10 = new Mono[] {};
        poly7.elements = mono_array10;
        Poly poly12 = poly6.mult(poly7);
        Poly poly13 = poly7.clone();
        Poly poly14 = new Poly();
        Poly poly15 = new Poly();
        Poly poly16 = poly14.mult(poly15);
        Poly poly17 = new Poly();
        Poly poly18 = new Poly();
        Poly poly19 = poly17.mult(poly18);
        Poly poly20 = new Poly();
        Poly poly21 = new Poly();
        Poly poly22 = poly20.mult(poly21);
        Poly poly23 = poly17.mult(poly22);
        Poly poly24 = new Poly();
        Poly poly25 = new Poly();
        Poly poly26 = poly24.mult(poly25);
        Mono[] mono_array27 = new Mono[] {};
        poly24.elements = mono_array27;
        Poly poly29 = poly23.mult(poly24);
        Mono[] mono_array30 = poly29.elements;
        poly14.elements = mono_array30;
        Poly poly32 = poly7.mult(poly14);
        Poly poly33 = poly32.clone();
        java.lang.String str34 = poly33.toString();
        Mono mono35 = null;
        try {
            Poly poly36 = poly33.multMono(mono35);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(poly2);
        org.junit.Assert.assertNotNull(poly5);
        org.junit.Assert.assertNotNull(poly6);
        org.junit.Assert.assertNotNull(poly9);
        org.junit.Assert.assertNotNull(mono_array10);
        org.junit.Assert.assertNotNull(poly12);
        org.junit.Assert.assertNotNull(poly13);
        org.junit.Assert.assertNotNull(poly16);
        org.junit.Assert.assertNotNull(poly19);
        org.junit.Assert.assertNotNull(poly22);
        org.junit.Assert.assertNotNull(poly23);
        org.junit.Assert.assertNotNull(poly26);
        org.junit.Assert.assertNotNull(mono_array27);
        org.junit.Assert.assertNotNull(poly29);
        org.junit.Assert.assertNotNull(mono_array30);
        org.junit.Assert.assertNotNull(poly32);
        org.junit.Assert.assertNotNull(poly33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "(0/1)x^0 + (0/1)x^1 + (0/1)x^2 + (0/1)x^3 + (0/1)x^4 + (0/1)x^5 + (0/1)x^6 + (0/1)x^7 + (0/1)x^8 + (0/1)x^9" + "'", str34.equals("(0/1)x^0 + (0/1)x^1 + (0/1)x^2 + (0/1)x^3 + (0/1)x^4 + (0/1)x^5 + (0/1)x^6 + (0/1)x^7 + (0/1)x^8 + (0/1)x^9"));
    }

    @Test
    public void test45() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test45");
        Poly poly0 = new Poly();
        Poly poly1 = new Poly();
        Poly poly2 = poly0.mult(poly1);
        Poly poly3 = new Poly();
        Poly poly4 = new Poly();
        Poly poly5 = poly3.mult(poly4);
        Poly poly6 = poly0.mult(poly5);
        Poly poly7 = new Poly();
        Poly poly8 = new Poly();
        Poly poly9 = poly7.mult(poly8);
        Mono[] mono_array10 = new Mono[] {};
        poly7.elements = mono_array10;
        Poly poly12 = poly6.mult(poly7);
        Poly poly13 = poly7.clone();
        Poly poly14 = new Poly();
        Poly poly15 = new Poly();
        Poly poly16 = poly14.mult(poly15);
        Poly poly17 = new Poly();
        Poly poly18 = new Poly();
        Poly poly19 = poly17.mult(poly18);
        Poly poly20 = new Poly();
        Poly poly21 = new Poly();
        Poly poly22 = poly20.mult(poly21);
        Poly poly23 = poly17.mult(poly22);
        Poly poly24 = new Poly();
        Poly poly25 = new Poly();
        Poly poly26 = poly24.mult(poly25);
        Mono[] mono_array27 = new Mono[] {};
        poly24.elements = mono_array27;
        Poly poly29 = poly23.mult(poly24);
        Mono[] mono_array30 = poly29.elements;
        poly14.elements = mono_array30;
        Poly poly32 = poly7.mult(poly14);
        Poly poly33 = poly32.clone();
        Mono[] mono_array34 = poly33.elements;
        java.lang.String str35 = poly33.toString();
        org.junit.Assert.assertNotNull(poly2);
        org.junit.Assert.assertNotNull(poly5);
        org.junit.Assert.assertNotNull(poly6);
        org.junit.Assert.assertNotNull(poly9);
        org.junit.Assert.assertNotNull(mono_array10);
        org.junit.Assert.assertNotNull(poly12);
        org.junit.Assert.assertNotNull(poly13);
        org.junit.Assert.assertNotNull(poly16);
        org.junit.Assert.assertNotNull(poly19);
        org.junit.Assert.assertNotNull(poly22);
        org.junit.Assert.assertNotNull(poly23);
        org.junit.Assert.assertNotNull(poly26);
        org.junit.Assert.assertNotNull(mono_array27);
        org.junit.Assert.assertNotNull(poly29);
        org.junit.Assert.assertNotNull(mono_array30);
        org.junit.Assert.assertNotNull(poly32);
        org.junit.Assert.assertNotNull(poly33);
        org.junit.Assert.assertNotNull(mono_array34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "(0/1)x^0 + (0/1)x^1 + (0/1)x^2 + (0/1)x^3 + (0/1)x^4 + (0/1)x^5 + (0/1)x^6 + (0/1)x^7 + (0/1)x^8 + (0/1)x^9" + "'", str35.equals("(0/1)x^0 + (0/1)x^1 + (0/1)x^2 + (0/1)x^3 + (0/1)x^4 + (0/1)x^5 + (0/1)x^6 + (0/1)x^7 + (0/1)x^8 + (0/1)x^9"));
    }

    @Test
    public void test46() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test46");
        Poly poly0 = new Poly();
        Poly poly1 = new Poly();
        Poly poly2 = poly0.mult(poly1);
        Poly poly3 = new Poly();
        Poly poly4 = new Poly();
        Poly poly5 = poly3.mult(poly4);
        Poly poly6 = poly0.mult(poly5);
        Poly poly7 = new Poly();
        Poly poly8 = new Poly();
        Poly poly9 = poly7.mult(poly8);
        Mono[] mono_array10 = new Mono[] {};
        poly7.elements = mono_array10;
        Poly poly12 = poly6.mult(poly7);
        Poly poly13 = new Poly();
        Poly poly14 = new Poly();
        Poly poly15 = poly13.mult(poly14);
        Poly poly16 = poly6.mult(poly13);
        Poly poly17 = new Poly();
        Poly poly18 = new Poly();
        Poly poly19 = poly17.mult(poly18);
        Poly poly20 = new Poly();
        Poly poly21 = new Poly();
        Poly poly22 = poly20.mult(poly21);
        Poly poly23 = poly17.mult(poly22);
        Poly poly24 = new Poly();
        Poly poly25 = new Poly();
        Poly poly26 = poly24.mult(poly25);
        Mono[] mono_array27 = new Mono[] {};
        poly24.elements = mono_array27;
        Poly poly29 = poly23.mult(poly24);
        Poly poly30 = poly24.clone();
        Poly poly31 = new Poly();
        Poly poly32 = new Poly();
        Poly poly33 = poly31.mult(poly32);
        Poly poly34 = new Poly();
        Poly poly35 = new Poly();
        Poly poly36 = poly34.mult(poly35);
        Poly poly37 = new Poly();
        Poly poly38 = new Poly();
        Poly poly39 = poly37.mult(poly38);
        Poly poly40 = poly34.mult(poly39);
        Poly poly41 = new Poly();
        Poly poly42 = new Poly();
        Poly poly43 = poly41.mult(poly42);
        Mono[] mono_array44 = new Mono[] {};
        poly41.elements = mono_array44;
        Poly poly46 = poly40.mult(poly41);
        Mono[] mono_array47 = poly46.elements;
        poly31.elements = mono_array47;
        Poly poly49 = poly24.mult(poly31);
        Poly poly50 = poly49.clone();
        Mono[] mono_array51 = poly50.elements;
        poly6.elements = mono_array51;
        org.junit.Assert.assertNotNull(poly2);
        org.junit.Assert.assertNotNull(poly5);
        org.junit.Assert.assertNotNull(poly6);
        org.junit.Assert.assertNotNull(poly9);
        org.junit.Assert.assertNotNull(mono_array10);
        org.junit.Assert.assertNotNull(poly12);
        org.junit.Assert.assertNotNull(poly15);
        org.junit.Assert.assertNotNull(poly16);
        org.junit.Assert.assertNotNull(poly19);
        org.junit.Assert.assertNotNull(poly22);
        org.junit.Assert.assertNotNull(poly23);
        org.junit.Assert.assertNotNull(poly26);
        org.junit.Assert.assertNotNull(mono_array27);
        org.junit.Assert.assertNotNull(poly29);
        org.junit.Assert.assertNotNull(poly30);
        org.junit.Assert.assertNotNull(poly33);
        org.junit.Assert.assertNotNull(poly36);
        org.junit.Assert.assertNotNull(poly39);
        org.junit.Assert.assertNotNull(poly40);
        org.junit.Assert.assertNotNull(poly43);
        org.junit.Assert.assertNotNull(mono_array44);
        org.junit.Assert.assertNotNull(poly46);
        org.junit.Assert.assertNotNull(mono_array47);
        org.junit.Assert.assertNotNull(poly49);
        org.junit.Assert.assertNotNull(poly50);
        org.junit.Assert.assertNotNull(mono_array51);
    }

    @Test
    public void test47() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test47");
        Poly poly0 = new Poly();
        Poly poly1 = new Poly();
        Poly poly2 = poly0.mult(poly1);
        Poly poly3 = new Poly();
        Poly poly4 = new Poly();
        Poly poly5 = poly3.mult(poly4);
        Poly poly6 = poly0.mult(poly5);
        Poly poly7 = new Poly();
        Poly poly8 = new Poly();
        Poly poly9 = new Poly();
        Poly poly10 = poly8.mult(poly9);
        Poly poly11 = poly7.mult(poly10);
        Poly poly12 = poly6.mult(poly11);
        Poly poly13 = new Poly();
        java.lang.String str14 = poly13.toString();
        Poly poly15 = poly6.mult(poly13);
        org.junit.Assert.assertNotNull(poly2);
        org.junit.Assert.assertNotNull(poly5);
        org.junit.Assert.assertNotNull(poly6);
        org.junit.Assert.assertNotNull(poly10);
        org.junit.Assert.assertNotNull(poly11);
        org.junit.Assert.assertNotNull(poly12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "(0/1)x^0 + (0/1)x^1 + (0/1)x^2 + (0/1)x^3 + (0/1)x^4 + (0/1)x^5 + (0/1)x^6 + (0/1)x^7 + (0/1)x^8 + (0/1)x^9" + "'", str14.equals("(0/1)x^0 + (0/1)x^1 + (0/1)x^2 + (0/1)x^3 + (0/1)x^4 + (0/1)x^5 + (0/1)x^6 + (0/1)x^7 + (0/1)x^8 + (0/1)x^9"));
        org.junit.Assert.assertNotNull(poly15);
    }

    @Test
    public void test48() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test48");
        Poly poly0 = new Poly();
        Poly poly1 = new Poly();
        Poly poly2 = poly0.mult(poly1);
        Poly poly3 = new Poly();
        Poly poly4 = new Poly();
        Poly poly5 = poly3.mult(poly4);
        Poly poly6 = poly0.mult(poly5);
        Poly poly7 = new Poly();
        Poly poly8 = new Poly();
        Poly poly9 = poly7.mult(poly8);
        Mono[] mono_array10 = new Mono[] {};
        poly7.elements = mono_array10;
        Poly poly12 = poly6.mult(poly7);
        Mono[] mono_array13 = poly12.elements;
        Mono mono14 = null;
        try {
            Poly poly15 = poly12.multMono(mono14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(poly2);
        org.junit.Assert.assertNotNull(poly5);
        org.junit.Assert.assertNotNull(poly6);
        org.junit.Assert.assertNotNull(poly9);
        org.junit.Assert.assertNotNull(mono_array10);
        org.junit.Assert.assertNotNull(poly12);
        org.junit.Assert.assertNotNull(mono_array13);
    }

    @Test
    public void test49() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test49");
        Poly poly0 = new Poly();
        Poly poly1 = new Poly();
        Poly poly2 = poly0.mult(poly1);
        Poly poly3 = new Poly();
        Poly poly4 = new Poly();
        Poly poly5 = poly3.mult(poly4);
        Poly poly6 = poly0.mult(poly5);
        Mono mono7 = null;
        try {
            Poly poly8 = poly5.multMono(mono7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(poly2);
        org.junit.Assert.assertNotNull(poly5);
        org.junit.Assert.assertNotNull(poly6);
    }

    @Test
    public void test50() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test50");
        Poly poly0 = new Poly();
        Poly poly1 = new Poly();
        Poly poly2 = poly0.mult(poly1);
        Poly poly3 = new Poly();
        Poly poly4 = new Poly();
        Poly poly5 = poly3.mult(poly4);
        Poly poly6 = poly0.mult(poly5);
        Poly poly7 = new Poly();
        Poly poly8 = new Poly();
        Poly poly9 = new Poly();
        Poly poly10 = poly8.mult(poly9);
        Poly poly11 = poly7.mult(poly10);
        Poly poly12 = poly6.mult(poly11);
        Mono mono13 = null;
        try {
            Poly poly14 = poly6.plus(mono13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(poly2);
        org.junit.Assert.assertNotNull(poly5);
        org.junit.Assert.assertNotNull(poly6);
        org.junit.Assert.assertNotNull(poly10);
        org.junit.Assert.assertNotNull(poly11);
        org.junit.Assert.assertNotNull(poly12);
    }

    @Test
    public void test51() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test51");
        Poly poly0 = new Poly();
        Mono[] mono_array1 = poly0.elements;
        org.junit.Assert.assertNotNull(mono_array1);
    }

    @Test
    public void test52() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test52");
        Poly poly0 = new Poly();
        Poly poly1 = new Poly();
        Poly poly2 = poly0.mult(poly1);
        Poly poly3 = new Poly();
        Poly poly4 = new Poly();
        Poly poly5 = poly3.mult(poly4);
        Poly poly6 = poly0.mult(poly5);
        Poly poly7 = new Poly();
        Poly poly8 = new Poly();
        Poly poly9 = poly7.mult(poly8);
        Mono[] mono_array10 = new Mono[] {};
        poly7.elements = mono_array10;
        Poly poly12 = poly6.mult(poly7);
        Poly poly13 = poly12.clone();
        Mono mono14 = null;
        try {
            Poly poly15 = poly12.plus(mono14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(poly2);
        org.junit.Assert.assertNotNull(poly5);
        org.junit.Assert.assertNotNull(poly6);
        org.junit.Assert.assertNotNull(poly9);
        org.junit.Assert.assertNotNull(mono_array10);
        org.junit.Assert.assertNotNull(poly12);
        org.junit.Assert.assertNotNull(poly13);
    }

    @Test
    public void test53() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test53");
        Poly poly0 = new Poly();
        Poly poly1 = poly0.clone();
        Poly poly2 = poly0.clone();
        org.junit.Assert.assertNotNull(poly1);
        org.junit.Assert.assertNotNull(poly2);
    }

    @Test
    public void test54() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test54");
        Poly poly0 = new Poly();
        Poly poly1 = new Poly();
        Poly poly2 = poly0.mult(poly1);
        Poly poly3 = new Poly();
        Poly poly4 = new Poly();
        Poly poly5 = poly3.mult(poly4);
        Poly poly6 = poly0.mult(poly5);
        java.lang.String str7 = poly5.toString();
        Mono[] mono_array8 = poly5.elements;
        Poly poly9 = new Poly();
        Poly poly10 = poly9.clone();
        Poly poly11 = new Poly();
        Poly poly12 = new Poly();
        Poly poly13 = poly11.mult(poly12);
        Poly poly14 = new Poly();
        Poly poly15 = new Poly();
        Poly poly16 = poly14.mult(poly15);
        Poly poly17 = poly11.mult(poly16);
        Poly poly18 = new Poly();
        Poly poly19 = new Poly();
        Poly poly20 = poly18.mult(poly19);
        Mono[] mono_array21 = new Mono[] {};
        poly18.elements = mono_array21;
        Poly poly23 = poly17.mult(poly18);
        Poly poly24 = poly18.clone();
        Poly poly25 = poly10.mult(poly24);
        Poly poly26 = new Poly();
        Poly poly27 = new Poly();
        Poly poly28 = poly26.mult(poly27);
        Poly poly29 = new Poly();
        Poly poly30 = new Poly();
        Poly poly31 = poly29.mult(poly30);
        Poly poly32 = poly26.mult(poly31);
        Poly poly33 = new Poly();
        Mono mono34 = null;
        Mono[] mono_array35 = new Mono[] { mono34 };
        poly33.elements = mono_array35;
        Mono mono37 = null;
        Mono[] mono_array38 = new Mono[] { mono37 };
        poly33.elements = mono_array38;
        Mono[] mono_array40 = poly33.elements;
        poly31.elements = mono_array40;
        poly24.elements = mono_array40;
        poly5.elements = mono_array40;
        org.junit.Assert.assertNotNull(poly2);
        org.junit.Assert.assertNotNull(poly5);
        org.junit.Assert.assertNotNull(poly6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "(0/1)x^0 + (0/1)x^1 + (0/1)x^2 + (0/1)x^3 + (0/1)x^4 + (0/1)x^5 + (0/1)x^6 + (0/1)x^7 + (0/1)x^8 + (0/1)x^9" + "'", str7.equals("(0/1)x^0 + (0/1)x^1 + (0/1)x^2 + (0/1)x^3 + (0/1)x^4 + (0/1)x^5 + (0/1)x^6 + (0/1)x^7 + (0/1)x^8 + (0/1)x^9"));
        org.junit.Assert.assertNotNull(mono_array8);
        org.junit.Assert.assertNotNull(poly10);
        org.junit.Assert.assertNotNull(poly13);
        org.junit.Assert.assertNotNull(poly16);
        org.junit.Assert.assertNotNull(poly17);
        org.junit.Assert.assertNotNull(poly20);
        org.junit.Assert.assertNotNull(mono_array21);
        org.junit.Assert.assertNotNull(poly23);
        org.junit.Assert.assertNotNull(poly24);
        org.junit.Assert.assertNotNull(poly25);
        org.junit.Assert.assertNotNull(poly28);
        org.junit.Assert.assertNotNull(poly31);
        org.junit.Assert.assertNotNull(poly32);
        org.junit.Assert.assertNotNull(mono_array35);
        org.junit.Assert.assertNotNull(mono_array38);
        org.junit.Assert.assertNotNull(mono_array40);
    }

    @Test
    public void test55() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test55");
        Poly poly0 = new Poly();
        Poly poly1 = new Poly();
        Poly poly2 = poly0.mult(poly1);
        java.lang.String str3 = poly0.toString();
        Poly poly4 = new Poly();
        Poly poly5 = new Poly();
        Poly poly6 = poly4.mult(poly5);
        Poly poly7 = new Poly();
        Poly poly8 = new Poly();
        Poly poly9 = poly7.mult(poly8);
        Poly poly10 = poly4.mult(poly9);
        Poly poly11 = new Poly();
        Poly poly12 = new Poly();
        Poly poly13 = poly11.mult(poly12);
        Mono[] mono_array14 = new Mono[] {};
        poly11.elements = mono_array14;
        Poly poly16 = poly10.mult(poly11);
        Poly poly17 = poly10.clone();
        Mono[] mono_array18 = poly10.elements;
        Poly poly19 = poly0.mult(poly10);
        Poly poly20 = new Poly();
        Poly poly21 = new Poly();
        Poly poly22 = poly20.mult(poly21);
        Poly poly23 = new Poly();
        Poly poly24 = new Poly();
        Poly poly25 = poly23.mult(poly24);
        Poly poly26 = poly20.mult(poly25);
        Poly poly27 = new Poly();
        Poly poly28 = new Poly();
        Poly poly29 = poly27.mult(poly28);
        Mono[] mono_array30 = new Mono[] {};
        poly27.elements = mono_array30;
        Poly poly32 = poly26.mult(poly27);
        Poly poly33 = poly32.clone();
        Poly poly34 = poly0.mult(poly33);
        Mono[] mono_array35 = poly0.elements;
        Poly poly36 = new Poly();
        Poly poly37 = new Poly();
        Poly poly38 = poly36.mult(poly37);
        Poly poly39 = new Poly();
        Poly poly40 = new Poly();
        Poly poly41 = poly39.mult(poly40);
        Poly poly42 = poly36.mult(poly41);
        Mono[] mono_array43 = poly42.elements;
        Poly poly44 = poly42.clone();
        Poly poly45 = poly0.mult(poly42);
        org.junit.Assert.assertNotNull(poly2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "(0/1)x^0 + (0/1)x^1 + (0/1)x^2 + (0/1)x^3 + (0/1)x^4 + (0/1)x^5 + (0/1)x^6 + (0/1)x^7 + (0/1)x^8 + (0/1)x^9" + "'", str3.equals("(0/1)x^0 + (0/1)x^1 + (0/1)x^2 + (0/1)x^3 + (0/1)x^4 + (0/1)x^5 + (0/1)x^6 + (0/1)x^7 + (0/1)x^8 + (0/1)x^9"));
        org.junit.Assert.assertNotNull(poly6);
        org.junit.Assert.assertNotNull(poly9);
        org.junit.Assert.assertNotNull(poly10);
        org.junit.Assert.assertNotNull(poly13);
        org.junit.Assert.assertNotNull(mono_array14);
        org.junit.Assert.assertNotNull(poly16);
        org.junit.Assert.assertNotNull(poly17);
        org.junit.Assert.assertNotNull(mono_array18);
        org.junit.Assert.assertNotNull(poly19);
        org.junit.Assert.assertNotNull(poly22);
        org.junit.Assert.assertNotNull(poly25);
        org.junit.Assert.assertNotNull(poly26);
        org.junit.Assert.assertNotNull(poly29);
        org.junit.Assert.assertNotNull(mono_array30);
        org.junit.Assert.assertNotNull(poly32);
        org.junit.Assert.assertNotNull(poly33);
        org.junit.Assert.assertNotNull(poly34);
        org.junit.Assert.assertNotNull(mono_array35);
        org.junit.Assert.assertNotNull(poly38);
        org.junit.Assert.assertNotNull(poly41);
        org.junit.Assert.assertNotNull(poly42);
        org.junit.Assert.assertNotNull(mono_array43);
        org.junit.Assert.assertNotNull(poly44);
        org.junit.Assert.assertNotNull(poly45);
    }

    @Test
    public void test56() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test56");
        Poly poly0 = new Poly();
        Poly poly1 = new Poly();
        Poly poly2 = poly0.mult(poly1);
        Poly poly3 = new Poly();
        Poly poly4 = new Poly();
        Poly poly5 = poly3.mult(poly4);
        Poly poly6 = poly0.mult(poly5);
        Poly poly7 = new Poly();
        Poly poly8 = new Poly();
        Poly poly9 = poly7.mult(poly8);
        Mono[] mono_array10 = new Mono[] {};
        poly7.elements = mono_array10;
        Poly poly12 = poly6.mult(poly7);
        Poly poly13 = poly6.clone();
        Poly poly14 = new Poly();
        Poly poly15 = new Poly();
        Poly poly16 = poly14.mult(poly15);
        Mono mono17 = null;
        Mono[] mono_array18 = new Mono[] { mono17 };
        poly14.elements = mono_array18;
        Mono[] mono_array20 = poly14.elements;
        poly6.elements = mono_array20;
        Poly poly22 = new Poly();
        Poly poly23 = new Poly();
        Poly poly24 = poly22.mult(poly23);
        Mono mono25 = null;
        Mono[] mono_array26 = new Mono[] { mono25 };
        poly22.elements = mono_array26;
        poly6.elements = mono_array26;
        org.junit.Assert.assertNotNull(poly2);
        org.junit.Assert.assertNotNull(poly5);
        org.junit.Assert.assertNotNull(poly6);
        org.junit.Assert.assertNotNull(poly9);
        org.junit.Assert.assertNotNull(mono_array10);
        org.junit.Assert.assertNotNull(poly12);
        org.junit.Assert.assertNotNull(poly13);
        org.junit.Assert.assertNotNull(poly16);
        org.junit.Assert.assertNotNull(mono_array18);
        org.junit.Assert.assertNotNull(mono_array20);
        org.junit.Assert.assertNotNull(poly24);
        org.junit.Assert.assertNotNull(mono_array26);
    }

    @Test
    public void test57() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test57");
        Poly poly0 = new Poly();
        Poly poly1 = new Poly();
        Poly poly2 = poly0.mult(poly1);
        Mono[] mono_array3 = poly0.elements;
        Poly poly4 = new Poly();
        Poly poly5 = new Poly();
        Poly poly6 = poly4.mult(poly5);
        Poly poly7 = poly0.mult(poly6);
        Mono mono8 = null;
        try {
            Poly poly9 = poly7.plus(mono8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(poly2);
        org.junit.Assert.assertNotNull(mono_array3);
        org.junit.Assert.assertNotNull(poly6);
        org.junit.Assert.assertNotNull(poly7);
    }

    @Test
    public void test58() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test58");
        Poly poly0 = new Poly();
        Poly poly1 = new Poly();
        Poly poly2 = poly0.mult(poly1);
        java.lang.String str3 = poly0.toString();
        Poly poly4 = new Poly();
        Poly poly5 = new Poly();
        Poly poly6 = poly4.mult(poly5);
        Poly poly7 = new Poly();
        Poly poly8 = new Poly();
        Poly poly9 = poly7.mult(poly8);
        Poly poly10 = poly4.mult(poly9);
        Poly poly11 = new Poly();
        Poly poly12 = new Poly();
        Poly poly13 = poly11.mult(poly12);
        Mono[] mono_array14 = new Mono[] {};
        poly11.elements = mono_array14;
        Poly poly16 = poly10.mult(poly11);
        Poly poly17 = poly10.clone();
        Mono[] mono_array18 = poly10.elements;
        Poly poly19 = poly0.mult(poly10);
        Poly poly20 = new Poly();
        Poly poly21 = new Poly();
        Poly poly22 = poly20.mult(poly21);
        Poly poly23 = new Poly();
        Poly poly24 = new Poly();
        Poly poly25 = poly23.mult(poly24);
        Poly poly26 = poly20.mult(poly25);
        Poly poly27 = new Poly();
        Poly poly28 = new Poly();
        Poly poly29 = poly27.mult(poly28);
        Mono[] mono_array30 = new Mono[] {};
        poly27.elements = mono_array30;
        Poly poly32 = poly26.mult(poly27);
        Poly poly33 = poly32.clone();
        Poly poly34 = poly0.mult(poly33);
        Mono mono35 = null;
        try {
            Poly poly36 = poly33.multMono(mono35);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(poly2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "(0/1)x^0 + (0/1)x^1 + (0/1)x^2 + (0/1)x^3 + (0/1)x^4 + (0/1)x^5 + (0/1)x^6 + (0/1)x^7 + (0/1)x^8 + (0/1)x^9" + "'", str3.equals("(0/1)x^0 + (0/1)x^1 + (0/1)x^2 + (0/1)x^3 + (0/1)x^4 + (0/1)x^5 + (0/1)x^6 + (0/1)x^7 + (0/1)x^8 + (0/1)x^9"));
        org.junit.Assert.assertNotNull(poly6);
        org.junit.Assert.assertNotNull(poly9);
        org.junit.Assert.assertNotNull(poly10);
        org.junit.Assert.assertNotNull(poly13);
        org.junit.Assert.assertNotNull(mono_array14);
        org.junit.Assert.assertNotNull(poly16);
        org.junit.Assert.assertNotNull(poly17);
        org.junit.Assert.assertNotNull(mono_array18);
        org.junit.Assert.assertNotNull(poly19);
        org.junit.Assert.assertNotNull(poly22);
        org.junit.Assert.assertNotNull(poly25);
        org.junit.Assert.assertNotNull(poly26);
        org.junit.Assert.assertNotNull(poly29);
        org.junit.Assert.assertNotNull(mono_array30);
        org.junit.Assert.assertNotNull(poly32);
        org.junit.Assert.assertNotNull(poly33);
        org.junit.Assert.assertNotNull(poly34);
    }

    @Test
    public void test59() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test59");
        Poly poly0 = new Poly();
        Poly poly1 = new Poly();
        Poly poly2 = poly0.mult(poly1);
        Poly poly3 = new Poly();
        Poly poly4 = new Poly();
        Poly poly5 = poly3.mult(poly4);
        Poly poly6 = poly0.mult(poly5);
        Poly poly7 = new Poly();
        Poly poly8 = new Poly();
        Poly poly9 = poly7.mult(poly8);
        Mono[] mono_array10 = new Mono[] {};
        poly7.elements = mono_array10;
        Poly poly12 = poly6.mult(poly7);
        Poly poly13 = poly12.clone();
        java.lang.String str14 = poly12.toString();
        Poly poly15 = poly12.clone();
        Mono mono16 = null;
        try {
            Poly poly17 = poly15.plus(mono16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(poly2);
        org.junit.Assert.assertNotNull(poly5);
        org.junit.Assert.assertNotNull(poly6);
        org.junit.Assert.assertNotNull(poly9);
        org.junit.Assert.assertNotNull(mono_array10);
        org.junit.Assert.assertNotNull(poly12);
        org.junit.Assert.assertNotNull(poly13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "(0/1)x^0 + (0/1)x^1 + (0/1)x^2 + (0/1)x^3 + (0/1)x^4 + (0/1)x^5 + (0/1)x^6 + (0/1)x^7 + (0/1)x^8 + (0/1)x^9" + "'", str14.equals("(0/1)x^0 + (0/1)x^1 + (0/1)x^2 + (0/1)x^3 + (0/1)x^4 + (0/1)x^5 + (0/1)x^6 + (0/1)x^7 + (0/1)x^8 + (0/1)x^9"));
        org.junit.Assert.assertNotNull(poly15);
    }

    @Test
    public void test60() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test60");
        Poly poly0 = new Poly();
        Poly poly1 = new Poly();
        Poly poly2 = poly0.mult(poly1);
        Poly poly3 = new Poly();
        Poly poly4 = new Poly();
        Poly poly5 = poly3.mult(poly4);
        Poly poly6 = poly0.mult(poly5);
        java.lang.String str7 = poly5.toString();
        Mono[] mono_array8 = poly5.elements;
        Mono[] mono_array9 = null;
        poly5.elements = mono_array9;
        org.junit.Assert.assertNotNull(poly2);
        org.junit.Assert.assertNotNull(poly5);
        org.junit.Assert.assertNotNull(poly6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "(0/1)x^0 + (0/1)x^1 + (0/1)x^2 + (0/1)x^3 + (0/1)x^4 + (0/1)x^5 + (0/1)x^6 + (0/1)x^7 + (0/1)x^8 + (0/1)x^9" + "'", str7.equals("(0/1)x^0 + (0/1)x^1 + (0/1)x^2 + (0/1)x^3 + (0/1)x^4 + (0/1)x^5 + (0/1)x^6 + (0/1)x^7 + (0/1)x^8 + (0/1)x^9"));
        org.junit.Assert.assertNotNull(mono_array8);
    }

    @Test
    public void test61() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test61");
        Poly poly0 = new Poly();
        Poly poly1 = new Poly();
        Poly poly2 = poly0.mult(poly1);
        Mono[] mono_array3 = new Mono[] {};
        poly0.elements = mono_array3;
        Poly poly5 = new Poly();
        Poly poly6 = new Poly();
        Poly poly7 = poly5.mult(poly6);
        Poly poly8 = poly7.clone();
        Poly poly9 = poly0.mult(poly8);
        Poly poly10 = poly9.clone();
        Poly poly11 = new Poly();
        Mono mono12 = null;
        Mono[] mono_array13 = new Mono[] { mono12 };
        poly11.elements = mono_array13;
        Mono mono15 = null;
        Mono[] mono_array16 = new Mono[] { mono15 };
        poly11.elements = mono_array16;
        poly9.elements = mono_array16;
        org.junit.Assert.assertNotNull(poly2);
        org.junit.Assert.assertNotNull(mono_array3);
        org.junit.Assert.assertNotNull(poly7);
        org.junit.Assert.assertNotNull(poly8);
        org.junit.Assert.assertNotNull(poly9);
        org.junit.Assert.assertNotNull(poly10);
        org.junit.Assert.assertNotNull(mono_array13);
        org.junit.Assert.assertNotNull(mono_array16);
    }

    @Test
    public void test62() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test62");
        Poly poly0 = new Poly();
        Poly poly1 = new Poly();
        Poly poly2 = poly0.mult(poly1);
        Poly poly3 = new Poly();
        Poly poly4 = new Poly();
        Poly poly5 = poly3.mult(poly4);
        Poly poly6 = poly0.mult(poly5);
        Mono[] mono_array7 = poly6.elements;
        Poly poly8 = poly6.clone();
        Mono[] mono_array9 = poly8.elements;
        org.junit.Assert.assertNotNull(poly2);
        org.junit.Assert.assertNotNull(poly5);
        org.junit.Assert.assertNotNull(poly6);
        org.junit.Assert.assertNotNull(mono_array7);
        org.junit.Assert.assertNotNull(poly8);
        org.junit.Assert.assertNotNull(mono_array9);
    }

    @Test
    public void test63() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test63");
        Poly poly0 = new Poly();
        Poly poly1 = new Poly();
        Poly poly2 = poly0.mult(poly1);
        Poly poly3 = new Poly();
        Poly poly4 = new Poly();
        Poly poly5 = poly3.mult(poly4);
        Poly poly6 = poly0.mult(poly5);
        Poly poly7 = new Poly();
        Poly poly8 = new Poly();
        Poly poly9 = poly7.mult(poly8);
        Mono[] mono_array10 = new Mono[] {};
        poly7.elements = mono_array10;
        Poly poly12 = poly6.mult(poly7);
        Poly poly13 = poly7.clone();
        Poly poly14 = new Poly();
        Poly poly15 = new Poly();
        Poly poly16 = poly14.mult(poly15);
        Poly poly17 = new Poly();
        Poly poly18 = new Poly();
        Poly poly19 = poly17.mult(poly18);
        Poly poly20 = new Poly();
        Poly poly21 = new Poly();
        Poly poly22 = poly20.mult(poly21);
        Poly poly23 = poly17.mult(poly22);
        Poly poly24 = new Poly();
        Poly poly25 = new Poly();
        Poly poly26 = poly24.mult(poly25);
        Mono[] mono_array27 = new Mono[] {};
        poly24.elements = mono_array27;
        Poly poly29 = poly23.mult(poly24);
        Mono[] mono_array30 = poly29.elements;
        poly14.elements = mono_array30;
        Poly poly32 = poly7.mult(poly14);
        Poly poly33 = poly32.clone();
        java.lang.String str34 = poly33.toString();
        Poly poly35 = new Poly();
        Poly poly36 = new Poly();
        Poly poly37 = poly35.mult(poly36);
        Poly poly38 = new Poly();
        Poly poly39 = new Poly();
        Poly poly40 = poly38.mult(poly39);
        Poly poly41 = poly35.mult(poly40);
        Poly poly42 = new Poly();
        Poly poly43 = new Poly();
        Poly poly44 = poly42.mult(poly43);
        Mono[] mono_array45 = new Mono[] {};
        poly42.elements = mono_array45;
        Poly poly47 = poly41.mult(poly42);
        Poly poly48 = poly41.clone();
        Mono[] mono_array49 = poly41.elements;
        poly33.elements = mono_array49;
        Poly poly51 = poly33.clone();
        org.junit.Assert.assertNotNull(poly2);
        org.junit.Assert.assertNotNull(poly5);
        org.junit.Assert.assertNotNull(poly6);
        org.junit.Assert.assertNotNull(poly9);
        org.junit.Assert.assertNotNull(mono_array10);
        org.junit.Assert.assertNotNull(poly12);
        org.junit.Assert.assertNotNull(poly13);
        org.junit.Assert.assertNotNull(poly16);
        org.junit.Assert.assertNotNull(poly19);
        org.junit.Assert.assertNotNull(poly22);
        org.junit.Assert.assertNotNull(poly23);
        org.junit.Assert.assertNotNull(poly26);
        org.junit.Assert.assertNotNull(mono_array27);
        org.junit.Assert.assertNotNull(poly29);
        org.junit.Assert.assertNotNull(mono_array30);
        org.junit.Assert.assertNotNull(poly32);
        org.junit.Assert.assertNotNull(poly33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "(0/1)x^0 + (0/1)x^1 + (0/1)x^2 + (0/1)x^3 + (0/1)x^4 + (0/1)x^5 + (0/1)x^6 + (0/1)x^7 + (0/1)x^8 + (0/1)x^9" + "'", str34.equals("(0/1)x^0 + (0/1)x^1 + (0/1)x^2 + (0/1)x^3 + (0/1)x^4 + (0/1)x^5 + (0/1)x^6 + (0/1)x^7 + (0/1)x^8 + (0/1)x^9"));
        org.junit.Assert.assertNotNull(poly37);
        org.junit.Assert.assertNotNull(poly40);
        org.junit.Assert.assertNotNull(poly41);
        org.junit.Assert.assertNotNull(poly44);
        org.junit.Assert.assertNotNull(mono_array45);
        org.junit.Assert.assertNotNull(poly47);
        org.junit.Assert.assertNotNull(poly48);
        org.junit.Assert.assertNotNull(mono_array49);
        org.junit.Assert.assertNotNull(poly51);
    }

    @Test
    public void test64() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test64");
        Poly poly0 = new Poly();
        Poly poly1 = new Poly();
        Poly poly2 = poly0.mult(poly1);
        java.lang.String str3 = poly0.toString();
        java.lang.String str4 = poly0.toString();
        org.junit.Assert.assertNotNull(poly2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "(0/1)x^0 + (0/1)x^1 + (0/1)x^2 + (0/1)x^3 + (0/1)x^4 + (0/1)x^5 + (0/1)x^6 + (0/1)x^7 + (0/1)x^8 + (0/1)x^9" + "'", str3.equals("(0/1)x^0 + (0/1)x^1 + (0/1)x^2 + (0/1)x^3 + (0/1)x^4 + (0/1)x^5 + (0/1)x^6 + (0/1)x^7 + (0/1)x^8 + (0/1)x^9"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "(0/1)x^0 + (0/1)x^1 + (0/1)x^2 + (0/1)x^3 + (0/1)x^4 + (0/1)x^5 + (0/1)x^6 + (0/1)x^7 + (0/1)x^8 + (0/1)x^9" + "'", str4.equals("(0/1)x^0 + (0/1)x^1 + (0/1)x^2 + (0/1)x^3 + (0/1)x^4 + (0/1)x^5 + (0/1)x^6 + (0/1)x^7 + (0/1)x^8 + (0/1)x^9"));
    }

    @Test
    public void test65() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test65");
        Poly poly0 = new Poly();
        java.lang.String str1 = poly0.toString();
        java.lang.String str2 = poly0.toString();
        Mono mono3 = null;
        try {
            Poly poly4 = poly0.multMono(mono3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "(0/1)x^0 + (0/1)x^1 + (0/1)x^2 + (0/1)x^3 + (0/1)x^4 + (0/1)x^5 + (0/1)x^6 + (0/1)x^7 + (0/1)x^8 + (0/1)x^9" + "'", str1.equals("(0/1)x^0 + (0/1)x^1 + (0/1)x^2 + (0/1)x^3 + (0/1)x^4 + (0/1)x^5 + (0/1)x^6 + (0/1)x^7 + (0/1)x^8 + (0/1)x^9"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "(0/1)x^0 + (0/1)x^1 + (0/1)x^2 + (0/1)x^3 + (0/1)x^4 + (0/1)x^5 + (0/1)x^6 + (0/1)x^7 + (0/1)x^8 + (0/1)x^9" + "'", str2.equals("(0/1)x^0 + (0/1)x^1 + (0/1)x^2 + (0/1)x^3 + (0/1)x^4 + (0/1)x^5 + (0/1)x^6 + (0/1)x^7 + (0/1)x^8 + (0/1)x^9"));
    }

    @Test
    public void test66() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test66");
        Poly poly0 = new Poly();
        Poly poly1 = new Poly();
        Poly poly2 = poly0.mult(poly1);
        Mono[] mono_array3 = poly0.elements;
        Poly poly4 = new Poly();
        Poly poly5 = new Poly();
        Poly poly6 = poly4.mult(poly5);
        Poly poly7 = poly0.mult(poly6);
        Mono mono8 = null;
        try {
            Poly poly9 = poly0.multMono(mono8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(poly2);
        org.junit.Assert.assertNotNull(mono_array3);
        org.junit.Assert.assertNotNull(poly6);
        org.junit.Assert.assertNotNull(poly7);
    }

    @Test
    public void test67() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test67");
        Poly poly0 = new Poly();
        Poly poly1 = new Poly();
        Poly poly2 = poly0.mult(poly1);
        Poly poly3 = new Poly();
        Poly poly4 = new Poly();
        Poly poly5 = poly3.mult(poly4);
        Poly poly6 = poly0.mult(poly5);
        Poly poly7 = new Poly();
        Poly poly8 = new Poly();
        Poly poly9 = poly7.mult(poly8);
        Mono[] mono_array10 = new Mono[] {};
        poly7.elements = mono_array10;
        Poly poly12 = poly6.mult(poly7);
        Poly poly13 = poly12.clone();
        Poly poly14 = poly12.clone();
        Poly poly15 = poly14.clone();
        java.lang.String str16 = poly14.toString();
        org.junit.Assert.assertNotNull(poly2);
        org.junit.Assert.assertNotNull(poly5);
        org.junit.Assert.assertNotNull(poly6);
        org.junit.Assert.assertNotNull(poly9);
        org.junit.Assert.assertNotNull(mono_array10);
        org.junit.Assert.assertNotNull(poly12);
        org.junit.Assert.assertNotNull(poly13);
        org.junit.Assert.assertNotNull(poly14);
        org.junit.Assert.assertNotNull(poly15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "(0/1)x^0 + (0/1)x^1 + (0/1)x^2 + (0/1)x^3 + (0/1)x^4 + (0/1)x^5 + (0/1)x^6 + (0/1)x^7 + (0/1)x^8 + (0/1)x^9" + "'", str16.equals("(0/1)x^0 + (0/1)x^1 + (0/1)x^2 + (0/1)x^3 + (0/1)x^4 + (0/1)x^5 + (0/1)x^6 + (0/1)x^7 + (0/1)x^8 + (0/1)x^9"));
    }

    @Test
    public void test68() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test68");
        Poly poly0 = new Poly();
        Mono mono1 = null;
        Mono[] mono_array2 = new Mono[] { mono1 };
        poly0.elements = mono_array2;
        Mono mono4 = null;
        Mono[] mono_array5 = new Mono[] { mono4 };
        poly0.elements = mono_array5;
        Poly poly7 = new Poly();
        Poly poly8 = new Poly();
        Poly poly9 = poly7.mult(poly8);
        Poly poly10 = new Poly();
        Poly poly11 = new Poly();
        Poly poly12 = poly10.mult(poly11);
        Poly poly13 = poly7.mult(poly12);
        Poly poly14 = new Poly();
        Poly poly15 = new Poly();
        Poly poly16 = poly14.mult(poly15);
        Mono[] mono_array17 = new Mono[] {};
        poly14.elements = mono_array17;
        Poly poly19 = poly13.mult(poly14);
        Poly poly20 = new Poly();
        Poly poly21 = new Poly();
        Poly poly22 = poly20.mult(poly21);
        Poly poly23 = poly13.mult(poly20);
        try {
            Poly poly24 = poly0.mult(poly23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(mono_array2);
        org.junit.Assert.assertNotNull(mono_array5);
        org.junit.Assert.assertNotNull(poly9);
        org.junit.Assert.assertNotNull(poly12);
        org.junit.Assert.assertNotNull(poly13);
        org.junit.Assert.assertNotNull(poly16);
        org.junit.Assert.assertNotNull(mono_array17);
        org.junit.Assert.assertNotNull(poly19);
        org.junit.Assert.assertNotNull(poly22);
        org.junit.Assert.assertNotNull(poly23);
    }

    @Test
    public void test69() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test69");
        Poly poly0 = new Poly();
        Poly poly1 = new Poly();
        Poly poly2 = poly0.mult(poly1);
        Poly poly3 = new Poly();
        Poly poly4 = new Poly();
        Poly poly5 = poly3.mult(poly4);
        Poly poly6 = poly0.mult(poly5);
        Poly poly7 = new Poly();
        Poly poly8 = new Poly();
        Poly poly9 = poly7.mult(poly8);
        Mono[] mono_array10 = new Mono[] {};
        poly7.elements = mono_array10;
        Poly poly12 = poly6.mult(poly7);
        Poly poly13 = poly6.clone();
        Mono mono14 = null;
        try {
            Poly poly15 = poly13.plus(mono14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(poly2);
        org.junit.Assert.assertNotNull(poly5);
        org.junit.Assert.assertNotNull(poly6);
        org.junit.Assert.assertNotNull(poly9);
        org.junit.Assert.assertNotNull(mono_array10);
        org.junit.Assert.assertNotNull(poly12);
        org.junit.Assert.assertNotNull(poly13);
    }

    @Test
    public void test70() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test70");
        Poly poly0 = new Poly();
        Poly poly1 = new Poly();
        Poly poly2 = poly0.mult(poly1);
        Poly poly3 = new Poly();
        Poly poly4 = new Poly();
        Poly poly5 = poly3.mult(poly4);
        Poly poly6 = poly0.mult(poly5);
        Poly poly7 = new Poly();
        Poly poly8 = new Poly();
        Poly poly9 = poly7.mult(poly8);
        Mono[] mono_array10 = new Mono[] {};
        poly7.elements = mono_array10;
        Poly poly12 = poly6.mult(poly7);
        Poly poly13 = poly6.clone();
        Poly poly14 = new Poly();
        Poly poly15 = new Poly();
        Poly poly16 = poly14.mult(poly15);
        Poly poly17 = new Poly();
        Poly poly18 = new Poly();
        Poly poly19 = poly17.mult(poly18);
        Poly poly20 = poly14.mult(poly19);
        Poly poly21 = new Poly();
        Poly poly22 = new Poly();
        Poly poly23 = poly21.mult(poly22);
        Mono[] mono_array24 = new Mono[] {};
        poly21.elements = mono_array24;
        Poly poly26 = poly20.mult(poly21);
        Poly poly27 = poly26.clone();
        Poly poly28 = poly26.clone();
        Poly poly29 = poly28.clone();
        Poly poly30 = poly13.mult(poly28);
        Mono[] mono_array31 = poly13.elements;
        org.junit.Assert.assertNotNull(poly2);
        org.junit.Assert.assertNotNull(poly5);
        org.junit.Assert.assertNotNull(poly6);
        org.junit.Assert.assertNotNull(poly9);
        org.junit.Assert.assertNotNull(mono_array10);
        org.junit.Assert.assertNotNull(poly12);
        org.junit.Assert.assertNotNull(poly13);
        org.junit.Assert.assertNotNull(poly16);
        org.junit.Assert.assertNotNull(poly19);
        org.junit.Assert.assertNotNull(poly20);
        org.junit.Assert.assertNotNull(poly23);
        org.junit.Assert.assertNotNull(mono_array24);
        org.junit.Assert.assertNotNull(poly26);
        org.junit.Assert.assertNotNull(poly27);
        org.junit.Assert.assertNotNull(poly28);
        org.junit.Assert.assertNotNull(poly29);
        org.junit.Assert.assertNotNull(poly30);
        org.junit.Assert.assertNotNull(mono_array31);
    }

    @Test
    public void test71() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test71");
        Poly poly0 = new Poly();
        Poly poly1 = new Poly();
        Poly poly2 = poly0.mult(poly1);
        Mono[] mono_array3 = poly0.elements;
        Mono mono4 = null;
        try {
            Poly poly5 = poly0.multMono(mono4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(poly2);
        org.junit.Assert.assertNotNull(mono_array3);
    }

    @Test
    public void test72() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test72");
        Poly poly0 = new Poly();
        Poly poly1 = poly0.clone();
        Poly poly2 = new Poly();
        Poly poly3 = new Poly();
        Poly poly4 = poly2.mult(poly3);
        Poly poly5 = new Poly();
        Poly poly6 = new Poly();
        Poly poly7 = poly5.mult(poly6);
        Poly poly8 = poly2.mult(poly7);
        Poly poly9 = new Poly();
        Poly poly10 = new Poly();
        Poly poly11 = poly9.mult(poly10);
        Mono[] mono_array12 = new Mono[] {};
        poly9.elements = mono_array12;
        Poly poly14 = poly8.mult(poly9);
        Poly poly15 = poly9.clone();
        Poly poly16 = poly1.mult(poly15);
        Poly poly17 = new Poly();
        Poly poly18 = new Poly();
        Poly poly19 = poly17.mult(poly18);
        Poly poly20 = new Poly();
        Poly poly21 = new Poly();
        Poly poly22 = poly20.mult(poly21);
        Poly poly23 = poly17.mult(poly22);
        Poly poly24 = new Poly();
        Poly poly25 = new Poly();
        Poly poly26 = poly24.mult(poly25);
        Mono[] mono_array27 = new Mono[] {};
        poly24.elements = mono_array27;
        Poly poly29 = poly23.mult(poly24);
        Poly poly30 = poly24.clone();
        Mono[] mono_array31 = poly30.elements;
        poly1.elements = mono_array31;
        org.junit.Assert.assertNotNull(poly1);
        org.junit.Assert.assertNotNull(poly4);
        org.junit.Assert.assertNotNull(poly7);
        org.junit.Assert.assertNotNull(poly8);
        org.junit.Assert.assertNotNull(poly11);
        org.junit.Assert.assertNotNull(mono_array12);
        org.junit.Assert.assertNotNull(poly14);
        org.junit.Assert.assertNotNull(poly15);
        org.junit.Assert.assertNotNull(poly16);
        org.junit.Assert.assertNotNull(poly19);
        org.junit.Assert.assertNotNull(poly22);
        org.junit.Assert.assertNotNull(poly23);
        org.junit.Assert.assertNotNull(poly26);
        org.junit.Assert.assertNotNull(mono_array27);
        org.junit.Assert.assertNotNull(poly29);
        org.junit.Assert.assertNotNull(poly30);
        org.junit.Assert.assertNotNull(mono_array31);
    }

    @Test
    public void test73() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test73");
        Poly poly0 = new Poly();
        Poly poly1 = poly0.clone();
        java.lang.String str2 = poly1.toString();
        org.junit.Assert.assertNotNull(poly1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "(0/1)x^0 + (0/1)x^1 + (0/1)x^2 + (0/1)x^3 + (0/1)x^4 + (0/1)x^5 + (0/1)x^6 + (0/1)x^7 + (0/1)x^8 + (0/1)x^9" + "'", str2.equals("(0/1)x^0 + (0/1)x^1 + (0/1)x^2 + (0/1)x^3 + (0/1)x^4 + (0/1)x^5 + (0/1)x^6 + (0/1)x^7 + (0/1)x^8 + (0/1)x^9"));
    }

    @Test
    public void test74() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test74");
        Poly poly0 = new Poly();
        Poly poly1 = new Poly();
        Poly poly2 = poly0.mult(poly1);
        Poly poly3 = new Poly();
        Poly poly4 = new Poly();
        Poly poly5 = poly3.mult(poly4);
        Poly poly6 = poly0.mult(poly5);
        Mono mono7 = null;
        try {
            Poly poly8 = poly5.plus(mono7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(poly2);
        org.junit.Assert.assertNotNull(poly5);
        org.junit.Assert.assertNotNull(poly6);
    }

    @Test
    public void test75() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test75");
        Poly poly0 = new Poly();
        Poly poly1 = new Poly();
        Poly poly2 = poly0.mult(poly1);
        Poly poly3 = new Poly();
        Poly poly4 = new Poly();
        Poly poly5 = poly3.mult(poly4);
        Poly poly6 = poly0.mult(poly5);
        Poly poly7 = new Poly();
        Poly poly8 = new Poly();
        Poly poly9 = poly7.mult(poly8);
        Mono[] mono_array10 = new Mono[] {};
        poly7.elements = mono_array10;
        Poly poly12 = poly6.mult(poly7);
        Poly poly13 = poly7.clone();
        Poly poly14 = new Poly();
        Poly poly15 = new Poly();
        Poly poly16 = poly14.mult(poly15);
        Poly poly17 = new Poly();
        Poly poly18 = new Poly();
        Poly poly19 = poly17.mult(poly18);
        Poly poly20 = new Poly();
        Poly poly21 = new Poly();
        Poly poly22 = poly20.mult(poly21);
        Poly poly23 = poly17.mult(poly22);
        Poly poly24 = new Poly();
        Poly poly25 = new Poly();
        Poly poly26 = poly24.mult(poly25);
        Mono[] mono_array27 = new Mono[] {};
        poly24.elements = mono_array27;
        Poly poly29 = poly23.mult(poly24);
        Mono[] mono_array30 = poly29.elements;
        poly14.elements = mono_array30;
        Poly poly32 = poly7.mult(poly14);
        Poly poly33 = poly32.clone();
        Poly poly34 = new Poly();
        Poly poly35 = new Poly();
        Poly poly36 = poly34.mult(poly35);
        Mono[] mono_array37 = new Mono[] {};
        poly34.elements = mono_array37;
        Poly poly39 = new Poly();
        Poly poly40 = new Poly();
        Poly poly41 = poly39.mult(poly40);
        Poly poly42 = poly41.clone();
        Poly poly43 = poly34.mult(poly42);
        Poly poly44 = poly43.clone();
        Poly poly45 = poly33.mult(poly44);
        Poly poly46 = new Poly();
        Poly poly47 = new Poly();
        Poly poly48 = poly46.mult(poly47);
        Mono[] mono_array49 = new Mono[] {};
        poly46.elements = mono_array49;
        Poly poly51 = poly46.clone();
        Mono[] mono_array52 = poly46.elements;
        poly45.elements = mono_array52;
        org.junit.Assert.assertNotNull(poly2);
        org.junit.Assert.assertNotNull(poly5);
        org.junit.Assert.assertNotNull(poly6);
        org.junit.Assert.assertNotNull(poly9);
        org.junit.Assert.assertNotNull(mono_array10);
        org.junit.Assert.assertNotNull(poly12);
        org.junit.Assert.assertNotNull(poly13);
        org.junit.Assert.assertNotNull(poly16);
        org.junit.Assert.assertNotNull(poly19);
        org.junit.Assert.assertNotNull(poly22);
        org.junit.Assert.assertNotNull(poly23);
        org.junit.Assert.assertNotNull(poly26);
        org.junit.Assert.assertNotNull(mono_array27);
        org.junit.Assert.assertNotNull(poly29);
        org.junit.Assert.assertNotNull(mono_array30);
        org.junit.Assert.assertNotNull(poly32);
        org.junit.Assert.assertNotNull(poly33);
        org.junit.Assert.assertNotNull(poly36);
        org.junit.Assert.assertNotNull(mono_array37);
        org.junit.Assert.assertNotNull(poly41);
        org.junit.Assert.assertNotNull(poly42);
        org.junit.Assert.assertNotNull(poly43);
        org.junit.Assert.assertNotNull(poly44);
        org.junit.Assert.assertNotNull(poly45);
        org.junit.Assert.assertNotNull(poly48);
        org.junit.Assert.assertNotNull(mono_array49);
        org.junit.Assert.assertNotNull(poly51);
        org.junit.Assert.assertNotNull(mono_array52);
    }
}

