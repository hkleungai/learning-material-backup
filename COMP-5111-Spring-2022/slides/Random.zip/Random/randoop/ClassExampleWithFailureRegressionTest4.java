import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class ClassExampleWithFailureRegressionTest4 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test001");
        int i2 = ClassExampleWithFailure.foo(1188298752, 2048);
        org.junit.Assert.assertTrue(i2 == 1073741824);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test002");
        int i2 = ClassExampleWithFailure.foo(1803550720, (-1371537408));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test003");
        int i2 = ClassExampleWithFailure.foo(1577058304, 224000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test004");
        int i2 = ClassExampleWithFailure.foo(5324800, (-2007040000));
        org.junit.Assert.assertTrue(i2 == (-2147483648));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test005");
        int i1 = ClassExampleWithFailure.twice(1769996288);
        org.junit.Assert.assertTrue(i1 == (-754974720));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test006");
        int i2 = ClassExampleWithFailure.foo(1954545664, 123731968);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test007");
        int i2 = ClassExampleWithFailure.foo((int) '4', (-22400));
        org.junit.Assert.assertTrue(i2 == (-2329600));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test008");
        int i2 = ClassExampleWithFailure.foo((int) 'a', (-2048));
        org.junit.Assert.assertTrue(i2 == (-397312));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test009");
        int i2 = ClassExampleWithFailure.foo(1946157056, 52428800);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test010");
        int i1 = ClassExampleWithFailure.twice(229376000);
        org.junit.Assert.assertTrue(i1 == 458752000);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test011");
        int i2 = ClassExampleWithFailure.foo(2097152000, 310400);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test012");
        int i2 = ClassExampleWithFailure.foo(248320000, (-1024));
        org.junit.Assert.assertTrue(i2 == (-1753219072));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test013");
        int i2 = ClassExampleWithFailure.foo(1434443776, (-1280));
        org.junit.Assert.assertTrue(i2 == 20971520);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test014");
        int i2 = ClassExampleWithFailure.foo(1879048192, (-1795162112));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test015");
        int i1 = ClassExampleWithFailure.twice((-130023424));
        org.junit.Assert.assertTrue(i1 == (-260046848));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test016");
        int i2 = ClassExampleWithFailure.foo(0, (-1979711488));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test017");
        int i2 = ClassExampleWithFailure.foo(1267400704, 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test018");
        int i2 = ClassExampleWithFailure.foo(19269632, 93184000);
        org.junit.Assert.assertTrue(i2 == 1577058304);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test019");
        int i2 = ClassExampleWithFailure.foo((-1146880000), 10240000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test020");
        int i2 = ClassExampleWithFailure.foo(10240000, 140509184);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test021");
        int i2 = ClassExampleWithFailure.foo((-1902116864), 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test022");
        int i1 = ClassExampleWithFailure.twice((-2329600));
        org.junit.Assert.assertTrue(i1 == (-4659200));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test023");
        int i2 = ClassExampleWithFailure.foo((-1024), 2048000);
        org.junit.Assert.assertTrue(i2 == 100663296);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test024");
        int i1 = ClassExampleWithFailure.twice((-8192));
        org.junit.Assert.assertTrue(i1 == (-16384));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test025");
        int i2 = ClassExampleWithFailure.foo(248320, 20971520);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test026");
        int i2 = ClassExampleWithFailure.foo(16384000, (-1083703296));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test027");
        int i2 = ClassExampleWithFailure.foo((-104857600), 1740177408);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test028");
        int i2 = ClassExampleWithFailure.foo((-209715200), 1003520000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test029");
        int i2 = ClassExampleWithFailure.foo((-286720000), (-286720000));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test030");
        int i2 = ClassExampleWithFailure.foo(112000, (-1363607552));
        org.junit.Assert.assertTrue(i2 == 1392508928);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test031");
        int i2 = ClassExampleWithFailure.foo(167772160, 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test032");
        int i2 = ClassExampleWithFailure.foo((-234881024), (-71680));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test033");
        int i2 = ClassExampleWithFailure.foo(4480000, (-1040187392));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test034");
        int i2 = ClassExampleWithFailure.foo(1064960000, (-1212153856));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test035");
        int i2 = ClassExampleWithFailure.foo(1210056704, (-201326592));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test036");
        int i2 = ClassExampleWithFailure.foo(1426063360, 1135214592);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test037");
        int i2 = ClassExampleWithFailure.foo((-397934592), 567607296);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test038");
        int i2 = ClassExampleWithFailure.foo(1660944384, (-1744830464));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test039");
        int i2 = ClassExampleWithFailure.foo((int) 'a', (-25600000));
        org.junit.Assert.assertTrue(i2 == (-671432704));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test040");
        int i2 = ClassExampleWithFailure.foo((-802816000), 810123264);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test041");
        int i2 = ClassExampleWithFailure.foo((-31040), 248320000);
        org.junit.Assert.assertTrue(i2 == (-1067974656));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test042");
        int i1 = ClassExampleWithFailure.twice((-627200));
        org.junit.Assert.assertTrue(i1 == (-1254400));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test043");
        int i2 = ClassExampleWithFailure.foo(0, (-5242880));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test044");
        int i2 = ClassExampleWithFailure.foo(36700160, 421789696);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test045");
        int i2 = ClassExampleWithFailure.foo(981467136, 2127560704);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test046");
        int i2 = ClassExampleWithFailure.foo((-1042808832), 3880);
        org.junit.Assert.assertTrue(i2 == (-478150656));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test047");
        int i1 = ClassExampleWithFailure.twice((-1992294400));
        org.junit.Assert.assertTrue(i1 == 310378496);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test048");
        int i2 = ClassExampleWithFailure.foo((int) (byte) 0, (-671432704));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test049");
        int i2 = ClassExampleWithFailure.foo(1358954496, (-198967296));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test050");
        int i1 = ClassExampleWithFailure.twice(397934592);
        org.junit.Assert.assertTrue(i1 == 795869184);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test051");
        int i2 = ClassExampleWithFailure.foo((-1170210816), (int) (byte) 10);
        org.junit.Assert.assertTrue(i2 == (-1929379840));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test052");
        int i2 = ClassExampleWithFailure.foo(1024000000, (-327680));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test053");
        int i1 = ClassExampleWithFailure.twice((-1229455360));
        org.junit.Assert.assertTrue(i1 == 1836056576);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test054");
        int i2 = ClassExampleWithFailure.foo((-1486094336), 2097152000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test055");
        int i1 = ClassExampleWithFailure.twice((-398458880));
        org.junit.Assert.assertTrue(i1 == (-796917760));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test056");
        int i2 = ClassExampleWithFailure.foo(18350080, 4480);
        org.junit.Assert.assertTrue(i2 == 1207959552);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test057");
        int i1 = ClassExampleWithFailure.twice(1962934272);
        org.junit.Assert.assertTrue(i1 == (-369098752));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test058");
        int i2 = ClassExampleWithFailure.foo((-1732247552), 248320000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test059");
        int i2 = ClassExampleWithFailure.foo((-520093696), 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test060");
        int i2 = ClassExampleWithFailure.foo((-1677721600), (-2071986176));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test061");
        int i1 = ClassExampleWithFailure.twice(248320000);
        org.junit.Assert.assertTrue(i1 == 496640000);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test062");
        int i2 = ClassExampleWithFailure.foo(1946157056, (-1986560000));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test063");
        int i2 = ClassExampleWithFailure.foo(4480, 199229440);
        org.junit.Assert.assertTrue(i2 == (-1610612736));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test064");
        int i1 = ClassExampleWithFailure.twice(1820327936);
        org.junit.Assert.assertTrue(i1 == (-654311424));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test065");
        int i1 = ClassExampleWithFailure.twice((-439040000));
        org.junit.Assert.assertTrue(i1 == (-878080000));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test066");
        int i2 = ClassExampleWithFailure.foo((-1513783296), (-1753219072));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test067");
        int i2 = ClassExampleWithFailure.foo(3136000, (-130023424));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test068");
        int i2 = ClassExampleWithFailure.foo((-1111490560), 33554432);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test069");
        int i2 = ClassExampleWithFailure.foo(1138753536, 1462763520);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test070");
        int i2 = ClassExampleWithFailure.foo(64000, 2097152000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test071");
        int i2 = ClassExampleWithFailure.foo(71680000, (-209715200));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test072");
        int i2 = ClassExampleWithFailure.foo(4480, (-57344000));
        org.junit.Assert.assertTrue(i2 == 1593835520);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test073");
        int i1 = ClassExampleWithFailure.twice((-85196800));
        org.junit.Assert.assertTrue(i1 == (-170393600));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test074");
        int i2 = ClassExampleWithFailure.foo(1552, (-2036334592));
        org.junit.Assert.assertTrue(i2 == 1409286144);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test075");
        int i2 = ClassExampleWithFailure.foo(1076494336, 1132462080);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test076");
        int i2 = ClassExampleWithFailure.foo((-770703360), 1535115264);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test077");
        int i1 = ClassExampleWithFailure.twice((-1067974656));
        org.junit.Assert.assertTrue(i1 == (-2135949312));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test078");
        int i2 = ClassExampleWithFailure.foo(2030043136, 1123549184);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test079");
        int i2 = ClassExampleWithFailure.foo(110100480, 293601280);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test080");
        int i2 = ClassExampleWithFailure.foo(641728512, (-2024538112));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test081");
        int i1 = ClassExampleWithFailure.twice(2048);
        org.junit.Assert.assertTrue(i1 == 4096);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test082");
        int i2 = ClassExampleWithFailure.foo(301989888, 109051904);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test083");
        int i2 = ClassExampleWithFailure.foo((-830472192), 1940);
        org.junit.Assert.assertTrue(i2 == (-1006632960));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test084");
        int i1 = ClassExampleWithFailure.twice(1317011456);
        org.junit.Assert.assertTrue(i1 == (-1660944384));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test085");
        int i2 = ClassExampleWithFailure.foo(31040, (-192937984));
        org.junit.Assert.assertTrue(i2 == 1073741824);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test086");
        int i1 = ClassExampleWithFailure.twice(734003200);
        org.junit.Assert.assertTrue(i1 == 1468006400);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test087");
        int i2 = ClassExampleWithFailure.foo(2013265920, (-1709178880));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test088");
        int i2 = ClassExampleWithFailure.foo(245891072, 795869184);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test089");
        int i1 = ClassExampleWithFailure.twice(1593835520);
        org.junit.Assert.assertTrue(i1 == (-1107296256));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test090");
        int i2 = ClassExampleWithFailure.foo(3584000, 567607296);
        org.junit.Assert.assertTrue(i2 == (-536870912));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test091");
        int i2 = ClassExampleWithFailure.foo((-1170210816), 429916160);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test092");
        int i2 = ClassExampleWithFailure.foo(1811939328, (-570425344));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test093");
        int i2 = ClassExampleWithFailure.foo((-603979776), 186368000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test094");
        int i1 = ClassExampleWithFailure.twice(10240);
        org.junit.Assert.assertTrue(i1 == 20480);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test095");
        int i2 = ClassExampleWithFailure.foo(0, 1803550720);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test096");
        int i1 = ClassExampleWithFailure.twice(245891072);
        org.junit.Assert.assertTrue(i1 == 491782144);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test097");
        int i1 = ClassExampleWithFailure.twice(192696320);
        org.junit.Assert.assertTrue(i1 == 385392640);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test098");
        int i2 = ClassExampleWithFailure.foo(17920000, (-790626304));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test099");
        int i2 = ClassExampleWithFailure.foo((-1709178880), (-947912704));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test100");
        int i1 = ClassExampleWithFailure.twice(1179648000);
        org.junit.Assert.assertTrue(i1 == (-1935671296));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test101");
        int i2 = ClassExampleWithFailure.foo((-1761607680), 22400);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test102");
        int i2 = ClassExampleWithFailure.foo(134217728, 443809792);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test103");
        int i2 = ClassExampleWithFailure.foo(192696320, (-280));
        org.junit.Assert.assertTrue(i2 == (-535756800));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test104");
        int i1 = ClassExampleWithFailure.twice(161408);
        org.junit.Assert.assertTrue(i1 == 322816);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test105");
        int i2 = ClassExampleWithFailure.foo((-889192448), 1042808832);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test106");
        int i2 = ClassExampleWithFailure.foo((-1677721600), (-805306368));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test107");
        int i2 = ClassExampleWithFailure.foo(2013265920, 16384000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test108");
        int i2 = ClassExampleWithFailure.foo(0, 100663296);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test109");
        int i2 = ClassExampleWithFailure.foo(229376000, 128000);
        org.junit.Assert.assertTrue(i2 == (-536870912));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test110");
        int i2 = ClassExampleWithFailure.foo((-179200), 1713373184);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test111");
        int i2 = ClassExampleWithFailure.foo(268435456, (-1543503872));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test112");
        int i2 = ClassExampleWithFailure.foo(166400, (-6400));
        org.junit.Assert.assertTrue(i2 == (-2129920000));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test113");
        int i1 = ClassExampleWithFailure.twice((-1426079744));
        org.junit.Assert.assertTrue(i1 == 1442807808);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test114");
        int i2 = ClassExampleWithFailure.foo(402653184, (-2113929216));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test115");
        int i2 = ClassExampleWithFailure.foo(3104000, 1578106880);
        org.junit.Assert.assertTrue(i2 == (-1610612736));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test116");
        int i2 = ClassExampleWithFailure.foo(0, 436207616);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test117");
        int i2 = ClassExampleWithFailure.foo(80, 292552704);
        org.junit.Assert.assertTrue(i2 == (-436207616));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test118");
        int i2 = ClassExampleWithFailure.foo((-1549271040), (-1509425152));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test119");
        int i2 = ClassExampleWithFailure.foo(512000000, 443809792);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test120");
        int i1 = ClassExampleWithFailure.twice(496640000);
        org.junit.Assert.assertTrue(i1 == 993280000);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test121");
        int i2 = ClassExampleWithFailure.foo(3584000, (-4659200));
        org.junit.Assert.assertTrue(i2 == 520093696);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test122");
        int i1 = ClassExampleWithFailure.twice(99328);
        org.junit.Assert.assertTrue(i1 == 198656);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test123");
        int i2 = ClassExampleWithFailure.foo((-301989888), 1835008000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test124");
        int i2 = ClassExampleWithFailure.foo(1567752192, 629145600);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test125");
        int i2 = ClassExampleWithFailure.foo(1262485504, (-2048));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test126");
        int i2 = ClassExampleWithFailure.foo(3136000, 1146880000);
        org.junit.Assert.assertTrue(i2 == (-1342177280));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test127");
        int i2 = ClassExampleWithFailure.foo(458227712, (-128));
        org.junit.Assert.assertTrue(i2 == (-1342177280));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test128");
        int i2 = ClassExampleWithFailure.foo(19600, (-16000));
        org.junit.Assert.assertTrue(i2 == (-627200000));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test129");
        int i2 = ClassExampleWithFailure.foo(1064960000, (-996147200));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test130");
        int i2 = ClassExampleWithFailure.foo(1308622848, (-8960));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test131");
        int i1 = ClassExampleWithFailure.twice((-4));
        org.junit.Assert.assertTrue(i1 == (-8));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test132");
        int i2 = ClassExampleWithFailure.foo((-80), (-248320000));
        org.junit.Assert.assertTrue(i2 == 1076494336);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test133");
        int i2 = ClassExampleWithFailure.foo((-256000), (-2621440));
        org.junit.Assert.assertTrue(i2 == (-2147483648));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test134");
        int i2 = ClassExampleWithFailure.foo(1708392448, (-878080000));
        org.junit.Assert.assertTrue(i2 == (-2147483648));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test135");
        int i1 = ClassExampleWithFailure.twice((-1107296256));
        org.junit.Assert.assertTrue(i1 == 2080374784);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test136");
        int i1 = ClassExampleWithFailure.twice(973078528);
        org.junit.Assert.assertTrue(i1 == 1946157056);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test137");
        int i1 = ClassExampleWithFailure.twice((-6656000));
        org.junit.Assert.assertTrue(i1 == (-13312000));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test138");
        int i2 = ClassExampleWithFailure.foo(1740177408, (-1560281088));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test139");
        int i2 = ClassExampleWithFailure.foo(536870912, 192696320);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test140");
        int i2 = ClassExampleWithFailure.foo((-114688000), 1178599424);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test141");
        int i2 = ClassExampleWithFailure.foo((-1140850688), (-2036334592));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test142");
        int i1 = ClassExampleWithFailure.twice((-229376000));
        org.junit.Assert.assertTrue(i1 == (-458752000));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test143");
        int i1 = ClassExampleWithFailure.twice(1267400704);
        org.junit.Assert.assertTrue(i1 == (-1760165888));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test144");
        int i1 = ClassExampleWithFailure.twice(11010048);
        org.junit.Assert.assertTrue(i1 == 22020096);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test145");
        int i2 = ClassExampleWithFailure.foo(320000, (-458752000));
        org.junit.Assert.assertTrue(i2 == (-1610612736));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test146");
        int i2 = ClassExampleWithFailure.foo((-71680000), 679215104);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test147");
        int i1 = ClassExampleWithFailure.twice(2059665408);
        org.junit.Assert.assertTrue(i1 == (-175636480));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test148");
        int i1 = ClassExampleWithFailure.twice(2048000);
        org.junit.Assert.assertTrue(i1 == 4096000);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test149");
        int i2 = ClassExampleWithFailure.foo(612368384, 794624000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test150");
        int i2 = ClassExampleWithFailure.foo((-140), 1541406720);
        org.junit.Assert.assertTrue(i2 == (-2097152000));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test151");
        int i2 = ClassExampleWithFailure.foo((-2621440), (-62720000));
        org.junit.Assert.assertTrue(i2 == (-2147483648));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test152");
        int i2 = ClassExampleWithFailure.foo((-1567752192), 2113929216);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test153");
        int i2 = ClassExampleWithFailure.foo(1207959552, 754974720);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test154");
        int i2 = ClassExampleWithFailure.foo(5324800, 782237696);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test155");
        int i2 = ClassExampleWithFailure.foo(843055104, (-10649600));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test156");
        int i2 = ClassExampleWithFailure.foo((-536870912), 109051904);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test157");
        int i2 = ClassExampleWithFailure.foo(603979776, 201326592);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test158");
        int i2 = ClassExampleWithFailure.foo(102400000, 1486094336);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test159");
        int i2 = ClassExampleWithFailure.foo(80, (-1845493760));
        org.junit.Assert.assertTrue(i2 == 1073741824);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test160");
        int i2 = ClassExampleWithFailure.foo((-624951296), 320);
        org.junit.Assert.assertTrue(i2 == (-536870912));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test161");
        int i2 = ClassExampleWithFailure.foo(10240000, 1744830464);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test162");
        int i1 = ClassExampleWithFailure.twice((-819200));
        org.junit.Assert.assertTrue(i1 == (-1638400));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test163");
        int i2 = ClassExampleWithFailure.foo(1626079232, (-2127560704));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test164");
        int i2 = ClassExampleWithFailure.foo(1216768000, 2080374784);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test165");
        int i2 = ClassExampleWithFailure.foo((-603979776), 1626079232);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test166");
        int i2 = ClassExampleWithFailure.foo(2046820352, 19600);
        org.junit.Assert.assertTrue(i2 == 1073741824);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test167");
        int i2 = ClassExampleWithFailure.foo((-1107296256), 1135214592);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test168");
        int i1 = ClassExampleWithFailure.twice((-170393600));
        org.junit.Assert.assertTrue(i1 == (-340787200));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test169");
        int i2 = ClassExampleWithFailure.foo((-1744830464), (-1509425152));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test170");
        int i2 = ClassExampleWithFailure.foo((-1709178880), 872415232);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test171");
        int i2 = ClassExampleWithFailure.foo((-1404436480), 2097152000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test172");
        int i1 = ClassExampleWithFailure.twice((-2007040000));
        org.junit.Assert.assertTrue(i1 == 280887296);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test173");
        int i2 = ClassExampleWithFailure.foo((-1024000000), (-1560281088));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test174");
        int i2 = ClassExampleWithFailure.foo(1946157056, 88080384);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test175");
        int i2 = ClassExampleWithFailure.foo(1369440256, 738197504);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test176");
        int i2 = ClassExampleWithFailure.foo((-4000), (-1918369792));
        org.junit.Assert.assertTrue(i2 == 1040187392);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test177");
        int i2 = ClassExampleWithFailure.foo(310400, 1003520000);
        org.junit.Assert.assertTrue(i2 == 209715200);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test178");
        int i2 = ClassExampleWithFailure.foo(1371537408, 3584000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test179");
        int i2 = ClassExampleWithFailure.foo(1879048192, (-1371537408));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test180");
        int i2 = ClassExampleWithFailure.foo(320000, 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test181");
        int i2 = ClassExampleWithFailure.foo(1064960000, 1600);
        org.junit.Assert.assertTrue(i2 == 1962934272);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test182");
        int i2 = ClassExampleWithFailure.foo(0, 1135214592);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test183");
        int i2 = ClassExampleWithFailure.foo((-4096), (-2122317824));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test184");
        int i2 = ClassExampleWithFailure.foo((-1660944384), 553648128);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test185");
        int i2 = ClassExampleWithFailure.foo(15520, 624951296);
        org.junit.Assert.assertTrue(i2 == (-1879048192));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test186");
        int i2 = ClassExampleWithFailure.foo(194, 198656);
        org.junit.Assert.assertTrue(i2 == 77078528);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test187");
        int i2 = ClassExampleWithFailure.foo((-2139095040), (-2129920000));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test188");
        int i2 = ClassExampleWithFailure.foo(96348160, (-512000000));
        org.junit.Assert.assertTrue(i2 == (-1744830464));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test189");
        int i2 = ClassExampleWithFailure.foo(1509949440, 1123549184);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test190");
        int i2 = ClassExampleWithFailure.foo((-192937984), (-6656000));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test191");
        int i2 = ClassExampleWithFailure.foo((-4096), (-512000));
        org.junit.Assert.assertTrue(i2 == (-100663296));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test192");
        int i2 = ClassExampleWithFailure.foo((-1795162112), 8000);
        org.junit.Assert.assertTrue(i2 == (-2147483648));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test193");
        int i2 = ClassExampleWithFailure.foo(458227712, 1216768000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test194");
        int i2 = ClassExampleWithFailure.foo(1744830464, (-2017460224));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test195");
        int i2 = ClassExampleWithFailure.foo(6400, (-795869184));
        org.junit.Assert.assertTrue(i2 == 536870912);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test196");
        int i2 = ClassExampleWithFailure.foo(2071986176, (-535756800));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test197");
        int i2 = ClassExampleWithFailure.foo(421789696, 1018167296);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test198");
        int i2 = ClassExampleWithFailure.foo(220200960, (-268435456));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test199");
        int i2 = ClassExampleWithFailure.foo(1940, 1543503872);
        org.junit.Assert.assertTrue(i2 == 1610612736);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test200");
        int i2 = ClassExampleWithFailure.foo(1778384896, 210894848);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test201");
        int i2 = ClassExampleWithFailure.foo(1369440256, 5120000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test202");
        int i1 = ClassExampleWithFailure.twice(1174405120);
        org.junit.Assert.assertTrue(i1 == (-1946157056));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test203");
        int i2 = ClassExampleWithFailure.foo(1803550720, (-654311424));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test204");
        int i2 = ClassExampleWithFailure.foo(1649410048, 1135214592);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test205");
        int i2 = ClassExampleWithFailure.foo((-599785472), 4096);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test206");
        int i2 = ClassExampleWithFailure.foo(419430400, (-218103808));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test207");
        int i1 = ClassExampleWithFailure.twice(77078528);
        org.junit.Assert.assertTrue(i1 == 154157056);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test208");
        int i2 = ClassExampleWithFailure.foo(1439432704, 602176);
        org.junit.Assert.assertTrue(i2 == 1711276032);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test209");
        int i2 = ClassExampleWithFailure.foo(560, 71680000);
        org.junit.Assert.assertTrue(i2 == (-1322778624));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test210");
        int i1 = ClassExampleWithFailure.twice(556236800);
        org.junit.Assert.assertTrue(i1 == 1112473600);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test211");
        int i2 = ClassExampleWithFailure.foo((-110100480), 112000);
        org.junit.Assert.assertTrue(i2 == (-805306368));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test212");
        int i1 = ClassExampleWithFailure.twice(280887296);
        org.junit.Assert.assertTrue(i1 == 561774592);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test213");
        int i2 = ClassExampleWithFailure.foo(2071986176, 388);
        org.junit.Assert.assertTrue(i2 == 1543503872);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test214");
        int i2 = ClassExampleWithFailure.foo(1543503872, 1191182336);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test215");
        int i2 = ClassExampleWithFailure.foo(210894848, (-17920000));
        org.junit.Assert.assertTrue(i2 == 1073741824);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test216");
        int i2 = ClassExampleWithFailure.foo((-1451098112), (-1083703296));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test217");
        int i2 = ClassExampleWithFailure.foo((-661127168), (-204800000));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test218");
        int i2 = ClassExampleWithFailure.foo((-8960), 1262485504);
        org.junit.Assert.assertTrue(i2 == (-2147483648));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test219");
        int i2 = ClassExampleWithFailure.foo(469762048, 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test220");
        int i2 = ClassExampleWithFailure.foo(496640000, 1551892480);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test221");
        int i2 = ClassExampleWithFailure.foo(35127296, (-1753219072));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test222");
        int i1 = ClassExampleWithFailure.twice((-1709178880));
        org.junit.Assert.assertTrue(i1 == 876609536);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test223");
        int i1 = ClassExampleWithFailure.twice(1310720);
        org.junit.Assert.assertTrue(i1 == 2621440);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test224");
        int i2 = ClassExampleWithFailure.foo((-1392771072), 1267400704);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test225");
        int i1 = ClassExampleWithFailure.twice((-280887296));
        org.junit.Assert.assertTrue(i1 == (-561774592));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test226");
        int i1 = ClassExampleWithFailure.twice(11468800);
        org.junit.Assert.assertTrue(i1 == 22937600);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test227");
        int i2 = ClassExampleWithFailure.foo(402653184, 1275068416);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test228");
        int i2 = ClassExampleWithFailure.foo(870088704, (-256000));
        org.junit.Assert.assertTrue(i2 == 1476395008);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test229");
        int i2 = ClassExampleWithFailure.foo(81920, (-28672000));
        org.junit.Assert.assertTrue(i2 == 1073741824);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test230");
        int i2 = ClassExampleWithFailure.foo(1275068416, 1188298752);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test231");
        int i1 = ClassExampleWithFailure.twice(491782144);
        org.junit.Assert.assertTrue(i1 == 983564288);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test232");
        int i2 = ClassExampleWithFailure.foo(1077936128, (-2147483648));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test233");
        int i1 = ClassExampleWithFailure.twice((-201326592));
        org.junit.Assert.assertTrue(i1 == (-402653184));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test234");
        int i2 = ClassExampleWithFailure.foo((-1760165888), (-1577058304));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test235");
        int i1 = ClassExampleWithFailure.twice((-262144000));
        org.junit.Assert.assertTrue(i1 == (-524288000));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test236");
        int i2 = ClassExampleWithFailure.foo(200, 1112473600);
        org.junit.Assert.assertTrue(i2 == (-1687158784));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test237");
        int i2 = ClassExampleWithFailure.foo(1426063360, (-520093696));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test238");
        int i2 = ClassExampleWithFailure.foo(1660944384, 71680000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test239");
        int i1 = ClassExampleWithFailure.twice(1210056704);
        org.junit.Assert.assertTrue(i1 == (-1874853888));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test240");
        int i2 = ClassExampleWithFailure.foo(1212153856, (-1509949440));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test241");
        int i2 = ClassExampleWithFailure.foo((-201326592), (int) 'a');
        org.junit.Assert.assertTrue(i2 == (-402653184));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test242");
        int i2 = ClassExampleWithFailure.foo(285212672, 4);
        org.junit.Assert.assertTrue(i2 == (-2013265920));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test243");
        int i2 = ClassExampleWithFailure.foo(256000, 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test244");
        int i1 = ClassExampleWithFailure.twice(1132462080);
        org.junit.Assert.assertTrue(i1 == (-2030043136));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test245");
        int i1 = ClassExampleWithFailure.twice((-100663296));
        org.junit.Assert.assertTrue(i1 == (-201326592));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test246");
        int i2 = ClassExampleWithFailure.foo((-1581252608), 800);
        org.junit.Assert.assertTrue(i2 == (-268435456));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test247");
        int i2 = ClassExampleWithFailure.foo(143360000, (-616562688));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test248");
        int i1 = ClassExampleWithFailure.twice(989855744);
        org.junit.Assert.assertTrue(i1 == 1979711488);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test249");
        int i2 = ClassExampleWithFailure.foo((-102400000), 70254592);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test250");
        int i2 = ClassExampleWithFailure.foo((-2113929216), (-400));
        org.junit.Assert.assertTrue(i2 == (-1073741824));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test251");
        int i2 = ClassExampleWithFailure.foo(5120000, 10);
        org.junit.Assert.assertTrue(i2 == 102400000);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test252");
        int i2 = ClassExampleWithFailure.foo((-1212153856), 1462763520);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test253");
        int i2 = ClassExampleWithFailure.foo((-2085617664), 204800000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test254");
        int i2 = ClassExampleWithFailure.foo((-439040000), (-770703360));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test255");
        int i2 = ClassExampleWithFailure.foo(776, 10240);
        org.junit.Assert.assertTrue(i2 == 15892480);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test256");
        int i2 = ClassExampleWithFailure.foo(2240000, (-872415232));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test257");
        int i2 = ClassExampleWithFailure.foo((-469762048), (-458752000));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test258");
        int i2 = ClassExampleWithFailure.foo((-22400), 1426063360);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test259");
        int i1 = ClassExampleWithFailure.twice((-1543503872));
        org.junit.Assert.assertTrue(i1 == 1207959552);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test260");
        int i1 = ClassExampleWithFailure.twice(186368000);
        org.junit.Assert.assertTrue(i1 == 372736000);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test261");
        int i2 = ClassExampleWithFailure.foo((-1509425152), 490733568);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test262");
        int i2 = ClassExampleWithFailure.foo(2085617664, (-770703360));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test263");
        int i2 = ClassExampleWithFailure.foo(4096, 4096000);
        org.junit.Assert.assertTrue(i2 == (-805306368));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test264");
        int i2 = ClassExampleWithFailure.foo((-819200), (-1024));
        org.junit.Assert.assertTrue(i2 == 1677721600);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test265");
        int i2 = ClassExampleWithFailure.foo((-1744830464), 15520);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test266");
        int i2 = ClassExampleWithFailure.foo(5324800, (-1233125376));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test267");
        int i2 = ClassExampleWithFailure.foo((-973078528), 4587520);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test268");
        int i1 = ClassExampleWithFailure.twice((-524288000));
        org.junit.Assert.assertTrue(i1 == (-1048576000));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test269");
        int i2 = ClassExampleWithFailure.foo(810123264, 1811939328);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test270");
        int i2 = ClassExampleWithFailure.foo(10240000, 123731968);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test271");
        int i1 = ClassExampleWithFailure.twice((-872415232));
        org.junit.Assert.assertTrue(i1 == (-1744830464));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test272");
        int i2 = ClassExampleWithFailure.foo(496640000, 1719664640);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test273");
        int i2 = ClassExampleWithFailure.foo(0, (-2047868928));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test274");
        int i2 = ClassExampleWithFailure.foo((-2095054848), (-2122317824));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test275");
        int i2 = ClassExampleWithFailure.foo(771751936, 637534208);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test276");
        int i2 = ClassExampleWithFailure.foo((-2080374784), (-1426079744));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test277");
        int i1 = ClassExampleWithFailure.twice(896000);
        org.junit.Assert.assertTrue(i1 == 1792000);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test278");
        int i2 = ClassExampleWithFailure.foo(1241513984, 830472192);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test279");
        int i1 = ClassExampleWithFailure.twice((-1687158784));
        org.junit.Assert.assertTrue(i1 == 920649728);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test280");
        int i2 = ClassExampleWithFailure.foo(1191182336, 1018167296);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test281");
        int i2 = ClassExampleWithFailure.foo(795869184, (-1229455360));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test282");
        int i2 = ClassExampleWithFailure.foo(1120, 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test283");
        int i2 = ClassExampleWithFailure.foo((-1358954496), (-1732247552));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test284");
        int i2 = ClassExampleWithFailure.foo(20971520, 1310720);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test285");
        int i2 = ClassExampleWithFailure.foo((-889192448), (-3276800));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test286");
        int i2 = ClassExampleWithFailure.foo(166400, (int) 'a');
        org.junit.Assert.assertTrue(i2 == 32281600);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test287");
        int i2 = ClassExampleWithFailure.foo(35127296, 805306368);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test288");
        int i1 = ClassExampleWithFailure.twice(8960);
        org.junit.Assert.assertTrue(i1 == 17920);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test289");
        int i2 = ClassExampleWithFailure.foo(256, 1509949440);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test290");
        int i2 = ClassExampleWithFailure.foo(12800000, (-2122317824));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test291");
        int i2 = ClassExampleWithFailure.foo((int) (byte) 100, (-109051904));
        org.junit.Assert.assertTrue(i2 == (-335544320));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test292");
        int i2 = ClassExampleWithFailure.foo((-2135949312), (-401408000));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test293");
        int i2 = ClassExampleWithFailure.foo(198967296, 1120);
        org.junit.Assert.assertTrue(i2 == (-989855744));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test294");
        int i2 = ClassExampleWithFailure.foo(0, (-62720000));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test295");
        int i1 = ClassExampleWithFailure.twice(4096);
        org.junit.Assert.assertTrue(i1 == 8192);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test296");
        int i2 = ClassExampleWithFailure.foo(1064960000, (-335544320));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test297");
        int i2 = ClassExampleWithFailure.foo(734003200, (-1513783296));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test298");
        int i2 = ClassExampleWithFailure.foo((-8), 2046820352);
        org.junit.Assert.assertTrue(i2 == 1610612736);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test299");
        int i2 = ClassExampleWithFailure.foo(1112473600, 2080374784);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test300");
        int i2 = ClassExampleWithFailure.foo(1170210816, 1434443776);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test301");
        int i2 = ClassExampleWithFailure.foo(1552000, (-1992294400));
        org.junit.Assert.assertTrue(i2 == 1073741824);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test302");
        int i2 = ClassExampleWithFailure.foo((-292552704), 1581252608);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test303");
        int i2 = ClassExampleWithFailure.foo(268435456, 102400000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test304");
        int i2 = ClassExampleWithFailure.foo(16, (-10485760));
        org.junit.Assert.assertTrue(i2 == (-335544320));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test305");
        int i2 = ClassExampleWithFailure.foo(372736000, (-1358954496));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test306");
        int i1 = ClassExampleWithFailure.twice((-143360000));
        org.junit.Assert.assertTrue(i1 == (-286720000));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test307");
        int i2 = ClassExampleWithFailure.foo((-1581252608), 33554432);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test308");
        int i2 = ClassExampleWithFailure.foo(209715200, 469762048);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test309");
        int i2 = ClassExampleWithFailure.foo((-2621440), 99328);
        org.junit.Assert.assertTrue(i2 == (-1073741824));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test310");
        int i2 = ClassExampleWithFailure.foo(629145600, 685768704);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test311");
        int i2 = ClassExampleWithFailure.foo((-805306368), (-2024538112));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test312");
        int i2 = ClassExampleWithFailure.foo((-1276116992), (-1067974656));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test313");
        int i2 = ClassExampleWithFailure.foo((-1760165888), (-1404436480));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test314");
        int i1 = ClassExampleWithFailure.twice((-1254400));
        org.junit.Assert.assertTrue(i1 == (-2508800));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test315");
        int i1 = ClassExampleWithFailure.twice(167772160);
        org.junit.Assert.assertTrue(i1 == 335544320);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test316");
        int i2 = ClassExampleWithFailure.foo((-512000000), (-218103808));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test317");
        int i2 = ClassExampleWithFailure.foo(448000, 1476395008);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test318");
        int i2 = ClassExampleWithFailure.foo((-1146880000), 405061632);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test319");
        int i1 = ClassExampleWithFailure.twice((-39845888));
        org.junit.Assert.assertTrue(i1 == (-79691776));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test320");
        int i2 = ClassExampleWithFailure.foo((-1442840576), 1605632000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test321");
        int i1 = ClassExampleWithFailure.twice((-1946157056));
        org.junit.Assert.assertTrue(i1 == 402653184);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test322");
        int i2 = ClassExampleWithFailure.foo((-1578106880), 1946157056);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test323");
        int i2 = ClassExampleWithFailure.foo(16777216, (-1732247552));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test324");
        int i1 = ClassExampleWithFailure.twice(10240000);
        org.junit.Assert.assertTrue(i1 == 20480000);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test325");
        int i2 = ClassExampleWithFailure.foo(843055104, 545259520);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test326");
        int i1 = ClassExampleWithFailure.twice(3104);
        org.junit.Assert.assertTrue(i1 == 6208);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test327");
        int i2 = ClassExampleWithFailure.foo(22937600, (-640));
        org.junit.Assert.assertTrue(i2 == 704643072);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test328");
        int i2 = ClassExampleWithFailure.foo(1744830464, 512);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test329");
        int i2 = ClassExampleWithFailure.foo(1610612736, 585105408);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test330");
        int i2 = ClassExampleWithFailure.foo((-2001207296), 1660944384);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test331");
        int i2 = ClassExampleWithFailure.foo(603979776, 221904896);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test332");
        int i2 = ClassExampleWithFailure.foo((-10485760), (-819200000));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test333");
        int i1 = ClassExampleWithFailure.twice((-1249902592));
        org.junit.Assert.assertTrue(i1 == 1795162112);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test334");
        int i2 = ClassExampleWithFailure.foo(1024000000, (int) (short) 1);
        org.junit.Assert.assertTrue(i2 == 2048000000);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test335");
        int i2 = ClassExampleWithFailure.foo(512, 214958080);
        org.junit.Assert.assertTrue(i2 == 1073741824);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test336");
        int i2 = ClassExampleWithFailure.foo(1317011456, (-64000));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test337");
        int i1 = ClassExampleWithFailure.twice((-175636480));
        org.junit.Assert.assertTrue(i1 == (-351272960));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test338");
        int i2 = ClassExampleWithFailure.foo(1107296256, (-1280));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test339");
        int i1 = ClassExampleWithFailure.twice((-878080000));
        org.junit.Assert.assertTrue(i1 == (-1756160000));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test340");
        int i2 = ClassExampleWithFailure.foo((-545259520), (-878182400));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test341");
        int i2 = ClassExampleWithFailure.foo((-2135949312), 320000);
        org.junit.Assert.assertTrue(i2 == (-1073741824));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test342");
        int i1 = ClassExampleWithFailure.twice(1310720000);
        org.junit.Assert.assertTrue(i1 == (-1673527296));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test343");
        int i1 = ClassExampleWithFailure.twice(1713373184);
        org.junit.Assert.assertTrue(i1 == (-868220928));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test344");
        int i2 = ClassExampleWithFailure.foo((-1660944384), 494927872);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test345");
        int i2 = ClassExampleWithFailure.foo(641728512, 2048);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test346");
        int i2 = ClassExampleWithFailure.foo((-458752000), (-320));
        org.junit.Assert.assertTrue(i2 == 1543503872);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test347");
        int i2 = ClassExampleWithFailure.foo((-143360), (-800));
        org.junit.Assert.assertTrue(i2 == 229376000);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test348");
        int i2 = ClassExampleWithFailure.foo(52428800, (-790626304));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test349");
        int i2 = ClassExampleWithFailure.foo(0, 1976041472);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test350");
        int i2 = ClassExampleWithFailure.foo(1792000, 8);
        org.junit.Assert.assertTrue(i2 == 28672000);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test351");
        int i1 = ClassExampleWithFailure.twice(50331648);
        org.junit.Assert.assertTrue(i1 == 100663296);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test352");
        int i2 = ClassExampleWithFailure.foo(322816, 44800);
        org.junit.Assert.assertTrue(i2 == (-1140457472));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test353");
        int i2 = ClassExampleWithFailure.foo((-989855744), 1023410176);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test354");
        int i2 = ClassExampleWithFailure.foo(1486094336, (-1581252608));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test355");
        int i2 = ClassExampleWithFailure.foo((-2030043136), (-8960000));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test356");
        int i2 = ClassExampleWithFailure.foo((-64000), 8000);
        org.junit.Assert.assertTrue(i2 == (-1024000000));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test357");
        int i1 = ClassExampleWithFailure.twice(1795162112);
        org.junit.Assert.assertTrue(i1 == (-704643072));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test358");
        int i1 = ClassExampleWithFailure.twice(17920);
        org.junit.Assert.assertTrue(i1 == 35840);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test359");
        int i2 = ClassExampleWithFailure.foo((-2127560704), 1107296256);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test360");
        int i2 = ClassExampleWithFailure.foo(3200000, 320);
        org.junit.Assert.assertTrue(i2 == 2048000000);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test361");
        int i2 = ClassExampleWithFailure.foo((-2071986176), 2118123520);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test362");
        int i2 = ClassExampleWithFailure.foo(160, (-1591738368));
        org.junit.Assert.assertTrue(i2 == 1744830464);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test363");
        int i2 = ClassExampleWithFailure.foo(1107296256, 166400);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test364");
        int i2 = ClassExampleWithFailure.foo((-996147200), 1581252608);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test365");
        int i2 = ClassExampleWithFailure.foo((-1042808832), (-1874853888));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test366");
        int i2 = ClassExampleWithFailure.foo((-1937768448), 4096000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test367");
        int i2 = ClassExampleWithFailure.foo(69529600, (-524288000));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test368");
        int i2 = ClassExampleWithFailure.foo((-1879048192), 1845493760);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test369");
        int i2 = ClassExampleWithFailure.foo((-28672000), 32281600);
        org.junit.Assert.assertTrue(i2 == 603979776);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test370");
        int i2 = ClassExampleWithFailure.foo(262144000, (-1912602624));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test371");
        int i1 = ClassExampleWithFailure.twice((-661127168));
        org.junit.Assert.assertTrue(i1 == (-1322254336));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test372");
        int i2 = ClassExampleWithFailure.foo(1042808832, 266240000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test373");
        int i2 = ClassExampleWithFailure.foo((-1761607680), 561774592);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test374");
        int i2 = ClassExampleWithFailure.foo(1308622848, (-818487296));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test375");
        int i2 = ClassExampleWithFailure.foo(1820327936, 1577058304);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test376");
        int i1 = ClassExampleWithFailure.twice(70254592);
        org.junit.Assert.assertTrue(i1 == 140509184);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test377");
        int i2 = ClassExampleWithFailure.foo(64, 81920);
        org.junit.Assert.assertTrue(i2 == 10485760);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test378");
        int i2 = ClassExampleWithFailure.foo(0, 10485760);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test379");
        int i2 = ClassExampleWithFailure.foo(124160, (-201326592));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test380");
        int i1 = ClassExampleWithFailure.twice((-218103808));
        org.junit.Assert.assertTrue(i1 == (-436207616));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test381");
        int i2 = ClassExampleWithFailure.foo((-198967296), 262144000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test382");
        int i2 = ClassExampleWithFailure.foo(4096000, (-5242880));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test383");
        int i1 = ClassExampleWithFailure.twice(1687158784);
        org.junit.Assert.assertTrue(i1 == (-920649728));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test384");
        int i1 = ClassExampleWithFailure.twice((-1954545664));
        org.junit.Assert.assertTrue(i1 == 385875968);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test385");
        int i1 = ClassExampleWithFailure.twice((-1935671296));
        org.junit.Assert.assertTrue(i1 == 423624704);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test386");
        int i2 = ClassExampleWithFailure.foo(0, (int) (byte) 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test387");
        int i2 = ClassExampleWithFailure.foo(62080, 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test388");
        int i2 = ClassExampleWithFailure.foo(0, (-2080374784));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test389");
        int i2 = ClassExampleWithFailure.foo(1711276032, 5324800);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test390");
        int i1 = ClassExampleWithFailure.twice(35840);
        org.junit.Assert.assertTrue(i1 == 71680);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test391");
        int i2 = ClassExampleWithFailure.foo((-247463936), 458227712);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test392");
        int i2 = ClassExampleWithFailure.foo(24832, 167772160);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test393");
        int i2 = ClassExampleWithFailure.foo(536870912, 1249902592);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test394");
        int i1 = ClassExampleWithFailure.twice(40960000);
        org.junit.Assert.assertTrue(i1 == 81920000);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test395");
        int i2 = ClassExampleWithFailure.foo((-40), 1509949440);
        org.junit.Assert.assertTrue(i2 == (-536870912));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test396");
        int i2 = ClassExampleWithFailure.foo((-1986560000), 4);
        org.junit.Assert.assertTrue(i2 == 1287389184);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test397");
        int i2 = ClassExampleWithFailure.foo(1196425216, 17920);
        org.junit.Assert.assertTrue(i2 == (-1073741824));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test398");
        int i2 = ClassExampleWithFailure.foo((-819200), 1212153856);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test399");
        int i2 = ClassExampleWithFailure.foo((-2080374784), 421789696);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test400");
        int i2 = ClassExampleWithFailure.foo((-8), (-1732247552));
        org.junit.Assert.assertTrue(i2 == 1946157056);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test401");
        int i2 = ClassExampleWithFailure.foo((int) (short) 0, (-622854144));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test402");
        int i2 = ClassExampleWithFailure.foo((-286720000), (-71680));
        org.junit.Assert.assertTrue(i2 == 1342177280);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test403");
        int i2 = ClassExampleWithFailure.foo(440401920, (-199229440));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test404");
        int i2 = ClassExampleWithFailure.foo((-1744830464), 1267400704);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test405");
        int i2 = ClassExampleWithFailure.foo((-39845888), 167772160);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test406");
        int i2 = ClassExampleWithFailure.foo(419430400, (-1756160000));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test407");
        int i2 = ClassExampleWithFailure.foo((-4480000), 448000);
        org.junit.Assert.assertTrue(i2 == 1714421760);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test408");
        int i2 = ClassExampleWithFailure.foo(1216768000, 155200);
        org.junit.Assert.assertTrue(i2 == (-1751908352));
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test409");
        int i1 = ClassExampleWithFailure.twice((-535756800));
        org.junit.Assert.assertTrue(i1 == (-1071513600));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test410");
        int i2 = ClassExampleWithFailure.foo(93184000, 40960000);
        org.junit.Assert.assertTrue(i2 == (-1073741824));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test411");
        int i1 = ClassExampleWithFailure.twice(8192);
        org.junit.Assert.assertTrue(i1 == 16384);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test412");
        int i2 = ClassExampleWithFailure.foo((-2113929216), (int) (byte) 1);
        org.junit.Assert.assertTrue(i2 == 67108864);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test413");
        int i2 = ClassExampleWithFailure.foo(166400, (-10649600));
        org.junit.Assert.assertTrue(i2 == (-838860800));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test414");
        int i2 = ClassExampleWithFailure.foo((-3328000), 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test415");
        int i2 = ClassExampleWithFailure.foo(0, (-64));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test416");
        int i1 = ClassExampleWithFailure.twice(640);
        org.junit.Assert.assertTrue(i1 == 1280);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test417");
        int i2 = ClassExampleWithFailure.foo(83886080, 2048);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test418");
        int i2 = ClassExampleWithFailure.foo(198656, (-671432704));
        org.junit.Assert.assertTrue(i2 == 738197504);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test419");
        int i2 = ClassExampleWithFailure.foo(9800, (-1363607552));
        org.junit.Assert.assertTrue(i2 == 873463808);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test420");
        int i2 = ClassExampleWithFailure.foo((-1769996288), 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test421");
        int i2 = ClassExampleWithFailure.foo(44040192, 40);
        org.junit.Assert.assertTrue(i2 == (-771751936));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test422");
        int i2 = ClassExampleWithFailure.foo(0, (-1760165888));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test423");
        int i2 = ClassExampleWithFailure.foo(5120000, 1404436480);
        org.junit.Assert.assertTrue(i2 == (-2147483648));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test424");
        int i2 = ClassExampleWithFailure.foo(10, 1112473600);
        org.junit.Assert.assertTrue(i2 == 774635520);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test425");
        int i2 = ClassExampleWithFailure.foo(1310720, (-838860800));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test426");
        int i1 = ClassExampleWithFailure.twice(12416000);
        org.junit.Assert.assertTrue(i1 == 24832000);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test427");
        int i2 = ClassExampleWithFailure.foo(33554432, (-17920));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test428");
        int i2 = ClassExampleWithFailure.foo((-1935671296), 200);
        org.junit.Assert.assertTrue(i2 == (-1174405120));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test429");
        int i2 = ClassExampleWithFailure.foo(0, 199229440);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test430");
        int i2 = ClassExampleWithFailure.foo((-872415232), 31040);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test431");
        int i2 = ClassExampleWithFailure.foo(221904896, 560);
        org.junit.Assert.assertTrue(i2 == (-574619648));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test432");
        int i2 = ClassExampleWithFailure.foo(16777216, 268435456);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test433");
        int i2 = ClassExampleWithFailure.foo(1179648000, 397934592);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test434");
        int i2 = ClassExampleWithFailure.foo(503316480, (int) (byte) -1);
        org.junit.Assert.assertTrue(i2 == (-1006632960));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test435");
        int i1 = ClassExampleWithFailure.twice((-1024000000));
        org.junit.Assert.assertTrue(i1 == (-2048000000));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test436");
        int i2 = ClassExampleWithFailure.foo(1442807808, (-2036334592));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test437");
        int i2 = ClassExampleWithFailure.foo((-1811939328), (-280));
        org.junit.Assert.assertTrue(i2 == 1073741824);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test438");
        int i2 = ClassExampleWithFailure.foo((-494927872), (-524288000));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test439");
        int i1 = ClassExampleWithFailure.twice(385392640);
        org.junit.Assert.assertTrue(i1 == 770785280);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test440");
        int i2 = ClassExampleWithFailure.foo((-1992294400), 93184000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test441");
        int i2 = ClassExampleWithFailure.foo((-685768704), (-6400));
        org.junit.Assert.assertTrue(i2 == (-1073741824));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test442");
        int i2 = ClassExampleWithFailure.foo(3584000, 6400);
        org.junit.Assert.assertTrue(i2 == (-1369440256));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test443");
        int i2 = ClassExampleWithFailure.foo(320000, 124160);
        org.junit.Assert.assertTrue(i2 == (-2141978624));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test444");
        int i2 = ClassExampleWithFailure.foo(1317011456, 8960000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test445");
        int i1 = ClassExampleWithFailure.twice(916455424);
        org.junit.Assert.assertTrue(i1 == 1832910848);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test446");
        int i2 = ClassExampleWithFailure.foo(32768000, 25600000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test447");
        int i2 = ClassExampleWithFailure.foo(0, 1769996288);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test448");
        int i2 = ClassExampleWithFailure.foo(4096, 1006632960);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test449");
        int i1 = ClassExampleWithFailure.twice(774635520);
        org.junit.Assert.assertTrue(i1 == 1549271040);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test450");
        int i2 = ClassExampleWithFailure.foo(31040, 1509425152);
        org.junit.Assert.assertTrue(i2 == 1811939328);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test451");
        int i1 = ClassExampleWithFailure.twice((-1233125376));
        org.junit.Assert.assertTrue(i1 == 1828716544);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test452");
        int i2 = ClassExampleWithFailure.foo((-42598400), (-8192));
        org.junit.Assert.assertTrue(i2 == (-2147483648));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test453");
        int i1 = ClassExampleWithFailure.twice((-327680));
        org.junit.Assert.assertTrue(i1 == (-655360));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test454");
        int i2 = ClassExampleWithFailure.foo(100, (-2147483648));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test455");
        int i2 = ClassExampleWithFailure.foo(52428800, (-2129920000));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test456");
        int i2 = ClassExampleWithFailure.foo(1832910848, 123731968);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test457");
        int i2 = ClassExampleWithFailure.foo(0, (-2030043136));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test458");
        int i1 = ClassExampleWithFailure.twice((-573440000));
        org.junit.Assert.assertTrue(i1 == (-1146880000));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test459");
        int i2 = ClassExampleWithFailure.foo(310378496, 10);
        org.junit.Assert.assertTrue(i2 == 1912602624);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test460");
        int i2 = ClassExampleWithFailure.foo(810123264, 99328);
        org.junit.Assert.assertTrue(i2 == (-872415232));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test461");
        int i1 = ClassExampleWithFailure.twice((-993280000));
        org.junit.Assert.assertTrue(i1 == (-1986560000));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test462");
        int i2 = ClassExampleWithFailure.foo(400, 2080374784);
        org.junit.Assert.assertTrue(i2 == (-2147483648));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test463");
        int i2 = ClassExampleWithFailure.foo(838860800, 419430400);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test464");
        int i2 = ClassExampleWithFailure.foo(896000, (-1140457472));
        org.junit.Assert.assertTrue(i2 == 268435456);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test465");
        int i2 = ClassExampleWithFailure.foo(2085617664, 3200);
        org.junit.Assert.assertTrue(i2 == (-805306368));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test466");
        int i1 = ClassExampleWithFailure.twice(109051904);
        org.junit.Assert.assertTrue(i1 == 218103808);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test467");
        int i2 = ClassExampleWithFailure.foo(0, 6208);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test468");
        int i2 = ClassExampleWithFailure.foo((-179200), (-35840));
        org.junit.Assert.assertTrue(i2 == (-39845888));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test469");
        int i2 = ClassExampleWithFailure.foo(876609536, (-1140850688));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test470");
        int i1 = ClassExampleWithFailure.twice(65536000);
        org.junit.Assert.assertTrue(i1 == 131072000);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test471");
        int i2 = ClassExampleWithFailure.foo((-996147200), (-478150656));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test472");
        int i2 = ClassExampleWithFailure.foo((-1609236480), 143360000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test473");
        int i2 = ClassExampleWithFailure.foo(0, 1275068416);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test474");
        int i2 = ClassExampleWithFailure.foo(1048576000, 123731968);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test475");
        int i2 = ClassExampleWithFailure.foo(89600, 643694592);
        org.junit.Assert.assertTrue(i2 == 134217728);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test476");
        int i2 = ClassExampleWithFailure.foo(39200, 1769996288);
        org.junit.Assert.assertTrue(i2 == 1610612736);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test477");
        int i2 = ClassExampleWithFailure.foo(124160, 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test478");
        int i2 = ClassExampleWithFailure.foo(0, (-2095054848));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test479");
        int i2 = ClassExampleWithFailure.foo((-400), (-1416101888));
        org.junit.Assert.assertTrue(i2 == (-989855744));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test480");
        int i2 = ClassExampleWithFailure.foo(81920000, 2071986176);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test481");
        int i1 = ClassExampleWithFailure.twice((-1751908352));
        org.junit.Assert.assertTrue(i1 == 791150592);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test482");
        int i1 = ClassExampleWithFailure.twice(32281600);
        org.junit.Assert.assertTrue(i1 == 64563200);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test483");
        int i2 = ClassExampleWithFailure.foo((-268435456), 1509949440);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test484");
        int i1 = ClassExampleWithFailure.twice(15892480);
        org.junit.Assert.assertTrue(i1 == 31784960);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test485");
        int i2 = ClassExampleWithFailure.foo(585105408, (-229376000));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test486");
        int i1 = ClassExampleWithFailure.twice(22020096);
        org.junit.Assert.assertTrue(i1 == 44040192);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test487");
        int i1 = ClassExampleWithFailure.twice((-561774592));
        org.junit.Assert.assertTrue(i1 == (-1123549184));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test488");
        int i2 = ClassExampleWithFailure.foo((-1600), 1879048192);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test489");
        int i1 = ClassExampleWithFailure.twice(24832000);
        org.junit.Assert.assertTrue(i1 == 49664000);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test490");
        int i2 = ClassExampleWithFailure.foo(0, (-819200));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test491");
        int i2 = ClassExampleWithFailure.foo((-1567752192), 327680);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test492");
        int i2 = ClassExampleWithFailure.foo(1468006400, (-685768704));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test493");
        int i2 = ClassExampleWithFailure.foo(1748107264, 268435456);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test494");
        int i2 = ClassExampleWithFailure.foo((-4096), (-268435456));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test495");
        int i2 = ClassExampleWithFailure.foo(124160000, (-1132462080));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test496");
        int i2 = ClassExampleWithFailure.foo((-878182400), (-342884352));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test497");
        int i2 = ClassExampleWithFailure.foo((-42598400), (-1902116864));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test498");
        int i1 = ClassExampleWithFailure.twice(1468006400);
        org.junit.Assert.assertTrue(i1 == (-1358954496));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test499");
        int i2 = ClassExampleWithFailure.foo(77600, 155200);
        org.junit.Assert.assertTrue(i2 == (-1682763776));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test500");
        int i2 = ClassExampleWithFailure.foo(123731968, 3136000);
        org.junit.Assert.assertTrue(i2 == (-2147483648));
    }
}

