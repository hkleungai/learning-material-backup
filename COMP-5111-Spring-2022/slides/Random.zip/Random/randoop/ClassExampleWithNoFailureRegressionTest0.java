import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class ClassExampleWithNoFailureRegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        int i2 = ClassExampleWithNoFailure.foo(100, (int) (byte) 1);
        org.junit.Assert.assertTrue(i2 == 10000);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        int i1 = ClassExampleWithNoFailure.twice(10000);
        org.junit.Assert.assertTrue(i1 == 100000000);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        int i2 = ClassExampleWithNoFailure.foo(100, 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        int i2 = ClassExampleWithNoFailure.foo((int) (short) 100, 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        int i1 = ClassExampleWithNoFailure.twice((int) '#');
        org.junit.Assert.assertTrue(i1 == 1225);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        int i1 = ClassExampleWithNoFailure.twice((int) (short) 10);
        org.junit.Assert.assertTrue(i1 == 100);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        int i1 = ClassExampleWithNoFailure.twice((int) (byte) 0);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        int i2 = ClassExampleWithNoFailure.foo(0, (int) (short) -1);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        int i2 = ClassExampleWithNoFailure.foo(0, 1);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        ClassExampleWithNoFailure classExampleWithNoFailure0 = new ClassExampleWithNoFailure();
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        int i2 = ClassExampleWithNoFailure.foo((int) '#', 10);
        org.junit.Assert.assertTrue(i2 == 12250);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        int i1 = ClassExampleWithNoFailure.twice((int) (short) 1);
        org.junit.Assert.assertTrue(i1 == 1);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        int i1 = ClassExampleWithNoFailure.twice((int) (short) 100);
        org.junit.Assert.assertTrue(i1 == 10000);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        int i2 = ClassExampleWithNoFailure.foo((int) (byte) 0, (int) 'a');
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        int i1 = ClassExampleWithNoFailure.twice(100000000);
        org.junit.Assert.assertTrue(i1 == 1874919424);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        int i1 = ClassExampleWithNoFailure.twice((int) 'a');
        org.junit.Assert.assertTrue(i1 == 9409);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        int i1 = ClassExampleWithNoFailure.twice((int) ' ');
        org.junit.Assert.assertTrue(i1 == 1024);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        int i1 = ClassExampleWithNoFailure.twice((-1));
        org.junit.Assert.assertTrue(i1 == 1);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        int i2 = ClassExampleWithNoFailure.foo(0, 100);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        int i2 = ClassExampleWithNoFailure.foo((int) (byte) 10, 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        int i1 = ClassExampleWithNoFailure.twice((int) (short) -1);
        org.junit.Assert.assertTrue(i1 == 1);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        int i2 = ClassExampleWithNoFailure.foo(1225, 100000000);
        org.junit.Assert.assertTrue(i2 == 637645056);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        int i1 = ClassExampleWithNoFailure.twice((int) (byte) 1);
        org.junit.Assert.assertTrue(i1 == 1);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        int i2 = ClassExampleWithNoFailure.foo(1, (int) '4');
        org.junit.Assert.assertTrue(i2 == 52);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        int i2 = ClassExampleWithNoFailure.foo((int) (short) 100, (int) ' ');
        org.junit.Assert.assertTrue(i2 == 320000);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        int i2 = ClassExampleWithNoFailure.foo(0, (int) (short) 1);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        int i2 = ClassExampleWithNoFailure.foo(10, 1024);
        org.junit.Assert.assertTrue(i2 == 102400);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        int i2 = ClassExampleWithNoFailure.foo(637645056, 12250);
        org.junit.Assert.assertTrue(i2 == 2040135680);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        int i2 = ClassExampleWithNoFailure.foo(12250, 1);
        org.junit.Assert.assertTrue(i2 == 150062500);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        int i2 = ClassExampleWithNoFailure.foo((int) (byte) 0, (int) (short) 1);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        int i1 = ClassExampleWithNoFailure.twice(2040135680);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        int i2 = ClassExampleWithNoFailure.foo((int) (short) 100, (int) 'a');
        org.junit.Assert.assertTrue(i2 == 970000);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        int i1 = ClassExampleWithNoFailure.twice((int) (short) 0);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        int i1 = ClassExampleWithNoFailure.twice(1);
        org.junit.Assert.assertTrue(i1 == 1);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        int i1 = ClassExampleWithNoFailure.twice((int) (byte) 100);
        org.junit.Assert.assertTrue(i1 == 10000);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        int i2 = ClassExampleWithNoFailure.foo(1874919424, 102400);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        int i2 = ClassExampleWithNoFailure.foo(9409, 320000);
        org.junit.Assert.assertTrue(i2 == (-234364416));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        int i2 = ClassExampleWithNoFailure.foo(1, (int) '#');
        org.junit.Assert.assertTrue(i2 == 35);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        int i2 = ClassExampleWithNoFailure.foo(10, 35);
        org.junit.Assert.assertTrue(i2 == 3500);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        int i2 = ClassExampleWithNoFailure.foo(10, (int) (byte) 1);
        org.junit.Assert.assertTrue(i2 == 100);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        int i2 = ClassExampleWithNoFailure.foo((int) (short) 1, 9409);
        org.junit.Assert.assertTrue(i2 == 9409);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        int i1 = ClassExampleWithNoFailure.twice(320000);
        org.junit.Assert.assertTrue(i1 == (-679215104));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        int i2 = ClassExampleWithNoFailure.foo(102400, (int) (short) 1);
        org.junit.Assert.assertTrue(i2 == 1895825408);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        int i2 = ClassExampleWithNoFailure.foo(1, 2040135680);
        org.junit.Assert.assertTrue(i2 == 2040135680);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        int i2 = ClassExampleWithNoFailure.foo((int) '#', (int) (byte) 100);
        org.junit.Assert.assertTrue(i2 == 122500);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        int i2 = ClassExampleWithNoFailure.foo((int) (byte) 10, 52);
        org.junit.Assert.assertTrue(i2 == 5200);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        int i2 = ClassExampleWithNoFailure.foo((int) (byte) 0, (int) (short) 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        int i1 = ClassExampleWithNoFailure.twice(9409);
        org.junit.Assert.assertTrue(i1 == 88529281);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        int i2 = ClassExampleWithNoFailure.foo(320000, 1874919424);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        int i2 = ClassExampleWithNoFailure.foo(5200, 320000);
        org.junit.Assert.assertTrue(i2 == (-1559101440));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        int i2 = ClassExampleWithNoFailure.foo(637645056, (int) 'a');
        org.junit.Assert.assertTrue(i2 == (-2134835200));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        int i1 = ClassExampleWithNoFailure.twice(1024);
        org.junit.Assert.assertTrue(i1 == 1048576);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        int i1 = ClassExampleWithNoFailure.twice(1874919424);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        int i1 = ClassExampleWithNoFailure.twice(1895825408);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        int i1 = ClassExampleWithNoFailure.twice(1225);
        org.junit.Assert.assertTrue(i1 == 1500625);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        int i1 = ClassExampleWithNoFailure.twice((-679215104));
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        int i2 = ClassExampleWithNoFailure.foo(10000, 10000);
        org.junit.Assert.assertTrue(i2 == (-727379968));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        int i2 = ClassExampleWithNoFailure.foo(100, 637645056);
        org.junit.Assert.assertTrue(i2 == (-1575874560));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        int i1 = ClassExampleWithNoFailure.twice(150062500);
        org.junit.Assert.assertTrue(i1 == (-144846576));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        int i1 = ClassExampleWithNoFailure.twice((-727379968));
        org.junit.Assert.assertTrue(i1 == (-1593835520));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        int i2 = ClassExampleWithNoFailure.foo(100, (int) '4');
        org.junit.Assert.assertTrue(i2 == 520000);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        int i2 = ClassExampleWithNoFailure.foo(1874919424, (int) (short) 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        int i2 = ClassExampleWithNoFailure.foo(1048576, 1048576);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        int i2 = ClassExampleWithNoFailure.foo((-1559101440), 3500);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        int i1 = ClassExampleWithNoFailure.twice(100);
        org.junit.Assert.assertTrue(i1 == 10000);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        int i1 = ClassExampleWithNoFailure.twice(1500625);
        org.junit.Assert.assertTrue(i1 == 1312527521);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        int i2 = ClassExampleWithNoFailure.foo((int) 'a', (int) '#');
        org.junit.Assert.assertTrue(i2 == 329315);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        int i2 = ClassExampleWithNoFailure.foo(100, 10000);
        org.junit.Assert.assertTrue(i2 == 100000000);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        int i2 = ClassExampleWithNoFailure.foo(970000, 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        int i1 = ClassExampleWithNoFailure.twice(329315);
        org.junit.Assert.assertTrue(i1 == 1074186825);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        int i1 = ClassExampleWithNoFailure.twice((-1575874560));
        org.junit.Assert.assertTrue(i1 == 1090519040);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        int i2 = ClassExampleWithNoFailure.foo((int) '#', (int) 'a');
        org.junit.Assert.assertTrue(i2 == 118825);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        int i1 = ClassExampleWithNoFailure.twice((int) (byte) 10);
        org.junit.Assert.assertTrue(i1 == 100);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        int i2 = ClassExampleWithNoFailure.foo(100000000, 1312527521);
        org.junit.Assert.assertTrue(i2 == (-597622784));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        int i2 = ClassExampleWithNoFailure.foo((int) 'a', (int) (short) 10);
        org.junit.Assert.assertTrue(i2 == 94090);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        int i1 = ClassExampleWithNoFailure.twice(52);
        org.junit.Assert.assertTrue(i1 == 2704);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        int i1 = ClassExampleWithNoFailure.twice((int) '4');
        org.junit.Assert.assertTrue(i1 == 2704);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        int i2 = ClassExampleWithNoFailure.foo(1225, 10);
        org.junit.Assert.assertTrue(i2 == 15006250);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        int i1 = ClassExampleWithNoFailure.twice(3500);
        org.junit.Assert.assertTrue(i1 == 12250000);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        int i2 = ClassExampleWithNoFailure.foo(12250000, (int) (short) 100);
        org.junit.Assert.assertTrue(i2 == (-660003840));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        int i2 = ClassExampleWithNoFailure.foo((-144846576), 118825);
        org.junit.Assert.assertTrue(i2 == 711477504);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        int i1 = ClassExampleWithNoFailure.twice(1090519040);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        int i2 = ClassExampleWithNoFailure.foo(0, (int) 'a');
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        int i2 = ClassExampleWithNoFailure.foo(0, 94090);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        int i2 = ClassExampleWithNoFailure.foo(1048576, 150062500);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        int i2 = ClassExampleWithNoFailure.foo(970000, 5200);
        org.junit.Assert.assertTrue(i2 == (-714715136));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        int i1 = ClassExampleWithNoFailure.twice(1048576);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        int i1 = ClassExampleWithNoFailure.twice(5200);
        org.junit.Assert.assertTrue(i1 == 27040000);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        int i1 = ClassExampleWithNoFailure.twice((-1559101440));
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        int i2 = ClassExampleWithNoFailure.foo(2040135680, 520000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        int i2 = ClassExampleWithNoFailure.foo((int) (byte) 0, (int) (short) -1);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        int i2 = ClassExampleWithNoFailure.foo(0, 10);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        int i1 = ClassExampleWithNoFailure.twice((-1593835520));
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        int i1 = ClassExampleWithNoFailure.twice(88529281);
        org.junit.Assert.assertTrue(i1 == (-1252527359));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        int i2 = ClassExampleWithNoFailure.foo(320000, 100000000);
        org.junit.Assert.assertTrue(i2 == 67108864);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        int i1 = ClassExampleWithNoFailure.twice(1312527521);
        org.junit.Assert.assertTrue(i1 == (-192901823));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        int i1 = ClassExampleWithNoFailure.twice((int) (byte) -1);
        org.junit.Assert.assertTrue(i1 == 1);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        int i2 = ClassExampleWithNoFailure.foo(10000, (int) (short) 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        int i2 = ClassExampleWithNoFailure.foo((-1593835520), (-1593835520));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        int i1 = ClassExampleWithNoFailure.twice((-660003840));
        org.junit.Assert.assertTrue(i1 == (-1928331264));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        int i2 = ClassExampleWithNoFailure.foo(67108864, 35);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        int i2 = ClassExampleWithNoFailure.foo(0, 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        int i2 = ClassExampleWithNoFailure.foo(329315, (-1559101440));
        org.junit.Assert.assertTrue(i2 == (-1272840192));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        int i2 = ClassExampleWithNoFailure.foo((-234364416), (int) (short) 100);
        org.junit.Assert.assertTrue(i2 == (-544210944));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        int i2 = ClassExampleWithNoFailure.foo(52, 1090519040);
        org.junit.Assert.assertTrue(i2 == (-1879048192));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        int i2 = ClassExampleWithNoFailure.foo(2704, 1024);
        org.junit.Assert.assertTrue(i2 == (-1102839808));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        int i2 = ClassExampleWithNoFailure.foo((-660003840), 5200);
        org.junit.Assert.assertTrue(i2 == 1426063360);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        int i2 = ClassExampleWithNoFailure.foo(0, 637645056);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        int i1 = ClassExampleWithNoFailure.twice(711477504);
        org.junit.Assert.assertTrue(i1 == 1691418624);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        int i1 = ClassExampleWithNoFailure.twice(1426063360);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        int i2 = ClassExampleWithNoFailure.foo((int) (short) -1, 67108864);
        org.junit.Assert.assertTrue(i2 == 67108864);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        int i2 = ClassExampleWithNoFailure.foo((int) (short) 0, 35);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        int i2 = ClassExampleWithNoFailure.foo((int) (byte) 100, 118825);
        org.junit.Assert.assertTrue(i2 == 1188250000);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        int i2 = ClassExampleWithNoFailure.foo(1024, (-1928331264));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        int i1 = ClassExampleWithNoFailure.twice(637645056);
        org.junit.Assert.assertTrue(i1 == (-597622784));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        int i2 = ClassExampleWithNoFailure.foo((-192901823), (-727379968));
        org.junit.Assert.assertTrue(i2 == (-1009971200));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        int i2 = ClassExampleWithNoFailure.foo(1225, 35);
        org.junit.Assert.assertTrue(i2 == 52521875);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        int i2 = ClassExampleWithNoFailure.foo((int) (short) 0, 27040000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        int i2 = ClassExampleWithNoFailure.foo((int) (byte) -1, (-1928331264));
        org.junit.Assert.assertTrue(i2 == (-1928331264));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        int i1 = ClassExampleWithNoFailure.twice(12250000);
        org.junit.Assert.assertTrue(i1 == 637645056);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        int i2 = ClassExampleWithNoFailure.foo(520000, (-679215104));
        org.junit.Assert.assertTrue(i2 == 1073741824);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        int i1 = ClassExampleWithNoFailure.twice(102400);
        org.junit.Assert.assertTrue(i1 == 1895825408);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        int i1 = ClassExampleWithNoFailure.twice((-1252527359));
        org.junit.Assert.assertTrue(i1 == 2069423617);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        int i2 = ClassExampleWithNoFailure.foo((-1928331264), 1090519040);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        int i2 = ClassExampleWithNoFailure.foo((-1272840192), (-660003840));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        int i2 = ClassExampleWithNoFailure.foo((-1928331264), 52);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        int i2 = ClassExampleWithNoFailure.foo(2704, 88529281);
        org.junit.Assert.assertTrue(i2 == 1881215232);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        int i2 = ClassExampleWithNoFailure.foo(118825, 52521875);
        org.junit.Assert.assertTrue(i2 == (-1918156733));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        int i1 = ClassExampleWithNoFailure.twice(15006250);
        org.junit.Assert.assertTrue(i1 == (-1891234076));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        int i2 = ClassExampleWithNoFailure.foo(1312527521, (-234364416));
        org.junit.Assert.assertTrue(i2 == (-881171968));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        int i2 = ClassExampleWithNoFailure.foo(1074186825, 100000000);
        org.junit.Assert.assertTrue(i2 == (-402345728));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        int i2 = ClassExampleWithNoFailure.foo(94090, (-1891234076));
        org.junit.Assert.assertTrue(i2 == (-1495471856));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        int i2 = ClassExampleWithNoFailure.foo(970000, 1);
        org.junit.Assert.assertTrue(i2 == 302162176);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        int i2 = ClassExampleWithNoFailure.foo(1188250000, 302162176);
        org.junit.Assert.assertTrue(i2 == (-1827602432));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        int i2 = ClassExampleWithNoFailure.foo(27040000, 1188250000);
        org.junit.Assert.assertTrue(i2 == (-1601175552));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        int i2 = ClassExampleWithNoFailure.foo(52, (int) '4');
        org.junit.Assert.assertTrue(i2 == 140608);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        int i2 = ClassExampleWithNoFailure.foo((-1879048192), (int) (byte) 100);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        int i2 = ClassExampleWithNoFailure.foo(637645056, (-1575874560));
        org.junit.Assert.assertTrue(i2 == 268435456);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        int i2 = ClassExampleWithNoFailure.foo((int) ' ', (-1575874560));
        org.junit.Assert.assertTrue(i2 == 1212153856);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        int i1 = ClassExampleWithNoFailure.twice(27040000);
        org.junit.Assert.assertTrue(i1 == (-747569152));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        int i2 = ClassExampleWithNoFailure.foo(3500, (int) (byte) 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        int i1 = ClassExampleWithNoFailure.twice(1188250000);
        org.junit.Assert.assertTrue(i1 == (-466980608));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        int i2 = ClassExampleWithNoFailure.foo((-1827602432), 320000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        int i2 = ClassExampleWithNoFailure.foo(2704, 302162176);
        org.junit.Assert.assertTrue(i2 == 1278279680);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        int i1 = ClassExampleWithNoFailure.twice((-1891234076));
        org.junit.Assert.assertTrue(i1 == (-577914096));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        int i1 = ClassExampleWithNoFailure.twice(2704);
        org.junit.Assert.assertTrue(i1 == 7311616);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        int i2 = ClassExampleWithNoFailure.foo((int) (short) -1, (int) (byte) 100);
        org.junit.Assert.assertTrue(i2 == 100);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        int i1 = ClassExampleWithNoFailure.twice(0);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        int i2 = ClassExampleWithNoFailure.foo(5200, 2704);
        org.junit.Assert.assertTrue(i2 == 101715968);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        int i2 = ClassExampleWithNoFailure.foo((-1102839808), (-597622784));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        int i2 = ClassExampleWithNoFailure.foo(1312527521, (-1827602432));
        org.junit.Assert.assertTrue(i2 == (-1269760000));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        int i1 = ClassExampleWithNoFailure.twice((-1272840192));
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        int i2 = ClassExampleWithNoFailure.foo((-1593835520), 268435456);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        int i2 = ClassExampleWithNoFailure.foo(10000, 1895825408);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        int i2 = ClassExampleWithNoFailure.foo(10, 1312527521);
        org.junit.Assert.assertTrue(i2 == (-1891234076));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        int i1 = ClassExampleWithNoFailure.twice(140608);
        org.junit.Assert.assertTrue(i1 == (-1704226816));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        int i2 = ClassExampleWithNoFailure.foo(1, 7311616);
        org.junit.Assert.assertTrue(i2 == 7311616);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        int i2 = ClassExampleWithNoFailure.foo((-402345728), (int) '#');
        org.junit.Assert.assertTrue(i2 == 1396899840);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        int i2 = ClassExampleWithNoFailure.foo((-1593835520), (int) (byte) 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        int i2 = ClassExampleWithNoFailure.foo((-1252527359), 88529281);
        org.junit.Assert.assertTrue(i2 == 1812512641);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        int i2 = ClassExampleWithNoFailure.foo((int) ' ', 2040135680);
        org.junit.Assert.assertTrue(i2 == 1744830464);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        int i1 = ClassExampleWithNoFailure.twice((-1102839808));
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        int i1 = ClassExampleWithNoFailure.twice(52521875);
        org.junit.Assert.assertTrue(i1 == 1528444521);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        int i1 = ClassExampleWithNoFailure.twice((-1879048192));
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        int i2 = ClassExampleWithNoFailure.foo(12250, (int) (short) 10);
        org.junit.Assert.assertTrue(i2 == 1500625000);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        int i2 = ClassExampleWithNoFailure.foo((int) 'a', 1048576);
        org.junit.Assert.assertTrue(i2 == 1276116992);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        int i2 = ClassExampleWithNoFailure.foo((int) (short) 0, 1225);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        int i1 = ClassExampleWithNoFailure.twice(1744830464);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        int i2 = ClassExampleWithNoFailure.foo(118825, (-544210944));
        org.junit.Assert.assertTrue(i2 == 9437184);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        int i2 = ClassExampleWithNoFailure.foo(0, (-1272840192));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        int i2 = ClassExampleWithNoFailure.foo(1874919424, 637645056);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        int i2 = ClassExampleWithNoFailure.foo(1881215232, (int) (byte) 10);
        org.junit.Assert.assertTrue(i2 == (-548798464));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        int i2 = ClassExampleWithNoFailure.foo((-747569152), 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        int i1 = ClassExampleWithNoFailure.twice(94090);
        org.junit.Assert.assertTrue(i1 == 262993508);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        int i1 = ClassExampleWithNoFailure.twice(1074186825);
        org.junit.Assert.assertTrue(i1 == (-1690089263));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        int i2 = ClassExampleWithNoFailure.foo((int) (short) 1, (-402345728));
        org.junit.Assert.assertTrue(i2 == (-402345728));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        int i2 = ClassExampleWithNoFailure.foo(268435456, (-466980608));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        int i2 = ClassExampleWithNoFailure.foo(1188250000, 1881215232);
        org.junit.Assert.assertTrue(i2 == 1652621312);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        int i2 = ClassExampleWithNoFailure.foo(1881215232, (-144846576));
        org.junit.Assert.assertTrue(i2 == 588251136);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        int i2 = ClassExampleWithNoFailure.foo(9437184, 67108864);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        int i1 = ClassExampleWithNoFailure.twice((-1690089263));
        org.junit.Assert.assertTrue(i1 == 1209809569);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        int i1 = ClassExampleWithNoFailure.twice(118825);
        org.junit.Assert.assertTrue(i1 == 1234478737);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        int i2 = ClassExampleWithNoFailure.foo((-1), 15006250);
        org.junit.Assert.assertTrue(i2 == 15006250);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        int i2 = ClassExampleWithNoFailure.foo((-1269760000), (-1704226816));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        int i1 = ClassExampleWithNoFailure.twice(1652621312);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        int i2 = ClassExampleWithNoFailure.foo((-577914096), 1278279680);
        org.junit.Assert.assertTrue(i2 == (-1862270976));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        int i1 = ClassExampleWithNoFailure.twice((-1827602432));
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        int i2 = ClassExampleWithNoFailure.foo(100000000, (-1009971200));
        org.junit.Assert.assertTrue(i2 == 268435456);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        int i2 = ClassExampleWithNoFailure.foo((-1862270976), (-1593835520));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        int i1 = ClassExampleWithNoFailure.twice((-1495471856));
        org.junit.Assert.assertTrue(i1 == 665723136);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        int i2 = ClassExampleWithNoFailure.foo((int) (short) 0, 637645056);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        int i2 = ClassExampleWithNoFailure.foo(10000, 1528444521);
        org.junit.Assert.assertTrue(i2 == 693061888);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        int i2 = ClassExampleWithNoFailure.foo((-1918156733), (int) ' ');
        org.junit.Assert.assertTrue(i2 == (-193842912));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        int i1 = ClassExampleWithNoFailure.twice((-544210944));
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        int i2 = ClassExampleWithNoFailure.foo(7311616, 1234478737);
        org.junit.Assert.assertTrue(i2 == (-2001666048));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        int i2 = ClassExampleWithNoFailure.foo((-234364416), 1209809569);
        org.junit.Assert.assertTrue(i2 == 1040449536);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        int i2 = ClassExampleWithNoFailure.foo(1212153856, 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        int i2 = ClassExampleWithNoFailure.foo((-881171968), 1188250000);
        org.junit.Assert.assertTrue(i2 == 507510784);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        int i2 = ClassExampleWithNoFailure.foo((-192901823), 1090519040);
        org.junit.Assert.assertTrue(i2 == (-1056964608));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        int i1 = ClassExampleWithNoFailure.twice((-747569152));
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        int i2 = ClassExampleWithNoFailure.foo((-2134835200), 1874919424);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        int i2 = ClassExampleWithNoFailure.foo((-577914096), 15006250);
        org.junit.Assert.assertTrue(i2 == 535423488);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        int i2 = ClassExampleWithNoFailure.foo((-1272840192), (-2134835200));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        int i2 = ClassExampleWithNoFailure.foo(122500, 9409);
        org.junit.Assert.assertTrue(i2 == 1051361296);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        int i2 = ClassExampleWithNoFailure.foo(588251136, 507510784);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        int i1 = ClassExampleWithNoFailure.twice((-192901823));
        org.junit.Assert.assertTrue(i1 == 1995483777);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        int i2 = ClassExampleWithNoFailure.foo(100, 52);
        org.junit.Assert.assertTrue(i2 == 520000);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        int i1 = ClassExampleWithNoFailure.twice((-2134835200));
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        int i2 = ClassExampleWithNoFailure.foo(0, 100000000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        int i2 = ClassExampleWithNoFailure.foo((-1879048192), (-1928331264));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        int i1 = ClassExampleWithNoFailure.twice(12250);
        org.junit.Assert.assertTrue(i1 == 150062500);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        int i2 = ClassExampleWithNoFailure.foo(711477504, 535423488);
        org.junit.Assert.assertTrue(i2 == 167772160);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        int i2 = ClassExampleWithNoFailure.foo(100, 100000000);
        org.junit.Assert.assertTrue(i2 == (-727379968));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        int i1 = ClassExampleWithNoFailure.twice(520000);
        org.junit.Assert.assertTrue(i1 == (-182939648));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        int i2 = ClassExampleWithNoFailure.foo(1396899840, 1024);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        int i2 = ClassExampleWithNoFailure.foo(1396899840, 1812512641);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        int i2 = ClassExampleWithNoFailure.foo(1, 12250);
        org.junit.Assert.assertTrue(i2 == 12250);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        int i2 = ClassExampleWithNoFailure.foo(1, 1995483777);
        org.junit.Assert.assertTrue(i2 == 1995483777);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        int i2 = ClassExampleWithNoFailure.foo((-1495471856), 1881215232);
        org.junit.Assert.assertTrue(i2 == (-785317888));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        int i2 = ClassExampleWithNoFailure.foo(15006250, 1090519040);
        org.junit.Assert.assertTrue(i2 == (-469762048));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        int i2 = ClassExampleWithNoFailure.foo((int) '#', 329315);
        org.junit.Assert.assertTrue(i2 == 403410875);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        int i1 = ClassExampleWithNoFailure.twice(101715968);
        org.junit.Assert.assertTrue(i1 == 16777216);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        int i2 = ClassExampleWithNoFailure.foo(0, 262993508);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        int i2 = ClassExampleWithNoFailure.foo(1234478737, 2040135680);
        org.junit.Assert.assertTrue(i2 == 953810944);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        int i2 = ClassExampleWithNoFailure.foo((-597622784), 27040000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        int i2 = ClassExampleWithNoFailure.foo((-1891234076), 118825);
        org.junit.Assert.assertTrue(i2 == 1589638544);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        int i2 = ClassExampleWithNoFailure.foo((int) (short) -1, 507510784);
        org.junit.Assert.assertTrue(i2 == 507510784);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        int i2 = ClassExampleWithNoFailure.foo(711477504, 403410875);
        org.junit.Assert.assertTrue(i2 == 1672151040);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        int i1 = ClassExampleWithNoFailure.twice(1672151040);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        int i1 = ClassExampleWithNoFailure.twice(535423488);
        org.junit.Assert.assertTrue(i1 == (-907804672));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        int i2 = ClassExampleWithNoFailure.foo(1048576, (-660003840));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        int i2 = ClassExampleWithNoFailure.foo(1209809569, 262993508);
        org.junit.Assert.assertTrue(i2 == (-1425583260));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        int i1 = ClassExampleWithNoFailure.twice((-1056964608));
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        int i2 = ClassExampleWithNoFailure.foo((-1918156733), (int) (byte) -1);
        org.junit.Assert.assertTrue(i2 == 1214017143);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        int i2 = ClassExampleWithNoFailure.foo((-907804672), (-1));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        int i2 = ClassExampleWithNoFailure.foo(94090, 1426063360);
        org.junit.Assert.assertTrue(i2 == 872415232);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        int i2 = ClassExampleWithNoFailure.foo((-144846576), (-192901823));
        org.junit.Assert.assertTrue(i2 == 944791808);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        int i2 = ClassExampleWithNoFailure.foo(100, 101715968);
        org.junit.Assert.assertTrue(i2 == (-747569152));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        int i2 = ClassExampleWithNoFailure.foo(0, 35);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        int i2 = ClassExampleWithNoFailure.foo((-785317888), 1874919424);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        int i2 = ClassExampleWithNoFailure.foo((-1879048192), 1874919424);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        int i2 = ClassExampleWithNoFailure.foo(1090519040, 1691418624);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        int i1 = ClassExampleWithNoFailure.twice(122500);
        org.junit.Assert.assertTrue(i1 == 2121348112);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        int i2 = ClassExampleWithNoFailure.foo(302162176, 693061888);
        org.junit.Assert.assertTrue(i2 == (-1996488704));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        int i2 = ClassExampleWithNoFailure.foo((-466980608), 1225);
        org.junit.Assert.assertTrue(i2 == 1638465536);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        int i1 = ClassExampleWithNoFailure.twice(1278279680);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        int i2 = ClassExampleWithNoFailure.foo(1589638544, 329315);
        org.junit.Assert.assertTrue(i2 == (-1262013696));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        int i2 = ClassExampleWithNoFailure.foo(1589638544, (-544210944));
        org.junit.Assert.assertTrue(i2 == (-1879048192));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        int i1 = ClassExampleWithNoFailure.twice(1051361296);
        org.junit.Assert.assertTrue(i1 == 357564672);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        int i2 = ClassExampleWithNoFailure.foo((-1827602432), 1874919424);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        int i2 = ClassExampleWithNoFailure.foo((int) (short) 10, (int) (short) 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        int i2 = ClassExampleWithNoFailure.foo(1234478737, (-192901823));
        org.junit.Assert.assertTrue(i2 == 1484264289);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        int i2 = ClassExampleWithNoFailure.foo(1040449536, 1426063360);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        int i2 = ClassExampleWithNoFailure.foo((-1827602432), 872415232);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        int i2 = ClassExampleWithNoFailure.foo((-1928331264), 1225);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        int i1 = ClassExampleWithNoFailure.twice(1995483777);
        org.junit.Assert.assertTrue(i1 == 258970881);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        int i1 = ClassExampleWithNoFailure.twice(872415232);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        int i1 = ClassExampleWithNoFailure.twice((-577914096));
        org.junit.Assert.assertTrue(i1 == 944791808);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        int i2 = ClassExampleWithNoFailure.foo((-548798464), (int) (short) -1);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        int i2 = ClassExampleWithNoFailure.foo((-881171968), 1744830464);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        int i2 = ClassExampleWithNoFailure.foo((-193842912), 122500);
        org.junit.Assert.assertTrue(i2 == 592384000);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        int i2 = ClassExampleWithNoFailure.foo(1214017143, (int) '4');
        org.junit.Assert.assertTrue(i2 == 239144052);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        int i2 = ClassExampleWithNoFailure.foo(12250000, (-1262013696));
        org.junit.Assert.assertTrue(i2 == (-314376192));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        int i2 = ClassExampleWithNoFailure.foo(5200, 88529281);
        org.junit.Assert.assertTrue(i2 == 1671043328);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        int i2 = ClassExampleWithNoFailure.foo(9409, 1895825408);
        org.junit.Assert.assertTrue(i2 == (-251658240));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        int i2 = ClassExampleWithNoFailure.foo(1214017143, (int) (short) -1);
        org.junit.Assert.assertTrue(i2 == 2060289199);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        int i2 = ClassExampleWithNoFailure.foo(970000, 592384000);
        org.junit.Assert.assertTrue(i2 == (-653262848));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        int i2 = ClassExampleWithNoFailure.foo(94090, 1589638544);
        org.junit.Assert.assertTrue(i2 == (-441168832));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        int i1 = ClassExampleWithNoFailure.twice((-251658240));
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        int i2 = ClassExampleWithNoFailure.foo(9409, 665723136);
        org.junit.Assert.assertTrue(i2 == (-1632132864));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        int i1 = ClassExampleWithNoFailure.twice(1073741824);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        int i2 = ClassExampleWithNoFailure.foo((-1632132864), (int) (short) 100);
        org.junit.Assert.assertTrue(i2 == (-2057043968));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        int i1 = ClassExampleWithNoFailure.twice((-144846576));
        org.junit.Assert.assertTrue(i1 == 1885020416);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        int i2 = ClassExampleWithNoFailure.foo(7311616, 872415232);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        int i2 = ClassExampleWithNoFailure.foo(535423488, 52);
        org.junit.Assert.assertTrue(i2 == 38797312);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        int i2 = ClassExampleWithNoFailure.foo((-1262013696), 1234478737);
        org.junit.Assert.assertTrue(i2 == 1094254592);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        int i1 = ClassExampleWithNoFailure.twice(1671043328);
        org.junit.Assert.assertTrue(i1 == 376504320);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        int i2 = ClassExampleWithNoFailure.foo((-1262013696), 35);
        org.junit.Assert.assertTrue(i2 == (-2120548352));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        int i2 = ClassExampleWithNoFailure.foo(2040135680, 1812512641);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        int i2 = ClassExampleWithNoFailure.foo((-182939648), 2069423617);
        org.junit.Assert.assertTrue(i2 == 1358954496);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        int i1 = ClassExampleWithNoFailure.twice(1484264289);
        org.junit.Assert.assertTrue(i1 == (-597194047));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        int i2 = ClassExampleWithNoFailure.foo(1276116992, 3500);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        int i1 = ClassExampleWithNoFailure.twice(2121348112);
        org.junit.Assert.assertTrue(i1 == (-1061781248));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        int i2 = ClassExampleWithNoFailure.foo(1212153856, 9409);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        int i2 = ClassExampleWithNoFailure.foo(100, (-469762048));
        org.junit.Assert.assertTrue(i2 == 1073741824);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        int i1 = ClassExampleWithNoFailure.twice(970000);
        org.junit.Assert.assertTrue(i1 == 302162176);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        int i2 = ClassExampleWithNoFailure.foo(1234478737, 268435456);
        org.junit.Assert.assertTrue(i2 == 268435456);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        int i1 = ClassExampleWithNoFailure.twice((-314376192));
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        int i1 = ClassExampleWithNoFailure.twice(302162176);
        org.junit.Assert.assertTrue(i1 == (-381616128));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        int i2 = ClassExampleWithNoFailure.foo(94090, (-1559101440));
        org.junit.Assert.assertTrue(i2 == (-16252928));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        int i2 = ClassExampleWithNoFailure.foo(872415232, 1358954496);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        int i1 = ClassExampleWithNoFailure.twice(35);
        org.junit.Assert.assertTrue(i1 == 1225);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        int i2 = ClassExampleWithNoFailure.foo(1073741824, (-402345728));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        int i1 = ClassExampleWithNoFailure.twice(1881215232);
        org.junit.Assert.assertTrue(i1 == 1663107072);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        int i2 = ClassExampleWithNoFailure.foo((-2120548352), 118825);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        int i2 = ClassExampleWithNoFailure.foo(1638465536, (-714715136));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        int i1 = ClassExampleWithNoFailure.twice(403410875);
        org.junit.Assert.assertTrue(i1 == (-1161530727));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        int i2 = ClassExampleWithNoFailure.foo(1040449536, (-2057043968));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        int i2 = ClassExampleWithNoFailure.foo((int) (byte) 0, (-679215104));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        int i2 = ClassExampleWithNoFailure.foo(1048576, 140608);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        int i2 = ClassExampleWithNoFailure.foo(1278279680, (-679215104));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        int i2 = ClassExampleWithNoFailure.foo((int) '4', 1225);
        org.junit.Assert.assertTrue(i2 == 3312400);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        int i2 = ClassExampleWithNoFailure.foo(1744830464, (-1056964608));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        int i2 = ClassExampleWithNoFailure.foo((-192901823), (-1996488704));
        org.junit.Assert.assertTrue(i2 == 150994944);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        int i1 = ClassExampleWithNoFailure.twice((-714715136));
        org.junit.Assert.assertTrue(i1 == (-654311424));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        int i2 = ClassExampleWithNoFailure.foo((-251658240), (-2120548352));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        int i2 = ClassExampleWithNoFailure.foo((-1559101440), 239144052);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        int i2 = ClassExampleWithNoFailure.foo(1638465536, 1500625);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        int i2 = ClassExampleWithNoFailure.foo(1214017143, (int) 'a');
        org.junit.Assert.assertTrue(i2 == 2015410609);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        int i2 = ClassExampleWithNoFailure.foo((-469762048), (int) (byte) 1);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        int i2 = ClassExampleWithNoFailure.foo((-234364416), (int) (short) -1);
        org.junit.Assert.assertTrue(i2 == (-595853312));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        int i2 = ClassExampleWithNoFailure.foo((-1918156733), 1040449536);
        org.junit.Assert.assertTrue(i2 == 1948516352);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        int i1 = ClassExampleWithNoFailure.twice(2060289199);
        org.junit.Assert.assertTrue(i1 == (-1861554271));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        int i2 = ClassExampleWithNoFailure.foo(1812512641, (-881171968));
        org.junit.Assert.assertTrue(i2 == 479748608);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        int i2 = ClassExampleWithNoFailure.foo((-1996488704), 27040000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        int i2 = ClassExampleWithNoFailure.foo(1024, (int) (short) 100);
        org.junit.Assert.assertTrue(i2 == 104857600);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        int i2 = ClassExampleWithNoFailure.foo(0, 2040135680);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        int i2 = ClassExampleWithNoFailure.foo(329315, (-1262013696));
        org.junit.Assert.assertTrue(i2 == (-318010624));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        int i2 = ClassExampleWithNoFailure.foo((-714715136), 104857600);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        int i1 = ClassExampleWithNoFailure.twice((-1704226816));
        org.junit.Assert.assertTrue(i1 == (-1325400064));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        int i2 = ClassExampleWithNoFailure.foo(1209809569, 52521875);
        org.junit.Assert.assertTrue(i2 == 262237011);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        int i2 = ClassExampleWithNoFailure.foo((-1632132864), (-1928331264));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        int i2 = ClassExampleWithNoFailure.foo(38797312, 268435456);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        int i1 = ClassExampleWithNoFailure.twice((-466980608));
        org.junit.Assert.assertTrue(i1 == 1172373504);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        int i2 = ClassExampleWithNoFailure.foo(150994944, 1638465536);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        int i2 = ClassExampleWithNoFailure.foo((int) (byte) 0, (-466980608));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        int i2 = ClassExampleWithNoFailure.foo((-1928331264), 1212153856);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        int i2 = ClassExampleWithNoFailure.foo(1948516352, (-881171968));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        int i2 = ClassExampleWithNoFailure.foo(872415232, 1051361296);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        int i2 = ClassExampleWithNoFailure.foo(0, (-2120548352));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        int i2 = ClassExampleWithNoFailure.foo(1652621312, 872415232);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        int i2 = ClassExampleWithNoFailure.foo(0, 1212153856);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        int i2 = ClassExampleWithNoFailure.foo((-314376192), (int) '#');
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        int i2 = ClassExampleWithNoFailure.foo(0, 320000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        int i2 = ClassExampleWithNoFailure.foo((int) (byte) 0, 1638465536);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        int i2 = ClassExampleWithNoFailure.foo((-714715136), (-1862270976));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        int i2 = ClassExampleWithNoFailure.foo(88529281, (-1862270976));
        org.junit.Assert.assertTrue(i2 == (-1862270976));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        int i2 = ClassExampleWithNoFailure.foo((int) '4', 1812512641);
        org.junit.Assert.assertTrue(i2 == 476496528);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        int i2 = ClassExampleWithNoFailure.foo(1885020416, 2040135680);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        int i2 = ClassExampleWithNoFailure.foo(1234478737, 9437184);
        org.junit.Assert.assertTrue(i2 == (-225443840));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        int i1 = ClassExampleWithNoFailure.twice((-182939648));
        org.junit.Assert.assertTrue(i1 == 1358954496);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        int i2 = ClassExampleWithNoFailure.foo(476496528, (-466980608));
        org.junit.Assert.assertTrue(i2 == (-939458560));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        int i2 = ClassExampleWithNoFailure.foo((-727379968), 535423488);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        int i2 = ClassExampleWithNoFailure.foo((-1928331264), (int) (byte) 10);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        int i2 = ClassExampleWithNoFailure.foo((-1), (-1704226816));
        org.junit.Assert.assertTrue(i2 == (-1704226816));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        int i2 = ClassExampleWithNoFailure.foo((-1), (int) (short) 10);
        org.junit.Assert.assertTrue(i2 == 10);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        int i1 = ClassExampleWithNoFailure.twice((-881171968));
        org.junit.Assert.assertTrue(i1 == (-1920729088));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        int i1 = ClassExampleWithNoFailure.twice(944791808);
        org.junit.Assert.assertTrue(i1 == (-993984512));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        int i1 = ClassExampleWithNoFailure.twice((-1862270976));
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        int i2 = ClassExampleWithNoFailure.foo((int) (short) 10, (int) (short) 10);
        org.junit.Assert.assertTrue(i2 == 1000);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        int i2 = ClassExampleWithNoFailure.foo(1358954496, (-785317888));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        int i2 = ClassExampleWithNoFailure.foo(507510784, (-381616128));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        int i2 = ClassExampleWithNoFailure.foo((-548798464), (-597194047));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        int i1 = ClassExampleWithNoFailure.twice(376504320);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        int i1 = ClassExampleWithNoFailure.twice((-653262848));
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        int i1 = ClassExampleWithNoFailure.twice(150994944);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        int i2 = ClassExampleWithNoFailure.foo(1234478737, 665723136);
        org.junit.Assert.assertTrue(i2 == 361775360);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        int i2 = ClassExampleWithNoFailure.foo(1073741824, (-2134835200));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        int i2 = ClassExampleWithNoFailure.foo((int) (short) 100, 1881215232);
        org.junit.Assert.assertTrue(i2 == 195563520);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        int i1 = ClassExampleWithNoFailure.twice((-2120548352));
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        int i2 = ClassExampleWithNoFailure.foo((-1891234076), 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        int i2 = ClassExampleWithNoFailure.foo(5200, 10);
        org.junit.Assert.assertTrue(i2 == 270400000);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        int i1 = ClassExampleWithNoFailure.twice((-2001666048));
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        int i2 = ClassExampleWithNoFailure.foo(665723136, 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        int i1 = ClassExampleWithNoFailure.twice(67108864);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        int i2 = ClassExampleWithNoFailure.foo((-577914096), (-2057043968));
        org.junit.Assert.assertTrue(i2 == (-469762048));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        int i1 = ClassExampleWithNoFailure.twice(1812512641);
        org.junit.Assert.assertTrue(i1 == 1599192833);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        int i2 = ClassExampleWithNoFailure.foo(1358954496, (-441168832));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        int i2 = ClassExampleWithNoFailure.foo((-577914096), 329315);
        org.junit.Assert.assertTrue(i2 == (-1906605312));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        int i1 = ClassExampleWithNoFailure.twice((-1920729088));
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        int i2 = ClassExampleWithNoFailure.foo((-193842912), 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        int i2 = ClassExampleWithNoFailure.foo((-1), 101715968);
        org.junit.Assert.assertTrue(i2 == 101715968);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        int i2 = ClassExampleWithNoFailure.foo(0, 1500625000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        int i1 = ClassExampleWithNoFailure.twice(268435456);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        int i1 = ClassExampleWithNoFailure.twice((-1061781248));
        org.junit.Assert.assertTrue(i1 == (-1392443392));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        int i2 = ClassExampleWithNoFailure.foo(357564672, (-381616128));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        int i1 = ClassExampleWithNoFailure.twice(262993508);
        org.junit.Assert.assertTrue(i1 == (-1148954864));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        int i1 = ClassExampleWithNoFailure.twice(479748608);
        org.junit.Assert.assertTrue(i1 == (-2054946816));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        int i2 = ClassExampleWithNoFailure.foo(592384000, 10000);
        org.junit.Assert.assertTrue(i2 == 268435456);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        int i2 = ClassExampleWithNoFailure.foo((-1392443392), 104857600);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        int i2 = ClassExampleWithNoFailure.foo(2060289199, (-660003840));
        org.junit.Assert.assertTrue(i2 == (-1829002240));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        int i2 = ClassExampleWithNoFailure.foo(1212153856, (-1861554271));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        int i1 = ClassExampleWithNoFailure.twice((-785317888));
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        int i2 = ClassExampleWithNoFailure.foo(1589638544, (int) 'a');
        org.junit.Assert.assertTrue(i2 == 1095192832);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        int i2 = ClassExampleWithNoFailure.foo(1024, (-1102839808));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        int i1 = ClassExampleWithNoFailure.twice(588251136);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        int i2 = ClassExampleWithNoFailure.foo(1663107072, (-1891234076));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        int i2 = ClassExampleWithNoFailure.foo(1396899840, (-1056964608));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        int i2 = ClassExampleWithNoFailure.foo((-1272840192), 1995483777);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        int i2 = ClassExampleWithNoFailure.foo(320000, (-314376192));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        int i2 = ClassExampleWithNoFailure.foo(1995483777, 588251136);
        org.junit.Assert.assertTrue(i2 == 1930428416);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        int i2 = ClassExampleWithNoFailure.foo((-1102839808), (-16252928));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        int i2 = ClassExampleWithNoFailure.foo(9437184, 1426063360);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        int i2 = ClassExampleWithNoFailure.foo(403410875, (-1575874560));
        org.junit.Assert.assertTrue(i2 == 669749248);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        int i2 = ClassExampleWithNoFailure.foo((-1392443392), 329315);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        int i2 = ClassExampleWithNoFailure.foo(94090, 1812512641);
        org.junit.Assert.assertTrue(i2 == (-719535004));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        int i2 = ClassExampleWithNoFailure.foo(1874919424, 669749248);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        int i1 = ClassExampleWithNoFailure.twice(665723136);
        org.junit.Assert.assertTrue(i1 == (-532611072));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        int i2 = ClassExampleWithNoFailure.foo((-381616128), 10);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        int i2 = ClassExampleWithNoFailure.foo((-381616128), 12250);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        int i2 = ClassExampleWithNoFailure.foo((-727379968), (-1879048192));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        int i2 = ClassExampleWithNoFailure.foo((-544210944), (-1425583260));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        int i2 = ClassExampleWithNoFailure.foo(1234478737, (int) (short) 1);
        org.junit.Assert.assertTrue(i2 == (-1240965599));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        int i2 = ClassExampleWithNoFailure.foo((int) (short) -1, (-1495471856));
        org.junit.Assert.assertTrue(i2 == (-1495471856));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        int i2 = ClassExampleWithNoFailure.foo((-727379968), 1881215232);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        int i2 = ClassExampleWithNoFailure.foo(262237011, (-1593835520));
        org.junit.Assert.assertTrue(i2 == (-1996488704));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        int i2 = ClassExampleWithNoFailure.foo(150994944, 1599192833);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        int i2 = ClassExampleWithNoFailure.foo(38797312, 270400000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        int i1 = ClassExampleWithNoFailure.twice(1930428416);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        int i2 = ClassExampleWithNoFailure.foo((int) (short) 10, 872415232);
        org.junit.Assert.assertTrue(i2 == 1342177280);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        int i2 = ClassExampleWithNoFailure.foo(970000, (int) (short) 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        int i2 = ClassExampleWithNoFailure.foo((-595853312), 1671043328);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        int i1 = ClassExampleWithNoFailure.twice(104857600);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        int i1 = ClassExampleWithNoFailure.twice((-597194047));
        org.junit.Assert.assertTrue(i1 == (-1434278527));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        int i2 = ClassExampleWithNoFailure.foo((-727379968), 9437184);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        int i2 = ClassExampleWithNoFailure.foo((-1632132864), 1214017143);
        org.junit.Assert.assertTrue(i2 == 1630994432);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        int i1 = ClassExampleWithNoFailure.twice(507510784);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        int i1 = ClassExampleWithNoFailure.twice(1528444521);
        org.junit.Assert.assertTrue(i1 == (-1092323567));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        int i2 = ClassExampleWithNoFailure.foo(1209809569, (int) '4');
        org.junit.Assert.assertTrue(i2 == (-510254796));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        int i1 = ClassExampleWithNoFailure.twice(16777216);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        int i1 = ClassExampleWithNoFailure.twice(1172373504);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        int i2 = ClassExampleWithNoFailure.foo((-1161530727), 52);
        org.junit.Assert.assertTrue(i2 == 1378902772);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        int i1 = ClassExampleWithNoFailure.twice(2069423617);
        org.junit.Assert.assertTrue(i1 == (-447362047));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        int i2 = ClassExampleWithNoFailure.foo(1589638544, 711477504);
        org.junit.Assert.assertTrue(i2 == (-122093568));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        int i2 = ClassExampleWithNoFailure.foo(3500, 1589638544);
        org.junit.Assert.assertTrue(i2 == (-318418688));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        int i2 = ClassExampleWithNoFailure.foo((int) (byte) 0, 592384000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        int i2 = ClassExampleWithNoFailure.foo(16777216, (-654311424));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        int i2 = ClassExampleWithNoFailure.foo((-1148954864), (-1559101440));
        org.junit.Assert.assertTrue(i2 == (-771751936));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        int i2 = ClassExampleWithNoFailure.foo((-192901823), 9409);
        org.junit.Assert.assertTrue(i2 == (-2090160319));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        int i1 = ClassExampleWithNoFailure.twice(258970881);
        org.junit.Assert.assertTrue(i1 == (-1416091135));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        int i2 = ClassExampleWithNoFailure.foo((-1559101440), (-469762048));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        int i2 = ClassExampleWithNoFailure.foo((-2057043968), (-1161530727));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        int i2 = ClassExampleWithNoFailure.foo(520000, (-441168832));
        org.junit.Assert.assertTrue(i2 == (-790364160));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        int i2 = ClassExampleWithNoFailure.foo(88529281, 1209809569);
        org.junit.Assert.assertTrue(i2 == (-713421407));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        int i2 = ClassExampleWithNoFailure.foo((int) (short) 10, (-2001666048));
        org.junit.Assert.assertTrue(i2 == 1696858112);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        int i1 = ClassExampleWithNoFailure.twice((-1148954864));
        org.junit.Assert.assertTrue(i1 == 1176232192);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        int i2 = ClassExampleWithNoFailure.foo((-2057043968), 268435456);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        int i2 = ClassExampleWithNoFailure.foo(1212153856, (-1879048192));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        int i2 = ClassExampleWithNoFailure.foo(1630994432, 1671043328);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        int i1 = ClassExampleWithNoFailure.twice(361775360);
        org.junit.Assert.assertTrue(i1 == 813760512);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        int i2 = ClassExampleWithNoFailure.foo((-577914096), (-785317888));
        org.junit.Assert.assertTrue(i2 == (-1862270976));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        int i2 = ClassExampleWithNoFailure.foo(88529281, (-713421407));
        org.junit.Assert.assertTrue(i2 == 656466081);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        int i1 = ClassExampleWithNoFailure.twice(693061888);
        org.junit.Assert.assertTrue(i1 == 584122368);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        int i2 = ClassExampleWithNoFailure.foo(1500625, (-144846576));
        org.junit.Assert.assertTrue(i2 == (-577914096));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        int i2 = ClassExampleWithNoFailure.foo((-1920729088), 101715968);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        int i2 = ClassExampleWithNoFailure.foo((-1632132864), 1995483777);
        org.junit.Assert.assertTrue(i2 == 1572929536);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        int i1 = ClassExampleWithNoFailure.twice(1691418624);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        int i1 = ClassExampleWithNoFailure.twice((-907804672));
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        int i1 = ClassExampleWithNoFailure.twice(1176232192);
        org.junit.Assert.assertTrue(i1 == 1002504192);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        int i1 = ClassExampleWithNoFailure.twice(1638465536);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        int i2 = ClassExampleWithNoFailure.foo((-653262848), 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        int i2 = ClassExampleWithNoFailure.foo(101715968, 38797312);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        int i2 = ClassExampleWithNoFailure.foo(9437184, (-1434278527));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        int i1 = ClassExampleWithNoFailure.twice((-1392443392));
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        int i1 = ClassExampleWithNoFailure.twice((-1918156733));
        org.junit.Assert.assertTrue(i1 == (-1214017143));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        int i1 = ClassExampleWithNoFailure.twice(1000);
        org.junit.Assert.assertTrue(i1 == 1000000);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        int i2 = ClassExampleWithNoFailure.foo((-1928331264), 1572929536);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        int i2 = ClassExampleWithNoFailure.foo((-1), (-1559101440));
        org.junit.Assert.assertTrue(i2 == (-1559101440));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        int i2 = ClassExampleWithNoFailure.foo((-314376192), (-719535004));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        int i2 = ClassExampleWithNoFailure.foo((-2001666048), 262237011);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        int i2 = ClassExampleWithNoFailure.foo(1630994432, (int) (short) 100);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        int i2 = ClassExampleWithNoFailure.foo((-714715136), (-679215104));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        int i2 = ClassExampleWithNoFailure.foo(376504320, 16777216);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        int i2 = ClassExampleWithNoFailure.foo(3500, 101715968);
        org.junit.Assert.assertTrue(i2 == (-944177152));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        int i1 = ClassExampleWithNoFailure.twice((-402345728));
        org.junit.Assert.assertTrue(i1 == 39911424);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        int i2 = ClassExampleWithNoFailure.foo(1930428416, (int) (short) 100);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        int i1 = ClassExampleWithNoFailure.twice(1212153856);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        int i1 = ClassExampleWithNoFailure.twice(669749248);
        org.junit.Assert.assertTrue(i1 == (-1325400064));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        int i2 = ClassExampleWithNoFailure.foo((int) (short) -1, 1095192832);
        org.junit.Assert.assertTrue(i2 == 1095192832);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        int i1 = ClassExampleWithNoFailure.twice(9437184);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        int i2 = ClassExampleWithNoFailure.foo((-1601175552), (int) ' ');
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        int i2 = ClassExampleWithNoFailure.foo((int) 'a', 479748608);
        org.junit.Assert.assertTrue(i2 == (-55975424));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        int i2 = ClassExampleWithNoFailure.foo(329315, 1995483777);
        org.junit.Assert.assertTrue(i2 == 271608009);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        int i2 = ClassExampleWithNoFailure.foo(262237011, 872415232);
        org.junit.Assert.assertTrue(i2 == 1409286144);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        int i2 = ClassExampleWithNoFailure.foo((-747569152), 1652621312);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        int i2 = ClassExampleWithNoFailure.foo((-469762048), 271608009);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        int i2 = ClassExampleWithNoFailure.foo((-1829002240), 1663107072);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        int i1 = ClassExampleWithNoFailure.twice(1095192832);
        org.junit.Assert.assertTrue(i1 == 127991808);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        int i2 = ClassExampleWithNoFailure.foo((-1593835520), 52521875);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        int i2 = ClassExampleWithNoFailure.foo((-1434278527), 1358954496);
        org.junit.Assert.assertTrue(i2 == 1358954496);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        int i2 = ClassExampleWithNoFailure.foo(1812512641, 1040449536);
        org.junit.Assert.assertTrue(i2 == 973340672);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        int i2 = ClassExampleWithNoFailure.foo((-1272840192), 1630994432);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        int i2 = ClassExampleWithNoFailure.foo(9437184, 1409286144);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        int i2 = ClassExampleWithNoFailure.foo(1094254592, 1278279680);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        int i1 = ClassExampleWithNoFailure.twice((-1269760000));
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        int i2 = ClassExampleWithNoFailure.foo((-727379968), 329315);
        org.junit.Assert.assertTrue(i2 == 1124073472);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        int i2 = ClassExampleWithNoFailure.foo(693061888, (-785317888));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        int i2 = ClassExampleWithNoFailure.foo((-532611072), 1002504192);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        int i2 = ClassExampleWithNoFailure.foo(1409286144, 268435456);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        int i2 = ClassExampleWithNoFailure.foo(270400000, (-1632132864));
        org.junit.Assert.assertTrue(i2 == (-1543503872));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        int i2 = ClassExampleWithNoFailure.foo(0, 3312400);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        int i2 = ClassExampleWithNoFailure.foo((int) (byte) 0, 262993508);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        int i2 = ClassExampleWithNoFailure.foo(1426063360, (-939458560));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        int i2 = ClassExampleWithNoFailure.foo(637645056, 1672151040);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        int i2 = ClassExampleWithNoFailure.foo(7311616, 258970881);
        org.junit.Assert.assertTrue(i2 == 1159790592);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        int i2 = ClassExampleWithNoFailure.foo(0, 1172373504);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        int i2 = ClassExampleWithNoFailure.foo((-1829002240), (-785317888));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        int i1 = ClassExampleWithNoFailure.twice((-510254796));
        org.junit.Assert.assertTrue(i1 == 1430155920);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        int i1 = ClassExampleWithNoFailure.twice(271608009);
        org.junit.Assert.assertTrue(i1 == (-1773933103));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        int i2 = ClassExampleWithNoFailure.foo((-597194047), (-225443840));
        org.junit.Assert.assertTrue(i2 == 177209344);
    }
}

