import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class ClassExampleWithNoFailureRegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        int i1 = ClassExampleWithNoFailure.twice((-595853312));
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        int i2 = ClassExampleWithNoFailure.foo(261095424, (-2113863680));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        int i2 = ClassExampleWithNoFailure.foo((-1849706352), (-1752181121));
        org.junit.Assert.assertTrue(i2 == 946810624);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        int i2 = ClassExampleWithNoFailure.foo(1295360000, 2111055457);
        org.junit.Assert.assertTrue(i2 == 603979776);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        int i2 = ClassExampleWithNoFailure.foo(177209344, 1342177280);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test006");
        int i2 = ClassExampleWithNoFailure.foo(0, 873463808);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test007");
        int i2 = ClassExampleWithNoFailure.foo((-1752181121), (-559116288));
        org.junit.Assert.assertTrue(i2 == (-1789095936));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        int i2 = ClassExampleWithNoFailure.foo((-1543503872), 150062500);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        int i2 = ClassExampleWithNoFailure.foo(877400064, 1368522752);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        int i2 = ClassExampleWithNoFailure.foo((-1361378928), 730071040);
        org.junit.Assert.assertTrue(i2 == 1140850688);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        int i2 = ClassExampleWithNoFailure.foo(10000, (-734003200));
        org.junit.Assert.assertTrue(i2 == 1073741824);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        int i1 = ClassExampleWithNoFailure.twice((-588957183));
        org.junit.Assert.assertTrue(i1 == (-1964084223));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        int i2 = ClassExampleWithNoFailure.foo(1430155920, 851705856);
        org.junit.Assert.assertTrue(i2 == 67108864);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test014");
        int i2 = ClassExampleWithNoFailure.foo((-837812224), 588251136);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        int i2 = ClassExampleWithNoFailure.foo((-257146815), 94090);
        org.junit.Assert.assertTrue(i2 == 1579603082);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        int i1 = ClassExampleWithNoFailure.twice(879362048);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        int i2 = ClassExampleWithNoFailure.foo(1167720448, 150062500);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test018");
        int i2 = ClassExampleWithNoFailure.foo((-381616128), (-1742471168));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test019");
        int i2 = ClassExampleWithNoFailure.foo(823013632, 1276116992);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        int i1 = ClassExampleWithNoFailure.twice((-1354170368));
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        int i2 = ClassExampleWithNoFailure.foo(88529281, 1874919424);
        org.junit.Assert.assertTrue(i2 == (-1564409856));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test022");
        int i2 = ClassExampleWithNoFailure.foo(817323152, 3500);
        org.junit.Assert.assertTrue(i2 == (-1533187072));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        int i2 = ClassExampleWithNoFailure.foo((-1272840192), 1652621312);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test024");
        int i1 = ClassExampleWithNoFailure.twice(1581514752);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        int i1 = ClassExampleWithNoFailure.twice((-1699389847));
        org.junit.Assert.assertTrue(i1 == (-146061551));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        int i2 = ClassExampleWithNoFailure.foo((-55975424), 42875);
        org.junit.Assert.assertTrue(i2 == 74186752);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        int i2 = ClassExampleWithNoFailure.foo(1224736768, 1);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        int i2 = ClassExampleWithNoFailure.foo(0, 1593835520);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        int i2 = ClassExampleWithNoFailure.foo(729874432, (-399655103));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        int i2 = ClassExampleWithNoFailure.foo((-1996488704), 1608581120);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test031");
        int i2 = ClassExampleWithNoFailure.foo((-544210944), (-2130706432));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        int i2 = ClassExampleWithNoFailure.foo((-203161600), 1528444521);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        int i2 = ClassExampleWithNoFailure.foo((-2120548352), (-2130706432));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        int i2 = ClassExampleWithNoFailure.foo(399655103, (-1416091135));
        org.junit.Assert.assertTrue(i2 == 1035286657);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        int i2 = ClassExampleWithNoFailure.foo((-1274322432), 952172544);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        int i2 = ClassExampleWithNoFailure.foo(1030291456, (-559116288));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        int i2 = ClassExampleWithNoFailure.foo(479748608, (-804257792));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        int i2 = ClassExampleWithNoFailure.foo((-16252928), 15006250);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        int i1 = ClassExampleWithNoFailure.twice((-1214017143));
        org.junit.Assert.assertTrue(i1 == (-2060289199));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        int i2 = ClassExampleWithNoFailure.foo(27040000, (-192901823));
        org.junit.Assert.assertTrue(i2 == (-323944448));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        int i1 = ClassExampleWithNoFailure.twice((-1752181121));
        org.junit.Assert.assertTrue(i1 == 664441601);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        int i2 = ClassExampleWithNoFailure.foo(507510784, (-1056964608));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        int i2 = ClassExampleWithNoFailure.foo(1134624768, (-1849706352));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test044");
        int i1 = ClassExampleWithNoFailure.twice((-1604255744));
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        int i2 = ClassExampleWithNoFailure.foo((-2147483648), (-796113247));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        int i1 = ClassExampleWithNoFailure.twice(1630994432);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        int i2 = ClassExampleWithNoFailure.foo(382606593, 376504320);
        org.junit.Assert.assertTrue(i2 == (-1334771712));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        int i1 = ClassExampleWithNoFailure.twice(987824128);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test049");
        int i2 = ClassExampleWithNoFailure.foo(1811939328, (-1564409856));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test050");
        int i2 = ClassExampleWithNoFailure.foo((-588957183), 693061888);
        org.junit.Assert.assertTrue(i2 == (-194819840));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        int i2 = ClassExampleWithNoFailure.foo(1036582912, 476496528);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        int i2 = ClassExampleWithNoFailure.foo((-785317888), (-550170624));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        int i2 = ClassExampleWithNoFailure.foo(27040000, 1378902772);
        org.junit.Assert.assertTrue(i2 == (-910950400));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        int i2 = ClassExampleWithNoFailure.foo(253820928, (-881171968));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        int i2 = ClassExampleWithNoFailure.foo((-1009971200), (-2054946816));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        int i1 = ClassExampleWithNoFailure.twice((-949846384));
        org.junit.Assert.assertTrue(i1 == 80875776);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        int i2 = ClassExampleWithNoFailure.foo(1225, 2069423617);
        org.junit.Assert.assertTrue(i2 == (-43471919));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        int i2 = ClassExampleWithNoFailure.foo(409792768, (-381616128));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        int i2 = ClassExampleWithNoFailure.foo(0, 1368522752);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        int i2 = ClassExampleWithNoFailure.foo(262237011, 319099136);
        org.junit.Assert.assertTrue(i2 == 1742240000);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        int i2 = ClassExampleWithNoFailure.foo((-623290943), (-291954432));
        org.junit.Assert.assertTrue(i2 == 1631887616);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        int i2 = ClassExampleWithNoFailure.foo(535423488, 1500625);
        org.junit.Assert.assertTrue(i2 == (-953942016));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        int i2 = ClassExampleWithNoFailure.foo((-1721499648), 508166144);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        int i1 = ClassExampleWithNoFailure.twice((-146061551));
        org.junit.Assert.assertTrue(i1 == (-2052034783));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test065");
        int i1 = ClassExampleWithNoFailure.twice(1092616192);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test066");
        int i2 = ClassExampleWithNoFailure.foo((-1891234076), (int) '4');
        org.junit.Assert.assertTrue(i2 == 13238080);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test067");
        int i2 = ClassExampleWithNoFailure.foo((-1891234076), 302162176);
        org.junit.Assert.assertTrue(i2 == (-1195044864));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        int i2 = ClassExampleWithNoFailure.foo(126877696, 1188250000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        int i2 = ClassExampleWithNoFailure.foo(1024, 258970881);
        org.junit.Assert.assertTrue(i2 == 1343225856);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test070");
        int i2 = ClassExampleWithNoFailure.foo(1031340032, 520000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        int i2 = ClassExampleWithNoFailure.foo((-1577720095), (-2001666048));
        org.junit.Assert.assertTrue(i2 == (-831455232));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        int i2 = ClassExampleWithNoFailure.foo((-1611296799), 74186752);
        org.junit.Assert.assertTrue(i2 == 426508288);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test073");
        int i1 = ClassExampleWithNoFailure.twice((-1789095936));
        org.junit.Assert.assertTrue(i1 == (-788529152));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        int i2 = ClassExampleWithNoFailure.foo((-2057043968), 1504772096);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        int i2 = ClassExampleWithNoFailure.foo(177209344, (-1827602432));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        int i2 = ClassExampleWithNoFailure.foo((int) ' ', 1895825408);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test077");
        int i1 = ClassExampleWithNoFailure.twice(1811939328);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        int i2 = ClassExampleWithNoFailure.foo((-1891234076), (int) (short) 10);
        org.junit.Assert.assertTrue(i2 == (-1484173664));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        int i2 = ClassExampleWithNoFailure.foo(1212153856, (-2052034783));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test080");
        int i2 = ClassExampleWithNoFailure.foo(1695088640, 944791808);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        int i2 = ClassExampleWithNoFailure.foo(127991808, 1946157056);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        int i2 = ClassExampleWithNoFailure.foo((-267386880), 864494529);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        int i2 = ClassExampleWithNoFailure.foo((-1651507200), (-907804672));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test084");
        int i2 = ClassExampleWithNoFailure.foo((-1928331264), (-1773933103));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test085");
        int i1 = ClassExampleWithNoFailure.twice(592384000);
        org.junit.Assert.assertTrue(i1 == (-520093696));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        int i2 = ClassExampleWithNoFailure.foo((-785317888), 27040000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        int i1 = ClassExampleWithNoFailure.twice((-493879296));
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test088");
        int i2 = ClassExampleWithNoFailure.foo(9409, (-1928331264));
        org.junit.Assert.assertTrue(i2 == (-1525678080));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        int i2 = ClassExampleWithNoFailure.foo((-399655103), 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test090");
        int i2 = ClassExampleWithNoFailure.foo(1930428416, 1134624768);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        int i2 = ClassExampleWithNoFailure.foo((-1601175552), 1409286144);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        int i2 = ClassExampleWithNoFailure.foo(1188250000, (-318418688));
        org.junit.Assert.assertTrue(i2 == (-1564409856));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        int i2 = ClassExampleWithNoFailure.foo(1589638544, 1074186825);
        org.junit.Assert.assertTrue(i2 == (-1824868096));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test094");
        int i2 = ClassExampleWithNoFailure.foo(268435456, (-831455232));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        int i2 = ClassExampleWithNoFailure.foo((-1575874560), 100);
        org.junit.Assert.assertTrue(i2 == 1677721600);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        int i2 = ClassExampleWithNoFailure.foo(823013632, 409792768);
        org.junit.Assert.assertTrue(i2 == 1358954496);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test097");
        int i2 = ClassExampleWithNoFailure.foo(440401920, 9437184);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        int i2 = ClassExampleWithNoFailure.foo(1095192832, (-949846384));
        org.junit.Assert.assertTrue(i2 == (-2003828736));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test099");
        int i2 = ClassExampleWithNoFailure.foo(3312400, (int) 'a');
        org.junit.Assert.assertTrue(i2 == (-911294208));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        int i1 = ClassExampleWithNoFailure.twice((-194819840));
        org.junit.Assert.assertTrue(i1 == (-1966014464));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        int i1 = ClassExampleWithNoFailure.twice((-1484173664));
        org.junit.Assert.assertTrue(i1 == (-10099712));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        int i2 = ClassExampleWithNoFailure.foo((-2120548352), 584122368);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        int i1 = ClassExampleWithNoFailure.twice(426508288);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        int i2 = ClassExampleWithNoFailure.foo((-1325400064), 1608581120);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        int i2 = ClassExampleWithNoFailure.foo(1036582912, 523923841);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test106");
        int i2 = ClassExampleWithNoFailure.foo((-1354170368), 1000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        int i2 = ClassExampleWithNoFailure.foo((-771751936), (-1918156733));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test108");
        int i2 = ClassExampleWithNoFailure.foo(1199767552, 2084891265);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        int i2 = ClassExampleWithNoFailure.foo(0, (-907804672));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test110");
        int i2 = ClassExampleWithNoFailure.foo((-520093696), (-1704226816));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test111");
        int i1 = ClassExampleWithNoFailure.twice(2085458641);
        org.junit.Assert.assertTrue(i1 == 502075041);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test112");
        int i2 = ClassExampleWithNoFailure.foo((-804257792), 1031340032);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        int i2 = ClassExampleWithNoFailure.foo((-1013972992), (-1824868096));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        int i1 = ClassExampleWithNoFailure.twice(1885020416);
        org.junit.Assert.assertTrue(i1 == 2051080192);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test115");
        int i1 = ClassExampleWithNoFailure.twice((-1632132864));
        org.junit.Assert.assertTrue(i1 == (-1824456704));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test116");
        int i2 = ClassExampleWithNoFailure.foo(1895825408, (-1632132864));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test117");
        int i1 = ClassExampleWithNoFailure.twice((-635371520));
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test118");
        int i2 = ClassExampleWithNoFailure.foo(0, 2103294208);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test119");
        int i2 = ClassExampleWithNoFailure.foo(2015410609, 1411973120);
        org.junit.Assert.assertTrue(i2 == 260636672);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test120");
        int i2 = ClassExampleWithNoFailure.foo((int) '#', 1048576);
        org.junit.Assert.assertTrue(i2 == 1284505600);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test121");
        int i2 = ClassExampleWithNoFailure.foo(329315, (-704410879));
        org.junit.Assert.assertTrue(i2 == 1421307209);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test122");
        int i2 = ClassExampleWithNoFailure.foo(268435456, (-2147483648));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test123");
        int i1 = ClassExampleWithNoFailure.twice((-1610612736));
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test124");
        int i2 = ClassExampleWithNoFailure.foo((-1056964608), (-1789095936));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test125");
        int i2 = ClassExampleWithNoFailure.foo((-2057043968), 100);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test126");
        int i2 = ClassExampleWithNoFailure.foo((-1647681280), 357564672);
        org.junit.Assert.assertTrue(i2 == (-1056964608));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test127");
        int i2 = ClassExampleWithNoFailure.foo(272687360, (-192901823));
        org.junit.Assert.assertTrue(i2 == 50397184);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test128");
        int i1 = ClassExampleWithNoFailure.twice((-306118656));
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test129");
        int i1 = ClassExampleWithNoFailure.twice(167772160);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test130");
        int i2 = ClassExampleWithNoFailure.foo((-532611072), 588251136);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test131");
        int i1 = ClassExampleWithNoFailure.twice(603979776);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test132");
        int i2 = ClassExampleWithNoFailure.foo(39911424, 2069423617);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test133");
        int i2 = ClassExampleWithNoFailure.foo(1031340032, (-704410879));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test134");
        int i2 = ClassExampleWithNoFailure.foo((-1013972992), (-654311424));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test135");
        int i2 = ClassExampleWithNoFailure.foo(0, 382606593);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test136");
        int i2 = ClassExampleWithNoFailure.foo((-944177152), 840915856);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test137");
        int i2 = ClassExampleWithNoFailure.foo((-1559101440), 1082392576);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test138");
        int i2 = ClassExampleWithNoFailure.foo(2085458641, 1342177280);
        org.junit.Assert.assertTrue(i2 == 1342177280);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test139");
        int i1 = ClassExampleWithNoFailure.twice((-911294208));
        org.junit.Assert.assertTrue(i1 == (-310312960));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test140");
        int i2 = ClassExampleWithNoFailure.foo((-1274322432), 426508288);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test141");
        int i2 = ClassExampleWithNoFailure.foo(26517361, 476496528);
        org.junit.Assert.assertTrue(i2 == 13594768);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test142");
        int i2 = ClassExampleWithNoFailure.foo(1035286657, 1761783105);
        org.junit.Assert.assertTrue(i2 == (-1574003135));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test143");
        int i2 = ClassExampleWithNoFailure.foo((-318418688), (int) (short) 10);
        org.junit.Assert.assertTrue(i2 == (-1538654208));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test144");
        int i2 = ClassExampleWithNoFailure.foo(970000, (-466980608));
        org.junit.Assert.assertTrue(i2 == (-1827602432));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test145");
        int i2 = ClassExampleWithNoFailure.foo((-837812224), 1853773456);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test146");
        int i2 = ClassExampleWithNoFailure.foo(1572929536, 646056321);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test147");
        int i2 = ClassExampleWithNoFailure.foo(1134624768, 953810944);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test148");
        int i2 = ClassExampleWithNoFailure.foo((-1392443392), (-449079295));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test149");
        int i2 = ClassExampleWithNoFailure.foo(1572929536, (-1611296799));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test150");
        int i1 = ClassExampleWithNoFailure.twice(973340672);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test151");
        int i2 = ClassExampleWithNoFailure.foo((-1361378928), 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test152");
        int i1 = ClassExampleWithNoFailure.twice(952172544);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test153");
        int i1 = ClassExampleWithNoFailure.twice(1310785536);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test154");
        int i2 = ClassExampleWithNoFailure.foo(80875776, (-1061781248));
        org.junit.Assert.assertTrue(i2 == (-1593835520));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test155");
        int i2 = ClassExampleWithNoFailure.foo(1500625000, (-2090160319));
        org.junit.Assert.assertTrue(i2 == 1207040576);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test156");
        int i2 = ClassExampleWithNoFailure.foo((-1562779392), 1631887616);
        org.junit.Assert.assertTrue(i2 == 1627389952);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test157");
        int i2 = ClassExampleWithNoFailure.foo(7311616, 1742240000);
        org.junit.Assert.assertTrue(i2 == (-1728053248));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test158");
        int i2 = ClassExampleWithNoFailure.foo((-1467940864), (-1752181121));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test159");
        int i2 = ClassExampleWithNoFailure.foo(646056321, (-1861554271));
        org.junit.Assert.assertTrue(i2 == (-321248607));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test160");
        int i2 = ClassExampleWithNoFailure.foo((-1928331264), 637645056);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test161");
        int i2 = ClassExampleWithNoFailure.foo((-1272840192), 426508288);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test162");
        int i1 = ClassExampleWithNoFailure.twice(42875);
        org.junit.Assert.assertTrue(i1 == 1838265625);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test163");
        int i2 = ClassExampleWithNoFailure.foo(0, 1948516352);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test164");
        int i2 = ClassExampleWithNoFailure.foo(1094254592, 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test165");
        int i2 = ClassExampleWithNoFailure.foo((-595853312), 271608009);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test166");
        int i2 = ClassExampleWithNoFailure.foo(1124073472, 2040135680);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test167");
        int i2 = ClassExampleWithNoFailure.foo(970000, 2002243840);
        org.junit.Assert.assertTrue(i2 == (-596574208));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test168");
        int i2 = ClassExampleWithNoFailure.foo((-1452398080), (-805994240));
        org.junit.Assert.assertTrue(i2 == (-469762048));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test169");
        int i1 = ClassExampleWithNoFailure.twice(177209344);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test170");
        int i1 = ClassExampleWithNoFailure.twice((-1197408256));
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test171");
        int i1 = ClassExampleWithNoFailure.twice((-1824868096));
        org.junit.Assert.assertTrue(i1 == 1504772096);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test172");
        int i2 = ClassExampleWithNoFailure.foo(584122368, 1936073728);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test173");
        int i2 = ClassExampleWithNoFailure.foo((-1195044864), 80875776);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test174");
        int i2 = ClassExampleWithNoFailure.foo((-2057043968), (-2113863680));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test175");
        int i2 = ClassExampleWithNoFailure.foo((int) 'a', 708837376);
        org.junit.Assert.assertTrue(i2 == (-633339904));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test176");
        int i2 = ClassExampleWithNoFailure.foo((-713421407), (-713421407));
        org.junit.Assert.assertTrue(i2 == (-1854565151));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test177");
        int i2 = ClassExampleWithNoFailure.foo(12250, 1811939328);
        org.junit.Assert.assertTrue(i2 == 805306368);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test178");
        int i2 = ClassExampleWithNoFailure.foo((-862978048), (-192901823));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test179");
        int i2 = ClassExampleWithNoFailure.foo(637645056, (-1415505152));
        org.junit.Assert.assertTrue(i2 == 989855744);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test180");
        int i2 = ClassExampleWithNoFailure.foo(10000, (-257146815));
        org.junit.Assert.assertTrue(i2 == 665723136);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test181");
        int i2 = ClassExampleWithNoFailure.foo(1040449536, 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test182");
        int i2 = ClassExampleWithNoFailure.foo(2111055457, 1358954496);
        org.junit.Assert.assertTrue(i2 == 285212672);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test183");
        int i1 = ClassExampleWithNoFailure.twice(341211073);
        org.junit.Assert.assertTrue(i1 == (-709820543));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test184");
        int i2 = ClassExampleWithNoFailure.foo(0, (-1964084223));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test185");
        int i1 = ClassExampleWithNoFailure.twice(1421307209);
        org.junit.Assert.assertTrue(i1 == 1426407121);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test186");
        int i2 = ClassExampleWithNoFailure.foo((-633339904), (-1611296799));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test187");
        int i1 = ClassExampleWithNoFailure.twice((-559116288));
        org.junit.Assert.assertTrue(i1 == (-788529152));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test188");
        int i2 = ClassExampleWithNoFailure.foo(1948516352, 952172544);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test189");
        int i2 = ClassExampleWithNoFailure.foo((-1811939328), 2103294208);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test190");
        int i2 = ClassExampleWithNoFailure.foo(1396899840, (-466980608));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test191");
        int i1 = ClassExampleWithNoFailure.twice(126877696);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test192");
        int i2 = ClassExampleWithNoFailure.foo((-1452398080), 260636672);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test193");
        int i2 = ClassExampleWithNoFailure.foo(2117679457, (-487502751));
        org.junit.Assert.assertTrue(i2 == (-1428083935));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test194");
        int i2 = ClassExampleWithNoFailure.foo((-635371520), 1677721600);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test195");
        int i2 = ClassExampleWithNoFailure.foo(1140850688, 507510784);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test196");
        int i2 = ClassExampleWithNoFailure.foo((-557374719), 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test197");
        int i1 = ClassExampleWithNoFailure.twice((-623290943));
        org.junit.Assert.assertTrue(i1 == 837532545);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test198");
        int i2 = ClassExampleWithNoFailure.foo(952172544, 1753876371);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test199");
        int i2 = ClassExampleWithNoFailure.foo(1358954496, (-881171968));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test200");
        int i2 = ClassExampleWithNoFailure.foo(0, (-1849706352));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test201");
        int i2 = ClassExampleWithNoFailure.foo(1378902772, 262237011);
        org.junit.Assert.assertTrue(i2 == (-438499664));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test202");
        int i2 = ClassExampleWithNoFailure.foo((-1827602432), 1672151040);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test203");
        int i1 = ClassExampleWithNoFailure.twice(1936073728);
        org.junit.Assert.assertTrue(i1 == (-1257242624));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test204");
        int i2 = ClassExampleWithNoFailure.foo((-910950400), 1652621312);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test205");
        int i1 = ClassExampleWithNoFailure.twice(1124073472);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test206");
        int i1 = ClassExampleWithNoFailure.twice((-788529152));
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test207");
        int i2 = ClassExampleWithNoFailure.foo(195563520, 262993508);
        org.junit.Assert.assertTrue(i2 == 1677721600);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test208");
        int i2 = ClassExampleWithNoFailure.foo((-2113863680), 473276416);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test209");
        int i2 = ClassExampleWithNoFailure.foo(1631887616, 35);
        org.junit.Assert.assertTrue(i2 == 1877147648);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test210");
        int i2 = ClassExampleWithNoFailure.foo((-550170624), 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test211");
        int i2 = ClassExampleWithNoFailure.foo(1312527521, (-469762048));
        org.junit.Assert.assertTrue(i2 == (-469762048));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test212");
        int i2 = ClassExampleWithNoFailure.foo(473276416, (-2057043968));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test213");
        int i2 = ClassExampleWithNoFailure.foo(39911424, (-704410879));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test214");
        int i2 = ClassExampleWithNoFailure.foo((-1452398080), 1002504192);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test215");
        int i1 = ClassExampleWithNoFailure.twice(840915856);
        org.junit.Assert.assertTrue(i1 == (-1918914304));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test216");
        int i2 = ClassExampleWithNoFailure.foo((-466980608), (-1195044864));
        org.junit.Assert.assertTrue(i2 == 268435456);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test217");
        int i2 = ClassExampleWithNoFailure.foo((-1699389847), (-1195044864));
        org.junit.Assert.assertTrue(i2 == (-1668935680));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test218");
        int i2 = ClassExampleWithNoFailure.foo((-1009971200), (-910950400));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test219");
        int i2 = ClassExampleWithNoFailure.foo((-16252928), (-993984512));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test220");
        int i2 = ClassExampleWithNoFailure.foo(1528444521, 823013632);
        org.junit.Assert.assertTrue(i2 == 2126004480);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test221");
        int i2 = ClassExampleWithNoFailure.foo(1036582912, 17825792);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test222");
        int i2 = ClassExampleWithNoFailure.foo(10000, 1663107072);
        org.junit.Assert.assertTrue(i2 == 16777216);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test223");
        int i2 = ClassExampleWithNoFailure.foo(0, 603979776);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test224");
        int i2 = ClassExampleWithNoFailure.foo(150062500, (-1538654208));
        org.junit.Assert.assertTrue(i2 == (-1365245952));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test225");
        int i1 = ClassExampleWithNoFailure.twice((-1365245952));
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test226");
        int i2 = ClassExampleWithNoFailure.foo(0, (-1891234076));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test227");
        int i2 = ClassExampleWithNoFailure.foo((-182939648), 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test228");
        int i2 = ClassExampleWithNoFailure.foo((-1484173664), (-704410879));
        org.junit.Assert.assertTrue(i2 == (-30284800));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test229");
        int i2 = ClassExampleWithNoFailure.foo(1409286144, 1874919424);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test230");
        int i2 = ClassExampleWithNoFailure.foo(177209344, 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test231");
        int i2 = ClassExampleWithNoFailure.foo((-1879048192), (-2147483648));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test232");
        int i2 = ClassExampleWithNoFailure.foo(42875, 302162176);
        org.junit.Assert.assertTrue(i2 == (-820594432));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test233");
        int i2 = ClassExampleWithNoFailure.foo(944791808, (-402345728));
        org.junit.Assert.assertTrue(i2 == 1895825408);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test234");
        int i2 = ClassExampleWithNoFailure.foo((-588957183), 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test235");
        int i2 = ClassExampleWithNoFailure.foo(1608581120, 39911424);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test236");
        int i1 = ClassExampleWithNoFailure.twice((-230686720));
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test237");
        int i2 = ClassExampleWithNoFailure.foo(0, 1146266785);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test238");
        int i1 = ClassExampleWithNoFailure.twice(1677721600);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test239");
        int i2 = ClassExampleWithNoFailure.foo(1930428416, 2103294208);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test240");
        int i1 = ClassExampleWithNoFailure.twice(74186752);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test241");
        int i2 = ClassExampleWithNoFailure.foo(94090, (-1604255744));
        org.junit.Assert.assertTrue(i2 == (-605814784));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test242");
        int i2 = ClassExampleWithNoFailure.foo((-1604255744), 26517361);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test243");
        int i1 = ClassExampleWithNoFailure.twice((-831455232));
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test244");
        int i2 = ClassExampleWithNoFailure.foo(970000, 2121348112);
        org.junit.Assert.assertTrue(i2 == (-1176629248));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test245");
        int i2 = ClassExampleWithNoFailure.foo(7311616, (-469762048));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test246");
        int i2 = ClassExampleWithNoFailure.foo(1812512641, (-993984512));
        org.junit.Assert.assertTrue(i2 == (-1010761728));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test247");
        int i2 = ClassExampleWithNoFailure.foo((-1392866287), 1146266785);
        org.junit.Assert.assertTrue(i2 == (-1499369023));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test248");
        int i2 = ClassExampleWithNoFailure.foo((-1416091135), (-193842912));
        org.junit.Assert.assertTrue(i2 == 51425568);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test249");
        int i2 = ClassExampleWithNoFailure.foo((-1564409856), (int) '#');
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test250");
        int i2 = ClassExampleWithNoFailure.foo(1671043328, (-1918156733));
        org.junit.Assert.assertTrue(i2 == 529727488);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test251");
        int i2 = ClassExampleWithNoFailure.foo((-1274322432), 88529281);
        org.junit.Assert.assertTrue(i2 == 931397632);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test252");
        int i1 = ClassExampleWithNoFailure.twice(1134624768);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test253");
        int i1 = ClassExampleWithNoFailure.twice((-907197440));
        org.junit.Assert.assertTrue(i1 == (-99614720));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test254");
        int i2 = ClassExampleWithNoFailure.foo((-635371520), 946810624);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test255");
        int i1 = ClassExampleWithNoFailure.twice(805306368);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test256");
        int i2 = ClassExampleWithNoFailure.foo((-635739584), (int) (short) 10);
        org.junit.Assert.assertTrue(i2 == (-1206738944));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test257");
        int i2 = ClassExampleWithNoFailure.foo(479748608, (-1604255744));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test258");
        int i2 = ClassExampleWithNoFailure.foo(2117679457, 2069423617);
        org.junit.Assert.assertTrue(i2 == (-2057847615));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test259");
        int i1 = ClassExampleWithNoFailure.twice((-910950400));
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test260");
        int i2 = ClassExampleWithNoFailure.foo((-321248607), 1092616192);
        org.junit.Assert.assertTrue(i2 == (-1457520640));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test261");
        int i2 = ClassExampleWithNoFailure.foo(2126004480, (-1148954864));
        org.junit.Assert.assertTrue(i2 == (-552599552));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test262");
        int i2 = ClassExampleWithNoFailure.foo((-2001666048), (-1486259696));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test263");
        int i1 = ClassExampleWithNoFailure.twice((-633339904));
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test264");
        int i2 = ClassExampleWithNoFailure.foo(873463808, 94090);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test265");
        int i1 = ClassExampleWithNoFailure.twice(51425568);
        org.junit.Assert.assertTrue(i1 == 1586316288);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test266");
        int i2 = ClassExampleWithNoFailure.foo(743917057, 877400064);
        org.junit.Assert.assertTrue(i2 == (-317976576));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test267");
        int i1 = ClassExampleWithNoFailure.twice(939786240);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test268");
        int i2 = ClassExampleWithNoFailure.foo((-879292160), 1073741824);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test269");
        int i2 = ClassExampleWithNoFailure.foo(1074186825, (int) ' ');
        org.junit.Assert.assertTrue(i2 == 1751718432);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test270");
        int i2 = ClassExampleWithNoFailure.foo(1276116992, 1035286657);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test271");
        int i1 = ClassExampleWithNoFailure.twice(946810624);
        org.junit.Assert.assertTrue(i1 == (-895418368));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test272");
        int i2 = ClassExampleWithNoFailure.foo(1214017143, 52521875);
        org.junit.Assert.assertTrue(i2 == 1845013123);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test273");
        int i2 = ClassExampleWithNoFailure.foo(1751718432, (-804257792));
        org.junit.Assert.assertTrue(i2 == 1073741824);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test274");
        int i2 = ClassExampleWithNoFailure.foo(1295360000, 523923841);
        org.junit.Assert.assertTrue(i2 == (-1543503872));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test275");
        int i2 = ClassExampleWithNoFailure.foo(725680128, 523923841);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test276");
        int i2 = ClassExampleWithNoFailure.foo((-1564409856), (-10099712));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test277");
        int i1 = ClassExampleWithNoFailure.twice(798162944);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test278");
        int i2 = ClassExampleWithNoFailure.foo((-487502751), 851705856);
        org.junit.Assert.assertTrue(i2 == 902037504);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test279");
        int i2 = ClassExampleWithNoFailure.foo((int) '#', (-544210944));
        org.junit.Assert.assertTrue(i2 == (-938475520));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test280");
        int i2 = ClassExampleWithNoFailure.foo((-1699389847), (-182939648));
        org.junit.Assert.assertTrue(i2 == 1183944704);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test281");
        int i2 = ClassExampleWithNoFailure.foo(2044120257, (-804257792));
        org.junit.Assert.assertTrue(i2 == 1745879040);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test282");
        int i1 = ClassExampleWithNoFailure.twice(873463808);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test283");
        int i1 = ClassExampleWithNoFailure.twice(195563520);
        org.junit.Assert.assertTrue(i1 == 16777216);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test284");
        int i1 = ClassExampleWithNoFailure.twice((-1195044864));
        org.junit.Assert.assertTrue(i1 == (-1593835520));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test285");
        int i2 = ClassExampleWithNoFailure.foo((-654311424), 27040000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test286");
        int i2 = ClassExampleWithNoFailure.foo(1812512641, (-1964084223));
        org.junit.Assert.assertTrue(i2 == (-2033437951));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test287");
        int i2 = ClassExampleWithNoFailure.foo(361775360, 2040135680);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test288");
        int i1 = ClassExampleWithNoFailure.twice(357564672);
        org.junit.Assert.assertTrue(i1 == (-1610547200));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test289");
        int i1 = ClassExampleWithNoFailure.twice((-1811939328));
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test290");
        int i2 = ClassExampleWithNoFailure.foo(1041519617, 69206016);
        org.junit.Assert.assertTrue(i2 == 69206016);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test291");
        int i2 = ClassExampleWithNoFailure.foo(0, (int) (byte) 100);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test292");
        int i2 = ClassExampleWithNoFailure.foo((-1704226816), 708837376);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test293");
        int i2 = ClassExampleWithNoFailure.foo((-1056964608), (-1010761728));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test294");
        int i2 = ClassExampleWithNoFailure.foo((-1979711488), 376504320);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test295");
        int i2 = ClassExampleWithNoFailure.foo(104857600, (-1829002240));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test296");
        int i1 = ClassExampleWithNoFailure.twice((-790364160));
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test297");
        int i2 = ClassExampleWithNoFailure.foo(426508288, (-1906605312));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test298");
        int i2 = ClassExampleWithNoFailure.foo(88529281, 74186752);
        org.junit.Assert.assertTrue(i2 == (-2006188032));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test299");
        int i2 = ClassExampleWithNoFailure.foo((-1811939328), 1036582912);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test300");
        int i1 = ClassExampleWithNoFailure.twice(518258688);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test301");
        int i2 = ClassExampleWithNoFailure.foo((-1811939328), (-1854565151));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test302");
        int i1 = ClassExampleWithNoFailure.twice((-2006188032));
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test303");
        int i2 = ClassExampleWithNoFailure.foo(1631887616, 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test304");
        int i2 = ClassExampleWithNoFailure.foo((-2003828736), (-635371520));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test305");
        int i2 = ClassExampleWithNoFailure.foo(426508288, (-520093696));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test306");
        int i2 = ClassExampleWithNoFailure.foo(864494529, 1877147648);
        org.junit.Assert.assertTrue(i2 == (-2040332288));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test307");
        int i1 = ClassExampleWithNoFailure.twice(2084891265);
        org.junit.Assert.assertTrue(i1 == 1666716929);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test308");
        int i2 = ClassExampleWithNoFailure.foo(646056321, 1273233408);
        org.junit.Assert.assertTrue(i2 == 937689088);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test309");
        int i1 = ClassExampleWithNoFailure.twice((-895418368));
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test310");
        int i2 = ClassExampleWithNoFailure.foo(1579603082, (-784436992));
        org.junit.Assert.assertTrue(i2 == (-1801575424));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test311");
        int i2 = ClassExampleWithNoFailure.foo(2121348112, 447362047);
        org.junit.Assert.assertTrue(i2 == (-75661568));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test312");
        int i2 = ClassExampleWithNoFailure.foo((-1325400064), (-1651507200));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test313");
        int i2 = ClassExampleWithNoFailure.foo((-907804672), 1812512641);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test314");
        int i1 = ClassExampleWithNoFailure.twice((-939458560));
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test315");
        int i2 = ClassExampleWithNoFailure.foo(1736704000, (-862978048));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test316");
        int i2 = ClassExampleWithNoFailure.foo((-203161600), 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test317");
        int i1 = ClassExampleWithNoFailure.twice(353370112);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test318");
        int i2 = ClassExampleWithNoFailure.foo(329315, 3312400);
        org.junit.Assert.assertTrue(i2 == 847529872);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test319");
        int i2 = ClassExampleWithNoFailure.foo(1936073728, (-310312960));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test320");
        int i2 = ClassExampleWithNoFailure.foo((-2090160319), 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test321");
        int i2 = ClassExampleWithNoFailure.foo((-1148954864), 140608);
        org.junit.Assert.assertTrue(i2 == 1350385664);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test322");
        int i2 = ClassExampleWithNoFailure.foo((-493879296), 798162944);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test323");
        int i2 = ClassExampleWithNoFailure.foo(382606593, 1209809569);
        org.junit.Assert.assertTrue(i2 == 2070525089);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test324");
        int i2 = ClassExampleWithNoFailure.foo(101715968, (-43471919));
        org.junit.Assert.assertTrue(i2 == (-788529152));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test325");
        int i1 = ClassExampleWithNoFailure.twice(1877147648);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test326");
        int i2 = ClassExampleWithNoFailure.foo((int) (byte) 10, 1124073472);
        org.junit.Assert.assertTrue(i2 == 738197504);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test327");
        int i1 = ClassExampleWithNoFailure.twice((-862978048));
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test328");
        int i1 = ClassExampleWithNoFailure.twice((-1457520640));
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test329");
        int i2 = ClassExampleWithNoFailure.foo(261095424, (-1577720095));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test330");
        int i2 = ClassExampleWithNoFailure.foo(1895825408, 953810944);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test331");
        int i1 = ClassExampleWithNoFailure.twice((-804257792));
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test332");
        int i2 = ClassExampleWithNoFailure.foo(0, (-831455232));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test333");
        int i2 = ClassExampleWithNoFailure.foo((-1920729088), (-1740636160));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test334");
        int i2 = ClassExampleWithNoFailure.foo(1140850688, 529727488);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test335");
        int i2 = ClassExampleWithNoFailure.foo((-1092323567), (-1610612736));
        org.junit.Assert.assertTrue(i2 == (-1610612736));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test336");
        int i2 = ClassExampleWithNoFailure.foo(584122368, (-1457520640));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test337");
        int i2 = ClassExampleWithNoFailure.foo(100, (-790364160));
        org.junit.Assert.assertTrue(i2 == (-901775360));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test338");
        int i1 = ClassExampleWithNoFailure.twice((-1361378928));
        org.junit.Assert.assertTrue(i1 == 1818390784);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test339");
        int i2 = ClassExampleWithNoFailure.foo(10, 1276116992);
        org.junit.Assert.assertTrue(i2 == (-1237319680));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test340");
        int i2 = ClassExampleWithNoFailure.foo(2121348112, 2704);
        org.junit.Assert.assertTrue(i2 == (-2018340864));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test341");
        int i2 = ClassExampleWithNoFailure.foo(58922128, (-804257792));
        org.junit.Assert.assertTrue(i2 == 268435456);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test342");
        int i2 = ClassExampleWithNoFailure.foo(2072199168, 1140850688);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test343");
        int i2 = ClassExampleWithNoFailure.foo(27040000, (-1906605312));
        org.junit.Assert.assertTrue(i2 == (-754974720));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test344");
        int i1 = ClassExampleWithNoFailure.twice(2116464640);
        org.junit.Assert.assertTrue(i1 == (-1191182336));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test345");
        int i2 = ClassExampleWithNoFailure.foo(1234478737, (-953942016));
        org.junit.Assert.assertTrue(i2 == (-475791360));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test346");
        int i1 = ClassExampleWithNoFailure.twice(931397632);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test347");
        int i1 = ClassExampleWithNoFailure.twice((-1533187072));
        org.junit.Assert.assertTrue(i1 == (-1517289472));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test348");
        int i2 = ClassExampleWithNoFailure.foo(1885020416, (-1704226816));
        org.junit.Assert.assertTrue(i2 == (-1879048192));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test349");
        int i1 = ClassExampleWithNoFailure.twice((-1390421375));
        org.junit.Assert.assertTrue(i1 == (-4328191));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test350");
        int i2 = ClassExampleWithNoFailure.foo(523923841, 409792768);
        org.junit.Assert.assertTrue(i2 == 1415573760);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test351");
        int i2 = ClassExampleWithNoFailure.foo((-1610547200), 743917057);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test352");
        int i2 = ClassExampleWithNoFailure.foo(584122368, 1159790592);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test353");
        int i2 = ClassExampleWithNoFailure.foo(74186752, (-653262848));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test354");
        int i2 = ClassExampleWithNoFailure.foo(239144052, 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test355");
        int i2 = ClassExampleWithNoFailure.foo(1048576, 239144052);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test356");
        int i2 = ClassExampleWithNoFailure.foo((-1010761728), (-399655103));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test357");
        int i2 = ClassExampleWithNoFailure.foo((-1647681280), 353370112);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test358");
        int i1 = ClassExampleWithNoFailure.twice((-1824456704));
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test359");
        int i2 = ClassExampleWithNoFailure.foo((-796113247), (-1252527359));
        org.junit.Assert.assertTrue(i2 == 1294738497);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test360");
        int i2 = ClassExampleWithNoFailure.foo(1095192832, 302162176);
        org.junit.Assert.assertTrue(i2 == 1090519040);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test361");
        int i2 = ClassExampleWithNoFailure.foo(533589633, (-1010761728));
        org.junit.Assert.assertTrue(i2 == (-1597964288));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test362");
        int i2 = ClassExampleWithNoFailure.foo((-99614720), 1284505600);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test363");
        int i2 = ClassExampleWithNoFailure.foo((-1862270976), (-1415505152));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test364");
        int i2 = ClassExampleWithNoFailure.foo((-438499664), 1411973120);
        org.junit.Assert.assertTrue(i2 == (-1593835520));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test365");
        int i1 = ClassExampleWithNoFailure.twice((-1577720095));
        org.junit.Assert.assertTrue(i1 == (-1125969471));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test366");
        int i2 = ClassExampleWithNoFailure.foo((-1559101440), 329315);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test367");
        int i2 = ClassExampleWithNoFailure.foo((-635371520), (-1879048192));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test368");
        int i2 = ClassExampleWithNoFailure.foo((-1416091135), 1000000);
        org.junit.Assert.assertTrue(i2 == (-1362345408));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test369");
        int i2 = ClassExampleWithNoFailure.foo((-1773933103), (-1849706352));
        org.junit.Assert.assertTrue(i2 == (-638627184));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test370");
        int i2 = ClassExampleWithNoFailure.foo((-552599552), 2103294208);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test371");
        int i2 = ClassExampleWithNoFailure.foo(1074186825, (-754974720));
        org.junit.Assert.assertTrue(i2 == 1124073472);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test372");
        int i2 = ClassExampleWithNoFailure.foo(3500, (-1761607680));
        org.junit.Assert.assertTrue(i2 == (-268435456));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test373");
        int i2 = ClassExampleWithNoFailure.foo(902037504, 1082392576);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test374");
        int i2 = ClassExampleWithNoFailure.foo((-1996488704), 39911424);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test375");
        int i2 = ClassExampleWithNoFailure.foo((-1829002240), (-544210944));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test376");
        int i2 = ClassExampleWithNoFailure.foo(813760512, (-1362345408));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test377");
        int i1 = ClassExampleWithNoFailure.twice(319099136);
        org.junit.Assert.assertTrue(i1 == (-1423900672));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test378");
        int i2 = ClassExampleWithNoFailure.foo((-910950400), 1295360000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test379");
        int i2 = ClassExampleWithNoFailure.foo(1500625000, 1295360000);
        org.junit.Assert.assertTrue(i2 == 162004992);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test380");
        int i1 = ClassExampleWithNoFailure.twice((-449079295));
        org.junit.Assert.assertTrue(i1 == 884420609);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test381");
        int i1 = ClassExampleWithNoFailure.twice(785727825);
        org.junit.Assert.assertTrue(i1 == (-579585119));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test382");
        int i2 = ClassExampleWithNoFailure.foo(0, (-1499369023));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test383");
        int i1 = ClassExampleWithNoFailure.twice(1343225856);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test384");
        int i2 = ClassExampleWithNoFailure.foo(50397184, (-1416091135));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test385");
        int i2 = ClassExampleWithNoFailure.foo(38797312, (-1610612736));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test386");
        int i1 = ClassExampleWithNoFailure.twice((-310312960));
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test387");
        int i2 = ClassExampleWithNoFailure.foo(1278279680, 708837376);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test388");
        int i2 = ClassExampleWithNoFailure.foo((-1979711488), (-192901823));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test389");
        int i2 = ClassExampleWithNoFailure.foo(1207040576, (-257146815));
        org.junit.Assert.assertTrue(i2 == (-312143872));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test390");
        int i2 = ClassExampleWithNoFailure.foo(1176232192, (-273612800));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test391");
        int i1 = ClassExampleWithNoFailure.twice(1207040576);
        org.junit.Assert.assertTrue(i1 == (-1591668736));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test392");
        int i2 = ClassExampleWithNoFailure.foo((-1723822080), 285212672);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test393");
        int i2 = ClassExampleWithNoFailure.foo((-1274322432), (int) '#');
        org.junit.Assert.assertTrue(i2 == (-452198400));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test394");
        int i2 = ClassExampleWithNoFailure.foo(447362047, 840915856);
        org.junit.Assert.assertTrue(i2 == (-1163076720));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test395");
        int i2 = ClassExampleWithNoFailure.foo(127991808, 1378902772);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test396");
        int i2 = ClassExampleWithNoFailure.foo((-805994240), (-2003828736));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test397");
        int i2 = ClassExampleWithNoFailure.foo((-1829002240), (-595853312));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test398");
        int i2 = ClassExampleWithNoFailure.foo((-510254796), 272687360);
        org.junit.Assert.assertTrue(i2 == (-2035249152));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test399");
        int i2 = ClassExampleWithNoFailure.foo(664441601, 1572929536);
        org.junit.Assert.assertTrue(i2 == 62980096);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test400");
        int i2 = ClassExampleWithNoFailure.foo(473276416, (-633339904));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test401");
        int i2 = ClassExampleWithNoFailure.foo(1845013123, (-1593835520));
        org.junit.Assert.assertTrue(i2 == (-1459617792));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test402");
        int i1 = ClassExampleWithNoFailure.twice(902037504);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test403");
        int i2 = ClassExampleWithNoFailure.foo((-43471919), (-1272840192));
        org.junit.Assert.assertTrue(i2 == 157417472);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test404");
        int i2 = ClassExampleWithNoFailure.foo((-1533187072), 329315);
        org.junit.Assert.assertTrue(i2 == 1722810368);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test405");
        int i2 = ClassExampleWithNoFailure.foo((-557374719), 426508288);
        org.junit.Assert.assertTrue(i2 == (-1586757632));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test406");
        int i2 = ClassExampleWithNoFailure.foo((-1601175552), (-704410879));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test407");
        int i2 = ClassExampleWithNoFailure.foo(52, 760357888);
        org.junit.Assert.assertTrue(i2 == (-1281605632));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test408");
        int i2 = ClassExampleWithNoFailure.foo(2084891265, 1581514752);
        org.junit.Assert.assertTrue(i2 == (-230424576));
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test409");
        int i2 = ClassExampleWithNoFailure.foo((-2121269248), 953810944);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test410");
        int i2 = ClassExampleWithNoFailure.foo((-1611296799), 1818390784);
        org.junit.Assert.assertTrue(i2 == (-1029033728));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test411");
        int i2 = ClassExampleWithNoFailure.foo((-597622784), 9409);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test412");
        int i1 = ClassExampleWithNoFailure.twice(2044120257);
        org.junit.Assert.assertTrue(i1 == 1752181121);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test413");
        int i1 = ClassExampleWithNoFailure.twice(1627389952);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test414");
        int i2 = ClassExampleWithNoFailure.foo(271608009, (-469762048));
        org.junit.Assert.assertTrue(i2 == 603979776);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test415");
        int i2 = ClassExampleWithNoFailure.foo((-2057847615), (-1334771712));
        org.junit.Assert.assertTrue(i2 == (-504299520));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test416");
        int i1 = ClassExampleWithNoFailure.twice((-1486259696));
        org.junit.Assert.assertTrue(i1 == 995311872);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test417");
        int i1 = ClassExampleWithNoFailure.twice(837532545);
        org.junit.Assert.assertTrue(i1 == 707507969);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test418");
        int i1 = ClassExampleWithNoFailure.twice((-1601415295));
        org.junit.Assert.assertTrue(i1 == 318828289);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test419");
        int i2 = ClassExampleWithNoFailure.foo(51425568, 1090519040);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test420");
        int i2 = ClassExampleWithNoFailure.foo((-949846384), (-1272840192));
        org.junit.Assert.assertTrue(i2 == 1107296256);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test421");
        int i2 = ClassExampleWithNoFailure.foo((-2121269248), 1608581120);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test422");
        int i1 = ClassExampleWithNoFailure.twice((-938475520));
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test423");
        int i2 = ClassExampleWithNoFailure.foo((-2120548352), (-635739584));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test424");
        int i2 = ClassExampleWithNoFailure.foo(1691418624, 1310785536);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test425");
        int i2 = ClassExampleWithNoFailure.foo((-1879048192), (-1742471168));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test426");
        int i2 = ClassExampleWithNoFailure.foo(126877696, 74186752);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test427");
        int i2 = ClassExampleWithNoFailure.foo((-2147483648), (-449079295));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test428");
        int i2 = ClassExampleWithNoFailure.foo(1188250000, 1853773456);
        org.junit.Assert.assertTrue(i2 == 936742912);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test429");
        int i2 = ClassExampleWithNoFailure.foo(987824128, (-1292697600));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test430");
        int i2 = ClassExampleWithNoFailure.foo((-754974720), 2051080192);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test431");
        int i1 = ClassExampleWithNoFailure.twice((-1428083935));
        org.junit.Assert.assertTrue(i1 == (-1421469119));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test432");
        int i2 = ClassExampleWithNoFailure.foo(1225, 1284505600);
        org.junit.Assert.assertTrue(i2 == 1368391680);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test433");
        int i2 = ClassExampleWithNoFailure.foo((-679215104), (-1148954864));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test434");
        int i2 = ClassExampleWithNoFailure.foo(319099136, 669749248);
        org.junit.Assert.assertTrue(i2 == (-1879048192));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test435");
        int i1 = ClassExampleWithNoFailure.twice((-1849706352));
        org.junit.Assert.assertTrue(i1 == 200233216);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test436");
        int i2 = ClassExampleWithNoFailure.foo(1214017143, 2116464640);
        org.junit.Assert.assertTrue(i2 == (-523390976));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test437");
        int i2 = ClassExampleWithNoFailure.foo(100000000, 2015410609);
        org.junit.Assert.assertTrue(i2 == (-1116667904));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test438");
        int i2 = ClassExampleWithNoFailure.foo((-1206738944), (-1846253936));
        org.junit.Assert.assertTrue(i2 == 1073741824);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test439");
        int i1 = ClassExampleWithNoFailure.twice((-1586757632));
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test440");
        int i2 = ClassExampleWithNoFailure.foo(1000, (-1601415295));
        org.junit.Assert.assertTrue(i2 == 1916019264);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test441");
        int i2 = ClassExampleWithNoFailure.foo(1946157056, (-10099712));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test442");
        int i2 = ClassExampleWithNoFailure.foo((-1459617792), (-1467940864));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test443");
        int i2 = ClassExampleWithNoFailure.foo(743917057, 1409286144);
        org.junit.Assert.assertTrue(i2 == 1409286144);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test444");
        int i2 = ClassExampleWithNoFailure.foo(1744830464, (-146061551));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test445");
        int i2 = ClassExampleWithNoFailure.foo((-993984512), 1082392576);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test446");
        int i2 = ClassExampleWithNoFailure.foo((-654311424), 1415573760);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test447");
        int i2 = ClassExampleWithNoFailure.foo(2126004480, 1916019264);
        org.junit.Assert.assertTrue(i2 == 1111490560);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test448");
        int i2 = ClassExampleWithNoFailure.foo(62980096, 1234478737);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test449");
        int i1 = ClassExampleWithNoFailure.twice((-267386880));
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test450");
        int i1 = ClassExampleWithNoFailure.twice(884420609);
        org.junit.Assert.assertTrue(i1 == 309223425);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test451");
        int i2 = ClassExampleWithNoFailure.foo(1358954496, 2051080192);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test452");
        int i2 = ClassExampleWithNoFailure.foo((-399655103), (-944177152));
        org.junit.Assert.assertTrue(i2 == (-1036451840));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test453");
        int i2 = ClassExampleWithNoFailure.foo(1500625000, (-837812224));
        org.junit.Assert.assertTrue(i2 == 603979776);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test454");
        int i2 = ClassExampleWithNoFailure.foo(1700855808, 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test455");
        int i2 = ClassExampleWithNoFailure.foo((-1495471856), (-1161530727));
        org.junit.Assert.assertTrue(i2 == (-2050770688));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test456");
        int i2 = ClassExampleWithNoFailure.foo(253820928, (-559116288));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test457");
        int i2 = ClassExampleWithNoFailure.foo((-935788544), (-1176629248));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test458");
        int i2 = ClassExampleWithNoFailure.foo(1885020416, 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test459");
        int i1 = ClassExampleWithNoFailure.twice((-291954432));
        org.junit.Assert.assertTrue(i1 == 1983971328);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test460");
        int i1 = ClassExampleWithNoFailure.twice(1845013123);
        org.junit.Assert.assertTrue(i1 == 1566719753);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test461");
        int i1 = ClassExampleWithNoFailure.twice((-605814784));
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test462");
        int i1 = ClassExampleWithNoFailure.twice(936742912);
        org.junit.Assert.assertTrue(i1 == (-251658240));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test463");
        int i1 = ClassExampleWithNoFailure.twice(1167720448);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test464");
        int i2 = ClassExampleWithNoFailure.foo((-1985425631), (-719535004));
        org.junit.Assert.assertTrue(i2 == 1632904548);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test465");
        int i1 = ClassExampleWithNoFailure.twice(1426407121);
        org.junit.Assert.assertTrue(i1 == 1301538465);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test466");
        int i2 = ClassExampleWithNoFailure.foo(637645056, (-310312960));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test467");
        int i2 = ClassExampleWithNoFailure.foo((-1742471168), (-597194047));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test468");
        int i2 = ClassExampleWithNoFailure.foo((-43471919), 1030291456);
        org.junit.Assert.assertTrue(i2 == 2131296256);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test469");
        int i2 = ClassExampleWithNoFailure.foo(1916019264, 1183944704);
        org.junit.Assert.assertTrue(i2 == (-385875968));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test470");
        int i2 = ClassExampleWithNoFailure.foo((-944177152), 12250000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test471");
        int i2 = ClassExampleWithNoFailure.foo((-704410879), (-1163076720));
        org.junit.Assert.assertTrue(i2 == 1837841296);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test472");
        int i2 = ClassExampleWithNoFailure.foo((-1130716928), 1722810368);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test473");
        int i2 = ClassExampleWithNoFailure.foo((-2001666048), 353370112);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test474");
        int i2 = ClassExampleWithNoFailure.foo((-91226112), 1695088640);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test475");
        int i2 = ClassExampleWithNoFailure.foo((-784436992), (-1029033728));
        org.junit.Assert.assertTrue(i2 == 285212672);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test476");
        int i2 = ClassExampleWithNoFailure.foo(760357888, 1566719753);
        org.junit.Assert.assertTrue(i2 == (-1383071744));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test477");
        int i2 = ClassExampleWithNoFailure.foo((-234364416), 285212672);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test478");
        int i2 = ClassExampleWithNoFailure.foo((-1752181121), 1671043328);
        org.junit.Assert.assertTrue(i2 == (-369813248));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test479");
        int i2 = ClassExampleWithNoFailure.foo((-595853312), (-1467940864));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test480");
        int i2 = ClassExampleWithNoFailure.foo(0, 823013632);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test481");
        int i1 = ClassExampleWithNoFailure.twice((-1574003135));
        org.junit.Assert.assertTrue(i1 == (-2060432255));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test482");
        int i2 = ClassExampleWithNoFailure.foo(100, 1212153856);
        org.junit.Assert.assertTrue(i2 == 1140850688);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test483");
        int i2 = ClassExampleWithNoFailure.foo(1214017143, (-273612800));
        org.junit.Assert.assertTrue(i2 == (-503250944));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test484");
        int i2 = ClassExampleWithNoFailure.foo((-1102839808), (-85851327));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test485");
        int i2 = ClassExampleWithNoFailure.foo(104857600, 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test486");
        int i2 = ClassExampleWithNoFailure.foo((-1829002240), 69206016);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test487");
        int i2 = ClassExampleWithNoFailure.foo((-638627184), (-1918914304));
        org.junit.Assert.assertTrue(i2 == (-213843968));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test488");
        int i2 = ClassExampleWithNoFailure.foo(357564672, 946810624);
        org.junit.Assert.assertTrue(i2 == 788529152);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test489");
        int i1 = ClassExampleWithNoFailure.twice((-734003200));
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test490");
        int i2 = ClassExampleWithNoFailure.foo(1811939328, 760357888);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test491");
        int i2 = ClassExampleWithNoFailure.foo(0, 520000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test492");
        int i2 = ClassExampleWithNoFailure.foo((-503250944), (-784436992));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test493");
        int i2 = ClassExampleWithNoFailure.foo(502075041, 1366606080);
        org.junit.Assert.assertTrue(i2 == 325452032);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test494");
        int i2 = ClassExampleWithNoFailure.foo(1107296256, 1342177280);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test495");
        int i1 = ClassExampleWithNoFailure.twice((-321248607));
        org.junit.Assert.assertTrue(i1 == (-689755839));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test496");
        int i2 = ClassExampleWithNoFailure.foo(884420609, 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test497");
        int i2 = ClassExampleWithNoFailure.foo((-734003200), 122500);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test498");
        int i2 = ClassExampleWithNoFailure.foo((-805994240), (-679215104));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test499");
        int i2 = ClassExampleWithNoFailure.foo((-1274322432), 3312400);
        org.junit.Assert.assertTrue(i2 == (-1002438656));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test500");
        int i2 = ClassExampleWithNoFailure.foo((-862978048), 341211073);
        org.junit.Assert.assertTrue(i2 == 0);
    }
}

