import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class ClassExampleWithNoFailureRegressionTest4 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test001");
        int i2 = ClassExampleWithNoFailure.foo(353370112, (-1860035453));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test002");
        int i1 = ClassExampleWithNoFailure.twice((-1407188992));
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test003");
        int i2 = ClassExampleWithNoFailure.foo(1073741824, 10);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test004");
        int i2 = ClassExampleWithNoFailure.foo(1930428416, (-1647681280));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test005");
        int i2 = ClassExampleWithNoFailure.foo((-1761607680), 798162944);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test006");
        int i1 = ClassExampleWithNoFailure.twice(1586316288);
        org.junit.Assert.assertTrue(i1 == (-99614720));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test007");
        int i2 = ClassExampleWithNoFailure.foo(1107296256, (-831455232));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test008");
        int i2 = ClassExampleWithNoFailure.foo(1031340032, 533589633);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test009");
        int i2 = ClassExampleWithNoFailure.foo(1278279680, (-861863936));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test010");
        int i2 = ClassExampleWithNoFailure.foo((-1421469119), 973340672);
        org.junit.Assert.assertTrue(i2 == 1275330560);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test011");
        int i2 = ClassExampleWithNoFailure.foo(1877147648, (-317976576));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test012");
        int i1 = ClassExampleWithNoFailure.twice((-213843968));
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test013");
        int i2 = ClassExampleWithNoFailure.foo(1140850688, (-1591668736));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test014");
        int i2 = ClassExampleWithNoFailure.foo(508166144, 2117679457);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test015");
        int i2 = ClassExampleWithNoFailure.foo((-335544320), 1669370112);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test016");
        int i2 = ClassExampleWithNoFailure.foo(709951488, (-704410879));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test017");
        int i2 = ClassExampleWithNoFailure.foo(1516536832, (-532611072));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test018");
        int i2 = ClassExampleWithNoFailure.foo((-1996467199), 873463808);
        org.junit.Assert.assertTrue(i2 == (-1274019840));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test019");
        int i1 = ClassExampleWithNoFailure.twice(811712768);
        org.junit.Assert.assertTrue(i1 == (-746520576));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test020");
        int i1 = ClassExampleWithNoFailure.twice(970863104);
        org.junit.Assert.assertTrue(i1 == (-1044119552));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test021");
        int i2 = ClassExampleWithNoFailure.foo(0, (-1434451968));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test022");
        int i1 = ClassExampleWithNoFailure.twice((-1274322432));
        org.junit.Assert.assertTrue(i1 == (-1853620224));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test023");
        int i2 = ClassExampleWithNoFailure.foo(364118016, (-333597679));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test024");
        int i2 = ClassExampleWithNoFailure.foo(454033408, 196704897);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test025");
        int i2 = ClassExampleWithNoFailure.foo(1761783105, 1312527521);
        org.junit.Assert.assertTrue(i2 == 1487212321);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test026");
        int i2 = ClassExampleWithNoFailure.foo((-1521891072), 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test027");
        int i1 = ClassExampleWithNoFailure.twice(515141888);
        org.junit.Assert.assertTrue(i1 == 434176000);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test028");
        int i1 = ClassExampleWithNoFailure.twice(1157693440);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test029");
        int i1 = ClassExampleWithNoFailure.twice((-1781989376));
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test030");
        int i2 = ClassExampleWithNoFailure.foo((-94302208), 1207040576);
        org.junit.Assert.assertTrue(i2 == 1073741824);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test031");
        int i1 = ClassExampleWithNoFailure.twice(1066317897);
        org.junit.Assert.assertTrue(i1 == (-475724591));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test032");
        int i2 = ClassExampleWithNoFailure.foo((-1593835520), 448987136);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test033");
        int i2 = ClassExampleWithNoFailure.foo(239144052, (-1971257344));
        org.junit.Assert.assertTrue(i2 == (-57671680));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test034");
        int i2 = ClassExampleWithNoFailure.foo(1745879040, (-605814784));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test035");
        int i2 = ClassExampleWithNoFailure.foo((-119996416), 2051080192);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test036");
        int i2 = ClassExampleWithNoFailure.foo(1173917952, (-493879296));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test037");
        int i2 = ClassExampleWithNoFailure.foo((-1920729088), 473276416);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test038");
        int i1 = ClassExampleWithNoFailure.twice(729874432);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test039");
        int i1 = ClassExampleWithNoFailure.twice(2003566592);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test040");
        int i2 = ClassExampleWithNoFailure.foo(253820928, 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test041");
        int i2 = ClassExampleWithNoFailure.foo((-493879296), (-552599552));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test042");
        int i2 = ClassExampleWithNoFailure.foo(261095424, 1672151040);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test043");
        int i2 = ClassExampleWithNoFailure.foo(982515712, 1669370112);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test044");
        int i2 = ClassExampleWithNoFailure.foo((-2006188032), 1751518976);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test045");
        int i2 = ClassExampleWithNoFailure.foo(535423488, 97497344);
        org.junit.Assert.assertTrue(i2 == (-1543503872));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test046");
        int i2 = ClassExampleWithNoFailure.foo((int) '#', (-323944448));
        org.junit.Assert.assertTrue(i2 == (-1694957568));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test047");
        int i2 = ClassExampleWithNoFailure.foo((-1036451840), 989855744);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test048");
        int i2 = ClassExampleWithNoFailure.foo(1066317897, 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test049");
        int i2 = ClassExampleWithNoFailure.foo(1277427712, 879362048);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test050");
        int i2 = ClassExampleWithNoFailure.foo(258970881, (-57671680));
        org.junit.Assert.assertTrue(i2 == (-1668284416));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test051");
        int i2 = ClassExampleWithNoFailure.foo((-218103808), 970863104);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test052");
        int i2 = ClassExampleWithNoFailure.foo(0, 1853773456);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test053");
        int i2 = ClassExampleWithNoFailure.foo((-949846384), 126877696);
        org.junit.Assert.assertTrue(i2 == (-1879048192));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test054");
        int i2 = ClassExampleWithNoFailure.foo(162004992, (-1197408256));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test055");
        int i2 = ClassExampleWithNoFailure.foo(1276116992, (-1249572525));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test056");
        int i1 = ClassExampleWithNoFailure.twice(1652334592);
        org.junit.Assert.assertTrue(i1 == 1677721600);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test057");
        int i2 = ClassExampleWithNoFailure.foo((int) (byte) 1, (-907804672));
        org.junit.Assert.assertTrue(i2 == (-907804672));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test058");
        int i2 = ClassExampleWithNoFailure.foo((-1061781248), 38797312);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test059");
        int i2 = ClassExampleWithNoFailure.foo((-43471919), 319099136);
        org.junit.Assert.assertTrue(i2 == (-2062569216));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test060");
        int i1 = ClassExampleWithNoFailure.twice(1764818944);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test061");
        int i2 = ClassExampleWithNoFailure.foo(1751718432, 261095424);
        org.junit.Assert.assertTrue(i2 == 1073741824);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test062");
        int i1 = ClassExampleWithNoFailure.twice((-1125969471));
        org.junit.Assert.assertTrue(i1 == (-176082047));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test063");
        int i2 = ClassExampleWithNoFailure.foo(1234478737, (-1593835520));
        org.junit.Assert.assertTrue(i2 == (-1056964608));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test064");
        int i2 = ClassExampleWithNoFailure.foo(1358954496, (-218103808));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test065");
        int i2 = ClassExampleWithNoFailure.foo((-323944448), (-55975424));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test066");
        int i2 = ClassExampleWithNoFailure.foo((-879292160), 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test067");
        int i2 = ClassExampleWithNoFailure.foo(1599192833, (-52362720));
        org.junit.Assert.assertTrue(i2 == 1751958048);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test068");
        int i2 = ClassExampleWithNoFailure.foo(239144052, (int) (byte) 1);
        org.junit.Assert.assertTrue(i2 == 58922128);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test069");
        int i2 = ClassExampleWithNoFailure.foo((int) (byte) 1, 2060289199);
        org.junit.Assert.assertTrue(i2 == 2060289199);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test070");
        int i1 = ClassExampleWithNoFailure.twice((-1281605632));
        org.junit.Assert.assertTrue(i1 == 268435456);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test071");
        int i2 = ClassExampleWithNoFailure.foo((-879292160), 1415573760);
        org.junit.Assert.assertTrue(i2 == 285212672);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test072");
        int i2 = ClassExampleWithNoFailure.foo(1874919424, 1202671265);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test073");
        int i2 = ClassExampleWithNoFailure.foo((-1632132864), 513708288);
        org.junit.Assert.assertTrue(i2 == (-788529152));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test074");
        int i1 = ClassExampleWithNoFailure.twice((-1029033728));
        org.junit.Assert.assertTrue(i1 == 492896256);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test075");
        int i2 = ClassExampleWithNoFailure.foo((-1632132864), (-557374719));
        org.junit.Assert.assertTrue(i2 == 1983971328);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test076");
        int i2 = ClassExampleWithNoFailure.foo(864494529, 479748608);
        org.junit.Assert.assertTrue(i2 == (-904437248));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test077");
        int i2 = ClassExampleWithNoFailure.foo(1368522752, 1035286657);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test078");
        int i2 = ClassExampleWithNoFailure.foo(118825, (-719535004));
        org.junit.Assert.assertTrue(i2 == 1785992356);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test079");
        int i2 = ClassExampleWithNoFailure.foo((-523390976), 140608);
        org.junit.Assert.assertTrue(i2 == 1073741824);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test080");
        int i1 = ClassExampleWithNoFailure.twice(65536);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test081");
        int i2 = ClassExampleWithNoFailure.foo(1163984896, (-1525678080));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test082");
        int i2 = ClassExampleWithNoFailure.foo(2040135680, (-1425583260));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test083");
        int i1 = ClassExampleWithNoFailure.twice(1301538465);
        org.junit.Assert.assertTrue(i1 == (-2035568319));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test084");
        int i2 = ClassExampleWithNoFailure.foo((-832684032), (-1415505152));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test085");
        int i2 = ClassExampleWithNoFailure.foo((-884998144), (-1269760000));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test086");
        int i2 = ClassExampleWithNoFailure.foo(80875776, 448987136);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test087");
        int i2 = ClassExampleWithNoFailure.foo(1173917952, (-689755839));
        org.junit.Assert.assertTrue(i2 == 325124096);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test088");
        int i2 = ClassExampleWithNoFailure.foo((-148832256), 268435456);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test089");
        int i1 = ClassExampleWithNoFailure.twice((-1136360448));
        org.junit.Assert.assertTrue(i1 == 1678770176);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test090");
        int i2 = ClassExampleWithNoFailure.foo((-306118656), (-544210944));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test091");
        int i1 = ClassExampleWithNoFailure.twice(314239553);
        org.junit.Assert.assertTrue(i1 == 1624171649);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test092");
        int i2 = ClassExampleWithNoFailure.foo(0, (-1521891072));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test093");
        int i2 = ClassExampleWithNoFailure.foo((-881171968), (-2052034783));
        org.junit.Assert.assertTrue(i2 == 2047082496);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test094");
        int i1 = ClassExampleWithNoFailure.twice((-85851327));
        org.junit.Assert.assertTrue(i1 == (-1295083903));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test095");
        int i1 = ClassExampleWithNoFailure.twice((-746520576));
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test096");
        int i2 = ClassExampleWithNoFailure.foo((-597622784), (-1354170368));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test097");
        int i2 = ClassExampleWithNoFailure.foo(1167720448, (-907197440));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test098");
        int i2 = ClassExampleWithNoFailure.foo(1608581120, 84934656);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test099");
        int i2 = ClassExampleWithNoFailure.foo(520000, (-1274019840));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test100");
        int i2 = ClassExampleWithNoFailure.foo((-1591668736), (int) (short) -1);
        org.junit.Assert.assertTrue(i2 == (-553648128));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test101");
        int i2 = ClassExampleWithNoFailure.foo(0, (-1543503872));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test102");
        int i2 = ClassExampleWithNoFailure.foo((-907804672), 693061888);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test103");
        int i1 = ClassExampleWithNoFailure.twice(1273233408);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test104");
        int i2 = ClassExampleWithNoFailure.foo((-1073741824), 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test105");
        int i1 = ClassExampleWithNoFailure.twice((-131370752));
        org.junit.Assert.assertTrue(i1 == 669057024);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test106");
        int i2 = ClassExampleWithNoFailure.foo(1700855808, (-1902859455));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test107");
        int i2 = ClassExampleWithNoFailure.foo(953810944, 172244992);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test108");
        int i2 = ClassExampleWithNoFailure.foo(1652334592, (-1845493760));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test109");
        int i1 = ClassExampleWithNoFailure.twice(1284505600);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test110");
        int i1 = ClassExampleWithNoFailure.twice((-1740570624));
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test111");
        int i1 = ClassExampleWithNoFailure.twice(1107296256);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test112");
        int i2 = ClassExampleWithNoFailure.foo((-446399255), (-1265631232));
        org.junit.Assert.assertTrue(i2 == (-1114636288));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test113");
        int i2 = ClassExampleWithNoFailure.foo(101715968, (-784436992));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test114");
        int i2 = ClassExampleWithNoFailure.foo(196704897, 785727825);
        org.junit.Assert.assertTrue(i2 == (-1162082735));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test115");
        int i2 = ClassExampleWithNoFailure.foo(0, (-1419182080));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test116");
        int i2 = ClassExampleWithNoFailure.foo(1415573760, 952172544);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test117");
        int i1 = ClassExampleWithNoFailure.twice((-1728053248));
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test118");
        int i2 = ClassExampleWithNoFailure.foo(1812512641, 353370112);
        org.junit.Assert.assertTrue(i2 == 84934656);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test119");
        int i1 = ClassExampleWithNoFailure.twice((-1724907520));
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test120");
        int i2 = ClassExampleWithNoFailure.foo(1881215232, 361775360);
        org.junit.Assert.assertTrue(i2 == 1627389952);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test121");
        int i1 = ClassExampleWithNoFailure.twice((-861863936));
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test122");
        int i2 = ClassExampleWithNoFailure.foo(1030291456, 1350385664);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test123");
        int i2 = ClassExampleWithNoFailure.foo((-1214017143), 1353434017);
        org.junit.Assert.assertTrue(i2 == (-406241039));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test124");
        int i2 = ClassExampleWithNoFailure.foo(1538326528, (-213843968));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test125");
        int i2 = ClassExampleWithNoFailure.foo(0, 1090519040);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test126");
        int i1 = ClassExampleWithNoFailure.twice((-2024982476));
        org.junit.Assert.assertTrue(i1 == (-1281439088));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test127");
        int i2 = ClassExampleWithNoFailure.foo((int) (short) 10, 1157693440);
        org.junit.Assert.assertTrue(i2 == (-194772992));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test128");
        int i2 = ClassExampleWithNoFailure.foo(1095192832, 719388672);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test129");
        int i2 = ClassExampleWithNoFailure.foo(1593835520, (-993984512));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test130");
        int i2 = ClassExampleWithNoFailure.foo((-1269760000), 1124073472);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test131");
        int i1 = ClassExampleWithNoFailure.twice((-1918278384));
        org.junit.Assert.assertTrue(i1 == 923115776);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test132");
        int i1 = ClassExampleWithNoFailure.twice(492896256);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test133");
        int i2 = ClassExampleWithNoFailure.foo(987824128, (-43471919));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test134");
        int i1 = ClassExampleWithNoFailure.twice((-435093504));
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test135");
        int i2 = ClassExampleWithNoFailure.foo(669749248, 1035286657);
        org.junit.Assert.assertTrue(i2 == 822083584);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test136");
        int i2 = ClassExampleWithNoFailure.foo((-820594432), 1761783105);
        org.junit.Assert.assertTrue(i2 == 1525743616);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test137");
        int i2 = ClassExampleWithNoFailure.foo((-872349696), (-1010761728));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test138");
        int i2 = ClassExampleWithNoFailure.foo((-1776287744), 84934656);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test139");
        int i1 = ClassExampleWithNoFailure.twice(1525743616);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test140");
        int i2 = ClassExampleWithNoFailure.foo(1082392576, (int) (short) 10);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test141");
        int i2 = ClassExampleWithNoFailure.foo(325452032, 1581514752);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test142");
        int i2 = ClassExampleWithNoFailure.foo((-1214017143), (-1214017143));
        org.junit.Assert.assertTrue(i2 == 1265622873);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test143");
        int i1 = ClassExampleWithNoFailure.twice((-1944518656));
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test144");
        int i2 = ClassExampleWithNoFailure.foo(1146266785, (-335544320));
        org.junit.Assert.assertTrue(i2 == (-335544320));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test145");
        int i2 = ClassExampleWithNoFailure.foo(403410875, 1487212321);
        org.junit.Assert.assertTrue(i2 == 178699449);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test146");
        int i2 = ClassExampleWithNoFailure.foo((int) ' ', (-944177152));
        org.junit.Assert.assertTrue(i2 == (-469762048));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test147");
        int i1 = ClassExampleWithNoFailure.twice(1804795904);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test148");
        int i2 = ClassExampleWithNoFailure.foo((-4328191), 1063305681);
        org.junit.Assert.assertTrue(i2 == 113101777);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test149");
        int i1 = ClassExampleWithNoFailure.twice((-1022361600));
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test150");
        int i2 = ClassExampleWithNoFailure.foo((-1415505152), (-734003200));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test151");
        int i2 = ClassExampleWithNoFailure.foo(9437184, (-257146815));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test152");
        int i2 = ClassExampleWithNoFailure.foo(1983971328, 2145204480);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test153");
        int i2 = ClassExampleWithNoFailure.foo((int) (short) 0, (-689755839));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test154");
        int i1 = ClassExampleWithNoFailure.twice((-2018340864));
        org.junit.Assert.assertTrue(i1 == (-1862270976));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test155");
        int i2 = ClassExampleWithNoFailure.foo((-1493172224), 1630994432);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test156");
        int i2 = ClassExampleWithNoFailure.foo((-318418688), (-1013972992));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test157");
        int i1 = ClassExampleWithNoFailure.twice(253820928);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test158");
        int i2 = ClassExampleWithNoFailure.foo((-910950400), (-335544320));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test159");
        int i2 = ClassExampleWithNoFailure.foo(975147441, (-131370752));
        org.junit.Assert.assertTrue(i2 == (-1565404928));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test160");
        int i2 = ClassExampleWithNoFailure.foo((-679215104), 90898432);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test161");
        int i2 = ClassExampleWithNoFailure.foo(101715968, 172244992);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test162");
        int i2 = ClassExampleWithNoFailure.foo(1277427712, (-1269760000));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test163");
        int i2 = ClassExampleWithNoFailure.foo((-1325400064), 1589638544);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test164");
        int i2 = ClassExampleWithNoFailure.foo(1895825408, 944791808);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test165");
        int i1 = ClassExampleWithNoFailure.twice((-1191182336));
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test166");
        int i1 = ClassExampleWithNoFailure.twice((-1854565151));
        org.junit.Assert.assertTrue(i1 == 1312746945);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test167");
        int i2 = ClassExampleWithNoFailure.foo((-2090160319), (-820594432));
        org.junit.Assert.assertTrue(i2 == (-1619969792));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test168");
        int i2 = ClassExampleWithNoFailure.foo(1744830464, 13594768);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test169");
        int i2 = ClassExampleWithNoFailure.foo(723811841, (-1565404928));
        org.junit.Assert.assertTrue(i2 == (-1200762624));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test170");
        int i2 = ClassExampleWithNoFailure.foo(1409286144, 872415232);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test171");
        int i2 = ClassExampleWithNoFailure.foo(1378902772, 1191968768);
        org.junit.Assert.assertTrue(i2 == (-1765801984));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test172");
        int i2 = ClassExampleWithNoFailure.foo((-1252527359), 1426407121);
        org.junit.Assert.assertTrue(i2 == 239928529);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test173");
        int i2 = ClassExampleWithNoFailure.foo(376504320, (-449079295));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test174");
        int i1 = ClassExampleWithNoFailure.twice((-2147483648));
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test175");
        int i1 = ClassExampleWithNoFailure.twice((-1281439088));
        org.junit.Assert.assertTrue(i1 == 168268032);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test176");
        int i2 = ClassExampleWithNoFailure.foo(100, 1885020416);
        org.junit.Assert.assertTrue(i2 == (-407302144));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test177");
        int i2 = ClassExampleWithNoFailure.foo((-653262848), (-1928331264));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test178");
        int i2 = ClassExampleWithNoFailure.foo(1202671265, (-85851327));
        org.junit.Assert.assertTrue(i2 == (-632646527));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test179");
        int i2 = ClassExampleWithNoFailure.foo((-884998144), 1295360000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test180");
        int i1 = ClassExampleWithNoFailure.twice(1173917952);
        org.junit.Assert.assertTrue(i1 == 1109458944);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test181");
        int i2 = ClassExampleWithNoFailure.foo(1140850688, (-292220928));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test182");
        int i2 = ClassExampleWithNoFailure.foo((-785317888), 1);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test183");
        int i2 = ClassExampleWithNoFailure.foo((-597194047), (-2057847615));
        org.junit.Assert.assertTrue(i2 == (-1042251199));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test184");
        int i2 = ClassExampleWithNoFailure.foo((-1362345408), 150994944);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test185");
        int i2 = ClassExampleWithNoFailure.foo((-1226374400), (-2018340864));
        org.junit.Assert.assertTrue(i2 == 268435456);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test186");
        int i2 = ClassExampleWithNoFailure.foo(637645056, 325452032);
        org.junit.Assert.assertTrue(i2 == 1627389952);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test187");
        int i2 = ClassExampleWithNoFailure.foo(167772160, (-761200640));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test188");
        int i2 = ClassExampleWithNoFailure.foo(12250000, 1638465536);
        org.junit.Assert.assertTrue(i2 == (-654311424));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test189");
        int i2 = ClassExampleWithNoFailure.foo(126877696, 996409344);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test190");
        int i2 = ClassExampleWithNoFailure.foo((-1125969471), 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test191");
        int i1 = ClassExampleWithNoFailure.twice((-406241039));
        org.junit.Assert.assertTrue(i1 == (-118791455));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test192");
        int i2 = ClassExampleWithNoFailure.foo((-369813248), (-804257792));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test193");
        int i2 = ClassExampleWithNoFailure.foo((-944177152), 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test194");
        int i2 = ClassExampleWithNoFailure.foo((-2062569216), 1159790592);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test195");
        int i2 = ClassExampleWithNoFailure.foo(0, 10000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test196");
        int i1 = ClassExampleWithNoFailure.twice(1542656000);
        org.junit.Assert.assertTrue(i1 == 1627389952);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test197");
        int i2 = ClassExampleWithNoFailure.foo(1212153856, (-1562779392));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test198");
        int i2 = ClassExampleWithNoFailure.foo(1771835392, 502075041);
        org.junit.Assert.assertTrue(i2 == 553648128);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test199");
        int i1 = ClassExampleWithNoFailure.twice((-304021504));
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test200");
        int i2 = ClassExampleWithNoFailure.foo(1845013123, 1608581120);
        org.junit.Assert.assertTrue(i2 == (-1108803584));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test201");
        int i2 = ClassExampleWithNoFailure.foo((-790364160), 2072199168);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test202");
        int i1 = ClassExampleWithNoFailure.twice((-796113247));
        org.junit.Assert.assertTrue(i1 == (-208375487));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test203");
        int i2 = ClassExampleWithNoFailure.foo((-709820543), 319815680);
        org.junit.Assert.assertTrue(i2 == 51380224);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test204");
        int i2 = ClassExampleWithNoFailure.foo(0, (-230686720));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test205");
        int i2 = ClassExampleWithNoFailure.foo(157417472, 320000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test206");
        int i2 = ClassExampleWithNoFailure.foo((-1740570624), (-1728053248));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test207");
        int i2 = ClassExampleWithNoFailure.foo(1599192833, (-1849706352));
        org.junit.Assert.assertTrue(i2 == 316053648);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test208");
        int i2 = ClassExampleWithNoFailure.foo(1183944704, (-1343160320));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test209");
        int i2 = ClassExampleWithNoFailure.foo(177209344, 1368391680);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test210");
        int i2 = ClassExampleWithNoFailure.foo((-1161530727), (-402345728));
        org.junit.Assert.assertTrue(i2 == (-1476321024));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test211");
        int i1 = ClassExampleWithNoFailure.twice((-407302144));
        org.junit.Assert.assertTrue(i1 == 553648128);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test212");
        int i2 = ClassExampleWithNoFailure.foo(2131296256, 708837376);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test213");
        int i2 = ClassExampleWithNoFailure.foo(1134624768, 1109458944);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test214");
        int i2 = ClassExampleWithNoFailure.foo(2038497280, 960349825);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test215");
        int i2 = ClassExampleWithNoFailure.foo((-633339904), 785727825);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test216");
        int i2 = ClassExampleWithNoFailure.foo((-318010624), 1183944704);
        org.junit.Assert.assertTrue(i2 == 268435456);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test217");
        int i2 = ClassExampleWithNoFailure.foo(822083584, (-1452398080));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test218");
        int i2 = ClassExampleWithNoFailure.foo(1368522752, (-218103808));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test219");
        int i2 = ClassExampleWithNoFailure.foo(3312400, (-559677440));
        org.junit.Assert.assertTrue(i2 == 603979776);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test220");
        int i2 = ClassExampleWithNoFailure.foo((-1136360448), (-793374720));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test221");
        int i2 = ClassExampleWithNoFailure.foo(1066317897, 426508288);
        org.junit.Assert.assertTrue(i2 == 1898708992);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test222");
        int i2 = ClassExampleWithNoFailure.foo(1352663040, 424718336);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test223");
        int i2 = ClassExampleWithNoFailure.foo(1581514752, (-1102839808));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test224");
        int i1 = ClassExampleWithNoFailure.twice(664441601);
        org.junit.Assert.assertTrue(i1 == 2141070849);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test225");
        int i2 = ClassExampleWithNoFailure.foo((-1240965599), 1214017143);
        org.junit.Assert.assertTrue(i2 == 1124715575);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test226");
        int i1 = ClassExampleWithNoFailure.twice(2047082496);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test227");
        int i2 = ClassExampleWithNoFailure.foo((-323944448), (-192901823));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test228");
        int i1 = ClassExampleWithNoFailure.twice(982515712);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test229");
        int i2 = ClassExampleWithNoFailure.foo((-1010761728), (-559116288));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test230");
        int i1 = ClassExampleWithNoFailure.twice((-2057847615));
        org.junit.Assert.assertTrue(i1 == 1616513409);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test231");
        int i2 = ClassExampleWithNoFailure.foo(1092616192, 314239553);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test232");
        int i1 = ClassExampleWithNoFailure.twice(1983971328);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test233");
        int i2 = ClassExampleWithNoFailure.foo(529727488, (-805994240));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test234");
        int i2 = ClassExampleWithNoFailure.foo(319099136, (-653262848));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test235");
        int i2 = ClassExampleWithNoFailure.foo((-579585119), (int) (byte) 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test236");
        int i2 = ClassExampleWithNoFailure.foo((-88691952), 1889533952);
        org.junit.Assert.assertTrue(i2 == (-1610612736));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test237");
        int i1 = ClassExampleWithNoFailure.twice(364118016);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test238");
        int i2 = ClassExampleWithNoFailure.foo(1652334592, (int) (short) -1);
        org.junit.Assert.assertTrue(i2 == (-1677721600));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test239");
        int i2 = ClassExampleWithNoFailure.foo(26214400, 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test240");
        int i2 = ClassExampleWithNoFailure.foo(840915856, (-131370752));
        org.junit.Assert.assertTrue(i2 == 941686784);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test241");
        int i2 = ClassExampleWithNoFailure.foo((-435093504), (-88691952));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test242");
        int i1 = ClassExampleWithNoFailure.twice(285212672);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test243");
        int i2 = ClassExampleWithNoFailure.foo(941686784, 1695088640);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test244");
        int i2 = ClassExampleWithNoFailure.foo(0, 1051361296);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test245");
        int i1 = ClassExampleWithNoFailure.twice(84934656);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test246");
        int i1 = ClassExampleWithNoFailure.twice(127991808);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test247");
        int i2 = ClassExampleWithNoFailure.foo(1889884481, (-211922175));
        org.junit.Assert.assertTrue(i2 == 953554305);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test248");
        int i2 = ClassExampleWithNoFailure.foo((-1392866287), (-1918278384));
        org.junit.Assert.assertTrue(i2 == 1268553488);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test249");
        int i2 = ClassExampleWithNoFailure.foo((-1383071744), (-323944448));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test250");
        int i2 = ClassExampleWithNoFailure.foo((-314376192), 515141888);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test251");
        int i2 = ClassExampleWithNoFailure.foo((-1383071744), 1829163264);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test252");
        int i1 = ClassExampleWithNoFailure.twice((-57671680));
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test253");
        int i2 = ClassExampleWithNoFailure.foo((-1970240447), (-1593835520));
        org.junit.Assert.assertTrue(i2 == 553648128);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test254");
        int i1 = ClassExampleWithNoFailure.twice(13238080);
        org.junit.Assert.assertTrue(i1 == (-788492288));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test255");
        int i2 = ClassExampleWithNoFailure.foo(931397632, (-2024982476));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test256");
        int i2 = ClassExampleWithNoFailure.foo((-1920729088), (-75661568));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test257");
        int i2 = ClassExampleWithNoFailure.foo(9437184, 399655103);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test258");
        int i2 = ClassExampleWithNoFailure.foo(820920225, (-1564409856));
        org.junit.Assert.assertTrue(i2 == 906035200);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test259");
        int i2 = ClassExampleWithNoFailure.foo((-469762048), 2117679457);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test260");
        int i2 = ClassExampleWithNoFailure.foo((-1419182080), (-926262652));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test261");
        int i2 = ClassExampleWithNoFailure.foo(1525743616, 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test262");
        int i1 = ClassExampleWithNoFailure.twice((-1521891072));
        org.junit.Assert.assertTrue(i1 == 1070661632);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test263");
        int i2 = ClassExampleWithNoFailure.foo((-1262013696), 813760512);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test264");
        int i2 = ClassExampleWithNoFailure.foo((-1029033728), (-55975424));
        org.junit.Assert.assertTrue(i2 == (-1577058304));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test265");
        int i1 = ClassExampleWithNoFailure.twice((-820594432));
        org.junit.Assert.assertTrue(i1 == 1370554368);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test266");
        int i2 = ClassExampleWithNoFailure.foo(729874432, 1273233408);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test267");
        int i2 = ClassExampleWithNoFailure.foo(1207040576, 51425568);
        org.junit.Assert.assertTrue(i2 == 3276800);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test268");
        int i2 = ClassExampleWithNoFailure.foo(1804795904, (-523390976));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test269");
        int i2 = ClassExampleWithNoFailure.foo((-2062569216), (-1906605312));
        org.junit.Assert.assertTrue(i2 == (-1560281088));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test270");
        int i1 = ClassExampleWithNoFailure.twice(90898432);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test271");
        int i2 = ClassExampleWithNoFailure.foo(1225, (-1829002240));
        org.junit.Assert.assertTrue(i2 == 824501248);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test272");
        int i2 = ClassExampleWithNoFailure.foo(473276416, (-911294208));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test273");
        int i2 = ClassExampleWithNoFailure.foo((-230686720), (-881171968));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test274");
        int i2 = ClassExampleWithNoFailure.foo((-1428083935), (-1274019840));
        org.junit.Assert.assertTrue(i2 == 1477443584);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test275");
        int i2 = ClassExampleWithNoFailure.foo(1751518976, (-935788544));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test276");
        int i2 = ClassExampleWithNoFailure.foo((-949846384), (-208375487));
        org.junit.Assert.assertTrue(i2 == (-958967552));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test277");
        int i1 = ClassExampleWithNoFailure.twice((-1162082735));
        org.junit.Assert.assertTrue(i1 == (-81795679));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test278");
        int i2 = ClassExampleWithNoFailure.foo(1073741824, (-1742471168));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test279");
        int i2 = ClassExampleWithNoFailure.foo(513708288, (-1971257344));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test280");
        int i2 = ClassExampleWithNoFailure.foo(1312746945, (-719535004));
        org.junit.Assert.assertTrue(i2 == (-659635612));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test281");
        int i2 = ClassExampleWithNoFailure.foo((-2130706432), 663359488);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test282");
        int i1 = ClassExampleWithNoFailure.twice((-1853620224));
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test283");
        int i1 = ClassExampleWithNoFailure.twice(738955264);
        org.junit.Assert.assertTrue(i1 == (-1325400064));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test284");
        int i2 = ClassExampleWithNoFailure.foo(1159790592, 1477443584);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test285");
        int i2 = ClassExampleWithNoFailure.foo(1895825408, 1421123584);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test286");
        int i2 = ClassExampleWithNoFailure.foo(13238080, (-487502751));
        org.junit.Assert.assertTrue(i2 == (-336162816));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test287");
        int i1 = ClassExampleWithNoFailure.twice(1631887616);
        org.junit.Assert.assertTrue(i1 == (-314507264));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test288");
        int i2 = ClassExampleWithNoFailure.foo((-1296891904), (-1130716928));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test289");
        int i2 = ClassExampleWithNoFailure.foo((-1565404928), (-719535004));
        org.junit.Assert.assertTrue(i2 == (-1293680640));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test290");
        int i2 = ClassExampleWithNoFailure.foo((-1467940864), 1370554368);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test291");
        int i2 = ClassExampleWithNoFailure.foo(0, 2069423617);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test292");
        int i2 = ClassExampleWithNoFailure.foo(84934656, (-1740570624));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test293");
        int i2 = ClassExampleWithNoFailure.foo((int) (byte) 0, (-503316480));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test294");
        int i1 = ClassExampleWithNoFailure.twice(1265622873);
        org.junit.Assert.assertTrue(i1 == (-1744163599));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test295");
        int i2 = ClassExampleWithNoFailure.foo(1691418624, (-1390421375));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test296");
        int i2 = ClassExampleWithNoFailure.foo(937689088, 102400);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test297");
        int i1 = ClassExampleWithNoFailure.twice((-552599552));
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test298");
        int i2 = ClassExampleWithNoFailure.foo(1031340032, (-1176629248));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test299");
        int i2 = ClassExampleWithNoFailure.foo((-1593835520), 26517361);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test300");
        int i2 = ClassExampleWithNoFailure.foo((-318418688), 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test301");
        int i2 = ClassExampleWithNoFailure.foo(1448939520, 75433104);
        org.junit.Assert.assertTrue(i2 == (-1879048192));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test302");
        int i2 = ClassExampleWithNoFailure.foo((-2050770688), (-958967552));
        org.junit.Assert.assertTrue(i2 == 16777216);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test303");
        int i2 = ClassExampleWithNoFailure.foo((-243728384), (-660003840));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test304");
        int i2 = ClassExampleWithNoFailure.foo(1349054657, (-704410879));
        org.junit.Assert.assertTrue(i2 == 90078337);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test305");
        int i2 = ClassExampleWithNoFailure.foo((-1197408256), (-633339904));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test306");
        int i1 = ClassExampleWithNoFailure.twice((-1677721600));
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test307");
        int i2 = ClassExampleWithNoFailure.foo(1736704000, 1500625);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test308");
        int i2 = ClassExampleWithNoFailure.foo((-659635612), (-1257242624));
        org.junit.Assert.assertTrue(i2 == (-1056964608));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test309");
        int i2 = ClassExampleWithNoFailure.foo((-1029033728), 822083584);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test310");
        int i2 = ClassExampleWithNoFailure.foo((-1525678080), 1094254592);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test311");
        int i2 = ClassExampleWithNoFailure.foo(1207040576, (-793374720));
        org.junit.Assert.assertTrue(i2 == 1895825408);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test312");
        int i2 = ClassExampleWithNoFailure.foo(0, (-872349696));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test313");
        int i2 = ClassExampleWithNoFailure.foo((-660003840), (-1879048192));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test314");
        int i2 = ClassExampleWithNoFailure.foo((-1632132864), 75433104);
        org.junit.Assert.assertTrue(i2 == (-661651456));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test315");
        int i2 = ClassExampleWithNoFailure.foo((-1108803584), (-1902859455));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test316");
        int i2 = ClassExampleWithNoFailure.foo(2015410609, 272687360);
        org.junit.Assert.assertTrue(i2 == 1013006592);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test317");
        int i1 = ClassExampleWithNoFailure.twice((-475724591));
        org.junit.Assert.assertTrue(i1 == (-612289887));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test318");
        int i2 = ClassExampleWithNoFailure.foo((-1996488704), 403410875);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test319");
        int i1 = ClassExampleWithNoFailure.twice((-718449855));
        org.junit.Assert.assertTrue(i1 == (-1980942719));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test320");
        int i2 = ClassExampleWithNoFailure.foo((-1), 595853312);
        org.junit.Assert.assertTrue(i2 == 595853312);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test321");
        int i2 = ClassExampleWithNoFailure.foo(1176232192, 361775360);
        org.junit.Assert.assertTrue(i2 == 16777216);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test322");
        int i2 = ClassExampleWithNoFailure.foo(58922128, (-2001666048));
        org.junit.Assert.assertTrue(i2 == (-2130706432));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test323");
        int i2 = ClassExampleWithNoFailure.foo((-771751936), 822083584);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test324");
        int i1 = ClassExampleWithNoFailure.twice(1566719753);
        org.junit.Assert.assertTrue(i1 == (-597070255));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test325");
        int i2 = ClassExampleWithNoFailure.foo((-225443840), 840915856);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test326");
        int i2 = ClassExampleWithNoFailure.foo((-234364416), (-837812224));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test327");
        int i1 = ClassExampleWithNoFailure.twice(941686784);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test328");
        int i1 = ClassExampleWithNoFailure.twice(200233216);
        org.junit.Assert.assertTrue(i1 == 1470169088);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test329");
        int i2 = ClassExampleWithNoFailure.foo(1579603082, 1678770176);
        org.junit.Assert.assertTrue(i2 == (-1237319680));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test330");
        int i1 = ClassExampleWithNoFailure.twice((-1476321024));
        org.junit.Assert.assertTrue(i1 == 1178664960);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test331");
        int i1 = ClassExampleWithNoFailure.twice(2145204480);
        org.junit.Assert.assertTrue(i1 == 1991311360);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test332");
        int i1 = ClassExampleWithNoFailure.twice(3276800);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test333");
        int i2 = ClassExampleWithNoFailure.foo((-1490743296), (-548798464));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test334");
        int i2 = ClassExampleWithNoFailure.foo((-1846253936), (-935788544));
        org.junit.Assert.assertTrue(i2 == (-922746880));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test335");
        int i1 = ClassExampleWithNoFailure.twice((-964543103));
        org.junit.Assert.assertTrue(i1 == 298498817);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test336");
        int i2 = ClassExampleWithNoFailure.foo((-1493172224), (-2134835200));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test337");
        int i2 = ClassExampleWithNoFailure.foo(447362047, (-949846384));
        org.junit.Assert.assertTrue(i2 == 1035468432);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test338");
        int i2 = ClassExampleWithNoFailure.foo(1599192833, 1159790592);
        org.junit.Assert.assertTrue(i2 == (-2094989312));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test339");
        int i2 = ClassExampleWithNoFailure.foo(798162944, 811712768);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test340");
        int i1 = ClassExampleWithNoFailure.twice(923115776);
        org.junit.Assert.assertTrue(i1 == (-1354694656));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test341");
        int i2 = ClassExampleWithNoFailure.foo(1278279680, 1881215232);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test342");
        int i2 = ClassExampleWithNoFailure.foo(664441601, 479748608);
        org.junit.Assert.assertTrue(i2 == 925131264);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test343");
        int i2 = ClassExampleWithNoFailure.foo(1700855808, (int) '#');
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test344");
        int i2 = ClassExampleWithNoFailure.foo((-425530304), (-1854565151));
        org.junit.Assert.assertTrue(i2 == 1368657920);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test345");
        int i2 = ClassExampleWithNoFailure.foo(1343225856, (-1125969471));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test346");
        int i2 = ClassExampleWithNoFailure.foo((-605814784), 502075041);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test347");
        int i1 = ClassExampleWithNoFailure.twice(1484873985);
        org.junit.Assert.assertTrue(i1 == (-1748778495));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test348");
        int i2 = ClassExampleWithNoFailure.foo((-559116288), (-1459617792));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test349");
        int i2 = ClassExampleWithNoFailure.foo(1632904548, (-449079295));
        org.junit.Assert.assertTrue(i2 == 951553808);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test350");
        int i2 = ClassExampleWithNoFailure.foo((-148832256), 664441601);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test351");
        int i2 = ClassExampleWithNoFailure.foo(440401920, 1368522752);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test352");
        int i2 = ClassExampleWithNoFailure.foo(1396899840, 1117912848);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test353");
        int i2 = ClassExampleWithNoFailure.foo((-866704191), (-369813248));
        org.junit.Assert.assertTrue(i2 == (-88958720));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test354");
        int i2 = ClassExampleWithNoFailure.foo(102400, (-550170624));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test355");
        int i2 = ClassExampleWithNoFailure.foo((-449079295), (-831455232));
        org.junit.Assert.assertTrue(i2 == (-26148864));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test356");
        int i2 = ClassExampleWithNoFailure.foo((-1740636160), 1484264289);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test357");
        int i1 = ClassExampleWithNoFailure.twice((-1243545600));
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test358");
        int i2 = ClassExampleWithNoFailure.foo((-1378181120), 1785992356);
        org.junit.Assert.assertTrue(i2 == 268435456);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test359");
        int i1 = ClassExampleWithNoFailure.twice(1124715575);
        org.junit.Assert.assertTrue(i1 == (-926567471));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test360");
        int i2 = ClassExampleWithNoFailure.foo(1284505600, (-926262652));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test361");
        int i2 = ClassExampleWithNoFailure.foo((-407302144), 507510784);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test362");
        int i1 = ClassExampleWithNoFailure.twice(707507969);
        org.junit.Assert.assertTrue(i1 == 1361604097);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test363");
        int i2 = ClassExampleWithNoFailure.foo(1048576, 16777216);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test364");
        int i2 = ClassExampleWithNoFailure.foo(1671043328, (-1102839808));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test365");
        int i2 = ClassExampleWithNoFailure.foo((-689755839), 1368657920);
        org.junit.Assert.assertTrue(i2 == (-2118381568));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test366");
        int i2 = ClassExampleWithNoFailure.foo(1829163264, 847529872);
        org.junit.Assert.assertTrue(i2 == 1636827136);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test367");
        int i2 = ClassExampleWithNoFailure.foo(1225, 309223425);
        org.junit.Assert.assertTrue(i2 == 135480785);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test368");
        int i2 = ClassExampleWithNoFailure.foo(0, 1284505600);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test369");
        int i2 = ClassExampleWithNoFailure.foo((-1979711488), (-1827602432));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test370");
        int i1 = ClassExampleWithNoFailure.twice(197787648);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test371");
        int i2 = ClassExampleWithNoFailure.foo(1995483777, 823013632);
        org.junit.Assert.assertTrue(i2 == (-1298976512));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test372");
        int i1 = ClassExampleWithNoFailure.twice((-1295083903));
        org.junit.Assert.assertTrue(i1 == (-199791359));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test373");
        int i2 = ClassExampleWithNoFailure.foo(364118016, 52);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test374");
        int i2 = ClassExampleWithNoFailure.foo((-713421407), 1507429120);
        org.junit.Assert.assertTrue(i2 == (-1913566464));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test375");
        int i2 = ClassExampleWithNoFailure.foo(535423488, 1306719553);
        org.junit.Assert.assertTrue(i2 == 1994653696);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test376");
        int i2 = ClassExampleWithNoFailure.foo(1700855808, (-2057847615));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test377");
        int i1 = ClassExampleWithNoFailure.twice(196704897);
        org.junit.Assert.assertTrue(i1 == 1594963201);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test378");
        int i1 = ClassExampleWithNoFailure.twice(1361604097);
        org.junit.Assert.assertTrue(i1 == 831839233);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test379");
        int i2 = ClassExampleWithNoFailure.foo(1636827136, 925131264);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test380");
        int i2 = ClassExampleWithNoFailure.foo((-633339904), 51425568);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test381");
        int i2 = ClassExampleWithNoFailure.foo(507510784, 533589633);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test382");
        int i2 = ClassExampleWithNoFailure.foo((-438499664), (-1879048192));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test383");
        int i2 = ClassExampleWithNoFailure.foo(533589633, (-1361378928));
        org.junit.Assert.assertTrue(i2 == 535318928);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test384");
        int i2 = ClassExampleWithNoFailure.foo(694926529, 2051080192);
        org.junit.Assert.assertTrue(i2 == (-473890816));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test385");
        int i2 = ClassExampleWithNoFailure.foo((-788529152), 1594963201);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test386");
        int i2 = ClassExampleWithNoFailure.foo(1201513025, (-503316480));
        org.junit.Assert.assertTrue(i2 == (-503316480));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test387");
        int i2 = ClassExampleWithNoFailure.foo(1829163264, 1627389952);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test388");
        int i2 = ClassExampleWithNoFailure.foo(743917057, 1294738497);
        org.junit.Assert.assertTrue(i2 == (-313413567));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test389");
        int i2 = ClassExampleWithNoFailure.foo((-544210944), (-523390976));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test390");
        int i2 = ClassExampleWithNoFailure.foo((-2062569216), (-793374720));
        org.junit.Assert.assertTrue(i2 == 268435456);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test391");
        int i2 = ClassExampleWithNoFailure.foo((-1996467199), (-911294208));
        org.junit.Assert.assertTrue(i2 == 139903232);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test392");
        int i2 = ClassExampleWithNoFailure.foo((-30284800), (-910950400));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test393");
        int i2 = ClassExampleWithNoFailure.foo((-597622784), (-1200762624));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test394");
        int i1 = ClassExampleWithNoFailure.twice(1579603082);
        org.junit.Assert.assertTrue(i1 == 560781924);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test395");
        int i2 = ClassExampleWithNoFailure.foo(1426407121, (-953942016));
        org.junit.Assert.assertTrue(i2 == (-1784414208));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test396");
        int i1 = ClassExampleWithNoFailure.twice(535318928);
        org.junit.Assert.assertTrue(i1 == (-822316800));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test397");
        int i1 = ClassExampleWithNoFailure.twice((-88958720));
        org.junit.Assert.assertTrue(i1 == 527499264);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test398");
        int i2 = ClassExampleWithNoFailure.foo((-2060432255), 2030043136);
        org.junit.Assert.assertTrue(i2 == 2030043136);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test399");
        int i1 = ClassExampleWithNoFailure.twice((-317976576));
        org.junit.Assert.assertTrue(i1 == (-2130706432));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test400");
        int i2 = ClassExampleWithNoFailure.foo(0, 1983971328);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test401");
        int i2 = ClassExampleWithNoFailure.foo((-26148864), 560781924);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test402");
        int i2 = ClassExampleWithNoFailure.foo(9409, 743917057);
        org.junit.Assert.assertTrue(i2 == 2073501569);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test403");
        int i2 = ClassExampleWithNoFailure.foo((-653262848), (-1776287744));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test404");
        int i1 = ClassExampleWithNoFailure.twice(1593835520);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test405");
        int i1 = ClassExampleWithNoFailure.twice(1382097920);
        org.junit.Assert.assertTrue(i1 == 1292894208);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test406");
        int i1 = ClassExampleWithNoFailure.twice((-1226374400));
        org.junit.Assert.assertTrue(i1 == 1778974720);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test407");
        int i1 = ClassExampleWithNoFailure.twice(113101777);
        org.junit.Assert.assertTrue(i1 == 1625235617);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test408");
        int i2 = ClassExampleWithNoFailure.foo(0, (-1845493760));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test409");
        int i2 = ClassExampleWithNoFailure.foo((-2057847615), 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test410");
        int i2 = ClassExampleWithNoFailure.foo(0, 1484873985);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test411");
        int i2 = ClassExampleWithNoFailure.foo((-1272840192), (-446399255));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test412");
        int i2 = ClassExampleWithNoFailure.foo((-119996416), (-713421407));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test413");
        int i2 = ClassExampleWithNoFailure.foo(975147441, 1672151040);
        org.junit.Assert.assertTrue(i2 == 399179776);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test414");
        int i2 = ClassExampleWithNoFailure.foo(27040000, 88529281);
        org.junit.Assert.assertTrue(i2 == 1425080320);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test415");
        int i2 = ClassExampleWithNoFailure.foo((-1244227295), (-1249572525));
        org.junit.Assert.assertTrue(i2 == 614440979);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test416");
        int i2 = ClassExampleWithNoFailure.foo(785727825, (-901775360));
        org.junit.Assert.assertTrue(i2 == (-230686720));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test417");
        int i2 = ClassExampleWithNoFailure.foo(1209809569, 975147441);
        org.junit.Assert.assertTrue(i2 == 314541809);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test418");
        int i2 = ClassExampleWithNoFailure.foo(1201513025, 1500625);
        org.junit.Assert.assertTrue(i2 == (-863870383));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test419");
        int i2 = ClassExampleWithNoFailure.foo(1589638544, 1124073472);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test420");
        int i2 = ClassExampleWithNoFailure.foo((-1295083903), 1853773456);
        org.junit.Assert.assertTrue(i2 == 1078568592);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test421");
        int i2 = ClassExampleWithNoFailure.foo(831839233, (-1740636160));
        org.junit.Assert.assertTrue(i2 == (-1740636160));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test422");
        int i2 = ClassExampleWithNoFailure.foo((-1560281088), 730071040);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test423");
        int i2 = ClassExampleWithNoFailure.foo(140608, 925131264);
        org.junit.Assert.assertTrue(i2 == 1830813696);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test424");
        int i2 = ClassExampleWithNoFailure.foo((-1240965599), 518258688);
        org.junit.Assert.assertTrue(i2 == (-672923648));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test425");
        int i2 = ClassExampleWithNoFailure.foo(1885020416, (-118791455));
        org.junit.Assert.assertTrue(i2 == 1428226048);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test426");
        int i2 = ClassExampleWithNoFailure.foo(162004992, 851705856);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test427");
        int i1 = ClassExampleWithNoFailure.twice((-149502976));
        org.junit.Assert.assertTrue(i1 == 1175453696);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test428");
        int i2 = ClassExampleWithNoFailure.foo((-1970240447), 1140850688);
        org.junit.Assert.assertTrue(i2 == 1140850688);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test429");
        int i2 = ClassExampleWithNoFailure.foo(1273233408, 50397184);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test430");
        int i2 = ClassExampleWithNoFailure.foo((-192329968), (-230686720));
        org.junit.Assert.assertTrue(i2 == 1073741824);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test431");
        int i1 = ClassExampleWithNoFailure.twice(1178664960);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test432");
        int i2 = ClassExampleWithNoFailure.foo(1063305681, 1349054657);
        org.junit.Assert.assertTrue(i2 == 1549088097);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test433");
        int i2 = ClassExampleWithNoFailure.foo((-659635612), (-1761607680));
        org.junit.Assert.assertTrue(i2 == 1879048192);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test434");
        int i2 = ClassExampleWithNoFailure.foo(1638465536, 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test435");
        int i2 = ClassExampleWithNoFailure.foo(0, 2145204480);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test436");
        int i1 = ClassExampleWithNoFailure.twice((-672923648));
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test437");
        int i2 = ClassExampleWithNoFailure.foo((-16252928), 1109458944);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test438");
        int i2 = ClassExampleWithNoFailure.foo(1936073728, 253820928);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test439");
        int i2 = ClassExampleWithNoFailure.foo(1509949440, 1632904548);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test440");
        int i2 = ClassExampleWithNoFailure.foo((-1748778495), 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test441");
        int i1 = ClassExampleWithNoFailure.twice((-211922175));
        org.junit.Assert.assertTrue(i1 == (-173693439));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test442");
        int i1 = ClassExampleWithNoFailure.twice((-226657520));
        org.junit.Assert.assertTrue(i1 == (-1463262976));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test443");
        int i2 = ClassExampleWithNoFailure.foo(1225, (-1257242624));
        org.junit.Assert.assertTrue(i2 == 571473920);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test444");
        int i2 = ClassExampleWithNoFailure.foo(0, (-176082047));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test445");
        int i2 = ClassExampleWithNoFailure.foo((-30284800), (-203161600));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test446");
        int i2 = ClassExampleWithNoFailure.foo((-1188823040), 1895825408);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test447");
        int i2 = ClassExampleWithNoFailure.foo(122022739, (-1829002240));
        org.junit.Assert.assertTrue(i2 == 1182286848);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test448");
        int i1 = ClassExampleWithNoFailure.twice(97497344);
        org.junit.Assert.assertTrue(i1 == (-1201602560));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test449");
        int i2 = ClassExampleWithNoFailure.foo(341211073, 936742912);
        org.junit.Assert.assertTrue(i2 == (-586313728));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test450");
        int i2 = ClassExampleWithNoFailure.foo(1487212321, 2085458641);
        org.junit.Assert.assertTrue(i2 == 572311825);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test451");
        int i2 = ClassExampleWithNoFailure.foo(0, (-926567471));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test452");
        int i2 = ClassExampleWithNoFailure.foo((-1586757632), 1051361296);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test453");
        int i1 = ClassExampleWithNoFailure.twice(1015189760);
        org.junit.Assert.assertTrue(i1 == (-1776222208));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test454");
        int i2 = ClassExampleWithNoFailure.foo(1761783105, (-2035249152));
        org.junit.Assert.assertTrue(i2 == (-2103930880));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test455");
        int i2 = ClassExampleWithNoFailure.foo(664441601, (-704410879));
        org.junit.Assert.assertTrue(i2 == (-1505513215));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test456");
        int i2 = ClassExampleWithNoFailure.foo((-1013972992), (int) 'a');
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test457");
        int i2 = ClassExampleWithNoFailure.foo(2003566592, 1421123584);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test458");
        int i2 = ClassExampleWithNoFailure.foo((-604356608), (-1860035453));
        org.junit.Assert.assertTrue(i2 == 805306368);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test459");
        int i1 = ClassExampleWithNoFailure.twice((-261202831));
        org.junit.Assert.assertTrue(i1 == 1920821729);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test460");
        int i2 = ClassExampleWithNoFailure.foo((-1010761728), (-597070255));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test461");
        int i2 = ClassExampleWithNoFailure.foo((-1591668736), (-1505513215));
        org.junit.Assert.assertTrue(i2 == 553648128);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test462");
        int i2 = ClassExampleWithNoFailure.foo((-1214017143), 760357888);
        org.junit.Assert.assertTrue(i2 == (-699833344));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test463");
        int i1 = ClassExampleWithNoFailure.twice(178699449);
        org.junit.Assert.assertTrue(i1 == (-1089716815));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test464");
        int i2 = ClassExampleWithNoFailure.foo(298498817, (-306118656));
        org.junit.Assert.assertTrue(i2 == (-473890816));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test465");
        int i2 = ClassExampleWithNoFailure.foo((-544210944), 434176000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test466");
        int i2 = ClassExampleWithNoFailure.foo(1421307209, 1761783105);
        org.junit.Assert.assertTrue(i2 == 1483354129);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test467");
        int i1 = ClassExampleWithNoFailure.twice((-81795679));
        org.junit.Assert.assertTrue(i1 == 553086785);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test468");
        int i2 = ClassExampleWithNoFailure.foo(476496528, (-588957183));
        org.junit.Assert.assertTrue(i2 == (-1065840384));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test469");
        int i2 = ClassExampleWithNoFailure.foo(440401920, (-475791360));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test470");
        int i1 = ClassExampleWithNoFailure.twice((-1108803584));
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test471");
        int i1 = ClassExampleWithNoFailure.twice(1632904548);
        org.junit.Assert.assertTrue(i1 == 1461063440);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test472");
        int i2 = ClassExampleWithNoFailure.foo(1672151040, 1678770176);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test473");
        int i2 = ClassExampleWithNoFailure.foo(0, (int) (short) 10);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test474");
        int i2 = ClassExampleWithNoFailure.foo((int) (byte) 10, 1430155920);
        org.junit.Assert.assertTrue(i2 == 1281671232);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test475");
        int i2 = ClassExampleWithNoFailure.foo(1273233408, 837532545);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test476");
        int i1 = ClassExampleWithNoFailure.twice(399655103);
        org.junit.Assert.assertTrue(i1 == (-1682174335));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test477");
        int i1 = ClassExampleWithNoFailure.twice((-1784414208));
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test478");
        int i2 = ClassExampleWithNoFailure.foo((-1610547200), (-713421407));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test479");
        int i1 = ClassExampleWithNoFailure.twice((-523390976));
        org.junit.Assert.assertTrue(i1 == 1493172224);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test480");
        int i2 = ClassExampleWithNoFailure.foo(1024, 923115776);
        org.junit.Assert.assertTrue(i2 == 268435456);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test481");
        int i2 = ClassExampleWithNoFailure.foo((-866704191), 1785992356);
        org.junit.Assert.assertTrue(i2 == (-1001559388));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test482");
        int i1 = ClassExampleWithNoFailure.twice(1182286848);
        org.junit.Assert.assertTrue(i1 == (-770703360));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test483");
        int i2 = ClassExampleWithNoFailure.foo((-43471919), (-10099712));
        org.junit.Assert.assertTrue(i2 == 1184130048);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test484");
        int i2 = ClassExampleWithNoFailure.foo(0, 507510784);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test485");
        int i2 = ClassExampleWithNoFailure.foo((-261202831), 1359253760);
        org.junit.Assert.assertTrue(i2 == (-511938304));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test486");
        int i2 = ClassExampleWithNoFailure.foo((-30284800), (-723099071));
        org.junit.Assert.assertTrue(i2 == (-149946368));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test487");
        int i1 = ClassExampleWithNoFailure.twice(1199767552);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test488");
        int i2 = ClassExampleWithNoFailure.foo((-938475520), 1936073728);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test489");
        int i2 = ClassExampleWithNoFailure.foo((-1505513215), (-1784414208));
        org.junit.Assert.assertTrue(i2 == 1571028992);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test490");
        int i2 = ClassExampleWithNoFailure.foo((-81795679), 2002243840);
        org.junit.Assert.assertTrue(i2 == 132845824);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test491");
        int i2 = ClassExampleWithNoFailure.foo((-949846384), 1695088640);
        org.junit.Assert.assertTrue(i2 == (-1728053248));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test492");
        int i2 = ClassExampleWithNoFailure.foo(0, 1720010625);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test493");
        int i2 = ClassExampleWithNoFailure.foo(0, 1368391680);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test494");
        int i1 = ClassExampleWithNoFailure.twice((-2062569216));
        org.junit.Assert.assertTrue(i1 == 945881088);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test495");
        int i2 = ClassExampleWithNoFailure.foo((-310312960), (int) (byte) 1);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test496");
        int i2 = ClassExampleWithNoFailure.foo(258970881, 840915856);
        org.junit.Assert.assertTrue(i2 == (-458949744));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test497");
        int i2 = ClassExampleWithNoFailure.foo(1421307209, (-1056964608));
        org.junit.Assert.assertTrue(i2 == (-1862270976));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test498");
        int i2 = ClassExampleWithNoFailure.foo((-1362345408), 1);
        org.junit.Assert.assertTrue(i2 == (-1490743296));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test499");
        int i2 = ClassExampleWithNoFailure.foo(0, (-579585119));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test500");
        int i2 = ClassExampleWithNoFailure.foo((-1668284416), 1294738497);
        org.junit.Assert.assertTrue(i2 == 0);
    }
}

