import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class ClassExampleWithFailureRegressionTest3 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test001");
        int i2 = ClassExampleWithFailure.foo((-8960000), 36700160);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test002");
        int i1 = ClassExampleWithFailure.twice((-2048000000));
        org.junit.Assert.assertTrue(i1 == 198967296);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test003");
        int i2 = ClassExampleWithFailure.foo(5734400, 1979711488);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test004");
        int i2 = ClassExampleWithFailure.foo((-65536000), 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test005");
        int i1 = ClassExampleWithFailure.twice(5120000);
        org.junit.Assert.assertTrue(i1 == 10240000);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test006");
        int i2 = ClassExampleWithFailure.foo((-1744830464), 405061632);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test007");
        int i2 = ClassExampleWithFailure.foo(767557632, 4587520);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test008");
        int i2 = ClassExampleWithFailure.foo(2030043136, 1104674816);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test009");
        int i2 = ClassExampleWithFailure.foo(32000, (-1021018112));
        org.junit.Assert.assertTrue(i2 == (-1526726656));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test010");
        int i2 = ClassExampleWithFailure.foo(0, (-40));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test011");
        int i2 = ClassExampleWithFailure.foo(1210056704, 854196224);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test012");
        int i2 = ClassExampleWithFailure.foo(143360000, (-1577058304));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test013");
        int i2 = ClassExampleWithFailure.foo((-16000), (-398458880));
        org.junit.Assert.assertTrue(i2 == (-1073741824));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test014");
        int i2 = ClassExampleWithFailure.foo(1541406720, 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test015");
        int i2 = ClassExampleWithFailure.foo(2662400, 629145600);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test016");
        int i2 = ClassExampleWithFailure.foo(19269632, 150994944);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test017");
        int i2 = ClassExampleWithFailure.foo(1929379840, (-280887296));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test018");
        int i2 = ClassExampleWithFailure.foo(1369440256, (-570425344));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test019");
        int i2 = ClassExampleWithFailure.foo((-830472192), 1104674816);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test020");
        int i2 = ClassExampleWithFailure.foo(587202560, (-795869184));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test021");
        int i2 = ClassExampleWithFailure.foo((-1451098112), (-6400));
        org.junit.Assert.assertTrue(i2 == (-1677721600));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test022");
        int i2 = ClassExampleWithFailure.foo((-1732247552), (-2127560704));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test023");
        int i2 = ClassExampleWithFailure.foo(685768704, (-1146880000));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test024");
        int i2 = ClassExampleWithFailure.foo((-1170210816), 10);
        org.junit.Assert.assertTrue(i2 == (-1929379840));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test025");
        int i1 = ClassExampleWithFailure.twice((-754974720));
        org.junit.Assert.assertTrue(i1 == (-1509949440));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test026");
        int i2 = ClassExampleWithFailure.foo((-12800000), 469762048);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test027");
        int i2 = ClassExampleWithFailure.foo((-1280), (-248320000));
        org.junit.Assert.assertTrue(i2 == 44040192);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test028");
        int i2 = ClassExampleWithFailure.foo((int) (short) 10, (-5242880));
        org.junit.Assert.assertTrue(i2 == (-104857600));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test029");
        int i2 = ClassExampleWithFailure.foo((-401408000), 1535115264);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test030");
        int i2 = ClassExampleWithFailure.foo(1476395008, 805306368);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test031");
        int i2 = ClassExampleWithFailure.foo(2080374784, (-512));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test032");
        int i2 = ClassExampleWithFailure.foo((-4480000), 128000);
        org.junit.Assert.assertTrue(i2 == (-123731968));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test033");
        int i2 = ClassExampleWithFailure.foo(73400320, 1178599424);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test034");
        int i2 = ClassExampleWithFailure.foo(1196425216, 981467136);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test035");
        int i1 = ClassExampleWithFailure.twice(286720000);
        org.junit.Assert.assertTrue(i1 == 573440000);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test036");
        int i2 = ClassExampleWithFailure.foo((-2048000000), 388);
        org.junit.Assert.assertTrue(i2 == (-110100480));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test037");
        int i1 = ClassExampleWithFailure.twice(1023410176);
        org.junit.Assert.assertTrue(i1 == 2046820352);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test038");
        int i2 = ClassExampleWithFailure.foo((int) '4', 102400000);
        org.junit.Assert.assertTrue(i2 == 2059665408);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test039");
        int i2 = ClassExampleWithFailure.foo((-42598400), 24832);
        org.junit.Assert.assertTrue(i2 == 1811939328);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test040");
        int i2 = ClassExampleWithFailure.foo(800, 248320);
        org.junit.Assert.assertTrue(i2 == 397312000);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test041");
        int i2 = ClassExampleWithFailure.foo(2240000, (-1811939328));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test042");
        int i2 = ClassExampleWithFailure.foo((-1986560000), 16000);
        org.junit.Assert.assertTrue(i2 == (-109051904));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test043");
        int i2 = ClassExampleWithFailure.foo((-880803840), (-1551892480));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test044");
        int i2 = ClassExampleWithFailure.foo((-1006632960), (-1756364800));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test045");
        int i2 = ClassExampleWithFailure.foo(1578106880, (-1024000));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test046");
        int i2 = ClassExampleWithFailure.foo((int) '4', 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test047");
        int i2 = ClassExampleWithFailure.foo(16, 8);
        org.junit.Assert.assertTrue(i2 == 256);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test048");
        int i2 = ClassExampleWithFailure.foo((-2007040000), 4480000);
        org.junit.Assert.assertTrue(i2 == 1207959552);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test049");
        int i2 = ClassExampleWithFailure.foo(224000, 1509425152);
        org.junit.Assert.assertTrue(i2 == 1342177280);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test050");
        int i1 = ClassExampleWithFailure.twice(281018368);
        org.junit.Assert.assertTrue(i1 == 562036736);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test051");
        int i1 = ClassExampleWithFailure.twice((-790626304));
        org.junit.Assert.assertTrue(i1 == (-1581252608));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test052");
        int i2 = ClassExampleWithFailure.foo((-35840), 248320000);
        org.junit.Assert.assertTrue(i2 == (-1233125376));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test053");
        int i2 = ClassExampleWithFailure.foo((-128), 1577058304);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test054");
        int i1 = ClassExampleWithFailure.twice(1600000);
        org.junit.Assert.assertTrue(i1 == 3200000);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test055");
        int i2 = ClassExampleWithFailure.foo((-1280), (-2621440));
        org.junit.Assert.assertTrue(i2 == (-1879048192));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test056");
        int i2 = ClassExampleWithFailure.foo(1120, 260046848);
        org.junit.Assert.assertTrue(i2 == (-1610612736));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test057");
        int i2 = ClassExampleWithFailure.foo((-165281792), (-2048));
        org.junit.Assert.assertTrue(i2 == (-1610612736));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test058");
        int i2 = ClassExampleWithFailure.foo((-896000), 1605632000);
        org.junit.Assert.assertTrue(i2 == 536870912);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test059");
        int i2 = ClassExampleWithFailure.foo((-1159462912), 8000);
        org.junit.Assert.assertTrue(i2 == (-1442840576));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test060");
        int i2 = ClassExampleWithFailure.foo(771751936, (-1986560000));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test061");
        int i2 = ClassExampleWithFailure.foo((-1929379840), (-104857600));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test062");
        int i2 = ClassExampleWithFailure.foo(150994944, 99328);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test063");
        int i2 = ClassExampleWithFailure.foo((-1308622848), (-150994944));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test064");
        int i2 = ClassExampleWithFailure.foo(102400000, 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test065");
        int i2 = ClassExampleWithFailure.foo((-401408000), 4096000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test066");
        int i1 = ClassExampleWithFailure.twice(266240000);
        org.junit.Assert.assertTrue(i1 == 532480000);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test067");
        int i2 = ClassExampleWithFailure.foo((-599785472), (-2129920000));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test068");
        int i2 = ClassExampleWithFailure.foo(1552, 194);
        org.junit.Assert.assertTrue(i2 == 602176);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test069");
        int i2 = ClassExampleWithFailure.foo(1476395008, 1042808832);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test070");
        int i2 = ClassExampleWithFailure.foo((-2048000000), (-872415232));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test071");
        int i2 = ClassExampleWithFailure.foo((-599785472), 1369440256);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test072");
        int i2 = ClassExampleWithFailure.foo(8192000, (-32000));
        org.junit.Assert.assertTrue(i2 == (-301989888));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test073");
        int i2 = ClassExampleWithFailure.foo(905969664, (-1549271040));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test074");
        int i2 = ClassExampleWithFailure.foo(8192000, 1836056576);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test075");
        int i2 = ClassExampleWithFailure.foo((-3276800), (-204800000));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test076");
        int i2 = ClassExampleWithFailure.foo((-110100480), (-1174405120));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test077");
        int i2 = ClassExampleWithFailure.foo(587202560, (-256000000));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test078");
        int i2 = ClassExampleWithFailure.foo(1556086784, (-2048));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test079");
        int i1 = ClassExampleWithFailure.twice(612368384);
        org.junit.Assert.assertTrue(i1 == 1224736768);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test080");
        int i2 = ClassExampleWithFailure.foo(12544000, 1434443776);
        org.junit.Assert.assertTrue(i2 == 637534208);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test081");
        int i2 = ClassExampleWithFailure.foo(6272000, (-1107296256));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test082");
        int i1 = ClassExampleWithFailure.twice(320);
        org.junit.Assert.assertTrue(i1 == 640);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test083");
        int i2 = ClassExampleWithFailure.foo((-1541406720), 536870912);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test084");
        int i2 = ClassExampleWithFailure.foo(1740177408, 1178599424);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test085");
        int i1 = ClassExampleWithFailure.twice((-1509949440));
        org.junit.Assert.assertTrue(i1 == 1275068416);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test086");
        int i1 = ClassExampleWithFailure.twice(321847296);
        org.junit.Assert.assertTrue(i1 == 643694592);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test087");
        int i2 = ClassExampleWithFailure.foo(4480000, 2017460224);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test088");
        int i2 = ClassExampleWithFailure.foo(1308622848, 8);
        org.junit.Assert.assertTrue(i2 == (-536870912));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test089");
        int i1 = ClassExampleWithFailure.twice(198967296);
        org.junit.Assert.assertTrue(i1 == 397934592);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test090");
        int i2 = ClassExampleWithFailure.foo((-114688000), 248320);
        org.junit.Assert.assertTrue(i2 == 1207959552);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test091");
        int i2 = ClassExampleWithFailure.foo(1740177408, 89600);
        org.junit.Assert.assertTrue(i2 == (-603979776));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test092");
        int i2 = ClassExampleWithFailure.foo(10240, (-81920));
        org.junit.Assert.assertTrue(i2 == (-1677721600));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test093");
        int i2 = ClassExampleWithFailure.foo(1083703296, 1);
        org.junit.Assert.assertTrue(i2 == (-2127560704));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test094");
        int i1 = ClassExampleWithFailure.twice(77600);
        org.junit.Assert.assertTrue(i1 == 155200);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test095");
        int i2 = ClassExampleWithFailure.foo((-397934592), 469762048);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test096");
        int i1 = ClassExampleWithFailure.twice((-599785472));
        org.junit.Assert.assertTrue(i1 == (-1199570944));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test097");
        int i2 = ClassExampleWithFailure.foo((-62720000), (-1541406720));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test098");
        int i2 = ClassExampleWithFailure.foo(0, 1224736768);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test099");
        int i2 = ClassExampleWithFailure.foo(19600, (-1224736768));
        org.junit.Assert.assertTrue(i2 == (-536870912));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test100");
        int i2 = ClassExampleWithFailure.foo((-17920), (-624951296));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test101");
        int i2 = ClassExampleWithFailure.foo(1543503872, 1740177408);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test102");
        int i2 = ClassExampleWithFailure.foo((-2046820352), 44040192);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test103");
        int i2 = ClassExampleWithFailure.foo((-160), 1308622848);
        org.junit.Assert.assertTrue(i2 == (-2147483648));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test104");
        int i1 = ClassExampleWithFailure.twice(262144000);
        org.junit.Assert.assertTrue(i1 == 524288000);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test105");
        int i2 = ClassExampleWithFailure.foo(1409286144, 536870912);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test106");
        int i2 = ClassExampleWithFailure.foo((-1542455296), 1541406720);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test107");
        int i1 = ClassExampleWithFailure.twice((-2013265920));
        org.junit.Assert.assertTrue(i1 == 268435456);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test108");
        int i2 = ClassExampleWithFailure.foo(1610612736, (-256000));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test109");
        int i2 = ClassExampleWithFailure.foo(770703360, 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test110");
        int i1 = ClassExampleWithFailure.twice((-2047868928));
        org.junit.Assert.assertTrue(i1 == 199229440);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test111");
        int i2 = ClassExampleWithFailure.foo(0, 1212153856);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test112");
        int i1 = ClassExampleWithFailure.twice((-409600));
        org.junit.Assert.assertTrue(i1 == (-819200));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test113");
        int i2 = ClassExampleWithFailure.foo((-35840), (-204800000));
        org.junit.Assert.assertTrue(i2 == (-134217728));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test114");
        int i2 = ClassExampleWithFailure.foo((-1212153856), (-1551892480));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test115");
        int i2 = ClassExampleWithFailure.foo(1708392448, 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test116");
        int i2 = ClassExampleWithFailure.foo((-512), 3136000);
        org.junit.Assert.assertTrue(i2 == 1083703296);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test117");
        int i2 = ClassExampleWithFailure.foo((-2024538112), 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test118");
        int i1 = ClassExampleWithFailure.twice((-3328000));
        org.junit.Assert.assertTrue(i1 == (-6656000));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test119");
        int i2 = ClassExampleWithFailure.foo((-763363328), (-35840));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test120");
        int i2 = ClassExampleWithFailure.foo(1024, 1090519040);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test121");
        int i2 = ClassExampleWithFailure.foo(2048, 293601280);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test122");
        int i2 = ClassExampleWithFailure.foo(3880, (-385875968));
        org.junit.Assert.assertTrue(i2 == (-805306368));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test123");
        int i2 = ClassExampleWithFailure.foo(2000, 1249902592);
        org.junit.Assert.assertTrue(i2 == 268435456);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test124");
        int i2 = ClassExampleWithFailure.foo((-260046848), 1358954496);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test125");
        int i2 = ClassExampleWithFailure.foo(36700160, 40);
        org.junit.Assert.assertTrue(i2 == (-1358954496));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test126");
        int i2 = ClassExampleWithFailure.foo(2046820352, (-1986560000));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test127");
        int i2 = ClassExampleWithFailure.foo(2, 1210056704);
        org.junit.Assert.assertTrue(i2 == 545259520);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test128");
        int i2 = ClassExampleWithFailure.foo((-1174405120), 256000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test129");
        int i1 = ClassExampleWithFailure.twice((-512000000));
        org.junit.Assert.assertTrue(i1 == (-1024000000));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test130");
        int i2 = ClassExampleWithFailure.foo(1120, 285212672);
        org.junit.Assert.assertTrue(i2 == (-1073741824));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test131");
        int i1 = ClassExampleWithFailure.twice(247463936);
        org.junit.Assert.assertTrue(i1 == 494927872);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test132");
        int i2 = ClassExampleWithFailure.foo((-989855744), 69529600);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test133");
        int i2 = ClassExampleWithFailure.foo(2080374784, 260046848);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test134");
        int i1 = ClassExampleWithFailure.twice((-1728053248));
        org.junit.Assert.assertTrue(i1 == 838860800);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test135");
        int i2 = ClassExampleWithFailure.foo((-1146880000), (-754974720));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test136");
        int i2 = ClassExampleWithFailure.foo(301989888, 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test137");
        int i1 = ClassExampleWithFailure.twice(93184000);
        org.junit.Assert.assertTrue(i1 == 186368000);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test138");
        int i2 = ClassExampleWithFailure.foo((-1024), 204800000);
        org.junit.Assert.assertTrue(i2 == 1476395008);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test139");
        int i2 = ClassExampleWithFailure.foo((-654311424), (-71680));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test140");
        int i2 = ClassExampleWithFailure.foo(109051904, (-1146880000));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test141");
        int i2 = ClassExampleWithFailure.foo(0, (-805306368));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test142");
        int i2 = ClassExampleWithFailure.foo(1040187392, 33554432);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test143");
        int i1 = ClassExampleWithFailure.twice(1107296256);
        org.junit.Assert.assertTrue(i1 == (-2080374784));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test144");
        int i1 = ClassExampleWithFailure.twice(1486094336);
        org.junit.Assert.assertTrue(i1 == (-1322778624));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test145");
        int i2 = ClassExampleWithFailure.foo(1040187392, (int) '#');
        org.junit.Assert.assertTrue(i2 == (-201326592));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test146");
        int i1 = ClassExampleWithFailure.twice((-448000));
        org.junit.Assert.assertTrue(i1 == (-896000));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test147");
        int i2 = ClassExampleWithFailure.foo(2017460224, 1591738368);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test148");
        int i2 = ClassExampleWithFailure.foo((-327680), (-1811939328));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test149");
        int i2 = ClassExampleWithFailure.foo((-5242880), 1744830464);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test150");
        int i2 = ClassExampleWithFailure.foo(123731968, (int) (short) 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test151");
        int i2 = ClassExampleWithFailure.foo(1476395008, 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test152");
        int i1 = ClassExampleWithFailure.twice((-1918369792));
        org.junit.Assert.assertTrue(i1 == 458227712);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test153");
        int i2 = ClassExampleWithFailure.foo(448000, 520093696);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test154");
        int i2 = ClassExampleWithFailure.foo((int) (short) 10, (-2047868928));
        org.junit.Assert.assertTrue(i2 == 1992294400);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test155");
        int i2 = ClassExampleWithFailure.foo(12544000, 671088640);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test156");
        int i2 = ClassExampleWithFailure.foo(229376000, (-2113929216));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test157");
        int i2 = ClassExampleWithFailure.foo((-163840), 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test158");
        int i2 = ClassExampleWithFailure.foo(80, 327680);
        org.junit.Assert.assertTrue(i2 == 52428800);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test159");
        int i2 = ClassExampleWithFailure.foo(222298112, 251658240);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test160");
        int i2 = ClassExampleWithFailure.foo((-1245708288), (-40));
        org.junit.Assert.assertTrue(i2 == 872415232);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test161");
        int i2 = ClassExampleWithFailure.foo(210894848, (-301989888));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test162");
        int i2 = ClassExampleWithFailure.foo((-1476395008), (-770703360));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test163");
        int i2 = ClassExampleWithFailure.foo(1509949440, 602176);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test164");
        int i2 = ClassExampleWithFailure.foo(1, (-199229440));
        org.junit.Assert.assertTrue(i2 == (-398458880));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test165");
        int i2 = ClassExampleWithFailure.foo(143360000, (-1174405120));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test166");
        int i2 = ClassExampleWithFailure.foo((-10649600), (-512000000));
        org.junit.Assert.assertTrue(i2 == (-2147483648));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test167");
        int i2 = ClassExampleWithFailure.foo(294912000, 40);
        org.junit.Assert.assertTrue(i2 == 2118123520);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test168");
        int i2 = ClassExampleWithFailure.foo(665600, 17920000);
        org.junit.Assert.assertTrue(i2 == 855638016);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test169");
        int i2 = ClassExampleWithFailure.foo((-512000000), (-1342177280));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test170");
        int i1 = ClassExampleWithFailure.twice((-71680000));
        org.junit.Assert.assertTrue(i1 == (-143360000));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test171");
        int i2 = ClassExampleWithFailure.foo((-1778384896), 9175040);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test172");
        int i1 = ClassExampleWithFailure.twice((-809500672));
        org.junit.Assert.assertTrue(i1 == (-1619001344));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test173");
        int i2 = ClassExampleWithFailure.foo((-956301312), 124160);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test174");
        int i2 = ClassExampleWithFailure.foo((-1591738368), (-1610612736));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test175");
        int i2 = ClassExampleWithFailure.foo((-1245708288), 608384000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test176");
        int i2 = ClassExampleWithFailure.foo(855638016, 80);
        org.junit.Assert.assertTrue(i2 == (-536870912));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test177");
        int i2 = ClassExampleWithFailure.foo((-585105408), (-1912602624));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test178");
        int i1 = ClassExampleWithFailure.twice(843579392);
        org.junit.Assert.assertTrue(i1 == 1687158784);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test179");
        int i2 = ClassExampleWithFailure.foo((-110100480), 140);
        org.junit.Assert.assertTrue(i2 == (-763363328));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test180");
        int i2 = ClassExampleWithFailure.foo(201326592, 256000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test181");
        int i2 = ClassExampleWithFailure.foo((-2), 1310720000);
        org.junit.Assert.assertTrue(i2 == (-947912704));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test182");
        int i2 = ClassExampleWithFailure.foo((-1451098112), (-192937984));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test183");
        int i2 = ClassExampleWithFailure.foo(0, 503316480);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test184");
        int i2 = ClassExampleWithFailure.foo(3200, 573440000);
        org.junit.Assert.assertTrue(i2 == 2113929216);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test185");
        int i1 = ClassExampleWithFailure.twice(859832320);
        org.junit.Assert.assertTrue(i1 == 1719664640);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test186");
        int i2 = ClassExampleWithFailure.foo(1024, 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test187");
        int i2 = ClassExampleWithFailure.foo((-2113929216), 81920);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test188");
        int i2 = ClassExampleWithFailure.foo(186368000, 192696320);
        org.junit.Assert.assertTrue(i2 == 1476395008);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test189");
        int i2 = ClassExampleWithFailure.foo((-8960), 256000);
        org.junit.Assert.assertTrue(i2 == (-292552704));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test190");
        int i2 = ClassExampleWithFailure.foo((-256), 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test191");
        int i2 = ClassExampleWithFailure.foo(1, 4480);
        org.junit.Assert.assertTrue(i2 == 8960);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test192");
        int i2 = ClassExampleWithFailure.foo(981467136, 8960);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test193");
        int i2 = ClassExampleWithFailure.foo((-143360000), 905969664);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test194");
        int i1 = ClassExampleWithFailure.twice(874053632);
        org.junit.Assert.assertTrue(i1 == 1748107264);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test195");
        int i2 = ClassExampleWithFailure.foo((-819200000), 256000);
        org.junit.Assert.assertTrue(i2 == (-1073741824));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test196");
        int i2 = ClassExampleWithFailure.foo(25600000, 3584000);
        org.junit.Assert.assertTrue(i2 == (-1677721600));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test197");
        int i2 = ClassExampleWithFailure.foo((-69529600), 830472192);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test198");
        int i2 = ClassExampleWithFailure.foo((-1073741824), 155200);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test199");
        int i2 = ClassExampleWithFailure.foo((-25600000), (-795869184));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test200");
        int i2 = ClassExampleWithFailure.foo(1748107264, 608384000);
        org.junit.Assert.assertTrue(i2 == 1342177280);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test201");
        int i2 = ClassExampleWithFailure.foo((-100663296), (-2046820352));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test202");
        int i2 = ClassExampleWithFailure.foo(1409286144, 4);
        org.junit.Assert.assertTrue(i2 == (-1610612736));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test203");
        int i1 = ClassExampleWithFailure.twice(8192000);
        org.junit.Assert.assertTrue(i1 == 16384000);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test204");
        int i2 = ClassExampleWithFailure.foo((-2047868928), 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test205");
        int i1 = ClassExampleWithFailure.twice(16384000);
        org.junit.Assert.assertTrue(i1 == 32768000);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test206");
        int i2 = ClassExampleWithFailure.foo(3136000, (-947912704));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test207");
        int i2 = ClassExampleWithFailure.foo(16777216, (-1638400000));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test208");
        int i1 = ClassExampleWithFailure.twice(52428800);
        org.junit.Assert.assertTrue(i1 == 104857600);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test209");
        int i2 = ClassExampleWithFailure.foo((-1073741824), (-1638400));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test210");
        int i1 = ClassExampleWithFailure.twice(1979711488);
        org.junit.Assert.assertTrue(i1 == (-335544320));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test211");
        int i2 = ClassExampleWithFailure.foo((-2080374784), (-102400000));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test212");
        int i2 = ClassExampleWithFailure.foo((-2036334592), 9800);
        org.junit.Assert.assertTrue(i2 == 973078528);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test213");
        int i2 = ClassExampleWithFailure.foo(810123264, (-1605632000));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test214");
        int i2 = ClassExampleWithFailure.foo(1649410048, 73400320);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test215");
        int i2 = ClassExampleWithFailure.foo((-1140850688), (-520093696));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test216");
        int i2 = ClassExampleWithFailure.foo((-1541406720), (-1392771072));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test217");
        int i1 = ClassExampleWithFailure.twice(524288000);
        org.junit.Assert.assertTrue(i1 == 1048576000);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test218");
        int i2 = ClassExampleWithFailure.foo(1543503872, 4096000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test219");
        int i2 = ClassExampleWithFailure.foo(8192000, (-866123776));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test220");
        int i1 = ClassExampleWithFailure.twice(2113929216);
        org.junit.Assert.assertTrue(i1 == (-67108864));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test221");
        int i1 = ClassExampleWithFailure.twice((-42598400));
        org.junit.Assert.assertTrue(i1 == (-85196800));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test222");
        int i2 = ClassExampleWithFailure.foo(17920000, (-1677721600));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test223");
        int i2 = ClassExampleWithFailure.foo(51200000, 293601280);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test224");
        int i2 = ClassExampleWithFailure.foo(1135214592, (-1174405120));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test225");
        int i2 = ClassExampleWithFailure.foo(641728512, 73400320);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test226");
        int i2 = ClassExampleWithFailure.foo((-802816000), 1342177280);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test227");
        int i2 = ClassExampleWithFailure.foo(5120, (-69529600));
        org.junit.Assert.assertTrue(i2 == 981467136);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test228");
        int i2 = ClassExampleWithFailure.foo(64000, (-496640000));
        org.junit.Assert.assertTrue(i2 == (-109051904));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test229");
        int i1 = ClassExampleWithFailure.twice(16252928);
        org.junit.Assert.assertTrue(i1 == 32505856);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test230");
        int i1 = ClassExampleWithFailure.twice(32505856);
        org.junit.Assert.assertTrue(i1 == 65011712);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test231");
        int i2 = ClassExampleWithFailure.foo((-6400), (-2042036224));
        org.junit.Assert.assertTrue(i2 == (-1107296256));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test232");
        int i2 = ClassExampleWithFailure.foo((-956301312), (-1404436480));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test233");
        int i2 = ClassExampleWithFailure.foo(1740177408, (-2017460224));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test234");
        int i2 = ClassExampleWithFailure.foo(18350080, (-1549271040));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test235");
        int i2 = ClassExampleWithFailure.foo(1578106880, 8000);
        org.junit.Assert.assertTrue(i2 == (-402653184));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test236");
        int i1 = ClassExampleWithFailure.twice(1024000);
        org.junit.Assert.assertTrue(i1 == 2048000);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test237");
        int i2 = ClassExampleWithFailure.foo(247463936, (-409600000));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test238");
        int i2 = ClassExampleWithFailure.foo((-6656000), 332800);
        org.junit.Assert.assertTrue(i2 == (-2122317824));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test239");
        int i1 = ClassExampleWithFailure.twice((-1560281088));
        org.junit.Assert.assertTrue(i1 == 1174405120);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test240");
        int i2 = ClassExampleWithFailure.foo((-192937984), 10);
        org.junit.Assert.assertTrue(i2 == 436207616);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test241");
        int i2 = ClassExampleWithFailure.foo((-398458880), 4);
        org.junit.Assert.assertTrue(i2 == 1107296256);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test242");
        int i1 = ClassExampleWithFailure.twice((-989855744));
        org.junit.Assert.assertTrue(i1 == (-1979711488));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test243");
        int i2 = ClassExampleWithFailure.foo((-763363328), 1610612736);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test244");
        int i2 = ClassExampleWithFailure.foo(36700160, 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test245");
        int i2 = ClassExampleWithFailure.foo(204800000, 9175040);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test246");
        int i2 = ClassExampleWithFailure.foo(754974720, 1154416640);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test247");
        int i2 = ClassExampleWithFailure.foo((-1451098112), 1541406720);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test248");
        int i2 = ClassExampleWithFailure.foo((int) (short) 1, (-44800));
        org.junit.Assert.assertTrue(i2 == (-89600));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test249");
        int i2 = ClassExampleWithFailure.foo((-939524096), (-1560281088));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test250");
        int i1 = ClassExampleWithFailure.twice(20480000);
        org.junit.Assert.assertTrue(i1 == 40960000);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test251");
        int i1 = ClassExampleWithFailure.twice((-342884352));
        org.junit.Assert.assertTrue(i1 == (-685768704));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test252");
        int i1 = ClassExampleWithFailure.twice((-330563584));
        org.junit.Assert.assertTrue(i1 == (-661127168));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test253");
        int i1 = ClassExampleWithFailure.twice(553648128);
        org.junit.Assert.assertTrue(i1 == 1107296256);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test254");
        int i1 = ClassExampleWithFailure.twice((-444596224));
        org.junit.Assert.assertTrue(i1 == (-889192448));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test255");
        int i2 = ClassExampleWithFailure.foo(31040, 163840);
        org.junit.Assert.assertTrue(i2 == 1581252608);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test256");
        int i2 = ClassExampleWithFailure.foo(62080000, (-123731968));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test257");
        int i2 = ClassExampleWithFailure.foo(655360, 1744830464);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test258");
        int i2 = ClassExampleWithFailure.foo(0, 128);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test259");
        int i2 = ClassExampleWithFailure.foo(1, 573440000);
        org.junit.Assert.assertTrue(i2 == 1146880000);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test260");
        int i1 = ClassExampleWithFailure.twice((-1513783296));
        org.junit.Assert.assertTrue(i1 == 1267400704);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test261");
        int i1 = ClassExampleWithFailure.twice((-62720000));
        org.junit.Assert.assertTrue(i1 == (-125440000));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test262");
        int i2 = ClassExampleWithFailure.foo(1188298752, (-1207959552));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test263");
        int i1 = ClassExampleWithFailure.twice((-2));
        org.junit.Assert.assertTrue(i1 == (-4));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test264");
        int i2 = ClassExampleWithFailure.foo((-1513783296), (-1245708288));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test265");
        int i1 = ClassExampleWithFailure.twice((-104857600));
        org.junit.Assert.assertTrue(i1 == (-209715200));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test266");
        int i2 = ClassExampleWithFailure.foo(3104000, (-2046820352));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test267");
        int i1 = ClassExampleWithFailure.twice(32768000);
        org.junit.Assert.assertTrue(i1 == 65536000);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test268");
        int i2 = ClassExampleWithFailure.foo(1426063360, 10);
        org.junit.Assert.assertTrue(i2 == (-1543503872));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test269");
        int i2 = ClassExampleWithFailure.foo(1509949440, 916455424);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test270");
        int i2 = ClassExampleWithFailure.foo(32768000, (-201326592));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test271");
        int i1 = ClassExampleWithFailure.twice(1207959552);
        org.junit.Assert.assertTrue(i1 == (-1879048192));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test272");
        int i2 = ClassExampleWithFailure.foo(201326592, (-2122317824));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test273");
        int i1 = ClassExampleWithFailure.twice(545259520);
        org.junit.Assert.assertTrue(i1 == 1090519040);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test274");
        int i2 = ClassExampleWithFailure.foo(112000, (-448000));
        org.junit.Assert.assertTrue(i2 == (-1567752192));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test275");
        int i2 = ClassExampleWithFailure.foo((-2048), 2046820352);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test276");
        int i1 = ClassExampleWithFailure.twice((-234881024));
        org.junit.Assert.assertTrue(i1 == (-469762048));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test277");
        int i2 = ClassExampleWithFailure.foo(1107296256, (-1542455296));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test278");
        int i2 = ClassExampleWithFailure.foo(6400000, 767557632);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test279");
        int i2 = ClassExampleWithFailure.foo(10, (-1577058304));
        org.junit.Assert.assertTrue(i2 == (-1476395008));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test280");
        int i2 = ClassExampleWithFailure.foo(2048, (-1605632000));
        org.junit.Assert.assertTrue(i2 == (-1073741824));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test281");
        int i2 = ClassExampleWithFailure.foo(1486094336, 1879048192);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test282");
        int i2 = ClassExampleWithFailure.foo((-109051904), 2059665408);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test283");
        int i2 = ClassExampleWithFailure.foo(1979711488, (-17382400));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test284");
        int i1 = ClassExampleWithFailure.twice(1178599424);
        org.junit.Assert.assertTrue(i1 == (-1937768448));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test285");
        int i2 = ClassExampleWithFailure.foo(1552, (-1322778624));
        org.junit.Assert.assertTrue(i2 == 83886080);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test286");
        int i2 = ClassExampleWithFailure.foo(1462763520, 2560000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test287");
        int i1 = ClassExampleWithFailure.twice((-2122317824));
        org.junit.Assert.assertTrue(i1 == 50331648);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test288");
        int i2 = ClassExampleWithFailure.foo(65536000, (-1918369792));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test289");
        int i2 = ClassExampleWithFailure.foo((-738197504), 163840);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test290");
        int i2 = ClassExampleWithFailure.foo((-2047868928), (int) (short) 10);
        org.junit.Assert.assertTrue(i2 == 1992294400);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test291");
        int i1 = ClassExampleWithFailure.twice(104857600);
        org.junit.Assert.assertTrue(i1 == 209715200);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test292");
        int i2 = ClassExampleWithFailure.foo((-1342177280), 1317011456);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test293");
        int i2 = ClassExampleWithFailure.foo((-989855744), (-204800000));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test294");
        int i2 = ClassExampleWithFailure.foo((-2138570752), 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test295");
        int i2 = ClassExampleWithFailure.foo(5324800, 209715200);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test296");
        int i2 = ClassExampleWithFailure.foo((-640), 102400000);
        org.junit.Assert.assertTrue(i2 == 2071986176);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test297");
        int i2 = ClassExampleWithFailure.foo(198967296, (-754974720));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test298");
        int i2 = ClassExampleWithFailure.foo(1979711488, (-25600000));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test299");
        int i2 = ClassExampleWithFailure.foo((-85196800), (-2071986176));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test300");
        int i2 = ClassExampleWithFailure.foo(19269632, (-104857600));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test301");
        int i2 = ClassExampleWithFailure.foo(1, 560);
        org.junit.Assert.assertTrue(i2 == 1120);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test302");
        int i2 = ClassExampleWithFailure.foo(1748107264, (-2017460224));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test303");
        int i1 = ClassExampleWithFailure.twice(810123264);
        org.junit.Assert.assertTrue(i1 == 1620246528);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test304");
        int i1 = ClassExampleWithFailure.twice(209715200);
        org.junit.Assert.assertTrue(i1 == 419430400);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test305");
        int i2 = ClassExampleWithFailure.foo(161408, (-1979711488));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test306");
        int i2 = ClassExampleWithFailure.foo((-1509425152), 83886080);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test307");
        int i2 = ClassExampleWithFailure.foo(1120, (-280));
        org.junit.Assert.assertTrue(i2 == (-627200));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test308");
        int i2 = ClassExampleWithFailure.foo(1308622848, 1308622848);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test309");
        int i2 = ClassExampleWithFailure.foo(67108864, 50331648);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test310");
        int i2 = ClassExampleWithFailure.foo(2059665408, (-2048000000));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test311");
        int i1 = ClassExampleWithFailure.twice(1104674816);
        org.junit.Assert.assertTrue(i1 == (-2085617664));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test312");
        int i2 = ClassExampleWithFailure.foo((-2047868928), 33554432);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test313");
        int i1 = ClassExampleWithFailure.twice(1409286144);
        org.junit.Assert.assertTrue(i1 == (-1476395008));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test314");
        int i2 = ClassExampleWithFailure.foo((-640), 1556086784);
        org.junit.Assert.assertTrue(i2 == 1073741824);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test315");
        int i1 = ClassExampleWithFailure.twice(44040192);
        org.junit.Assert.assertTrue(i1 == 88080384);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test316");
        int i2 = ClassExampleWithFailure.foo(405061632, 124160000);
        org.junit.Assert.assertTrue(i2 == 201326592);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test317");
        int i2 = ClassExampleWithFailure.foo(1748107264, 49664);
        org.junit.Assert.assertTrue(i2 == (-939524096));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test318");
        int i2 = ClassExampleWithFailure.foo(419430400, 738197504);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test319");
        int i2 = ClassExampleWithFailure.foo((int) (short) 0, (-229376000));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test320");
        int i2 = ClassExampleWithFailure.foo((-1021018112), 553648128);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test321");
        int i2 = ClassExampleWithFailure.foo(2560000, 665600);
        org.junit.Assert.assertTrue(i2 == 1962934272);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test322");
        int i2 = ClassExampleWithFailure.foo(198967296, (-805306368));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test323");
        int i1 = ClassExampleWithFailure.twice(679215104);
        org.junit.Assert.assertTrue(i1 == 1358430208);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test324");
        int i2 = ClassExampleWithFailure.foo(0, 281018368);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test325");
        int i2 = ClassExampleWithFailure.foo(0, (-44800));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test326");
        int i1 = ClassExampleWithFailure.twice(397312000);
        org.junit.Assert.assertTrue(i1 == 794624000);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test327");
        int i2 = ClassExampleWithFailure.foo(1600, 5734400);
        org.junit.Assert.assertTrue(i2 == 1170210816);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test328");
        int i2 = ClassExampleWithFailure.foo(4480, 1811939328);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test329");
        int i2 = ClassExampleWithFailure.foo(1392771072, (int) (byte) 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test330");
        int i2 = ClassExampleWithFailure.foo((-496640000), 128000);
        org.junit.Assert.assertTrue(i2 == (-218103808));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test331");
        int i2 = ClassExampleWithFailure.foo((-520093696), (-2001207296));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test332");
        int i1 = ClassExampleWithFailure.twice((-2024538112));
        org.junit.Assert.assertTrue(i1 == 245891072);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test333");
        int i2 = ClassExampleWithFailure.foo(843055104, 490733568);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test334");
        int i2 = ClassExampleWithFailure.foo((-62720000), (-1610612736));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test335");
        int i2 = ClassExampleWithFailure.foo((-8960), 83886080);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test336");
        int i2 = ClassExampleWithFailure.foo((-4), (-51200000));
        org.junit.Assert.assertTrue(i2 == 409600000);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test337");
        int i2 = ClassExampleWithFailure.foo(20, (-1605632000));
        org.junit.Assert.assertTrue(i2 == 199229440);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test338");
        int i2 = ClassExampleWithFailure.foo(40960000, 1940);
        org.junit.Assert.assertTrue(i2 == 11010048);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test339");
        int i1 = ClassExampleWithFailure.twice(292552704);
        org.junit.Assert.assertTrue(i1 == 585105408);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test340");
        int i2 = ClassExampleWithFailure.foo(1581252608, (int) (byte) 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test341");
        int i2 = ClassExampleWithFailure.foo((-268435456), 1620246528);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test342");
        int i1 = ClassExampleWithFailure.twice(220200960);
        org.junit.Assert.assertTrue(i1 == 440401920);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test343");
        int i2 = ClassExampleWithFailure.foo(0, 102400000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test344");
        int i1 = ClassExampleWithFailure.twice(608384000);
        org.junit.Assert.assertTrue(i1 == 1216768000);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test345");
        int i2 = ClassExampleWithFailure.foo(262144000, 64);
        org.junit.Assert.assertTrue(i2 == (-805306368));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test346");
        int i2 = ClassExampleWithFailure.foo((-1199570944), 64000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test347");
        int i2 = ClassExampleWithFailure.foo(51200000, (-398458880));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test348");
        int i1 = ClassExampleWithFailure.twice(222298112);
        org.junit.Assert.assertTrue(i1 == 444596224);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test349");
        int i1 = ClassExampleWithFailure.twice((-2127560704));
        org.junit.Assert.assertTrue(i1 == 39845888);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test350");
        int i2 = ClassExampleWithFailure.foo(1811939328, (-280));
        org.junit.Assert.assertTrue(i2 == (-1073741824));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test351");
        int i2 = ClassExampleWithFailure.foo(88080384, 294912000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test352");
        int i2 = ClassExampleWithFailure.foo((-201326592), 1610612736);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test353");
        int i2 = ClassExampleWithFailure.foo((-1), 7760);
        org.junit.Assert.assertTrue(i2 == (-15520));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test354");
        int i1 = ClassExampleWithFailure.twice(1170210816);
        org.junit.Assert.assertTrue(i1 == (-1954545664));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test355");
        int i1 = ClassExampleWithFailure.twice((-624951296));
        org.junit.Assert.assertTrue(i1 == (-1249902592));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test356");
        int i2 = ClassExampleWithFailure.foo((-1024000000), (-1638400));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test357");
        int i2 = ClassExampleWithFailure.foo((-1107296256), (-1567752192));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test358");
        int i2 = ClassExampleWithFailure.foo((-409600000), (-198967296));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test359");
        int i1 = ClassExampleWithFailure.twice(268435456);
        org.junit.Assert.assertTrue(i1 == 536870912);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test360");
        int i1 = ClassExampleWithFailure.twice((-1212153856));
        org.junit.Assert.assertTrue(i1 == 1870659584);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test361");
        int i1 = ClassExampleWithFailure.twice(2046820352);
        org.junit.Assert.assertTrue(i1 == (-201326592));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test362");
        int i1 = ClassExampleWithFailure.twice((-1979711488));
        org.junit.Assert.assertTrue(i1 == 335544320);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test363");
        int i2 = ClassExampleWithFailure.foo(140, 532480000);
        org.junit.Assert.assertTrue(i2 == (-1229455360));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test364");
        int i1 = ClassExampleWithFailure.twice(838860800);
        org.junit.Assert.assertTrue(i1 == 1677721600);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test365");
        int i2 = ClassExampleWithFailure.foo(1188298752, (-1322778624));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test366");
        int i1 = ClassExampleWithFailure.twice((-1581252608));
        org.junit.Assert.assertTrue(i1 == 1132462080);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test367");
        int i2 = ClassExampleWithFailure.foo(612368384, 160);
        org.junit.Assert.assertTrue(i2 == (-1610612736));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test368");
        int i1 = ClassExampleWithFailure.twice((-402653184));
        org.junit.Assert.assertTrue(i1 == (-805306368));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test369");
        int i1 = ClassExampleWithFailure.twice(139059200);
        org.junit.Assert.assertTrue(i1 == 278118400);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test370");
        int i1 = ClassExampleWithFailure.twice((-1638400000));
        org.junit.Assert.assertTrue(i1 == 1018167296);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test371");
        int i2 = ClassExampleWithFailure.foo(186368000, 973078528);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test372");
        int i2 = ClassExampleWithFailure.foo(2013265920, (-2085617664));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test373");
        int i2 = ClassExampleWithFailure.foo(838860800, (-1451098112));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test374");
        int i1 = ClassExampleWithFailure.twice((-1245708288));
        org.junit.Assert.assertTrue(i1 == 1803550720);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test375");
        int i2 = ClassExampleWithFailure.foo((-17920), (-536870912));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test376");
        int i2 = ClassExampleWithFailure.foo(553648128, 1369440256);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test377");
        int i1 = ClassExampleWithFailure.twice(1660944384);
        org.junit.Assert.assertTrue(i1 == (-973078528));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test378");
        int i1 = ClassExampleWithFailure.twice(1620246528);
        org.junit.Assert.assertTrue(i1 == (-1054474240));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test379");
        int i2 = ClassExampleWithFailure.foo(70254592, 1954545664);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test380");
        int i2 = ClassExampleWithFailure.foo((-494927872), 1174405120);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test381");
        int i1 = ClassExampleWithFailure.twice(573440000);
        org.junit.Assert.assertTrue(i1 == 1146880000);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test382");
        int i2 = ClassExampleWithFailure.foo((-10649600), 2);
        org.junit.Assert.assertTrue(i2 == (-42598400));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test383");
        int i2 = ClassExampleWithFailure.foo(671088640, 99328);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test384");
        int i2 = ClassExampleWithFailure.foo((-1229455360), (-624951296));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test385");
        int i1 = ClassExampleWithFailure.twice(1434443776);
        org.junit.Assert.assertTrue(i1 == (-1426079744));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test386");
        int i2 = ClassExampleWithFailure.foo(655360, 160);
        org.junit.Assert.assertTrue(i2 == 209715200);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test387");
        int i2 = ClassExampleWithFailure.foo(854196224, (-1769996288));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test388");
        int i2 = ClassExampleWithFailure.foo(0, (-1778384896));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test389");
        int i2 = ClassExampleWithFailure.foo((-1591738368), 102400000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test390");
        int i2 = ClassExampleWithFailure.foo((-204800000), 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test391");
        int i2 = ClassExampleWithFailure.foo((-896000), 1610612736);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test392");
        int i2 = ClassExampleWithFailure.foo((-229376000), (-1600));
        org.junit.Assert.assertTrue(i2 == (-436207616));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test393");
        int i2 = ClassExampleWithFailure.foo((-754974720), (-1732247552));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test394");
        int i2 = ClassExampleWithFailure.foo((-819200000), (-400));
        org.junit.Assert.assertTrue(i2 == (-1769996288));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test395");
        int i2 = ClassExampleWithFailure.foo((-4480000), 1976041472);
        org.junit.Assert.assertTrue(i2 == 1073741824);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test396");
        int i2 = ClassExampleWithFailure.foo(1744830464, (-520093696));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test397");
        int i2 = ClassExampleWithFailure.foo(1331200, 1434443776);
        org.junit.Assert.assertTrue(i2 == (-335544320));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test398");
        int i2 = ClassExampleWithFailure.foo(1392771072, 1188298752);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test399");
        int i2 = ClassExampleWithFailure.foo(80704, 1992294400);
        org.junit.Assert.assertTrue(i2 == (-536870912));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test400");
        int i2 = ClassExampleWithFailure.foo((-536870912), (-1979711488));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test401");
        int i2 = ClassExampleWithFailure.foo(1434443776, (-3200));
        org.junit.Assert.assertTrue(i2 == (-2095054848));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test402");
        int i2 = ClassExampleWithFailure.foo(1835008000, 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test403");
        int i2 = ClassExampleWithFailure.foo(35840000, 1280000);
        org.junit.Assert.assertTrue(i2 == 1308622848);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test404");
        int i2 = ClassExampleWithFailure.foo(0, (-123731968));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test405");
        int i2 = ClassExampleWithFailure.foo((-1392771072), (-10485760));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test406");
        int i1 = ClassExampleWithFailure.twice(419430400);
        org.junit.Assert.assertTrue(i1 == 838860800);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test407");
        int i2 = ClassExampleWithFailure.foo(4096000, (-104857600));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test408");
        int i1 = ClassExampleWithFailure.twice(603979776);
        org.junit.Assert.assertTrue(i1 == 1207959552);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test409");
        int i2 = ClassExampleWithFailure.foo(624951296, (-1207959552));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test410");
        int i2 = ClassExampleWithFailure.foo((-64000), 2000);
        org.junit.Assert.assertTrue(i2 == (-256000000));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test411");
        int i1 = ClassExampleWithFailure.twice(278118400);
        org.junit.Assert.assertTrue(i1 == 556236800);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test412");
        int i2 = ClassExampleWithFailure.foo(916455424, 1207959552);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test413");
        int i2 = ClassExampleWithFailure.foo(96348160, 1577058304);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test414");
        int i1 = ClassExampleWithFailure.twice(532480000);
        org.junit.Assert.assertTrue(i1 == 1064960000);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test415");
        int i2 = ClassExampleWithFailure.foo(776, 1174405120);
        org.junit.Assert.assertTrue(i2 == 1610612736);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test416");
        int i1 = ClassExampleWithFailure.twice(155200);
        org.junit.Assert.assertTrue(i1 == 310400);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test417");
        int i2 = ClassExampleWithFailure.foo(1541406720, 896000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test418");
        int i1 = ClassExampleWithFailure.twice(2030043136);
        org.junit.Assert.assertTrue(i1 == (-234881024));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test419");
        int i2 = ClassExampleWithFailure.foo(15520, 641728512);
        org.junit.Assert.assertTrue(i2 == (-805306368));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test420");
        int i2 = ClassExampleWithFailure.foo((-401408000), 139059200);
        org.junit.Assert.assertTrue(i2 == 1073741824);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test421");
        int i2 = ClassExampleWithFailure.foo(855638016, 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test422");
        int i2 = ClassExampleWithFailure.foo((-2085617664), (-830472192));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test423");
        int i2 = ClassExampleWithFailure.foo(12416000, 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test424");
        int i2 = ClassExampleWithFailure.foo(1409286144, 1462763520);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test425");
        int i1 = ClassExampleWithFailure.twice((-496640000));
        org.junit.Assert.assertTrue(i1 == (-993280000));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test426");
        int i2 = ClassExampleWithFailure.foo((-62720000), (-866123776));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test427");
        int i2 = ClassExampleWithFailure.foo((-20), (-12800000));
        org.junit.Assert.assertTrue(i2 == 512000000);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test428");
        int i1 = ClassExampleWithFailure.twice(80704);
        org.junit.Assert.assertTrue(i1 == 161408);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test429");
        int i2 = ClassExampleWithFailure.foo((-17920), 0);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test430");
        int i2 = ClassExampleWithFailure.foo((-1509425152), (-1513783296));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test431");
        int i2 = ClassExampleWithFailure.foo(1962934272, 585105408);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test432");
        int i2 = ClassExampleWithFailure.foo(553648128, 1744830464);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test433");
        int i2 = ClassExampleWithFailure.foo((-512000000), 1262485504);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test434");
        int i2 = ClassExampleWithFailure.foo(1120, 1591738368);
        org.junit.Assert.assertTrue(i2 == 671088640);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test435");
        int i2 = ClassExampleWithFailure.foo((-1756364800), 2240);
        org.junit.Assert.assertTrue(i2 == (-134217728));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test436");
        int i2 = ClassExampleWithFailure.foo(110100480, 1946157056);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test437");
        int i2 = ClassExampleWithFailure.foo((-1526726656), (-4000));
        org.junit.Assert.assertTrue(i2 == (-1073741824));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test438");
        int i2 = ClassExampleWithFailure.foo(16000, 256000);
        org.junit.Assert.assertTrue(i2 == (-397934592));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test439");
        int i2 = ClassExampleWithFailure.foo((-1111490560), (-192937984));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test440");
        int i2 = ClassExampleWithFailure.foo(0, (-996147200));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test441");
        int i1 = ClassExampleWithFailure.twice(83886080);
        org.junit.Assert.assertTrue(i1 == 167772160);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test442");
        int i2 = ClassExampleWithFailure.foo((-771751936), (-1146880000));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test443");
        int i2 = ClassExampleWithFailure.foo((-2), 573440000);
        org.junit.Assert.assertTrue(i2 == 2001207296);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test444");
        int i2 = ClassExampleWithFailure.foo(838860800, 110100480);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test445");
        int i2 = ClassExampleWithFailure.foo(35840000, 1146880000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test446");
        int i2 = ClassExampleWithFailure.foo(192696320, (-866123776));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test447");
        int i2 = ClassExampleWithFailure.foo((-1369440256), (-819200));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test448");
        int i2 = ClassExampleWithFailure.foo(1778384896, 2113929216);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test449");
        int i2 = ClassExampleWithFailure.foo(12416000, 109051904);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test450");
        int i2 = ClassExampleWithFailure.foo(93184000, (-622854144));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test451");
        int i2 = ClassExampleWithFailure.foo((int) (short) 0, 1979711488);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test452");
        int i2 = ClassExampleWithFailure.foo(320, (-889192448));
        org.junit.Assert.assertTrue(i2 == (-2147483648));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test453");
        int i2 = ClassExampleWithFailure.foo((-402653184), 490733568);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test454");
        int i2 = ClassExampleWithFailure.foo(388, 133120000);
        org.junit.Assert.assertTrue(i2 == 221904896);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test455");
        int i2 = ClassExampleWithFailure.foo((-35840000), 1077936128);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test456");
        int i2 = ClassExampleWithFailure.foo(62080, 1820327936);
        org.junit.Assert.assertTrue(i2 == (-2147483648));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test457");
        int i2 = ClassExampleWithFailure.foo(247463936, 4096000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test458");
        int i2 = ClassExampleWithFailure.foo((-1233125376), 24832);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test459");
        int i2 = ClassExampleWithFailure.foo((-110100480), (-67108864));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test460");
        int i2 = ClassExampleWithFailure.foo((-8000), 1371537408);
        org.junit.Assert.assertTrue(i2 == (-1610612736));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test461");
        int i2 = ClassExampleWithFailure.foo(245891072, 8960);
        org.junit.Assert.assertTrue(i2 == (-268435456));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test462");
        int i2 = ClassExampleWithFailure.foo(3136000, 65011712);
        org.junit.Assert.assertTrue(i2 == (-2147483648));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test463");
        int i2 = ClassExampleWithFailure.foo(2113929216, (-199229440));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test464");
        int i1 = ClassExampleWithFailure.twice((-996147200));
        org.junit.Assert.assertTrue(i1 == (-1992294400));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test465");
        int i2 = ClassExampleWithFailure.foo(1567752192, (-1543503872));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test466");
        int i2 = ClassExampleWithFailure.foo(0, 603979776);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test467");
        int i2 = ClassExampleWithFailure.foo(0, (-535756800));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test468");
        int i1 = ClassExampleWithFailure.twice((-15520));
        org.junit.Assert.assertTrue(i1 == (-31040));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test469");
        int i2 = ClassExampleWithFailure.foo((-234881024), 285212672);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test470");
        int i1 = ClassExampleWithFailure.twice(1048576000);
        org.junit.Assert.assertTrue(i1 == 2097152000);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test471");
        int i2 = ClassExampleWithFailure.foo((-1578106880), 248320);
        org.junit.Assert.assertTrue(i2 == (-1073741824));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test472");
        int i2 = ClassExampleWithFailure.foo((-819200), (-400));
        org.junit.Assert.assertTrue(i2 == 655360000);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test473");
        int i1 = ClassExampleWithFailure.twice((-1577058304));
        org.junit.Assert.assertTrue(i1 == 1140850688);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test474");
        int i2 = ClassExampleWithFailure.foo(16384000, (-1276116992));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test475");
        int i2 = ClassExampleWithFailure.foo(1719664640, (-1054474240));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test476");
        int i2 = ClassExampleWithFailure.foo(31040, 520093696);
        org.junit.Assert.assertTrue(i2 == (-2147483648));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test477");
        int i2 = ClassExampleWithFailure.foo((-1416101888), (-1229455360));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test478");
        int i2 = ClassExampleWithFailure.foo(1138753536, 1077936128);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test479");
        int i2 = ClassExampleWithFailure.foo((-260046848), 1845493760);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test480");
        int i2 = ClassExampleWithFailure.foo((-6656000), 1308622848);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test481");
        int i2 = ClassExampleWithFailure.foo(1541406720, 160);
        org.junit.Assert.assertTrue(i2 == (-671088640));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test482");
        int i2 = ClassExampleWithFailure.foo(18350080, (-872415232));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test483");
        int i2 = ClassExampleWithFailure.foo(12416000, (-15520));
        org.junit.Assert.assertTrue(i2 == 1154416640);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test484");
        int i2 = ClassExampleWithFailure.foo(2013265920, (-22400));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test485");
        int i2 = ClassExampleWithFailure.foo(3200000, (-535756800));
        org.junit.Assert.assertTrue(i2 == 671088640);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test486");
        int i1 = ClassExampleWithFailure.twice((-109051904));
        org.junit.Assert.assertTrue(i1 == (-218103808));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test487");
        int i2 = ClassExampleWithFailure.foo((-402653184), 685768704);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test488");
        int i2 = ClassExampleWithFailure.foo((-262144000), 1064960000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test489");
        int i2 = ClassExampleWithFailure.foo(843579392, 458227712);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test490");
        int i2 = ClassExampleWithFailure.foo((-128000), (-2129920000));
        org.junit.Assert.assertTrue(i2 == 536870912);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test491");
        int i1 = ClassExampleWithFailure.twice(585105408);
        org.junit.Assert.assertTrue(i1 == 1170210816);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test492");
        int i2 = ClassExampleWithFailure.foo(838860800, 562036736);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test493");
        int i2 = ClassExampleWithFailure.foo((-1462763520), 2000);
        org.junit.Assert.assertTrue(i2 == (-1308622848));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test494");
        int i2 = ClassExampleWithFailure.foo(917504000, (-512));
        org.junit.Assert.assertTrue(i2 == 1073741824);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test495");
        int i2 = ClassExampleWithFailure.foo((-35840), 1111490560);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test496");
        int i2 = ClassExampleWithFailure.foo((-599785472), 608384000);
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test497");
        int i2 = ClassExampleWithFailure.foo(65536000, (-536870912));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test498");
        int i1 = ClassExampleWithFailure.twice((-1061158912));
        org.junit.Assert.assertTrue(i1 == (-2122317824));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test499");
        int i2 = ClassExampleWithFailure.foo((-1728053248), (-1509425152));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test500");
        int i1 = ClassExampleWithFailure.twice(221904896);
        org.junit.Assert.assertTrue(i1 == 443809792);
    }
}

