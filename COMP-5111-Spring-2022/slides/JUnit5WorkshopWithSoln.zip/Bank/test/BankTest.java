//import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class BankTest {

	@BeforeEach
	public void setUp() throws Exception {
		acc1 = new Account("TestAcc1", 10);
		acc2 = new SavingsAccount("TestAcc2", 100, new Interest(rate));
		bank = new Bank(interest);
		bank.createAccount(acc1);
		bank.createAccount(acc2);
	}

	@AfterEach
	public void tearDown() throws Exception {
	}

	@Test
	public void testOfferInterest() {
		double expectedBal1 = 10;
		double expectedBal2 = 100 * (1 + rate);
		bank.offerInterest();
		assertEquals(expectedBal1, acc1.getBalance(), tolerance, "offerInterest() fails");
		assertEquals(expectedBal2, acc2.getBalance(), tolerance, "offerInterest() fails");
	}

	double rate = 0.05;
	double tolerance = 0.000001;
	Bank bank;
	Interest interest = new Interest(rate);
	Account acc1;
	Account acc2;
}
