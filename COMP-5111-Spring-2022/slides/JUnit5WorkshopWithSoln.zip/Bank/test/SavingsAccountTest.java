//import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;


public class SavingsAccountTest {

	@BeforeEach
	public void setUp() throws Exception {
		acc = new SavingsAccount(owner, balance, interest);
	}

	@AfterEach
	public void tearDown() throws Exception {
	}

	@Test
	public void testCreditInterest() {
		acc.creditInterest();
		double expectedBalance = this.balance*(1 + rate);
		assertEquals(expectedBalance, acc.getBalance(), tolerance, "creditInterest() fails");
	}

	SavingsAccount acc;
	String owner = "tom";
	double balance = 100;
	double rate = 0.05;
	double tolerance = 0.000001;
	Interest interest = new Interest(rate);
}
