
class SavingsAccount extends Account implements InterestEarningEntity{
	private Interest interest;

	public SavingsAccount(String n, double bal, Interest i) {
		super(n, bal);
		interest = i;
		i.attach(this); // associate myself to the interest object i
	}

	public void creditInterest() {
		setBalance(getBalance() * ( 1 + interest.getInterestRate()));
	}

	public void print() {
		System.out.print("Savings ");
		super.print();
	}
}

interface InterestEarningEntity {
	public void creditInterest();
}
