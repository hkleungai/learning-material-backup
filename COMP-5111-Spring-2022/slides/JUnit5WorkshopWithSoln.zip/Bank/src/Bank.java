
import java.util.*;

public class Bank {
	// Assume that the bank could manage at most 100 accounts.
	private Account[] accounts = new Account[100];
	public int index = 0;
	private Interest interest;

	public Bank(Interest i) {
		interest = i;
	}

	// Create a new account.
	public void createAccount(Account a) {
		accounts[index++] = a;
		if (a instanceof SavingsAccount)
			this.interest.attach((SavingsAccount) a);
	}

	// Print the information of each account
	public void printAccounts() {
		for (int i=0; i<index; i++)
			accounts[i].print();
	}

	// Offer interest to each account
	public void offerInterest() {
		interest.offerInterest(); // delegate this offering to an Interest object
	}

	public static void main(String[] args) throws Exception
	{
		// Set up a bank
		Interest interest = new Interest(0.01);
		Bank bank = new Bank(interest);

		// Create 5 accounts
		bank.createAccount(new SavingsAccount("Alex", 100, interest));
		bank.createAccount(new Account("Bob", 200));
		bank.createAccount(new SavingsAccount("Carlo", 1000, interest));
		bank.createAccount(new Account("Dick", 2000));
		bank.createAccount(new SavingsAccount("Eddie", 10000, interest));

		// Get and process user inputs.
		Scanner in = new Scanner(System.in);
		while (true) {
			System.out.printf("\nThe current interest rate is %5.2f %s", (interest.getInterestRate() * 100.0), "%\n");

			System.out.println("Press 1 for new interest rate");
			System.out.println("Press 2 for offering interest to all accounts");
			System.out.println("Press 3 to quit the program");

			System.out.print("\nChoice: ");
			System.out.flush();

			int i = in.nextInt();
			switch(i) {
				case 1:
					System.out.print("Enter the new interest rate (e.g. enter 10 for 10%): ");
					System.out.flush();
					interest.setInterestRate(in.nextDouble() / 100);
					break;
				case 2:
					bank.offerInterest();
					bank.printAccounts();
					System.out.println();
					break;
				case 3:
					return;
				default: break;
			}
		}
	}
}