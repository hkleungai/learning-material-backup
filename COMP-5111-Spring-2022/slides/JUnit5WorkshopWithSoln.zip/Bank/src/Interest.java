
public class Interest {
	private SavingsAccount[] accounts = new SavingsAccount[100];
	private int index = 0;
	private double interestRate;

	public Interest(double rate) {
		interestRate = rate;
	}

	// Link savings accounts with this interest object.
	public void attach(SavingsAccount s) {
		accounts[index++] = s;
	}

	// Get and Set the interest rate
	public double getInterestRate() {
		return interestRate;
	}
	public void setInterestRate(double newRate) {
		interestRate = newRate;
	}

	// Offer interest to each account
	public void offerInterest() {
		for (int i=0; i<index; i++)
			accounts[i].creditInterest();
	}
}