package coverage;

import soot.*;
import soot.options.Options;
import java.util.Arrays;

public class MainDriver{

    public static void main(String[] args){
        
      /* check the arguments */
    if (args.length <= 1 || ( args[0].compareTo("0") != 0 && args[0].compareTo("1") !=0 && args[0].compareTo("2") !=0)) {
      System.err.println("Usage: java CoverageCalc [coverage level] [soot options] classname");
      System.err.println("Usage: [coverage level] = 0 for statement coverage");
      System.err.println("Usage: [coverage level] = 1 for branch coverage");
      System.err.println("Usage: [coverage level] = 2 for line coverage");
      System.exit(0);
    }
    
    /*Set the soot-classpath to include the helper class and class to analyze*/
    Options.v().set_soot_classpath(Scene.v().defaultClassPath()+":./bin/");

    // for debug only
    // System.out.println(Options.v().soot_classpath());
    
      
    /* add a phase to transformer pack by call Pack.add */
    Pack jtp = PackManager.v().getPack("jtp");
    

    if (args[0].compareTo("0") ==0) {
      // invoke your statement coverage instrument function
      jtp.add(new Transform("jtp.instrumenter", new coverage.StmtCvgInstrument()));
    }else if (args[0].compareTo("1") ==0) {
      // invoke your branch coverage instrument function
      jtp.add(new Transform("jtp.instrumenter", new coverage.BranchCvgInstrument()));
    }else if (args[0].compareTo("2") ==0) {
      // invoke your line coverage instrument function
      jtp.add(new Transform("jtp.instrumenter", new coverage.LineCvgInstrument()));
    }

    // these args will be passed into soot. 
    String[] sootArgs = Arrays.copyOfRange(args, 1, args.length);
    
    // for debug only
    // for(String arg:sootArgs){
    //   System.out.println(arg);
    // }
    
    soot.Main.main(sootArgs);
    }


}
