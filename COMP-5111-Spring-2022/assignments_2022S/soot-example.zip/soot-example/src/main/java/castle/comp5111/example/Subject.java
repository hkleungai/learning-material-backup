package castle.comp5111.example;

/**
 * This class is the subject in our tutorial of soot.
 * We first generate tests using randoop.
 * Then, we will use soot to instrument this class and count the total number of static/instance methods are executed
 * in tests.
 */
public class Subject {
    public static int staticMethod_Add(int x, int y) {
        return x + y;
    }

    public static double staticMethod_Add(double x, double y) {
        return x + y;
    }

    public static int staticMethod_Mul(int x, int y) {
        return x * y;
    }

    public static double staticMethod_Mul(double x, double y) {
        return x * y;
    }

    public int instanceMethod_Add(int x, int y) {
        return x + y;
    }

    public double instanceMethod_Add(double x, double y) {
        return x + y;
    }

    public int instanceMethod_Mul(int x, int y) {
        return x * y;
    }

    public double instanceMethod_Mul(double x, double y) {
        return x * y;
    }
}
