#include <stdio.h>


int main() {
    int arr[5];
    int i;
    for (i=0;i<5;i++)
        arr[i] = i;
    for (i=0;i<=5;i++)
        printf("%d\n", arr[i]);
    return 0;
}
