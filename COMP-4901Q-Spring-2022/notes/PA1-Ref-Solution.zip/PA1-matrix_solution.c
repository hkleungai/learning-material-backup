#include <omp.h>
#include <stdio.h>
#include <stdlib.h>
#define N 1000


void transpose(double *A, double *B, int n) {
    int i, j;
    for (i = 0; i < n; i++) {
        for (j = 0; j < n; j++) {
            B[j * n + i] = A[i * n + j];
        }
    }
}

int main(int argc, char *argv) {
    // omp_set_num_threads(8);//set number of threads here
    int i, j, k;
    double sum;
    double start, end;    
    double *A, *B, *C;
    A = (double *)malloc(sizeof(double) * N * N);
    B = (double *)malloc(sizeof(double) * N * N);
    C = (double *)malloc(sizeof(double) * N * N);
        	
    for (i = 0; i < N; i++) {
        for (j = 0; j < N; j++) {
            A[i * N + j] = j * 1;
            B[i * N + j] = i * j + 2;
            C[i * N + j] = j - i * 2;
        }
    }

    start = omp_get_wtime(); //start time measurement

    double *BT = (double *)malloc(sizeof(double) * N * N);

    transpose(B, BT, N);

    #pragma omp parallel for num_threads(4) schedule(dynamic) private(i,j,k,sum) shared(A,BT,C) 
    for (i = 0; i < N; i++) {
        for (j = 0; j < N; j++) {
            sum = 0;
            for (k = 0; k < N; k++) {
                sum += A[i * N + k] * BT[j * N + k];
            }
            C[i * N + j] = sum;
        }
    }

    free(BT);

    end = omp_get_wtime(); //end time measurement
    printf("Time of computation: %f seconds\n", end-start);
    return(0);
}