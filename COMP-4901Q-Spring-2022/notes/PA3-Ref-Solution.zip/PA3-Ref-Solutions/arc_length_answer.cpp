// *********************************************************************
//     NOTICE: Write your code only in the specified section.
// *********************************************************************
#include <assert.h>
#include <math.h>
#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#include <algorithm>
#include <fstream>
#include <iostream>
#include <vector>

struct InputData {
  InputData() {}
  InputData(const double &_a, const double &_b, const double &_c,
            const double &_d, const double &_l, const double &_r, const int &_n)
      : a(_a), b(_b), c(_c), d(_d), l(_l), r(_r), n(_n) {}

  double a, b, c, d, l, r;
  int n;
};

inline double CubicFunction(const double &a, const double &b, const double &c,
                            const double &d, const double &x) {
  return a * x * x * x + b * x * x + c * x + d;
}
inline double Distancce(const double &x_0, const double &y_0, const double &x_1,
                        const double &y_1) {
  return sqrt((x_0 - x_1) * (x_0 - x_1) + (y_0 - y_1) * (y_0 - y_1));
}

double CalculateArcLength(const InputData &data) {
  double ans = 0;
  double last_x = data.l;
  double last_y = CubicFunction(data.a, data.b, data.c, data.d, last_x);
  double now_x, now_y;
  double interval = (data.r - data.l) / (data.n - 1);
  for (int i = 1; i < data.n; i++) {
    now_x = last_x + interval;
    now_y = CubicFunction(data.a, data.b, data.c, data.d, now_x);
    ans += Distancce(last_x, last_y, now_x, now_y);
    last_x = now_x;
    last_y = now_y;
  }
  return ans;
}

double SequentialCalculation(const std::vector<InputData> &input_data,
                             std::vector<double> *sequential_answer) {
  sequential_answer->clear();
  for (auto &data : input_data) {
    sequential_answer->push_back(CalculateArcLength(data));
  }
}

bool LoadFile(const std::string &input_file_path,
              std::vector<InputData> *input_data) {
  std::ifstream fin(input_file_path.c_str());
  if (!fin.is_open()) {
    return false;
  }
  double a, b, c, d, l, r;
  int n;
  input_data->clear();
  while (fin >> a >> b >> c >> d >> l >> r >> n) {
    input_data->push_back(InputData(a, b, c, d, l, r, n));
  }
  fin.close();
  return true;
}

void TestAnswerCorrectness(const std::vector<double> &sequential_answer,
                           const std::vector<double> &parallel_answer) {
  if (sequential_answer.size() != parallel_answer.size()) {
    std::cout << "Error! The number of sequential_answer and parallel_answer "
                 "is not the same"
              << std::endl;
    return;
  }
  double sum_sequential_answer = 0;
  double sum_parallel_answer = 0;
  double max_error = 0;
  for (uint i = 0; i < sequential_answer.size(); i++) {
    max_error =
        std::max(max_error, fabs(sequential_answer[i] - parallel_answer[i]));
    sum_sequential_answer += sequential_answer[i];
    sum_parallel_answer += parallel_answer[i];
    // std::cout << i << " " << sequential_answer[i] << " " << parallel_answer[i]
    //           << std::endl;
  }
  std::cout << "sum_sequential_answer = " << sum_sequential_answer << std::endl;
  std::cout << "sum_parallel_answer = " << sum_parallel_answer << std::endl;
  std::cout << "max_error:" << max_error << std::endl;
  if (max_error > 1e-6) {
    std::cout << "The error is too large. Max_error = " << max_error
              << std::endl;
  } else {
    std::cout << "Correct!!!" << std::endl;
  }
}

int main(int argc, char **argv) {
  int number_of_processes, rank;
  MPI_Init(&argc, &argv);
  MPI_Comm_size(MPI_COMM_WORLD, &number_of_processes);
  MPI_Comm_rank(MPI_COMM_WORLD, &rank);
  double parallel_start_time;
  std::vector<InputData> input_data;
  std::vector<double> parallel_answer;

  if (rank == 0) {
    if (argc < 2) {
      std::cout << "Error! Please use \"mpiexec -n [process number] "
                   "[--hostfile hostfile] arc_length [data_file_name]\"\n";
      return 1;
    } else {
      std::string input_file_path = std::string(argv[1]);
      if (!LoadFile(input_file_path, &input_data)) {
        std::cout << "Error! Please check the path and the format of input file\n";
        return 1;
      }
    }
  }

  const std::vector<InputData> const_input_data(input_data);
  if (rank == 0) {
    parallel_start_time = MPI_Wtime();
  }

  // ==============================================================
  // ==============================================================
  // ====    Write your implementation only below this line    ====
  // ==============================================================
  {
    InputData example;
    int blocklen[] = {6, 1};
    MPI_Datatype type[] = {MPI_DOUBLE, MPI_INT};
    MPI_Aint disp[2];
    MPI_Aint d0, d1, d2;
    MPI_Get_address(&example, &d0);
    MPI_Get_address(&(example.a), &d1);
    MPI_Get_address(&(example.n), &d2);
    disp[0] = d1 - d0;
    disp[1] = d2 - d0;
    MPI_Datatype data_type;
    MPI_Type_create_struct(2, blocklen, disp, type, &data_type);
    MPI_Type_commit(&data_type);
    int root = 0;
    int number_of_data = 0;
    if (rank == root) number_of_data = input_data.size();
    MPI_Bcast(&number_of_data, 1, MPI_INT, root, MPI_COMM_WORLD);
    int data_num_each_process =
        ceil(1.0 * number_of_data / number_of_processes);
    int start_data_id = data_num_each_process * rank;
    int end_data_id =
        std::min(start_data_id + data_num_each_process, number_of_data);
    InputData *input_data_all;
    InputData *input_data_this_process;
    if (rank == root) {
      input_data_all =
          new InputData[data_num_each_process * number_of_processes];
      for (uint i = 0; i < input_data.size(); i++) {
        input_data_all[i] = input_data[i];
      }
    }
    input_data_this_process = new InputData[data_num_each_process];
    MPI_Scatter(input_data_all, data_num_each_process, data_type,
                input_data_this_process, data_num_each_process, data_type, root,
                MPI_COMM_WORLD);
    double *answer_this_process = new double[data_num_each_process];
    for (int i = 0; i < end_data_id - start_data_id; i++) {
      answer_this_process[i] = CalculateArcLength(input_data_this_process[i]);
    }
    double *answer_all_process;
    if (rank == 0) {
      answer_all_process =
          new double[data_num_each_process * number_of_processes];
    }
    MPI_Gather(answer_this_process, data_num_each_process, MPI_DOUBLE,
               answer_all_process, data_num_each_process, MPI_DOUBLE, root,
               MPI_COMM_WORLD);

    if (rank == 0) {
      parallel_answer.clear();
      for (int i = 0; i < number_of_data; i++) {
        parallel_answer.push_back(answer_all_process[i]);
      }
    }

    delete answer_this_process;
    delete input_data_this_process;
    if (rank == 0) {
      delete input_data_all;
      delete answer_all_process;
    }
  }
  // ==============================================================
  // ====    Write your implementation only above this line    ====
  // ==============================================================
  // ==============================================================
  MPI_Barrier(MPI_COMM_WORLD);
  if (rank == 0) {
    double parallel_end_time = MPI_Wtime();
    double parallel_running_time = parallel_end_time - parallel_start_time;
    std::cout << "parallel running time:" << parallel_running_time << std::endl;

    std::vector<double> sequential_answer;
    double sequential_start_time = MPI_Wtime();

    SequentialCalculation(const_input_data, &sequential_answer);

    double sequential_end_time = MPI_Wtime();
    double sequential_running_time =
        sequential_end_time - sequential_start_time;
    std::cout << "sequential running time:" << sequential_running_time
              << std::endl;
    std::cout << "speed up:" <<  sequential_running_time/parallel_running_time
              << std::endl;
    TestAnswerCorrectness(sequential_answer, parallel_answer);
  }
  MPI_Finalize();
  return 0;
}