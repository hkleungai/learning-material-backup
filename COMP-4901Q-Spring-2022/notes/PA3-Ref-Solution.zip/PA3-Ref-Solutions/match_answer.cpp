// *********************************************************************
//     NOTICE: Write your code only in the specified section.
// *********************************************************************
#include <assert.h>
#include <math.h>
#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#include <algorithm>
#include <cstring>
#include <fstream>
#include <iostream>
#include <vector>

inline int Match(const char *st1, const int &start_id, const char *st2,
                 const int &length) {
  int res = 0;
  for (int i = 0; i < length; i++) {
    if (st1[i + start_id] == st2[i]) res++;
  }
  return res;
}

double SequentialCalculation(const std::string &input_st1,
                             const std::string &input_st2,
                             std::vector<int> *sequential_answer) {
  char *st1, *st2;
  int st1_len, st2_len;

  st1_len = input_st1.size();
  st1 = new char[st1_len + 1];
  strcpy(st1, input_st1.c_str());

  st2_len = input_st2.size();
  st2 = new char[st2_len + 1];
  strcpy(st2, input_st2.c_str());

  sequential_answer->clear();
  for (int i = 0; i < st1_len - st2_len + 1; i++) {
    sequential_answer->push_back(Match(st1, i, st2, st2_len));
  }
  delete st1;
  delete st2;
}

bool LoadFile(const std::string &input_file_path, std::string *st1,
              std::string *st2) {
  std::ifstream fin(input_file_path.c_str());
  if (!fin.is_open()) {
    return false;
  }
  fin >> (*st1) >> (*st2);
  fin.close();
  if ((*st1) == "" || (*st2) == "") return false;
  return true;
}

void TestAnswerCorrectness(const std::vector<int> &sequential_answer,
                           const std::vector<int> &parallel_answer) {
  if (sequential_answer.size() != parallel_answer.size()) {
    std::cout << "Error! The number of sequential_answer and parallel_answer "
                 "is not the same"
              << std::endl;
    return ;
  }
  long long sum_sequential_answer = 0;
  long long sum_parallel_answer = 0;
  int max_error = 0;
  for (uint i = 0; i < sequential_answer.size(); i++) {
    max_error =
        std::max(max_error, abs(sequential_answer[i] - parallel_answer[i]));
    sum_sequential_answer += sequential_answer[i];
    sum_parallel_answer += parallel_answer[i];
    // std::cout << i << " " << sequential_answer[i] << " " <<
    // parallel_answer[i]
    //           << std::endl;
  }
  std::cout << "sum_sequential_answer = " << sum_sequential_answer << std::endl;
  std::cout << "sum_parallel_answer = " << sum_parallel_answer << std::endl;

  if (max_error > 0) {
    std::cout << "Wrong Answer" << std::endl;
  } else {
    std::cout << "Correct!!!" << std::endl;
  }
}

int main(int argc, char **argv) {
  int number_of_processes, rank;
  MPI_Init(&argc, &argv);
  MPI_Comm_size(MPI_COMM_WORLD, &number_of_processes);
  MPI_Comm_rank(MPI_COMM_WORLD, &rank);
  double parallel_start_time;
  std::vector<int> parallel_answer;

  std::string input_st1;
  std::string input_st2;

  if (rank == 0) {
    if (argc < 2) {
      std::cout << "Error! Please use \"mpiexec -n [process number] "
                   "[--hostfile hostfile] match [data_file_name]\"\n";
      return 1;
    } else {
      std::string input_file_path = std::string(argv[1]);
      if (!LoadFile(input_file_path, &input_st1, &input_st2)) {
        std::cout << "Error! Please check the format of input file\n";
        return 1;
      }
    }
  }

  const std::string const_input_st1 = input_st1;
  const std::string const_input_st2 = input_st2;
  if (rank == 0) {
    parallel_start_time = MPI_Wtime();
  }
  // ==============================================================
  // ==============================================================
  // ====    Write your implementation only below this line    ====
  // ==============================================================
  {
    int root = 0;
    char *st1, *st2;
    int st1_len, st2_len;
    if (rank == root) {
      st1_len = input_st1.size();
      st1 = new char[st1_len + 1];
      strcpy(st1, input_st1.c_str());

      st2_len = input_st2.size();
      st2 = new char[st2_len + 1];
      strcpy(st2, input_st2.c_str());
    }
    MPI_Bcast(&st1_len, 1, MPI_INT, root, MPI_COMM_WORLD);
    MPI_Bcast(&st2_len, 1, MPI_INT, root, MPI_COMM_WORLD);
    if (rank != root) {
      st2 = new char[st2_len + 1];
    }
    MPI_Bcast(st2, st2_len, MPI_CHAR, root, MPI_COMM_WORLD);
    st2[st2_len] = 0;
    int num_of_match = st1_len - st2_len + 1;
    int match_num_each_process = ceil(1.0 * num_of_match / number_of_processes);
    int start_data_id = match_num_each_process * rank;
    int end_data_id = std::min(
        (start_data_id + match_num_each_process - 1) + st2_len - 1, st1_len);
    int match_this_process =
        (end_data_id - st2_len + 1) - start_data_id + 1;
    int *displs;
    int *scounts;
    if (rank == root) {
      displs = new int[number_of_processes];
      scounts = new int[number_of_processes];
      for (int i = 0; i < number_of_processes; i++) {
        int now_start_data_id = match_num_each_process * i;
        int now_end_data_id = std::min(
            (now_start_data_id + match_num_each_process - 1) + st2_len - 1,
            st1_len);
        displs[i] = now_start_data_id;
        scounts[i] = now_end_data_id - now_start_data_id + 1;
      }
    }
    char *st1_this_process = new char[end_data_id - start_data_id + 2];
    MPI_Scatterv(st1, scounts, displs, MPI_CHAR, st1_this_process,
                 end_data_id - start_data_id + 1, MPI_INT, root,
                 MPI_COMM_WORLD);
    st1_this_process[end_data_id - start_data_id + 1] = 0;
    int *answer_this_process = new int[match_this_process];
    for (int i = 0; i < match_this_process; i++) {
      answer_this_process[i] = Match(st1_this_process, i, st2, st2_len);
    }
    int *answer_all_process;
    if (rank == root) {
      answer_all_process =
          new int[match_num_each_process * number_of_processes];
    }
    MPI_Gather(answer_this_process, match_num_each_process, MPI_INT,
               answer_all_process, match_num_each_process, MPI_INT, root,
               MPI_COMM_WORLD);

    if (rank == root) {
      parallel_answer.clear();
      for (int i = 0; i < st1_len - st2_len + 1; i++) {
        parallel_answer.push_back(answer_all_process[i]);
      }
    }

    delete st1_this_process;
    delete st2;
    if (rank == root) {
      delete st1;
    }
  }
  // ==============================================================
  // ====    Write your implementation only above this line    ====
  // ==============================================================
  // ==============================================================
  MPI_Barrier(MPI_COMM_WORLD);
  if (rank == 0) {
    double parallel_end_time = MPI_Wtime();
    double parallel_running_time = parallel_end_time - parallel_start_time;
    std::cout << "parallel running time:" << parallel_running_time << std::endl;

    std::vector<int> sequential_answer;
    double sequential_start_time = MPI_Wtime();

    SequentialCalculation(const_input_st1, const_input_st2, &sequential_answer);

    double sequential_end_time = MPI_Wtime();
    double sequential_running_time =
        sequential_end_time - sequential_start_time;
    std::cout << "sequential running time:" << sequential_running_time
              << std::endl;
    std::cout << "speed up:" <<  sequential_running_time/parallel_running_time
              << std::endl;
    TestAnswerCorrectness(sequential_answer, parallel_answer);
  }
  MPI_Finalize();
  return 0;
}