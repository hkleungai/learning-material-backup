#!/usr/local/bin/perl5 -w
my $string = "Hello world!";

print "Original string: $string\n";

print "Does the string contain \"World\"?\n";
if ($string =~ m/World/) {print "Yes\n";}
else {print "No\n";}

print "Doe the string contain \"World\", ignoring case?\n";
if ($string =~ m#World#i) {print "Yes\n";}
else {print "No\n";}

print "Change to \"Hello mom!\"\n";
$string =~ s/world/mom/;
print "Updated string: $string\n";

