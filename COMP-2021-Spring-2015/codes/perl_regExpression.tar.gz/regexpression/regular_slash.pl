#!/usr/local/bin/perl5 -w
print "Enter path:\n";
$searchpath = <STDIN>;
if ($searchpath =~ m#\/usr\/local\/bin#){
	print "Path is /usr/local/bin \n";
}
else{
	print "Path doesn't match.\n";
}

