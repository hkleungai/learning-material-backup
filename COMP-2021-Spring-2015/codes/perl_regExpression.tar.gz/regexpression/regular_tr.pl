#!/usr/local/bin/perl5 -w
my $string = "The cat sat on the mat";
$string =~ tr/a/o/;
print "$string\n";
