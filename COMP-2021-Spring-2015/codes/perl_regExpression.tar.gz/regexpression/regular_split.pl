#!/usr/local/bin/perl5 -w

print "split with white space\n";
my $string = "ab cd ef gh ij";
my @strings = split / /, $string;
foreach(@strings){
    print "$_\n";
}


print "split with multiple patterns:\n";
$string= "10:10:10, 12/1/2011";
@strings = split /[:,\s\/]+/, $string;
#split with :, or ,, or any types of space character \s, and forward 
#slashes \/
# + is needed to match on 1 or more of the character immediately 
#proceding it
print "$string\n";
print "After splitting:\n";
foreach(@strings) {
    print "$_\n";
}
