#!/usr/local/bin/perl5 -w
print 'Match pattern /Bill(.)Gates\1', "\n";
$_ = "Bill!Gates!";
print;
if (/Bill(.)Gates\1/) {print ": match\n";}
else {print ":does not match\n"; }

$_ = "Bill?Gates!";
print;
if (/Bill(.)Gates\1/) {print ": match\n";}
else {print ":does not match\n";}


$_ = "AAA BBB CCC";
print "String: AAA BBB CCC\n";

print 'Match with m/(\w+)', "\n";
m/(\w+)/;
print "$1\n";

print 'Match with m/(\w+)/g', "\n";
@matches = m/(\w+)/g;
print "@matches\n";
