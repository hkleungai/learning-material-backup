#!/usr/local/bin/perl5 -w
use strict;
# try to add 'use strict' to sub_max_v1.pl and see what's going to happen

sub max{
	my ($n1, $n2) = @_;
	if ($n1 > $n2) {return $n1;}
	else {return $n2;}
}

print "Enter 1st number:\n";
chomp(my $a = <STDIN>);
print "Enter 2nd number:\n";
chomp(my $b = <STDIN>);
my $max = max($a, $b);
print "max: $max\n";

