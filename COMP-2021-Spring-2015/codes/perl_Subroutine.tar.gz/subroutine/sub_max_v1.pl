#!/usr/local/bin/perl5 -w

print "Enter 1st number:\n";
chomp($a = <STDIN>);
print "Enter 2nd number:\n";
chomp($b = <STDIN>);
$max = max($a, $b);
print "max: $max\n";

sub max{
	if($_[0] > $_[1]){ return $_[0]; }
	else{ return $_[1]; }
}

