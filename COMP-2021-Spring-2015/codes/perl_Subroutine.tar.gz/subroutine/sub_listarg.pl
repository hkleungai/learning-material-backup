#!/usr/local/bin/perl5 -w 
use strict;

sub double{
	foreach my $i (@_){
		$i *= 2;
	}
}
my @arr = (1, 2, 3, 4, 5);
double(@arr);
foreach my $i (@arr){
	print "$i ";
}
print "\n";
