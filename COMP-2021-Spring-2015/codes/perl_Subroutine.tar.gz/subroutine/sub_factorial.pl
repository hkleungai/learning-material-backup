#!/usr/local/bin/perl5 -w

$value = $ARGV[0];
$fv = fact($value);
print "factorial $value is $fv\n";

sub fact {
     my $val = $_[0];
     if ($val > 1) {
        return $val * fact($val-1);
     } else {
        return 1;
     }
}
