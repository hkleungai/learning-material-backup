#!/usr/local/bin/perl5 -w
$comp = "difficult";
$comp2021 = "fun";

print "COMP subject is $comp?\n";
print "But COMP2021 is $comp2021!\n";
print "COMP subject is ${comp}2021\n";
print "COMP "."2021 ". "is "."$comp2021.\n";

