#!/usr/local/bin/perl5 -w 			
print "Enter name: ";
$name = <STDIN>;
chomp ($name);
print "How many girlfriends do you have? ";
$number = <STDIN>;
chomp($number);
print "$name has $number girlfriends!\n";

