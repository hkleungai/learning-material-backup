#!/usr/local/bin/perl5 -w
$n = 2;
$m = 3;
$result = $n ** $m;
print "$n raised to the $m power is $result\n";

