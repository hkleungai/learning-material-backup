#!/usr/local/bin/perl5 -w
print "Hello world\n";
