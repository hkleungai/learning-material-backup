#!/usr/local/bin/perl5 -w
while(1){
	print "Wakeup [yes/no]? ";
	chomp($resp = <STDIN>);
	if($resp eq "yes"){
		last;
	}
}

