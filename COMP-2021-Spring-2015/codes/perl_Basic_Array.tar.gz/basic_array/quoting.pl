#!/usr/local/bin/perl5 -w
$user = `whoami`;
chomp($user);
$num = `who | wc -l`;
chomp($num);
print "Hi $user! There are $num users logged on.\n";

print "I have \$5000.\n";
print "It\'s Perl Programming.\n";
print '<-$1500.**>; (update?) [y\n]';
#print "\n";
