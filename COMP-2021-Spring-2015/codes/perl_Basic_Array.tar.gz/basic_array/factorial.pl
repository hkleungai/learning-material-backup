#!/usr/local/bin/perl5 -w

$fv = fact ($ARGV[0]);
print "factorial $ARGV[0] is $fv\n";
sub fact {
     my $val = $_[0];
     if ($val > 1) {
        $fv = $val * fact($val-1);
     } else {
        $fv = 1;
     }
}

