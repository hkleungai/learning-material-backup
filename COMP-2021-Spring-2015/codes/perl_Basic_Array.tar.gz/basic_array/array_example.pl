#!/usr/local/bin/perl5 -w


#Array Creation
@days = qw/Mon Tue Wed Thu Fri Sat Sun/;
print "Days in a week: @days\n";
print "Today is $days[1]\n";
print "Tomorrow is $days[-5]\n";
#Array Size
print "There are ".  @days . " days in a week\n";
print "That is: @days\n\n";

#Sequential Number Array
@10 = (1 .. 10);
@abc = ('a' .. 'z');
print "@10\n";
print "@abc\n";
print join(", ", @abc). "\n";
print "Max index in abc is: " . $#abc . "\n\n";

#adding and removing elements in array
@coins = qw/Quarter  Dime  Nickel/;
#add one element to the end
push(@coins, "Penny");
#add one element to the begining
unshift(@coins, "Dollar");
print "full list: @coins\n";
#remove one element from last
pop(@coins);
#remove one lement from the begining
shift(@coins);
print "After removing 2 elements: @coins\n";

#array chomp
@lines = <stdin>;
chomp(@lines);
print "@lines\n";
#print "The first line is: $lines[0]\n";
