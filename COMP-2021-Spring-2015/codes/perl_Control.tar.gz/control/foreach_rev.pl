#!/usr/local/bin/perl5 -w
	@a = (1,2,3,4,5);
	foreach $i (reverse @a){
		print "$i  ";
}
print "\n";

