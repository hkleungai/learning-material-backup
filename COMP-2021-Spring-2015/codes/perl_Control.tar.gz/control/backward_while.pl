#!/usr/local/bin/perl5 -w
print "Enter numbers to sum (0 to quit): \n";
$sum = 0;
$n = 1;
$sum += $n = <STDIN> while($n != 0);
print "The sum is: $sum: \n";

