#!/usr/local/bin/perl5 -w
	@a = (21,32,3,44,75,16,19);
	$sum = 0;
	foreach $b (@a){
		$sum += $b;
}
print "The array sum is: $sum\n";

