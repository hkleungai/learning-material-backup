#!/usr/local/bin/perl5 -w

my $compnum = 1 + int(rand 100);
my $guess;
my $times = 0;
do{
 print "Gimme your guess 1-100:\n";
 $guess = <STDIN>;
 chop($guess);
 if ($guess > $compnum){print "too much\n"}
 if ($guess < $compnum){print "too few\n"}
 $times++;
}while ($guess != $compnum);

print "Bingo! It is $guess. You get it in $times trials.\n";
