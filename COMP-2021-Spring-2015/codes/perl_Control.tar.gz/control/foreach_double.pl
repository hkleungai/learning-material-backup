#!/usr/local/bin/perl5 -w
@a = (1,2,3,4);
foreach $b (@a){
	$b *= 2;
}
print "@a\n";

