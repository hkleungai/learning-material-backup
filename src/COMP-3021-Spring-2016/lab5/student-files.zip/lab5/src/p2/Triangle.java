package p2;

/**
 * Modify this file accordingly
 * @author
 *
 */
public class Triangle extends Shape {
	// Properties of the class... 
	public double base;
	public double height;

	// Constructor of the class...
	public Triangle(double aBase, double aHeight) {
		base = aBase;
		height = aHeight; }

	// Methods of the class... 
	public String getName() {
		/**
		 * place your code here
		 */
	}
	public double getArea() { 
		/**
		 * place your code here
		 */
	}
}
