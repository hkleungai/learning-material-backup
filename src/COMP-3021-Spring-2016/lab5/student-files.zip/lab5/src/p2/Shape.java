package p2;

/**
 * Modify this file accordingly.
 * @author
 *
 */
public class Shape {
	/**
	 * place your code here
	 */
	
}
