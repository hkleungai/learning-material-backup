package p2;

public class ShapeTest {
	public Shape[] myShapes; 

	public void printAreas() {
		for (int i=0; i<myShapes.length; i++) {
			System.out.print("Shape " + i + " has area: ");
			/**
			 * place your code here
			 */
		} 
	}


	public void printNames() {
		for (int i=0; i<myShapes.length; i++) {
			System.out.print("Shape " + i + " is a: ");
			/**
			 * place your code here
			 */
		}
	}

	public void doStuff() {
		// create an empty shapes array... 
		myShapes = new Shape[4];
		// fill in the values of the elements...
		myShapes[0] = new Circle(12.0);
		myShapes[1] = new Circle(6.3);
		myShapes[2] = new Triangle(3,8);
		myShapes[3] = new Rectangle(10,10);
		printNames();
		printAreas();
	}


	// The main method is the point of entry into the program... 
	public static void main(String[] args) {
		ShapeTest me = new ShapeTest(); 
		me.doStuff();
	}
}
