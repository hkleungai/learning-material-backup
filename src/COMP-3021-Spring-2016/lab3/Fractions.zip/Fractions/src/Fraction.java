import java.util.StringTokenizer;

public class Fraction {
	private int numerator;
	private int denominator;
	
	/**
	 * Constructs a fraction with the specified numerator and denominator
	 * 
	 * @param numerator the numerator of the fraction
	 * @param denominator the denominator of the fraction
	 * */
	public Fraction(int numerator, int denominator){
		this.numerator = numerator;
		this.denominator = denominator;
	}
	
	/**
	 * Constructs a fraction with the specified numerator, 
	 * and denominator of 1
	 * 
	 * @param numerator the numerator of the fraction
	 * **/
	public Fraction(int numerator){
		this(numerator, 1);
	}
	
	/**
	 * Constructs a fraction with the String("1/5"), 
	 * 
	 * @param number the String form of the fraction
	 * **/
	public Fraction(String number){
		StringTokenizer tokenizer = new StringTokenizer(number, "/");
		this.numerator = Integer.parseInt(tokenizer.nextToken());
		this.denominator = Integer.parseInt(tokenizer.nextToken());
	}
	
	/**
	 * Adds this fraction to the specified fraction, simplifies the
	 * result, and returns it as a new fraction. Does not modify this
	 * fraction.
	 * 
	 * @param that The fraction to be added to this fraction
	 * @return a new fraction equivalent to this fraction plus the parameter
	 * **/
	public Fraction add(Fraction that){
		int num = (this.numerator * that.denominator)
				+ (this.denominator * that.numerator);
		int den = this.denominator * that.denominator;
		Fraction sum = new Fraction(num, den);
		sum.simplify();
		return sum;
	}

	public void simplify() {
		// TODO Auto-generated method stub
		int smaller = this.numerator<this.denominator?this.numerator:this.denominator;
		int maxCommonFactor = 1;
		for (int i = 1; i <= smaller; i++) {
			if(this.numerator%i==0 && this.denominator%i==0){
				maxCommonFactor = i;
			}
		}
		this.numerator = this.numerator/maxCommonFactor;
		this.denominator = this.denominator/maxCommonFactor;
	}

	
	public String toPrettyString() {
		// TODO Auto-generated method stub
		return this.numerator+"\n"+"---"+"\n"+this.denominator;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return this.numerator+"/"+this.denominator;
	}
	
	
	
}
