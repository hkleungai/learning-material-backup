
	public  class HelloWorld {
		 public static void main(String [] args) {
		 		System.out.println(args[1] + args[2]);
		 }
}