
public class Shape {
	protected String color;

	 public Shape(String color) {
	 	System.out.print(color);
		this.color = color;
	 }

 	public static void main(String [] args) {
 		new Rectangle();
 	}
 }

class Rectangle extends Shape {
	 public Rectangle() {
		 super("Red");
	 	System.out.print(color);
	 }
}