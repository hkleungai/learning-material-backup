
public class MyClass {
	long var;
	
	public MyClass()
	{
		this.var=0;
	}
	public MyClass(int var)
	{
		this.var=var;
	}
	public void MyClass(long param) { var = param; } 
	public static void main(String[] args) {
		MyClass a, b;
		a = new MyClass(); 
		b = new MyClass(5); 
	}
}