package p3;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class CalculatorFrame extends JFrame {
    
    private static class NumericPanel extends JPanel{
        public NumericPanel(ActionListener l) {
            GridBagLayout gridBag = new GridBagLayout();
            GridBagConstraints c = new GridBagConstraints();
            this.setLayout(gridBag);
            
            c.fill = GridBagConstraints.BOTH;
            c.weightx = c.weighty = 1.00;
            
            String[] buttons = new String[] {
                "7", "8", "9", "clear", "all clear",
                "4", "5", "6", "multiply", "divide",
                "1", "2", "3", "plus", "minus",
                "0", "."
            };
            
            /*
             * TO DO:
             * set gridx, gridy etc. 
             * add buttons
             */
 
        }
    }
    
    private static class ScientificPanel extends JPanel {
        public ScientificPanel() {
            this.setLayout(new GridLayout(1, 6));
            
            String[] buttons = new String[] {
                "sin", "cos", "tan", "1/x", "x!", "+/-"
            };
            
            /*
             * TO DO
             * add buttons here
             */
        }
    }
    
    private static class DisplayPanel extends JPanel implements ActionListener {
    	static JTextField display;
    	
    	public DisplayPanel() {
    		this.setLayout(new GridLayout(1, 1));
    		/*
    		 * TO DO
    		 * finish the constructor, add display to the panel
    		 */
        }
        
      //event handler
        public void actionPerformed(ActionEvent evt){
        	/*
        	 * TO DO
        	 * finish this method
        	 */
        }
    }
    
    @SuppressWarnings("deprecation")
	public static void main(String args[]) {
        CalculatorFrame frame = new CalculatorFrame();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.show();
    }
    
    public CalculatorFrame() {
        setSize(400, 300);
        setTitle("Calculator Frame");

        Container contentPane = getContentPane();
        
        Box box = Box.createVerticalBox();
        DisplayPanel dPanel = new DisplayPanel();
        contentPane.add(dPanel, BorderLayout.NORTH);
 
        box.add(Box.createVerticalStrut(10));
        box.add(new ScientificPanel());
        box.add(Box.createVerticalStrut(10));
        box.add(new NumericPanel(dPanel));
        
        contentPane.add(box, BorderLayout.CENTER);
    }
}
