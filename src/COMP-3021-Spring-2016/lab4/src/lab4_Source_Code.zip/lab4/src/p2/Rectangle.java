package p2;

public class Rectangle extends Shape {
	// Properties of the class... 
	public double width;
	public double length;

	// Constructor of the class...
	public Rectangle(double aWidth, double aLength) {
		width = aWidth;
		length = aLength; 
	}
}
