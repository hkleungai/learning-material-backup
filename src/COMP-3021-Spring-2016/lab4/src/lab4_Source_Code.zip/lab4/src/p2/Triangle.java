package p2;

public class Triangle extends Shape {
	// Properties of the class... 
	public double base;
	public double height;
	// Constructor of the class...
	public Triangle(double aBase, double aHeight) {
		base = aBase;
		height = aHeight; 
	}
}
