package p2;

public class Circle extends Shape {
	// Properties of the class... 
	public double radius;
	
	// Constructor of the class...
	public Circle(double aRadius) {
		radius = aRadius; 
	}
	
}
