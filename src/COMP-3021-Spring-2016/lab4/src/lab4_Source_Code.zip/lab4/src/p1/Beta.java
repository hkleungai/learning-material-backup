package p1;

public class Beta extends Alpha {
	protected int a = 0;
	public Beta(int x) {
		this.a = x;
	}
	public void beta() {
		a+=2;
		System.out.println(a);
	}
	public static void main (String [] args) {
		Alpha a = new Alpha();
		a.alpha();
		Beta b = new Beta(2);
		b.alpha();
		b.beta();
	}
}

//result is 1 1 4