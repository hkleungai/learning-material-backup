package p1;

public class Alpha {
	private int a = 0;
	public void alpha() {
		a++;
		System.out.println(a);
	}
	public static void main (String [] args) {
		Alpha a = new Alpha();
		a.alpha();
	}
}


//result is 1