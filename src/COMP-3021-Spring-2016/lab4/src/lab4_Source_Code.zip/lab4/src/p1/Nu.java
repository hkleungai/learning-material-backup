package p1;

public class Nu extends Beta {
	public Nu() {
		super(10);
	}
	public void nu() {
		a+=5;
		System.out.println(a);
	}
	public static void main (String [] args) {
		Nu n = new Nu();
		n.nu();
		n.beta();
		n.alpha();
		Beta b = new Beta(10);
		b.alpha();
		b.beta();
	}
}

//result is 15 17 1 1 12
