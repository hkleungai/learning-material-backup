import java.awt.Container;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;

class BouncerFrame extends JFrame{
	public static final int WIDTH = 300;
	public static final int HEIGHT = 384;
	GameEngine gameEngine;

	public BouncerFrame(){
		setSize(300, 384);
		setTitle("The Bouncer Game");

		Toolkit localToolkit = Toolkit.getDefaultToolkit();
		Dimension localDimension = localToolkit.getScreenSize();
		int i = localDimension.height;
		int j = localDimension.width;

		setResizable(false);
		setLocation(j / 4, i / 4);

		JMenuBar localJMenuBar = new JMenuBar();
		BouncerFrame.GameMenuListener localGameMenuListener = new BouncerFrame.GameMenuListener();

		JMenu localJMenu = new JMenu("Game");
		localJMenu.setMnemonic('G');
		localJMenu.add(localJMenu);

		JMenuItem localJMenuItem1 = new JMenuItem("Start");
		localJMenuItem1.setMnemonic('S');
		localJMenuItem1.addActionListener(localGameMenuListener);
		localJMenu.add(localJMenuItem1);

		JMenuItem localJMenuItem2 = new JMenuItem("Suspend/Resume");
		localJMenuItem2.setMnemonic('t');
		localJMenuItem2.addActionListener(localGameMenuListener);
		localJMenu.add(localJMenuItem2);

		localJMenu.addSeparator();

		JMenuItem localJMenuItem3 = new JMenuItem("Exit");
		localJMenuItem3.setMnemonic('x');
		localJMenuItem3.addActionListener(localGameMenuListener);
		localJMenu.add(localJMenuItem3);
		localJMenuBar.add(localJMenu);

		setJMenuBar(localJMenuBar);

		this.gameEngine = new GameEngine();

		Container localContainer = getContentPane();

		localContainer.add(this.gameEngine, "Center");
	}

	class GameMenuListener implements ActionListener{
		GameMenuListener() {}

		public void actionPerformed(ActionEvent paramActionEvent){
			String str = paramActionEvent.getActionCommand();
			if (str.equals("Start")){
				BouncerFrame.this.gameEngine.startGame();
			}
			else if (str.equals("Suspend/Resume")){
				BouncerFrame.this.gameEngine.suspendResumeGame();
			}
			else{
				BouncerFrame.this.gameEngine.stopGame();
				System.exit(0);
			}
		}
	}
}