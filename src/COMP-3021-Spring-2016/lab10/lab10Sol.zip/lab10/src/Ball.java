import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Ellipse2D.Double;

class Ball extends GameElement{
	private int prevXPos;
	private int prevYPos;
	private int xVel;
	private int yVel;
	public static final int RADIUS = 5;

	public Ball(int paramInt1, int paramInt2, Color paramColor, int paramInt3, int paramInt4){
		super(paramInt1, paramInt2, paramColor);
		this.xVel = paramInt3;
		this.yVel = paramInt4;
		this.color = paramColor;
	}

	public void move(int paramInt1, int paramInt2){
		this.prevXPos = this.xPos;
		this.prevYPos = this.yPos;

		this.xPos += this.xVel;
		this.yPos += this.yVel;
		if (this.xPos < 0){
			this.xPos = 0;
			this.xVel = (-this.xVel);
		}
		if (this.xPos + 10 >= paramInt1){
			this.xPos = (paramInt1 - 10);
			this.xVel = (-this.xVel);
		}
		if (this.yPos < 0){
			this.yPos = 0;
			this.yVel = (-this.yVel);
		}
		if (this.yPos + 10 >= paramInt2){
			this.yPos = (paramInt2 - 10);
			this.yVel = (-this.yVel);
			if (!GameEngine.isCheat) {
				GameEngine.isHitBottom = true;
			}
		}
	}

	public void draw(Graphics2D paramGraphics2D){
		paramGraphics2D.setColor(this.color);
		paramGraphics2D.fill(new Ellipse2D.Double(this.xPos, this.yPos, 10.0D, 10.0D));
	}

	public int getPrevXPos(){
		return this.prevXPos;
	}

	public int getPrevYPos(){
		return this.prevYPos;
	}

	public void setXVel(int paramInt){
		this.xVel = paramInt;
	}

	public int getXVel(){
		return this.xVel;
	}

	public void setYVel(int paramInt){
		this.yVel = paramInt;
	}

	public int getYVel(){
		return this.yVel;
	}
}
