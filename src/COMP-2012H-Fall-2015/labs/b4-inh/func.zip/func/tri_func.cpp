#include <cmath>
#include "tri_func.h"

#define ANGLE90  90.00 * M_PI / 180.00
using namespace std;

/////////
// sine
/////////

SinFunc::SinFunc(double _scale):
Func("sin", true), scale(_scale) { }

double SinFunc::EvaluateAt(double d) {
	return scale * sin(d);
}

double SinFunc::DerivativeAt(double d) {
	return scale * cos(d);
}

///////////
// cosine
///////////

// ToDo: class CosFunc implementation
