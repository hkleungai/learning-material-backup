#include "func.h"

#ifndef _POLY_FUNC_H
#define _POLY_FUNC_H

class PolyFunc: public Func {
public:
	// create a polynomial from an integer array a, with size s
	// P(x) = a[0] x^(s-1) + a[1] x^(s-2) + ... + a[s-2] x + a[s-1]
	PolyFunc(const int* array, int size);

	// it should release all memory used by this object
	~PolyFunc();

	double EvaluateAt(double d);
	double DerivativeAt(double d); 

private:
	int* terms; // an array of integer terms
	int num_of_terms;
};

#endif
