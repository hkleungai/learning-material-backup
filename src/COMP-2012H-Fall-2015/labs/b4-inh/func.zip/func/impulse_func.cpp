#include <cfloat>
#include "impulse_func.h"

#define EQUALITY_LIMIT 0.001

ImpulseFunc::ImpulseFunc(double _impulseAt, double _magnitude)
: Func("impulse", false), impulseAt(_impulseAt), magnitude(_magnitude)
{
};

// ToDo: override ImpulseFunc::IsDifferentiable(double)
// ...

double ImpulseFunc::EvaluateAt(double d) {
	// ToDo: implement this function
};

double ImpulseFunc::DerivativeAt(double d) {
	return IsDifferentiable(d)? 0.00: DBL_MAX;
};

double ImpulseFunc::DiffToImpulse(double d) const {
	double diff = d - impulseAt;
	if (diff < 0.00) { diff *= -1.00; }
	return diff;
};
