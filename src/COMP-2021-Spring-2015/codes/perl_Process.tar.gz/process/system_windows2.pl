use strict;
use Win32;

my ($days, $hours, $mins, $secs) = (
         int(((((Win32::GetTickCount()/1000)/60)/60)/24)),
		 int((((Win32::GetTickCount()/1000)/60)/60)),
		 int(((Win32::GetTickCount()/1000)/60)),
		 int((Win32::GetTickCount()/1000))
);
my $h  = ($hours - ($days*24));
my $m  = ($mins - ($hours*60));
my $s  = ($secs - ($mins*60));

print "=" x 30, "\n";
print Win32::GetCwd()."\n";
print "=" x 30, "\n";
print " Architecture : ".Win32::GetArchName()."\n";
print "         Chip : ".Win32::GetChipName()."\n";
print "    Node Name : ".Win32::NodeName()."\n";
print "   Login Name : ".Win32::LoginName()."\n";
print "      OS Name : ".Win32::GetOSName()."\n";
print "   OS Version : ".Win32::GetOSVersion()."\n";
print " Display Name : ".Win32::GetOSDisplayName()."\n";
# print " D H:M:S Boot : $days ${hours}:${mins}:${secs}\n"; # Raw data
print " D H:M:S Boot : $days ${h}:${m}:${s}\n";
print "  Domain Name : ".Win32::DomainName()."\n";
print "   Next Drive : ".Win32::GetNextAvailDrive()."\n";
#print "   Unique 128 : ".Win32::GuidGen()."\n";
# Returns something like: {09531CF1-D0C7-4860-840C-1C8C8735E2AD}
if (Win32::IsAdminUser()) {print "Is User Admin : True\n";} else
                          {print "Is User Admin : False\n";} 

# print Win32::MsgBox("MESSAGE",1,"Win32 Test");
# Displays Alert Box

print "=" x 30, "\n";
my ($str,$maj,$min,$build,$id) = Win32::GetOSVersion();
print "$str $maj $min $build $id\n";
