#!/usr/local/bin/perl5 -w

@files = `ls -l`;
$num = 0;
foreach my $file (@files){
	$num++;
	print "line $num: $file";
}
