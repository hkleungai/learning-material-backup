use warning;
use strict;
my $cmd = 'C:\Program Files (x86)\SSH Communications Security\SSH Secure Shell\SshClient.exe';
system($cmd);
