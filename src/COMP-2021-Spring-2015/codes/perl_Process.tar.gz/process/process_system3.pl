#!/usr/local/bin/perl5 -w
$where = "now";
system "(date; who) > $where &";

