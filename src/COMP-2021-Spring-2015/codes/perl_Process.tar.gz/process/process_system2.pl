#!/usr/local/bin/perl5 -w
if (system("date > now")){
	die "can't create file now";
}
