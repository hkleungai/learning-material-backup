#!/usr/local/bin/perl5 -w
system("date");
