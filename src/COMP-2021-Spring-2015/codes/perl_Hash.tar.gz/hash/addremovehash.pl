#!/usr/local/bin/perl5 -w

%data = ('John Paul' => 45, 'Lisa' => 30, 'Kumar' => 40);
$size = scalar keys %data;
print "1 - Hash size:  is $size\n";

# adding an element to the hash;
$data{'Ali'} = 55;
@keys = keys %data;
$size = @keys;
print "2 - Hash size:  is $size\n";

# delete the same element from the hash;
delete $data{'Ali'};
$size = scalar keys %data;
print "3 - Hash size:  is $size\n";
