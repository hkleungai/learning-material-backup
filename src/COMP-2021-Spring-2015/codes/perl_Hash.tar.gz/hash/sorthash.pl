#!/usr/local/bin/perl5 -w

print "==============================\n";
print "A sloar system hash example:\n";
print "==============================\n";

my %planets = (
Mercury => 0.4,
Venus => 0.7,
Earth => 1,
Mars => 1.5,
Ceres => 2.77,
Jupiter => 5.2,
Saturn => 9.5,
Uranus => 19.6,
Neptune => 30,
pluto => 39,
Charon => 39,
);

print "1. Print all key/value pairs:\n\n";
foreach my $name (keys %planets) {
	printf "%-8s %s\n", $name, $planets{$name};
};

print "\n\n" ;
print "2. Print all key/value pairs based on ASCII sorted keys:\n\n";
foreach my $name (sort keys %planets) {
    printf "%-8s %s\n", $name, $planets{$name}
};

print "\n\n" ; 
print "3. Print all key/value pairs based on sorted keys:\n\n";
foreach my $name (sort {lc $a cmp lc $b} keys %planets) {
    printf "%-8s %s\n", $name, $planets{$name};
};

print "\n\n" ;
print "4. Print ASCII sorted values:\n\n";
foreach my $distance (sort values %planets) {
    print "$distance\n";
};

# $a and $b are placeholder variables in sort
print "\n\n" ;
print "5. Print sorted values:\n\n";
foreach my $distance (sort {$a <=> $b} values %planets) {
    print "$distance\n";
};

# <=> spaceship operator, a 3-way comparison operator 
print "\n\n" ;
print "6. Sort the keys of hash according to the values:\n\n";
foreach my $name (sort { $planets{$a} <=> $planets{$b} } keys %planets) {
    printf "%-8s %s\n", $name, $planets{$name};
};

print "\n\n" ;
print "7. Sort the keys of hash according to the values (fixed 
position):\n\n";
foreach my $name (sort { $planets{$a} <=> $planets{$b} or $a cmp $b } keys %planets) {
    printf "%-8s %s\n", $name, $planets{$name};
}
