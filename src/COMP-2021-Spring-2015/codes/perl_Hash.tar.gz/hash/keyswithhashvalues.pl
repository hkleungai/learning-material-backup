#!/usr/local/bin/perl5 -w
use Data::Dumper;

my %hash = (
   "apple"  => "red",
   "banana" => "yellow",
   "orange" => "orange",
   "lemon"  => "yellow",
);

print "Hash with duplicate values:\n";
print Dumper(\%hash);

my $value = 'yellow';
print "Search for fruit with $value color:\n\n";

print "Method 1: reverse\n";
my %revhash = reverse %hash;
print "$revhash{$value}\n\n";

print "Method 2: grep\n";
my @matching_keys = grep { $hash{$_} eq $value } keys %hash;
print("$_\n")
   foreach @matching_keys;
print "\n";

print "Method 3: build a hash slice\n";
while (($key, $value) = each(%hash)){
	push(@{$invhash{$value}}, $key);
}
print "@{$invhash{yellow}} are yellow foods.\n"
