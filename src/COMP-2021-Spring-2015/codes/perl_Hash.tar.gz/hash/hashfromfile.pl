#!/usr/local/bin/perl5 -w

open (FILE, "$ARGV[0]") or die "$!\n";

my %hash;
while (<FILE>) {
	chomp;
	@row = split ("\t");
    	if (scalar(@row) ==  2){
		$key = $row[0];
		$value = $row[1];
		$hash{$key} = $value;
	}
}

foreach (keys %hash) {
	print "$_ has value $hash{$_}\n";
}
