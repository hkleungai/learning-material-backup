#!/usr/local/bin/perl5 -w
use Data::Dumper;

my %hash = (yat=>1, yee=>2, saam=>3);

print "Traditional way doesn't work!\n";
print "Cantonese hash: %hash\n";

print "\n";
print "Lots use foreach\n";
foreach (keys %hash){
	print "$_: $hash{$_}\n";
};

print "\n";
print "You can also use Dumper\n";
print Dumper(\%hash);
