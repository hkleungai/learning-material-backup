#!/usr/local/bin/perl5 -w

my %planets = (
Mercury => 0.4,
Venus => 0.7,
Earth => 1,
Mars => 1.5,
Ceres => 2.77,
Jupiter => 5.2,
Saturn => 9.5,
Uranus => 19.6,
Neptune => 30,
Pluto => 39,
Charon => 39,
);

print "reverse overwrites the duplicate values:\n";
%rev_planets = reverse %planets;
foreach (keys %rev_planets){
	print "$_ $rev_planets{$_}\n";
};

print "\n";
print "Another method:\n";
%rev_planets=();
push @{$rev_planets{$planets{$_}}}, $_ for keys %planets;
foreach (keys %rev_planets){
        print "$_ $rev_planets{$_}\n";
};

