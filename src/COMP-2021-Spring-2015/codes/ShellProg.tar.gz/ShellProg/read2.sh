#!/bin/sh
# Use read command to get and store input from the user

echo "Enter name and how many girlfriends: "
read name number
echo "$name has $number girlfriends!"
