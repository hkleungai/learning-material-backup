#!/bin/sh
if [ -f $1 ]
then
	while read eachline
	do
		echo $eachline
	done
fi
