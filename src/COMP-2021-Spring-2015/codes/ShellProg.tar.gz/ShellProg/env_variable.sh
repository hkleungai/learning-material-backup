#!/bin/sh
echo "Hi $USER!"
echo "Your home directory: $HOME"
echo "Your path: $PATH"
echo "Your current directory: $PWD"
echo "Your shell: $SHELL"
echo "Your printer: $PRINTER"

echo "-------------------------------------------------"
echo "The (very long) list of all environment variables"
echo "-------------------------------------------------"
echo `env`

echo "Update \$PATH "
PATH=$PATH\:/homes/lixin/COMP2021_Spring14/ShellProg
