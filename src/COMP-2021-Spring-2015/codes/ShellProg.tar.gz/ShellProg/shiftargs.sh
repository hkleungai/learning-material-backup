#!/bin/sh
echo "The arguments are 0 = $0, 1 = $1, 2 = $2"
shift
echo "The arguments are 0 = $0, 1 = $1, 2 = $2"
shift
echo "The arguments are 0 = $0, 1 = $1, 2 = $2"

