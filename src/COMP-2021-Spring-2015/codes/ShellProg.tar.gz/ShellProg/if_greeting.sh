#!/bin/sh
user=`whoami`
if [ $user = "lixin" ]
then
	echo "Hi Cindy!"
fi
