#!/bin/sh
# Example of expr

echo "Enter the first operand: "
read a
echo "Enter the second operand: "
read b

echo "$a + $b = `expr $a + $b`"

x=`expr $a - $b`
echo "$a - $b = $x"

y=`expr $a \* $b`
echo "$a * $b = $y"

echo "$a / $b = `expr $a / $b`"
