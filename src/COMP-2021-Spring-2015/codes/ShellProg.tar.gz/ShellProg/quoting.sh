#!/bin/sh
# Different quotes

DATE=`date`
echo "Current date: $DATE"

user=`whoami`
numusers=`who | wc -l`
echo "Hi $user! There are $numusers users logged on."

echo "I have \$5000."
echo "It\'s Shell Programming"

echo '<-$1500.**>; (update?) [y\n]'
