#!/bin/sh
echo "Enter a number"
read n
arm=0
temp=$n
while [ $temp -ne 0 ]
do
r=$(expr $temp % 10)
arm=$(expr $arm + $r \* $r \* $r)
temp=$(expr $temp / 10)
done
echo "Number is $n, cubes of its digits is $arm"
if [ $arm -eq $n ]
then
echo "Armstrong"
else
echo "Not Armstrong"
fi
