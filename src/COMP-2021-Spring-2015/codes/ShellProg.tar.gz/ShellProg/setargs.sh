#!/bin/sh
set yat yih saam
echo "In Cantonese: 1 is $1, 2 is $2, 3 is $3"
set `date`
echo "Today is $3 $2 $6"
