#! /bin/sh
# comment lines start with the # character
echo "Hello World"
