#!/bin/sh
echo "The arguments are $1 $2 $3 $4 $5 $6 $7 $8 $9"
echo "There're $# arguments"
