import os
import pytest
from typing import Any, Callable, Iterable
from inspect import signature
import numpy as np
import tensorflow as tf
from tensorflow import keras
from keras import Model


# TODO: categorical_crossentropy


# Setup & Data
keras.utils.set_random_seed(12345679)  # Something not 2211

np_data = np.load("draw.npz")
x_train_raw = np_data["x_train"]
y_train_raw = np_data["y_train"]
x_val_raw = np_data["x_val"]
y_val_raw = np_data["y_val"]
x_test_raw = np_data["x_test"]
y_test_raw = np_data["y_test"]
y_names = np_data["y_names"]
N_labels = len(y_names)
x_train = x_train_raw.reshape(-1, 28, 28, 1)
x_val = x_val_raw.reshape(-1, 28, 28, 1)
x_test = x_test_raw.reshape(-1, 28, 28, 1)
y_train = tf.one_hot(y_train_raw, N_labels)
y_val = tf.one_hot(y_val_raw, N_labels)
y_test = tf.one_hot(y_test_raw, N_labels)


## Monkey Patch
# def get_arg(func: Callable, args: list, kwargs: dict, name: str):
def get_arg(func, args, kwargs, name):
    """Given a func and the args/kwargs when calling it, find the value of param name"""
    # if name is passed in with name, i.e. in kwargs
    if name in kwargs:
        return kwargs[name]
    # otherwise, get the correct idx for name in unnamed args
    arg_list = list(signature(func).parameters)
    try:
        idx = arg_list.index(name) - 1 # -1 because of self
        if name.endswith('batch_size') and idx >= len(args):
            return 32
        return args[idx]
    except (ValueError, IndexError):
        raise RuntimeError(f'Grader internal error, could not find arg {name} in func {func.__name__} with param list {arg_list} and arg list {args}')

# def patch_method(class_: type, old_method: Callable, params: dict[str, Any]):
def patch_method(class_, old_method, params):
    method_name = old_method.__name__
    old_dict = None
    try:
        old_dict =  getattr(class_, '_patched_methods')
    except AttributeError:
        old_dict = {}
        setattr(class_, '_patched_methods', old_dict)
    old_dict[method_name] = old_method

    def monkey_patched_method(self, *args, **kwargs):
        for name, val in params.items():
            if val is None:
                continue

            a = get_arg(old_method, args, kwargs, name)

            if isinstance(val, Callable):
                judge = val(a)
                expected_msg = f'Wrong argument for {name}'
            elif isinstance(val, np.ndarray) or isinstance(val, tf.Tensor):
                judge = np.all(a == val)
                expected_msg = f'Wrong argument for {name}'
            else:
                judge = a == val
                expected_msg = f'Wrong argument for {name}. Expected {val}, got {a}'

            assert judge, expected_msg
        return old_method(self, *args, **kwargs)
    monkey_patched_method.__name__ = method_name

    setattr(class_, old_method.__name__, monkey_patched_method)

# def unpatch_method(class_: type, method: Callable):
def unpatch_method(class_, method):
    method_name = method.__name__
    old_dict = getattr(class_, '_patched_methods')
    setattr(class_, method_name, old_dict[method_name])


# Import PA code
model_path = "draw_model.h5"
from pa2 import *
import pa2_sol as sol


@pytest.fixture
def rx():
    return np.random.random((2, 28, 28, 1))


@pytest.fixture
def ry():
    return np.random.random((2, N_labels))


@pytest.fixture
def x():
    return np.zeros((1, 28, 28, 1))


@pytest.fixture
def y():
    return np.zeros((1, N_labels))


@pytest.fixture
def model():
    model = sol.build_model(N_labels)
    sol.compile_model(model, 1e-6)
    return model


class TestReshapeX:
    correct = sol.reshape_x(x_train_raw, x_val_raw, x_test_raw)
    
    @pytest.fixture
    def user_x(self):
        return reshape_x(x_train_raw, x_val_raw, x_test_raw)

    def test_reshape_x_train(self, user_x):
        assert np.all(user_x[0] == self.correct[0])

    def test_reshape_x_val(self, user_x):
        assert np.all(user_x[1] == self.correct[1])

    def test_reshape_x_test(self, user_x):
        assert np.all(user_x[2] == self.correct[2])


class TestEncodeY:
    correct = sol.encode_y(y_train_raw, y_val_raw, y_test_raw, N_labels)

    @pytest.fixture
    def user_y(self):
        return encode_y(y_train_raw, y_val_raw, y_test_raw, N_labels)

    def test_encode_y_train(self, user_y):
        assert np.all(user_y[0] == self.correct[0])

    def test_encode_y_val(self, user_y):
        assert np.all(user_y[1] == self.correct[1])

    def test_encode_y_test(self, user_y):
        assert np.all(user_y[2] == self.correct[2])


class _TestGeneralModel:
    # correct_model: keras.Model = None
    # attr: list[list[str]] = None
    correct_model = None
    attr = None
    start_i = 0

    def test_model_structure(self, user_model):
        assert len(user_model.layers) == len(
            self.correct_model.layers
        ), "#Layer mismatch"
        for i in range(self.start_i, len(self.correct_model.layers)):
            ul = user_model.layers[i]
            cl = self.correct_model.layers[i]
            assert type(ul) == type(cl), f"Layer #{i} has incorrect type"

    def test_model_parameters(self, user_model):
        for i in range(self.start_i, len(self.correct_model.layers)):
            ul = user_model.layers[i]
            cl = self.correct_model.layers[i]
            for at in self.attr[i]:
                ua = ul.__getattribute__(at)
                ca = cl.__getattribute__(at)
                err_msg = f"At layer #{i}, attribute {at} has incorrect value"
                # Special case for random rotate factor
                if at == 'factor' and isinstance(ua, Iterable):
                    assert ua[0] == -ua[1] and ca == ua[1], f"At layer {i}, attribute {at} has incorrect value {ua}. Expected {ca} or [{-ca}, {ca}]"
                    continue
                # Special case for activation ReLU vs relu
                if at == 'activation':
                    ua = self._get_actication(ua)
                    ca = self._get_actication(ca)
                # Special case for Initializer object
                if isinstance(ca, keras.initializers.Initializer):
                    ua = ua.__class__
                    ca = ca.__class__
                assert ua == ca, f"At layer {i}, attribute {at} has incorrect value {ua}. Expected {ca}"

    def _get_actication(self, value):
        if isinstance(value, keras.layers.Layer):
            return value.__class__.__name__.lower()
        elif isinstance(value, Callable):
            return value.__name__.lower()
        return value


@pytest.mark.incremental
class TestAugmentedLayer(_TestGeneralModel):
    correct_model = sol.AugmentationLayer()
    attr = [["mode"], ["factor", "fill_mode", "fill_value"]]

    @pytest.fixture
    def user_model(self):
        return AugmentationLayer()


@pytest.mark.incremental
class TestMainModel(_TestGeneralModel):
    correct_model = sol.build_model(N_labels)
    # start_i = 1
    attr = [
        [],
        ["scale", "offset"],
        ["filters", "kernel_size", "activation", "kernel_initializer"],
        ["pool_size"],
        ["filters", "kernel_size", "activation", "kernel_initializer"],
        ["pool_size"],
        ["filters", "kernel_size", "activation", "kernel_initializer"],
        ["pool_size"],
        [],
        ["rate"],
        ["units", "activation"],
    ]

    @pytest.fixture
    def user_model(self):
        return build_model(N_labels)


class TestCompileModel:
    @pytest.fixture
    def user_model(self):
        model = sol.build_model(N_labels)
        compile_model(model, 1e-6)
        return model

    @pytest.fixture
    def fitted_um(self, user_model, x, y):
        user_model.fit(x, y, verbose=0)
        return user_model

    @pytest.fixture
    def correct_model(self, x, y):
        model = sol.build_model(N_labels)
        sol.compile_model(model, 1e-6)
        model.fit(x, y, verbose=0)
        return model

    def test_compile_loss(self, user_model, correct_model):
        uloss = user_model.loss
        closs = correct_model.loss
        uloss = self._convert_loss(uloss)
        closs = self._convert_loss(closs)
        assert uloss == closs

    def test_compile_optimizer(self, user_model, correct_model):
        assert type(user_model.optimizer) == type(correct_model.optimizer)

    def test_compile_learning_rate(self, user_model, correct_model):
        assert user_model.optimizer.lr == correct_model.optimizer.lr

    def test_compile_metrics(self, fitted_um, correct_model):
        # Require compulsory metrics losses and accuracy.
        # For loop to prevent order issue (if any?)
        # Don't deduct points if students add more metrics
        metrics_names = [x.lower() for x in fitted_um.metrics_names]
        if "accuracy" not in metrics_names and "acc" not in metrics_names and "categorical_accuracy" not in metrics_names:
            print('Fallback test for metrics')
            correct_compiled_metrics = [x.__class__.__name__ for x in correct_model.compiled_metrics.metrics]
            user_compiled_metrics = [x.__class__.__name__ for x in fitted_um.compiled_metrics.metrics]
            for m in user_compiled_metrics:
                assert m in correct_compiled_metrics
    
    def _convert_loss(self, loss):
        if isinstance(loss, keras.losses.Loss):
            return loss.name
        elif isinstance(loss, Callable):
            return loss.__name__
        else:
            return loss


class TestTrainModel:
    d = {
        "epochs": "Incorrect epochs param",
        "steps": "Incorrect batch_size param",
    }

    @pytest.fixture
    def user_model(self):
        model = sol.build_model(N_labels)
        sol.compile_model(model, 1e-6)
        return model

    @pytest.fixture
    def correct_model(self):
        model = sol.build_model(N_labels)
        sol.compile_model(model, 1e-6)
        return model

    def test_fit_epochs(self, user_model, correct_model, x, y):
        uh = train_model(user_model, 1, x, y, x, y)
        ch = sol.train_model(correct_model, 1, x, y, x, y)
        assert uh, "train_model didn't return"  # not None; did return
        assert uh.params["epochs"] == ch.params["epochs"], "Incorrect epochs param"

    def test_fit_batch_size(self, user_model, correct_model): # batch size = 32
        self._test_single_batch_size(user_model, correct_model, 32)  # step = 1
        self._test_single_batch_size(user_model, correct_model, 33)  # step = 2

    def _test_single_batch_size(self, um, cm, batch_size):
        x = np.zeros((batch_size, 28, 28, 1))
        y = np.zeros((batch_size, N_labels))
        uh = train_model(um, 1, x, y, x, y)
        ch = sol.train_model(cm, 1, x, y, x, y)
        assert uh, "train_model didn't return"  # not None; did return
        assert uh.params["steps"] == ch.params["steps"], "Incorrect batch_size param"

    def test_fit_validation(self, user_model, x, y):
        def judge_validation_data(validation_data):
            return np.all(validation_data[0] == x_val) and np.all(validation_data[1] == y_val)

        patch_method(Model, Model.fit, {
            'validation_data': judge_validation_data,
            'validation_batch_size': 32,
        })
        train_model(user_model, 1, x, y, x_val, y_val)
        unpatch_method(Model, Model.fit)


class TestEvaluateModel:
    def test_evaluate(self, model, x, y):
        patch_method(Model, Model.evaluate, {
            'batch_size': 32,
        })
        evaluate_model(model, x, y)
        unpatch_method(Model, Model.evaluate)


class TestPredictImages:
    def test_predict(self, model):
        user_predict = predict_images(model, x_test)
        correct_predict = sol.predict_images(model, x_test)
        assert user_predict.shape == correct_predict.shape, f"Incorrect shape. Expected {correct_predict.shape}, got {user_predict.shape}"
        assert np.all(user_predict == correct_predict)


class TestSavedModel:
    correct_model = keras.models.load_model("correct_model.h5")

    @pytest.fixture
    def user_model(self):
        return keras.models.load_model(model_path)

    def test_accuracy(self, user_model):
        _, acc = user_model.evaluate(x_test, y_test, batch_size=32, verbose=0)
        assert acc > 0.6, f'Accuracy is only {acc}'

    def test_model_weights(self, user_model):
        uw = user_model.get_weights()
        cw = self.correct_model.get_weights()
        matches = [np.allclose(a, b, atol=5e-2) for a, b in zip(uw, cw)]
        assert np.mean(matches) > 6 / 8, f'You have only {np.sum(matches)}/8 correct weights'
