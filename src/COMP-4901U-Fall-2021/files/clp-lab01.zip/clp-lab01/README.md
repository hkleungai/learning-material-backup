## Lab 01: Interpreter

You can find instructions for this assignment [here](https://lptk.github.io/clpcd/labs/lab1-interpreter).
