/*******************************************************
* COMP2012 - 2015/16 Fall
* Programming Assignment 1
* File: Polynomial.cpp
*******************************************************/

#include <string>
#include <iostream>
#include <regex>

#include "Polynomial.h"

using namespace std;

/* if Polynomial a is empty, retrun true, else false */
bool isEmpty(PolyNode* a)
{
	return false;
}

/* erase a Polynomial pointed by ptr and deallocate the nodes */
void erase(PolyNode* ptr)
{
}

PolyNode* addTerm(PolyNode* front, string str)
{
	PolyNode* newTerm = new PolyNode;

	regex reg_x("x(\\^\\d+)?");
	regex reg_y("y(\\^\\d+)?");
	regex reg_d("[-]?\\d+");
	regex_iterator<string::iterator> iter_x(str.begin(), str.end(), reg_x);
	regex_iterator<string::iterator> iter_y(str.begin(), str.end(), reg_y);
	regex_iterator<string::iterator> end;

	if (iter_x == end)
	{
		newTerm->expx = 0;
	}
	else
	{
		newTerm->expx = 1;
		string part_x = iter_x->str();
		regex_iterator<string::iterator> iter_d(part_x.begin(), part_x.end(), reg_d);
		if (iter_d != end)
		{
			newTerm->expx = atoi(iter_d->str().c_str());
		}
	}

	if (iter_y == end)
	{
		newTerm->expy = 0;
	}
	else
	{
		newTerm->expy = 1;
		string part_y = iter_y->str();
		regex_iterator<string::iterator> iter_d(part_y.begin(), part_y.end(), reg_d);
		if (iter_d != end)
		{
			newTerm->expy = atoi(iter_d->str().c_str());
		}
	}

	str = regex_replace(str, reg_x, "");
	str = regex_replace(str, reg_y, "");
	regex_iterator<string::iterator> iter_d(str.begin(), str.end(), reg_d);
	if (iter_d == end)
	{
		if (str.find('-') != string::npos)
			newTerm->coef = -1;
		else
			newTerm->coef = 1;
	}
	else
	{
		newTerm->coef = atoi(iter_d->str().c_str());
	}

	newTerm->prev = nullptr;
	newTerm->next = front;
	if (front != nullptr)
		front->prev = newTerm;

	return newTerm;
}

/* read and create a Polynomial from a string*/
PolyNode* readPoly(string str)
{
	//empty input
	if (str.length() == 0)
	{
		return nullptr;
	}

	PolyNode* front = nullptr;

	regex two("[+-]?\\d*x(\\^\\d+)?y(\\^\\d+)?");
	regex one("[+-]?\\d*((x(\\^\\d+)?)|(y(\\^\\d+)?))");
	regex_iterator<string::iterator> iter_two(str.begin(), str.end(), two);
	regex_iterator<string::iterator> end;

	while (iter_two != end)
	{
		front = addTerm(front, iter_two->str());
		iter_two++;
	}

	str = regex_replace(str, two, "");
	std::regex_iterator<string::iterator> iter_one(str.begin(), str.end(), one);

	while (iter_one != end)
	{
		front = addTerm(front, iter_one->str());
		iter_one++;
	}

	str = regex_replace(str, one, "");
	if (str != "")
		front = addTerm(front, str);

	return front;
}

/* print the Polynomial a in decreasing order of exponent */
void printPoly(PolyNode* a)
{
}

/* Sort the polynomial a in decreasing order of exponent and combine terms with same exponent of x and y */
void sortPoly(PolyNode* a)
{
}

/* print the Polynomial a in ascending order of exponent */
void printPolyReverse(PolyNode* a)
{
}

/* evaluate the Polynomial a at value of x, y */
long eval(PolyNode* a, int x, int y)
{
	return 0;
}

/* add two PolyNode*amials, a & b, and return the sum in a third Polynomial*/
PolyNode* padd(PolyNode* a, PolyNode* b)
{
	PolyNode* c = nullptr;
	//c = a + b

	sortPoly(c);
	return c;
}

/* subtract Polynomial b from Polynomial a, return the result in a third Polynomial */
PolyNode* psubtract(PolyNode* a, PolyNode* b)
{
	PolyNode* c = nullptr;
	//c = a - b

	sortPoly(c);
	return c;
}

/* multiply Polynomial a with Polynomial b and return the result in a third Polynomial */
PolyNode* pmult(PolyNode* a, PolyNode* b)
{
	PolyNode* c = nullptr;
	//c = a * b

	sortPoly(c);
	return c;
}
