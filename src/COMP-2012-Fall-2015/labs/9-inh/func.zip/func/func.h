#include <string>

using namespace std;

#ifndef _FUNC_H
#define _FUNC_H

class Func {
public:
	// constructor
	Func(string _name, bool _isPeriodic):
	name(_name), isPeriodic(_isPeriodic) { };

	// get the function name
	string GetName() const {
		return name;
	}

	// is the function differentiable at d?
	bool IsDifferentiable(double d) const {
		// assume all functions are differentiable
		return true;
	};

	// is the function periodic?
	bool IsPeriodic() const {
		return isPeriodic;
	};

private:
	const string name;
	const bool isPeriodic;
};

#endif
