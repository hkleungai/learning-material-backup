#include <cmath>
#include "poly_func.h"

PolyFunc::PolyFunc(const int* array, int size)
: Func("poly", false) {
	num_of_terms = size;
	terms = new int[size];

	// copy from array to terms
	for (int i = 0; i < size; i++) {
		terms[i] = array[i];
	};
};

PolyFunc::~PolyFunc() {
	delete[] terms;
};

double PolyFunc::EvaluateAt(double x) {
	// P(x) = a[0] x^(s-1) + a[1] x^(s-2) + ... + a[s-2] x + a[s-1]
	double d = 0.00;
	for (int i = 0; i < num_of_terms; i++) {
		// use pow() from math library
		d += (terms[i] * pow(x, (num_of_terms - 1 - i)));
	};
	return d;
};

double PolyFunc::DerivativeAt(double x) {
	double d = 0.00;

	// ToDo: calculate the derivative at x
	// the loop should be similar to what we have
	// in PolyFunc::EvaluateAt(double)

	return d;
};
