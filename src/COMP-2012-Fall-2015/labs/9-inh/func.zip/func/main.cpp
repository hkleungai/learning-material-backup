#include <cmath>
#include <iostream>
#include <vector>
using namespace std;

#include "func.h"
#include "tri_func.h"
#include "poly_func.h"
#include "impulse_func.h"

const char* T = "true";
const char* F = "false";

void PrintFunc(const char* n, PolyFunc& f, double v) {
	cout << n << endl
		<< "\tname = " << f.GetName() << endl
		<< "\tis periodic = " << (f.IsPeriodic()? T: F) << endl
		<< "\tvalue at " << v << " = " << f.EvaluateAt(v) << endl;

	cout << "\tis differentiable at " << v
		<< " = " << (f.IsDifferentiable(v)? T: F) << endl;

	if (f.IsDifferentiable(v)) {
		cout << "\tderivative at " << v << " = " << f.DerivativeAt(v) << endl;
	}
}

void PrintFunc(const char* n, SinFunc& f, double v) {
	cout << n << endl
		<< "\tname = " << f.GetName() << endl
		<< "\tis periodic = " << (f.IsPeriodic()? T: F) << endl
		<< "\tvalue at " << v << " = " << f.EvaluateAt(v) << endl;

	cout << "\tis differentiable at " << v
		<< " = " << (f.IsDifferentiable(v)? T: F) << endl;

	if (f.IsDifferentiable(v)) {
		cout << "\tderivative at " << v << " = " << f.DerivativeAt(v) << endl;
	}
}

void PrintFunc(const char* n, CosFunc& f, double v) {
	cout << n << endl
		<< "\tname = " << f.GetName() << endl
		<< "\tis periodic = " << (f.IsPeriodic()? T: F) << endl
		<< "\tvalue at " << v << " = " << f.EvaluateAt(v) << endl;

	cout << "\tis differentiable at " << v
		<< " = " << (f.IsDifferentiable(v)? T: F) << endl;

	if (f.IsDifferentiable(v)) {
		cout << "\tderivative at " << v << " = " << f.DerivativeAt(v) << endl;
	}
}

void PrintFunc(const char* n, ImpulseFunc& f, double v) {
	cout << n << endl
		<< "\tname = " << f.GetName() << endl
		<< "\tis periodic = " << (f.IsPeriodic()? T: F) << endl
		<< "\tvalue at " << v << " = " << f.EvaluateAt(v) << endl;

	cout << "\tis differentiable at " << v
		<< " = " << (f.IsDifferentiable(v)? T: F) << endl;

	if (f.IsDifferentiable(v)) {
		cout << "\tderivative at " << v << " = " << f.DerivativeAt(v) << endl;
	}
}



void printLine() {
	cout << "-----------------------------------------------" << endl;
}

int main() {
	const int array[] = { 6, 0, 0, 1 };
	const int size = sizeof(array) / sizeof(array[0]);
	PolyFunc p(array, size);
	PrintFunc("p", p, 2.00);

	printLine();

	// in radian
	const double angle45 = 45.00 * 3.1415926 / 180.00;
	const double angle90 = 90.00 * 3.1415926 / 180.00;
	const double angle135 = 135.00 * 3.1415926 / 180.00;

	SinFunc s;
	PrintFunc("s", s, angle45);

	printLine();

	CosFunc c(2.00);
	PrintFunc("c", c, angle90);

	printLine();

	ImpulseFunc i(10.00, 7.00);
	PrintFunc("i", i, 800.00);
	PrintFunc("i again", i, 10.00);

	return 0;
};
