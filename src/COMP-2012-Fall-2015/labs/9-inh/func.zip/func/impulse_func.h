#include "func.h"

#ifndef _IMPULSE_FUNC_H
#define _IMPULSE_FUNC_H

/////////////////////
// impulse function
/////////////////////

class ImpulseFunc: public Func {
public:
	// constructor
	// _impulseAt: the x-coordinate of the impulse
	// _magitude: the y-coordinate of the impulse
	ImpulseFunc(double _impulseAt, double _magnitude);

	// override from Func
	// impulse function is differentiable except at the impulse
	//
	// ToDo: override Func::IsDifferentiable(double)
	// ...

	double EvaluateAt(double d);
	double DerivativeAt(double d); 

private:
	// return the difference between the impulse and d
	// it must be non-negative
	double DiffToImpulse(double d) const;

	const double impulseAt;
	const double magnitude;
};

#endif
