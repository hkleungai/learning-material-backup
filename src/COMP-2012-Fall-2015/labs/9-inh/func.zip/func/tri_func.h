#include "func.h"

#ifndef _TRI_FUNC_H
#define _TRI_FUNC_H


/////////
// sine
/////////
class SinFunc: public Func {
public:
	SinFunc(double _scale = 1.00);
	double EvaluateAt(double d);
	double DerivativeAt(double d);

private:
	double scale;
};

/////////////////////
// cosine = sin(90-x)
/////////////////////

// ToDo: the class cosine definition

class CosFunc: public SinFunc {
public:
	CosFunc(double _scale = 1.00);
	//cos(x) = sin(90-x)
	double EvaluateAt(double d);
	//cos(x)'=[sin(90-x)]'=-[sin(90-x)]'
	double DerivativeAt(double d);
};



#endif
