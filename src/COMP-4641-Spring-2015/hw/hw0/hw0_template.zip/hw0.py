import numpy as np
import networkx as nx

data = np.loadtxt('facebook_combined.txt')  # load all the edges, which is saved in facebook_combined.txt file
data = data.astype(int)   # conver nodeid from float to int, like 1.0 to 1
#print data.shape

edges_list = map(tuple, data)  # map(function, iterable): apply function to every item of iterable and return a list of results
#print edges_list[:10]

fbG = nx.Graph(edges_list)  # generate the facebook graph

# print number of nodes and edges, and whether this network is connected or not

# print the id of node(or nodes) with maximum degree

# print the clustering coefficient of the previous maximum degree node 
# and average clustering coefficient of the whole graph

# print number of triangles, check networkx.algorithms.cluster.triangles() function in networkx document

# print the shortest path from node 5 to 3000

# print the diameter and average shortest path length, it may take several minutes to complete, BE PATIENT!
