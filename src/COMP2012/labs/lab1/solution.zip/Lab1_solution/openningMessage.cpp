#include <iostream>

using namespace std;

int sayHello() {
    cout << "Hello, visitors!" << endl;
    cout << "Welcome to HKUST 30th Anniversary!" << endl;
    cout << "I am your reception bot." << endl;
    return 0;
}