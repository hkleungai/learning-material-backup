#include <iostream>
#include "school-namespaces.h"

// Note: You are supposed to insert new lines in this file, but not modify/delete existing lines!
// TODO 1: Specify namespaces to be used in this file.


void QueryEvents() {
    cout << "Select the school: 1. School of Engineering; 2. School of Science:";
    char choice;
    while(cin >> choice) {
        if (choice == '1' || choice == '2')
            break;
        else
            cout << "Select from 1 or 2." << endl;
    }

    if(choice == '1') {
        cout << "Select the department: 1. Department of CSE; 2. Department of ECE; 3. All Departments:";
        // TODO 2: Call the corresponding print_events function according to input.

    }
    else {
        cout << "Select the department: 1. Department of Mathematics; 2. Department of Physics; 3. All Departments:";
        // TODO 3: Call the corresponding print_events function according to input.

    }
}