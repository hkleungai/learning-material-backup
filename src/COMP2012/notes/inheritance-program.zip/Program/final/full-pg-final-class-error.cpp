#include <iostream>     /* File: pg-final-error.cpp */
using namespace std;
#include "v-student.h"
#include "v-pg-student.h"

int main()
{
    UPerson abby("Abby", CBME);
    Student bob("Bob", CIVL, 3.0);
    PG_Student matt("Matt", CSE, 3.8);
}
