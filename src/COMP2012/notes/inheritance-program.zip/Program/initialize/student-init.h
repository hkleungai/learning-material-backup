Student::Student(string n, Department d, float x) :
  UPerson(n,d), GPA(x), enrolled(nullptr), num_courses(0) { }
