#include <string> /* File: full-print-example.cpp */
using namespace std;
#include "../basics/student.h"
#include "../basics/teacher.h"

int main()
{
    #include "print-example.cpp"
    return 0;
}
