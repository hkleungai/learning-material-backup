T max(const T& a, const T& b) { ... }
