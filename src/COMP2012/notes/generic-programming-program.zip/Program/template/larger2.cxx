int i = larger(4, 5); // Rely on compilers to deduce larger<int>
int j = larger<int>(7, 2); // Explicit instantiation
