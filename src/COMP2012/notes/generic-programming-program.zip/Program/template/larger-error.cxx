cout << larger(4, 5.5);
// Error: no matching function for call to 'larger(int, double)'
