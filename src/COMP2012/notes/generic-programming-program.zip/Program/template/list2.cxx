List primes;      // Error: how can compilers deduce the type?
primes.append(2); // Error: too late; compilers can't lookahead!
