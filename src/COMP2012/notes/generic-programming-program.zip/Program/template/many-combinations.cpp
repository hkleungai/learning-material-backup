/* File: many-combinations.cpp */
short s = 1; char c = 'A';
int i = 1023; double d = 3.1415;

print_larger(s, s); print_larger(s, c);
print_larger(c, s); print_larger(s, i);
// ... And all other combinations; 16 in total.
