    string x("dot"), y("com"), z;
    z = x + y;
    z = x + "com";
    z = "dog" + y;
