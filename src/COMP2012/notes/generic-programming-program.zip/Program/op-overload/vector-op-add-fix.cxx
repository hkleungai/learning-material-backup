Vector operator+(double a, const Vector& b) { return b + a; }
