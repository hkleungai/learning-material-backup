        Vector a(1, 0);
        cout << " a = " << a << "\n";
