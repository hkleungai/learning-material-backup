#!/bin/sh
# A simple calculator
# take a file name as command line argument

input=$1
result=0
IFS=$' '
while read -r a op b 
do
# echo "$a $op $b"
  if [ $op = "+" ]
  then
    result=`expr $a + $b` 
    echo "$a + $b = $result"
  elif [ $op = "-" ]
  then  
    result=`expr $a - $b`
    echo "$a - $b = $result"
  elif [ $op = "x" ]
  then
    result=`expr $a \* $b`
    echo "$a x $b = $result"
  elif [ $op = "/" ]
  then
    result=`expr $a / $b`
    echo "$a / $b = $result" 
  else
    echo "Invalid calculation" 
 fi
done < "$input"
