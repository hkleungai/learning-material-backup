#!/bin/sh
# A simple calculator
# take a file name as command line argument

input=$1
result=0
IFS=$' '
while read -r a op b 
do
# echo "$a $op $b"
case "$op" in 
+) result=`expr $a - $b`
   echo "$a + $b = $result"
   ;;
-) result=`expr $a - $b`
   echo "$a - $b = $result"
   ;;
x) result=`expr $a \* $b`
   echo "$a x $b = $result"
   ;;
/) result=`expr $a % $b`
   echo "$a / $b = $result"
   ;;
*) echo "Invalid calculation"
   ;;
esac  

done < "$input"
