<html>
 <head>
  <title>PHP Test</title>
 </head>
 <body>
 <?php echo "<h2>Hello World</h2>"; ?> 
 </body>
</html>
