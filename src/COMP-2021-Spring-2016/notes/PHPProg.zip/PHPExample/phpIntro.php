#!/usr/bin/env php
<?php
# PHP scripts included in Lecture 6 
# Intro to PHP

print "-------------------\n";
print "Print\n";
print "-------------------\n";
print "Hello, World!\n";
print "Escape \"chars\" are the SAME as in Java!\n";
print "You can have
line breaks in a string.";
print 'A string can use "single-quotes". It\'s cool!';	

print "\n--------------------\n";
print "Int and Float\n";
print "--------------------\n";
$a = 7 / 2; # float: 3.5
print "a = $a\n";
$b = (int) $a; # int: 3
print "b = $b\n";
$c = round($a); # float: 4.0
print "c = $c\n";
$d = "123"; # string: "123"
print "d = $d\n";
$e = (int) $d; # int: 123
print "e = $e\n";

print "\n---------------------\n";
print "Math operation\n";
print "----------------------\n";
$a = 3;
$b = 4;
$c = sqrt(pow($a, 2) + pow($b, 2));
print "c = $c\n";

print "\n-------------------\n";
print "String Functions\n";
print "-------------------\n";
# index 0123456789012345
$name = "Leonardo DiCaprio";
$length = strlen($name); 
print "length $length\n";
$cmp = strcmp($name, "Leo"); 
print "Comparison result $cmp\n";
$index = strpos($name, "e"); 
print "Index $index\n";
$first = substr($name, 9, 5); 
print "First $first\n";
$name = strtoupper($name);  
print "Toupper $name\n";


print "\n-------------------\n";
print "For loop\n";
print "---------------------\n";
for ($i = 0; $i < 10; $i++) {
	print "$i squared is " . $i * $i . ".\n";
}

print "\n--------------------\n";
print "Array and foreach loop\n";
print "---------------------\n";

$fellowship = array("Frodo", "Sam", "Gandalf", "Strider", "Gimli", "Legolas", "Boromir");

print "The fellowship of the ring members are: \n";
for ($i = 0; $i < count($fellowship); $i++) {
	print "{$fellowship[$i]}\n";
}

print "The fellowship of the ring members are: \n";
foreach ($fellowship as $fellow) {
	print "$fellow\n";  
}

print "\n--------------------\n";
print "String Comparison\n";
print "---------------------\n";

$vowels = array("a", "e", "i", "o", "u", "A", "E", "I", "O", "U");
$onlyconsonants = str_replace($vowels, "", "Hello World of PHP");
print "Onlyconsonants: $onlyconsonants\n";

// Provides: You should eat pizza, beer, and ice cream every day
$phrase  = "You should eat fruits, vegetables, and fiber every day.";
$healthy = array("fruits", "vegetables", "fiber");
$yummy   = array("pizza", "beer", "ice cream");

$newphrase = str_replace($healthy, $yummy, $phrase);
print "NewPhrase: $newphrase\n";

print "\n---------------------\n";
print "Multi-dimensional array\n";
print "----------------------\n";

$meals = array('breakfast' => array('Walnut Bun','Coffee'),
               'lunch'     => array('Cashew Nuts', 'White Mushrooms'),
               'snack'     => array('Dried Mulberries','Salted Sesame Crab'));

$lunches = array( array('Chicken','Eggplant','Rice'),
                  array('Beef','Scallions','Noodles'),
                  array('Eggplant','Tofu'));

$flavors = array('Japanese' => array('hot' => 'wasabi',
                                     'salty' => 'soy sauce'),
                 'Chinese'  => array('hot' => 'mustard',
                                     'pepper-salty' => 'prickly ash'));

print $meals['lunch'][1]."\n";       // White Mushrooms
print $meals['snack'][0]."\n";       // Dried Mulberries
print $lunches[0][0]."\n";           // Chicken
print $lunches[2][1]."\n";           // Tofu
print $flavors['Japanese']['salty']."\n";  // soy sauce
print $flavors['Chinese']['hot']."\n";    // mustard  

print "\n------------------------\n";
print "Multi-dimensional array with foreach\n";
print "-----------------------\n";

$flavors = array('Japanese' => array('hot' => 'wasabi','salty' => 'soy sauce'),
                 'Chinese'  => array('hot' => 'mustard', 'pepper-salty' => 'prickly ash'));

// $culture is the key and $culture_flavors is the value (an array)
foreach ($flavors as $culture => $culture_flavors) {

    // $flavor is the key and $example is the value
    foreach ($culture_flavors as $flavor => $example) {
        print "A $culture $flavor flavor is $example.\n";
    }
}







?>
