<?php
# This is a set of examples which deal with time
#http://php.about.com/od/finishedphp1/ss/php_calendar.htm

# different time format
print "<br>" ."<b>Different time format</b>" . "<br>";
$b = time ();
print date("m/d/y",$b) . "<br>";
print date("D, F jS",$b) . "<br>";
print date("l, F jS Y",$b) . "<br>";
print date("g:i A",$b) . "<br>";
print date("r",$b) . "<br>";
print date("g:i:s A D, F jS Y",$b) . "<br>";
print "<br>";


# make time

print "<br>" ."<b>Make time</b>" . "<br>";
echo date("M-d-Y", mktime(12, 15, 4, 12, 15, 2016)). "<br>";
echo date("M-d-Y", mktime(0, 0, 0, 1, 1, 16))."<br>" ;
print "<br>";


# count down

print "<br>" ."<b>Count down</b>" . "<br>";
$target = mktime(0, 0, 0, 3, 24, 2016) ;
$today = time () ;
$difference =($target-$today) ;
$days =(int) ($difference/86400) ;
print "Our event will occur in $days days". "<br>";
print "<br>";


# Calender

print "<br>" ."<b>First day of month</b>" . "<br>";
//This gets today's date
$date =time () ;
//This puts the day, month, and year in seperate variables
$day = date('d', $date) ;
$month = date('m', $date) ;
$year = date('Y', $date) ;
//Here we generate the first day of the month
$first_day = mktime(0,0,0,$month, 1, $year) ;
print "First day of this month is ". date("m/d/y",$first_day) . "<br>";
//This gets us the month name
$title = date('F', $first_day) ;
print "$title";
?>
