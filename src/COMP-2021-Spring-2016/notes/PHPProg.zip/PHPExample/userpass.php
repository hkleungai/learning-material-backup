<?php
function userPass()
{
    echo "<form method='post' action=" . $_SERVER['PHP_SELF'] . ">";
    echo "User name: <br>";
    echo "<input type='text' name='user' /><br><br>";
    echo "Password: <br>";
    echo "<input type='password' name='pass' /><br><br>";
    echo "<input type='submit' value='Login' />";
}
    if(empty($_POST["user"]))
    {
        userPass();
    }
    if(!(empty($_POST["user"])))
    {
        if($_POST["user"] == "comp")
        {
            echo "Welcome comp";
        }
        else
        {
            echo "Wrong user";
        }
    }
    ?>