<?php
//The Money variable is how much money we are starting with to break into change
$money = 57.69;
//$money = 45;
echo "<b>" .$money." dollars.</b><br>";
//We are taking the money times 100 so we aren't working with decimal points.
// Sometimes PHP gets weird with decimals.
$money = $money *100;
echo "<b> equivalent " .$money." cents.</b><br>";
//Twenty dollar bills
$twe = floor ($money/2000); echo "$twe twenty dollar bills <br>"; $money = $money - 2000*$twe;
//End twenty dollar bills
//Ten dollar bills
$ten = floor ($money/1000); echo "$ten ten dollar bills <br>"; $money = $money - 1000*$ten; //End ten dollar bills
//Five dollar bills
$five = floor ($money/500); echo "$five five dollar bills <br>"; $money = $money - 500*$five; //End five dollar bills
//One dollar bills
$one = floor ($money/100); echo "$one one dollar bills <br>"; $money = $money - $one*100; //End one dollar bills
//Quarters
$qua = floor ($money/25); echo "$qua quarters <br>"; $money = $money - 25*$qua;  //End quarters
//Dimes
$dime = floor ($money/10); echo "$dime dimes <br>"; $money = $money - 10*$dime; //End dimes
//Nickels
$nic = floor ($money/05); echo "$nic nickels <br>"; $money = $money - 05*$nic; //End nickels
//Pennies
$pen = floor ($money/01); echo "$pen pennies <br>"; $money = $money - 01*$pen; //End pennies
?>