<html>
<head>
    <title>Magic 8-Ball</title>
</head>
<body>
<h2>Magic 8-Ball</h2><p>
<?php
    function Qinput() {
        print "<form method='post' action=" . $_SERVER['PHP_SELF'] . ">";
        print "<p>  Question: <input type='text' name='question' />";
        print " <input type = 'submit' value = 'Ask' />";
        print " </form>";
    }

    if(empty($_POST["question"])) {
        Qinput();
    }
    else {
	$result = rand (1,8);
//Reminds them of their question
print "<p>Your question: ". $_POST["question"]. "</p>";
//Based on the random number, gives an answer
if ($result ==1)  {print "The 8-ball says: Yes";}
elseif ($result ==2)  {  print "The 8-ball says: No";  }
elseif ($result ==3)  {  print "The 8-ball says: Ask again later";  }
elseif ($result ==4)  {  print "The 8-ball says: Perhaps, perhaps, perhaps";  }
elseif ($result ==5)  {  print "The 8-ball says: The future is hazy";  }
elseif ($result ==6)  {  print "The 8-ball says: It is certain";  }
elseif ($result ==7)  {  print "The 8-ball says: Without a doubt";  }
elseif ($result ==8)  {  print "The 8-ball says: There is no chance";  }
    }

?>