<?php
# form.php, work together with login.php, content.php, logout.html, logout.php
session_start();
if(isset($_SESSION["usr"]) && isset($_SESSION["pswd"])){
    header("Location: content.php");
}
?>
<html>
<head>
    <title> PHP Login Example</title>
</head>
<body>

<form method="post" action="login.php">
    <table>
        <tr><td>Username:</td><td><input type="text" name="usr"></td></tr>
        <tr><td>Password:</td><td><input type="password" name="pswd"></td></tr>
        <tr><td><input type="submit" name="login" value="Login"></td>
            <td><input type="reset" name=”reset" value="Reset"></td></tr>
    </table>
</form>
</body>
</html>