<?php
# form.php, work together with login.php, content.php, logout.html, logout.php
session_start();
if($_REQUEST["usr"]=="abc" && $_REQUEST["pswd"]=="123"){
    $_SESSION["usr"] = "abc";
    $_SESSION["pswd"] = "123";
    header("Location: content.php");
 }
 else{
     //echo $_REQUEST["usr"];
     //echo "Something wrong";
    header("Location: loginForm.php");
 }
?>