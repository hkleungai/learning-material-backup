<?php
session_start();
if(!isset($_SESSION["usr"]) || !isset($_SESSION["pswd"])){
    header("Location: loginForm.php");
}
echo "Congratulations! You've successfully logged in.";
include "logout.html";

?>