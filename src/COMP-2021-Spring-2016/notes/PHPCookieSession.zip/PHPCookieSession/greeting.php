<?php
#greeting.php
$cookie_exp = time()+60*60; // one hour

# case 1: cookies already set
if(isset($_COOKIE["name"])) {
    $name = $_COOKIE["name"];
    setcookie("name", $name, $cookie_exp);
    if (isset($_COOKIE["visits"])) { $num_visits = $_COOKIE["visits"]+1;
        setcookie("visits", $num_visits, $cookie_exp);
    }
    echo "Welcome $name! ";
    if (isset($_COOKIE["visits"])) {
        echo "You've visited $num_visits times"; }
}
# case 2: upon submission of form
else if (isset($_GET["name"])) {
    $name = $_GET["name"];
    setcookie("name", $name, $cookie_exp);
    setcookie("visits", 2, $cookie_exp);
    echo "Welcome $name! This is your second visit.";
}
# case 3: first visit: need to show form
else {
    # HereDoc
    # Complex data types in strings must be surrounded by {} for them to be parsed as variables
    $form = <<< FORM
    <form action="{$_SERVER["PHP_SELF"]}" method="get">
        Enter your name here: <input type="text" name="name" />
<br /><input type="submit" />
</form>
FORM;
    echo $form;
}

?>