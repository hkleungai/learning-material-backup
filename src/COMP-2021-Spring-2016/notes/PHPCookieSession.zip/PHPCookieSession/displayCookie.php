<?php
if(isset($_POST['name'])) {
    setcookie($_POST['name'], $_POST['value'], time() + $_POST['expiration']);
}
?>

<html>
<head>
    <title>PHP Cookie Example</title>
</head>
<body>
<form name="form" method="post" action="">
    Cookie Name <input type="text" name="name" /> <br />
    Cookie Value <input type="text" name="value" /> <br />
    Cookie Expiration <input type="text" name="expiration" /> <br/>
    <input type="submit" />
</form>

<h2>Cookies on your machine:</h2>
<table border="1">
    <tr>
        <th style="text-align:left">Name</th>
        <th style="text-align:left">Value</th>
    </tr>
    <?php
    foreach ($_COOKIE as $key => $value) {
        echo "<tr><td>$key</td><td>$value</td></tr>";
    }
    if(isset($_POST['name'])) {
        echo "<tr><td>",$_POST['name'],"</td><td>",$_POST['value'],"</td></tr>";
    }
    ?>
</body>
</html>