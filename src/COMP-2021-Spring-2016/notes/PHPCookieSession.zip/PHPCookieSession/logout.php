<?php
# form.php, work together with login.php, content.php, logout.html, logout.php
session_start();
session_unset();
session_destroy();
header("Location: loginForm.php");
exit;
?>