<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
    <title>Password Encryption</title>
    <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
    <style type="text/css">
        <!--
        .style1 {
            font-size: 36px;
            font-weight: bold;
        }
        -->
    </style>
</head>
<body>
<form action="pwdEncryption.php" method="post">
    <table width="100%"  border="1">
        <tr>
            <td colspan="2"><span class="style1">My Diary </span></td>
        </tr>
        <tr>
            <td width="7%"> </td>
            <td width="93%"> </td>
        </tr>
        <tr>
            <td>User:</td>
            <td><input type="text" name="usr"></td>
        </tr>
        <tr>
            <td>Password:</td>
            <td><input type="password" name="pw"></td>
        </tr>
        <tr>
            <td> </td>
            <td><input type="submit" name="submit" value="submit"></td>
        </tr>
    </table>
</form>

<?php
# illustrate hash the password
if(isset($_POST['submit'])){
    $npass = MD5($_POST['pw']);
    echo "Here is the fingerprint of your password which is <br>";
    echo  "<b>User:<b> ".$_POST['usr']." <b>Password:<b> ".$_POST['pw']."  <b>Hash:</b> ".$npass;
}
?>
</body>
</html>
