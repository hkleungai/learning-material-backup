<?php
session_start();
# password is stored in pwdfile.txt
# if login successfully, show editor.php
$filename = "pwdfile.txt";

if(isset($_POST['submit'])) {
    $file = fopen($filename, "r") or exit("Password file does not exist");
    while (!feof($file)) {
        $line = fgets($file);
        # if there's such user
        if (strpos($line, $_POST['usr']) !== FALSE) {
            list($loginName, $hashPwd) = explode(",", $line);
            break;
        }
    }
    fclose($file);

    $storedPwd = md5($_POST['pw']);

    # debug information
    echo $loginName. " " . $hashPwd . " ". $storedPwd . " ";
    # compare password
    if (strcmp($hashPwd,$storedPwd)){
        echo "Successfully log in!";
        //header("location:editor.php");
    }
    else {
        echo "Try again!";
        //header("location:login.php");
    }
}
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
    <title>Encrypted Log-in</title>
    <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
    <style type="text/css">
        <!--
        .style1 {
            font-size: 36px;
            font-weight: bold;
        }
        -->
    </style>
</head>
<body>

<form action="login.php" method="post">
    <table width="100%"  border="1">
        <tr>
            <td colspan="2"><span class="style1">My Diary Login </span></td>
        </tr>
        <tr>
            <td width="14%"> </td>
            <td width="86%"> </td>
        </tr>
        <tr>
            <td>User</td>
            <td><input type="text" name="usr"></td>
        </tr>
        <tr>
            <td>Login:</td>
            <td><input type="password" name="pw"></td>
        </tr>
        <tr>
            <td> </td>
            <td><input type="submit" name="submit" value="submit"></td>
        </tr>
    </table>
</form>
</body>
</html>