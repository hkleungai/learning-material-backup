#ifndef LIST_H
#define LIST_H

#include <iostream>
using namespace std;

class Node {
public:
	double data; // data
	Node* next;  // pointer to next node
};


class List {
public:
	// constructor
	List(void){
		// Since the list is empty initially,
		// head is set to NULL
		head = NULL;
	}
	
	// destructor
	~List(void);
	
	// determine whether or not the list is empty
	bool IsEmpty(){
		return head == NULL;
	}
	
	// insert a new node at a particular position
	Node* InsertNode(int index, double x);

	// find a node with a given value
	int FindNode(double x);

	// delete a node with a given value
	int DeleteNode(double x);

	// print all the nodes in the list
	void DisplayList(void);

private:
	// head: a pointer to the first node in the list. 
	Node* head;

	// To let ListIterator access the private member head,
	// we make ListIterator as a friend of List
	friend class ListIterator;
};

#endif