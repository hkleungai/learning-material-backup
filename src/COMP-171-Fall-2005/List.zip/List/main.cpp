#include "List.h"
#include "ListIterator.h"

int main(void) {
	List list;
	// add items to the list
	list.InsertNode(0, 7.0);	
	list.InsertNode(0, 5.0);	
	list.InsertNode(0, 6.0);	
	list.InsertNode(1, 8.0);
	
	// print all the elements
	list.DisplayList();		
	ListIterator listIter;
	
	// postfix increment operator
	listIter.Reset(list);
	Node* node = listIter++;
	cout << "postfix: " << node->data << endl;

	// prefix increment operator
	listIter.Reset(list);
	node = ++listIter;
	cout << "prefix: " << node->data << endl;

	// iteratively traverse the list
	listIter.Reset(list);
	while (!listIter) {
		cout << *listIter << " ";
		listIter++;		
	}
	cout << endl;

	return 0;
}
