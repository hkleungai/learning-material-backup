#include <iostream>
#include "List.h"
using namespace std;

// ---------------------------------------------------------------
//  Use the destructor to release all the memory used by the list.
//  Step through the list and delete each node one by one.
// ---------------------------------------------------------------

List::~List(void) {
	Node* currNode = head;
	Node* nextNode = NULL;
	while (currNode != NULL)
	{
		nextNode = currNode->next;
		// destroy the current node
		delete currNode;	
		currNode = nextNode;
	}
}

// ----------------------------------------------------------------
//  Insert a node with data equal to x after the index'th elements.
//  If the insertion is successful, return the inserted node. 
//  Otherwise, return NULL. 
// ----------------------------------------------------------------

Node* List::InsertNode(int index, double x) {
	// Try to locate index�th node.
	// If it doesn�t exist, return NULL.
	if (index < 0)
		return NULL;
	
	int currIndex = 1;
	Node* currNode = head;
	while (currNode && index > currIndex) {
		currNode = currNode->next;
		currIndex++;
	}
	if (index > 0 && currNode == NULL)
		return NULL;
	
	// Create a new node
	Node* newNode = new	Node;
	newNode->data = x;

	// Insert as first element
	if (index == 0) {
		newNode->next = head;
		head = newNode;
	}
	else {
		// Insert after currNode
		newNode->next = currNode->next;
		currNode->next = newNode;
	}
	return newNode;
}


// ---------------------------------------------------------
//  Search for a node with the value equal to x in the list.
//  If such a node is found, return its position.
//  Otherwise, return 0.
// ---------------------------------------------------------

int List::FindNode(double x) {
	Node* currNode = head;
	int currIndex = 1;

	// Try to find the node with its value equal to x
	while (currNode && currNode->data != x) {
		currNode = currNode->next;
		currIndex++;
	}
	if (currNode)
		return currIndex;
	return 0;
}


// --------------------------------------------------------
//  Delete a node with the value equal to x from the list.
//  If such a node is found, return its position.
//  Otherwise, return 0.
// --------------------------------------------------------

int List::DeleteNode(double x) {
	Node* prevNode = NULL;
	Node* currNode = head;
	int currIndex = 1;

	// Find the desirable node (similar to FindNode)
	while (currNode && currNode->data != x) {
		prevNode = currNode;
		currNode = currNode->next;
		currIndex++;
	}

	// Release the memory occupied by the found node	
	// Set the pointer of the predecessor of the found node
	// to the successor of the found node
	if (currNode) {
		if (prevNode) {
			prevNode->next = currNode->next;
			delete currNode;
		}
		else {
			head = currNode->next;
			delete currNode;
		}
		return currIndex;
	}
	return 0;
}

// ------------------------------------
//  Print the data of all the elements 
// ------------------------------------
void List::DisplayList()
{
	int num = 0;
	Node* currNode = head;

	// print data of each node
	while (currNode != NULL){
		cout << currNode->data << endl;
		currNode = currNode->next;
		num++;
	}
	//  Print the number of the nodes in the list
	cout << "Number of nodes in the list: " << num << endl;
}