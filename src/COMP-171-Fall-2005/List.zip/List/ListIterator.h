#ifndef LISTITERATOR_H
#define LISTITERATOR_H

#include <iostream>
#include "List.h"
using namespace std;

class ListIterator {
public:
	// constructor
	ListIterator() {
		currNode = NULL;
	}

	// set currNode to the first node of the list
	// note: friend feature; head is private in List
	void Reset(List &pList) {
		currNode = pList.head;
	}

	// return data in the current node
	double operator*();

	// check whether currNode points to a valid node
	bool operator!();

	// advance to next node (postfix operator)
	Node* operator++(int);

	// advance to next node (prefix operator)
	Node* operator++();

private:
	Node* currNode;
};

#endif