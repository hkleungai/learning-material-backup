#include "ListIterator.h"

// ----------------------------------
//  returns data in the current node
// ----------------------------------

double ListIterator::operator*() {
	if (!currNode) {
		cout << "Error: the stack is empty." << endl;
		return -1;
	}
	return currNode->data;
}

// ---------------------------------
//  checks whether pointer is valid
// ---------------------------------

bool ListIterator::operator!() {
	return currNode != NULL;
}

// ---------------------------------------
//  prefix increment operator: ++listIter
// ---------------------------------------

Node* ListIterator::operator++(int) {
	// first return value, then increment
	Node* tempNode =  currNode;
	if (currNode)
		currNode = currNode->next;
	return tempNode;
}

// -----------------------------------------
//  postfix increment operator:  listIter++
// -----------------------------------------
Node* ListIterator::operator++() {
	// first increment, then return value
	if (currNode)
		currNode = currNode->next;
	return currNode;
}