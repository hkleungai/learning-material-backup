./vectorAdd_seq
./vectorAdd_gpu
