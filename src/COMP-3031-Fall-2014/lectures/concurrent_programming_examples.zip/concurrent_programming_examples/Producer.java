class Producer extends Thread {

	private Queue buffer;
	private int new_item = 0;

	public Producer(Queue que) { buffer = que; }

	public void run() {
		while (true) { //-- create a new_item
			new_item++; 
			System.out.println("Before depositing item " + new_item);
			buffer.deposit(new_item);
	  		System.out.println("After depositing "+new_item);
	  		try {
				sleep(1000);
	  		}
	  		catch (Exception e) {};
	 	}
	}
}
