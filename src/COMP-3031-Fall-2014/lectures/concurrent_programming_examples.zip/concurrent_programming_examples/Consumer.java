class Consumer extends Thread {

	private Queue buffer;

	public Consumer(Queue que) { buffer = que; }

	public void run() {
		int stored_item;
		while (true) {
			stored_item = buffer.fetch();
			//-- consume stored_item
			System.out.println("After consuming "+stored_item);
			try {
				sleep(2000);
			}
			catch (Exception e) {};
		}
	}
}
