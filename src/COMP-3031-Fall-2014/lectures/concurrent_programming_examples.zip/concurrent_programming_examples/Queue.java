class Queue {

	private int [] que;
	private int nextIn, nextOut, filled, queSize;

	public Queue(int size) {
		que = new int [size];
		filled = 0; nextIn = 0; nextOut = 0; queSize = size;
	}

	public synchronized void deposit (int item) {
		try {
			while (filled == queSize) wait();
			que [nextIn] = item; nextIn++; 
			nextIn = nextIn % queSize;
			System.out.println("item " + item + "enqueue");
			System.out.println("nextIn at "+nextIn);
			filled++; notifyAll();
		}
		catch (InterruptedException e) {}
	}

	public synchronized int fetch ( ) {
		int item = 0;
		try {
			while (filled == 0) wait();
			item=que[nextOut]; nextOut++; 
			nextOut = nextOut % queSize;
			System.out.println("item " + item + "dequeue");
			System.out.println("nextOut at "+nextOut);
			filled--; notifyAll();
		}
		catch (InterruptedException e) {}
	return item;
	}
} // end of Queue class
