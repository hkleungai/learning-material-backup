/*P1*/

p(a).
p(X):-p(X).

