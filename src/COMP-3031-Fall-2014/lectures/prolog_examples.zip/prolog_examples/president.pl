president(bush,usa).
president(lincoln,usa).
president(washington,usa).
