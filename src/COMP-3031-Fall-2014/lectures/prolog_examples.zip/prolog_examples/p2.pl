/*P2*/

p(X):-p(X).
p(a).
