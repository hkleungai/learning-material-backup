fun filter f [] = [] |
    filter f (head::tail) = if f head then head::filter f tail
                                        else filter f tail;
