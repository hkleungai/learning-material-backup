datatype 'a tree = empty_tree | leaf of 'a | node of 'a tree * 'a tree;

fun leafcount(empty_tree) = 0
| leafcount(leaf(x)) = 1
| leafcount (node(L,R)) = leafcount(L) + leafcount(R);

