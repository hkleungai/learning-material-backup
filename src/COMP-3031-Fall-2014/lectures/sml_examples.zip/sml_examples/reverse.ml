fun reverse_([], L2) = L2
|   reverse_(x::tail, L2) = reverse_(tail, x::L2);
fun reverse L = reverse_(L, []);

