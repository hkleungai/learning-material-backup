datatype expr = constant of int
| variable of string
|sum of expr *expr
| product of expr * expr;

val zero = constant 0;

val one = constant 1;

fun D x (constant _) = zero
| D (variable w) (variable z) = if w = z then one else zero
| D x (sum(e1,e2)) = sum (D x e1, D x e2)
| D x (product(e1,e2)) = let val term1 = product (D x e1, e2)
                             val term2 = product (D x e2, e1)
                         in sum (term1, term2) end;

