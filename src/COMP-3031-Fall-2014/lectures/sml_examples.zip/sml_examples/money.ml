datatype Money = nomoney 
| coin of int
| note10 of int
| note100 of int
| check of string*int;

fun amount nomoney = 0
| amount (coin(x)) = x
| amount (note10(x)) = 10*x
| amount (note100(x)) = 100*x
| amount (check(bank, x)) = x;
