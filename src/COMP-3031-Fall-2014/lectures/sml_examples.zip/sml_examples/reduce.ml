fun reduce f [] v = v
| reduce f (h::t) v = f (h, reduce f t v);
