#include <iostream>      /* File: test-lr-value.cpp */
using namespace std;

int main()
{
    int x;

    cout << ++++++x << endl;
    cout << x++++++ << endl;

    return 0;
}
