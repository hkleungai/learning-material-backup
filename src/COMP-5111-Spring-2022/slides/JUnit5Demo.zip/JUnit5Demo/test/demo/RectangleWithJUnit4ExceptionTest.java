package demo;

import static org.junit.Assert.*;
import org.junit.Test;

public class RectangleWithJUnit4ExceptionTest {  
	/*
	@Test
	public void testGetArea() { 
		Rectangle r1 = new Rectangle(4,4);
		double expected = 16;
		double actual = r1.getArea();
		assertEquals(expected, actual, tolerance);
	}
   */
	@Test(expected = IllegalArgumentException.class) // JUnit 4 Exception Checking
	public void testResize() {
		Rectangle r1 = new Rectangle(4,4); // 2. change this to -4 and comment throw in resize()
		double expectedHeight = 1;
		double expectedWidth = 8;
		r1.resize(-0.25, 2); // want to check if this method is properly implemented to throw exception
//     1. uncomment the throw exception in resize()
//		assertEquals(expectedHeight, r1.getHeight(), tolerance,"resize - height fails");
//		assertEquals(expectedWidth, r1.getWidth(), tolerance,"resize - width fails");
	}
/*
	@Test
	public void testGetPerimeter() {
		Rectangle r1 = new Rectangle();
		r1.setWidth(2);
		r1.setHeight(4);
		double expectedPerimeter = 12;
		double actualPerimeter = r1.getPerimeter();
		assertEquals(expectedPerimeter, actualPerimeter,tolerance);
		// assertEquals(actualObject.equals(expectedObject));
	}
*/
	final static double tolerance = 0.0001;
}
