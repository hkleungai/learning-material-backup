package demo;

//import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

@DisplayName("Upperlevel Rectangle Test")
class NestedLambdaAssertAllRectangleTest { 

	// Nest related test methods into the same inner class
	@Nested 
	@DisplayName("After creating a 4x4 rectangle")
	class AfterRectangleCreation {
		Rectangle r1;
		@BeforeEach void init() {
			r1 = new Rectangle(4,4);
		}
		@Test
		public void testGetArea() {
			double expected = 16;
			double actual = r1.getArea();
			assertEquals(expected, actual, tolerance, "getArea fails");
		}	
		@Test
		public void testResize() {
			double expectedHeight = 1;
			double expectedWidth = 8;
			r1.resize(0.25, 2);
			// All assertEquals will be tried out; try modified expectedHeight and expectedWidth to see the effect
			assertAll("dim",
			  () -> { assertEquals(expectedHeight, r1.getHeight(), tolerance, "resize - height fails"); },
			  () -> { assertEquals(expectedWidth, r1.getWidth(), tolerance, "resize - width fails"); }
			);
		}
	}

	@Test
	public void testGetPerimeter() {
		Rectangle r1 = new Rectangle();
		r1.setWidth(2);
		r1.setHeight(4);
		double expectedPerimeter = 12;
		double actualPerimeter = r1.getPerimeter();
		assertEquals(expectedPerimeter, actualPerimeter,tolerance,"getPerimeter fails");
		// assertEquals(actualObject.equals(expectedObject));
	}
	final static double tolerance = 0.0001;
}
