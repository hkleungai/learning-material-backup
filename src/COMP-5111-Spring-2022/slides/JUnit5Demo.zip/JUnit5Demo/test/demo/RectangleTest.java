package demo;

//import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.RepeatedTest;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;

@DisplayName("First Rectangle Test")
class RectangleTest {

	@BeforeAll
	static void setUpBeforeClass() throws Exception {
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
	}

	@BeforeEach
	void setUp() throws Exception {
	}

	@AfterEach
	void tearDown() throws Exception {
	}

    //@Tag("Small")
	@Test
	public void testGetArea() { 
		Rectangle r1 = new Rectangle(4,4);
		double expected = 16;
		double actual = r1.getArea();
		assertEquals(expected, actual, tolerance,"getArea fails");
	}

	@Test
	// @Tag("Small")
	public void testResize() {
		Rectangle r1 = new Rectangle(4,4);
		double expectedHeight = 1;
		double expectedWidth = 8;
		r1.resize(0.25, 2);
		assertEquals(expectedHeight, r1.getHeight(), tolerance,"resize - height fails");
		assertEquals(expectedWidth, r1.getWidth(), tolerance,"resize - width fails");
	}

//	@Test
//	@RepeatedTest(5) // repeat the test a number of times
//	public void testGetPerimeter() {
//		Rectangle r1 = new Rectangle(); 
//		double width = Math.random()*100;
//		double height = Math.random()*100;
//		r1.setWidth(width);
//		r1.setHeight(height);
//		double expectedPerimeter = 2*(width+height);
//		double actualPerimeter = r1.getPerimeter();
//		assertEquals(expectedPerimeter, actualPerimeter,tolerance,"getPerimeter fails");
//		// assertEquals(actualObject.equals(expectedObject));
//	}

	final static double tolerance = 0.0001;

}
