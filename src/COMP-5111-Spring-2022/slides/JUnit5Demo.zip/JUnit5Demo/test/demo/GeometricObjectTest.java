package demo;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

class GeometricObjectTest {

	@BeforeAll
	static void setUpBeforeClass() throws Exception {
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
	}

	@Test
	void testGetColor() {
		// fail("Not yet implemented");
	}

	@Test
	void testSetFilled() {
		// fail("Not yet implemented");
	}

	@Test
	void testGetArea() {
		// fail("Not yet implemented");
	}

}
