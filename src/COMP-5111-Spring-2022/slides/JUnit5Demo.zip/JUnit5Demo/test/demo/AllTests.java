package demo;

import org.junit.platform.runner.JUnitPlatform;
import org.junit.runner.RunWith;
import org.junit.platform.suite.api.SelectClasses;

@RunWith(JUnitPlatform.class)

@SelectClasses({ 
	GeometricObjectTest.class
	//, RectangleTest.class
	// , CircleTest.class
		//, RectanglePUTest.class
})

public class AllTests {

}
