package demo;

import org.junit.platform.runner.JUnitPlatform;
import org.junit.platform.suite.api.IncludeTags;
import org.junit.platform.suite.api.SelectClasses;
import org.junit.runner.RunWith;

@RunWith(JUnitPlatform.class)
//@IncludeTags("Small")
@SelectClasses({ 
	GeometricObjectTest.class
	, RectangleTest1.class
	, CircleTest.class
	, RectangleCircleTheoriesTest.class
	, RectangleJUnit4PUTest.class 
})
public class AllTests5 { 
}
