package demo;

public class Picture {
	GeometricObject [] objects = new GeometricObject [100];
	
	public static void main(String[] args){
		// put down what I am going to draw in the picture
	}
}
