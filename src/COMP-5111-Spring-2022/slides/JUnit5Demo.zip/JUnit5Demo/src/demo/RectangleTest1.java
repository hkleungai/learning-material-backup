package demo;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class RectangleTest1 {

	@BeforeAll
	static void setUpBeforeClass() throws Exception {
		// acquire resources for tests in the test class; executed only once before any tests in this test class
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
		// release acquired resources for tests in the test class; executed only once after all tests in this test clas
	}

	@BeforeEach
	void setUp() throws Exception {
		// executed before each test in this test class
	}

	@AfterEach
	void tearDown() throws Exception {
		// executed after each test in this test class
	}

	@Test
	void test() {
		fail("Not yet implemented");
	}

}
