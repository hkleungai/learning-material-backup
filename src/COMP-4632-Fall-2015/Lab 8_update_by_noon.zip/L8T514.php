<?php 

    function clean_args($arg){
        $arg = preg_replace("/<script[^>]*>/", "", $arg);
        $arg = preg_replace("/<\/script[^>]*>/", "", $arg);
        return $arg;
    }

    $arg = $_GET['arg'];
    if ( isset($arg)){
	print clean_args($arg);
    } else {
	print "<form action='L8T514.php'><textarea name='arg'></textarea><br><input type='submit' value='submit'></form>";
    }
?>

