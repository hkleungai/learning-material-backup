<?php
    session_start();
    include "mysql.php";
	$conn = FALSE;
	$rows = NULL;
	$errmsg = NULL;
	$rowkeys = NULL;
	if( isset($_POST['query']) ){
		$conn = dbOpen();
		if (!$conn) {
            $errmsg .= mysql_error()."<br />";
		}else{
			$sql = "";
			$sql .= "SELECT * FROM Dict WHERE Word = '";
			$sql .= $_POST['query'];
			$sql .= "'";
			$res = mysql_query($sql, $conn) or die ("Error:".mysql_error());
			if ($res) {
				$rows = array();
				while ($row = mysql_fetch_assoc($res)) {
					$rows[] = $row;
				}
				$rowkeys = array_keys($rows[0]);
				mysql_free_result($res);
			}
		}
		dbClose($conn);
	}
    $conn = FALSE;
?>
<!DOCTYPE html>
<html>
<head>
<title>HKUST Dictionary</title>
<style>
/* div container containing the form  */
#searchContainer {
	margin:20px;
}
/* Style the search input field. */
#query {
	float:left; 
	width:300px; 
	height:27px; 
	line-height:27px;
	text-indent:10px; 
	font-family:arial, sans-serif; 
	font-size:1em; 
	color:#333; 
	background: #fff; 
	border:solid 1px #d9d9d9; 
	border-top:solid 1px #c0c0c0; 
	border-right:none;
}
/* Style the "X" text button next to the search input field */
#delete {
	float:left; 
	width:16px;
	height:29px; 
	line-height:27px; 
	margin-right:15px; 
	padding:0 10px 0 10px;
	font-family: "Lucida Sans", "Lucida Sans Unicode",sans-serif;
	font-size:22px; 
	background: #fff;  
	border:solid 1px #d9d9d9; 
	border-top:solid 1px #c0c0c0; 
	border-left:none;
}
/* Set default state of "X" and hide it */
#delete #x {
	color:#A1B9ED; 
	cursor:pointer;
	display:none;
}
/* Set the hover state of "X" */
#delete #x:hover {
	color:#36c;
}
#submit {
	cursor:pointer; 
	width:70px; 
	height: 31px; 
	border: 1px solid #3079ED; 
	-moz-border-radius: 2px; 
	-webkit-border-radius: 2px; 
}
/* Style the search button hover state */
#submit:hover {
	#357AE8; 
	border: 1px solid #2F5BB7;
}
/* Clear floats */
.fclear {clear:both}
</style>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.4/jquery.min.js"></script>
</head>
<body>
	<h1>HKUST Dictionary</h1>
	<p>Enter any term and start searching, e.g. air, add, allowed, e.t.c.</p>
	
	<?php if ($errmsg) {echo "<p><font color=red>".$errmsg."</font></p>";} ?>
	
	<div id="searchContainer">
	<form method="POST" action="">
		<input id="query" name="query" type="text" />
		<div id="delete"><span id="x">x</span></div>
		<input id="submit" name="submit" type="submit" value="Search" />
	</form>
	</div>
	
	</br>
	</br>
	
	<?php if( isset($_POST['query']) ){	?>
	<table>
		<tr>
			<th>Word</th>
			<th>Homophones</th>
		</tr>
		<?php for ($x = 0; $x < count($rows); $x++) { ?>
		<tr>
			<td><?=$rows[$x][$rowkeys[0]];?></td>
			<td><?=$rows[$x][$rowkeys[1]];?></td>
		</tr>
		<?php } ?> 
	</table>	
	<?php } ?>
	
	<script>
		$(document).ready(function() {
			// if text input field value is not empty show the "X" button
			$("#query").keyup(function() {
				$("#x").fadeIn();
				if ($.trim($("#query").val()) == "") {
					$("#x").fadeOut();
				}
			});
			// on click of "X", delete input field value and hide "X"
			$("#x").click(function() {
				$("#query").val("");
				$(this).hide();
			});
		});
	</script>
</body>
</html>