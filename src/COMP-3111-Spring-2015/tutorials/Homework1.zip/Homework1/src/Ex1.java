
public class Ex1 {
	public static void main(String [] args){
		
		//Task 1
		System.out.println("Instruction to Software Engineering");
		
		//Task 2
		int a=4, b=3; 
		int sum; 
		sum = a + b; 
		System.out.println(sum);
	}

}
