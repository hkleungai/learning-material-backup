#include <iostream> /* File postoffice.cpp */
using namespace std;
#include "postoffice.h"
int main()
{
    cout << "Beginning of main\n";
    Postoffice x;
    cout << "End of main\n";
}
