#ifndef DEQUE_H
#define DEQUE_H

#include <iostream>
#include <sstream>

using namespace std;

template <typename T>
class BiLNode {
public:
    T data {};
    BiLNode *next {nullptr};
    BiLNode *prev {nullptr};
    BiLNode(T input) {
        data = input;
        next = nullptr;
        prev = nullptr;
    }
};

template <typename T>
class Deque
{
private:
    BiLNode<T> *head {nullptr};
    BiLNode<T> *tail {nullptr};
    int size {0};

  public:
    Deque() = default;
    ~Deque() {
        BiLNode <T>* tmp = head;
        while(tmp != nullptr) {
            tmp = tmp->next;
            delete head;
            head = tmp;
        }
    }

    void push_back(const T& value) {
        if(head == nullptr) {
            head = new BiLNode<T> (value);
            tail = head;
        } else {
            BiLNode<T> *tmp = new BiLNode<T> (value);
            tmp->prev = tail;
            tail->next = tmp;
            tail = tmp;
        }
        size++;
    }

    void push_front(const T& value) {
        if(head == nullptr) {
            head = new BiLNode<T> (value);
            tail = head;
        } else {
            BiLNode<T> *tmp = new BiLNode<T> (value);
            tmp->next = head;
            head->prev = tmp;
            head = tmp;
        }
        size++;
    }

    T pop_back() {
        if (head == nullptr) {
            cout << "Nothing in deque!";
        }
        if (head->next == nullptr) {
            T tmp = head->data;
            delete head;
            head = nullptr;
            size--;
            return tmp;
        }
        T tmp = tail->data;
        BiLNode<T> *bftail = tail->prev;
        delete tail;
        tail = bftail;
        tail->next = nullptr;
        size--;
        return tmp;
    }

    T pop_front() {
        if (head == nullptr) {
            cout << "Nothing in deque!";
        }
        if (head->next == nullptr) {
            T tmp = head->data;
            delete head;
            head = nullptr;
            size--;
            return tmp;
        }
        T tmp = head->data;
        BiLNode<T> *afhead = head->next;
        delete head;
        head = afhead;
        head->prev = nullptr;
        size--;
        return tmp;
    }

    void clear() {
        while(size>0) pop_back();
    }

    // TODO 1: overload operator==
    bool operator==(const Deque<T>& other) const {
        if (size != other.size) return false;
        BiLNode<T> *thisHead = head;
        BiLNode<T> *otherHead = other.head;
        while (thisHead != nullptr && otherHead != nullptr) {
            if (thisHead->data != otherHead->data) return false;
            thisHead = thisHead->next;
            otherHead = otherHead->next;
        }
        return true;
    }

    // TODO 2: overload operator=
    Deque<T>& operator=(const Deque<T>& other) {
        clear();
        BiLNode<T> *tmp = other.head;
        while(tmp != nullptr) {
            push_back(tmp->data);
            tmp = tmp->next;
        }
        return *this;
    }

    // TODO 3: overload operator+
    Deque<T> operator+(const Deque<T>& other) const {
        Deque<T> sumDeque;
        BiLNode<T> *tmp = head;
        while(tmp != nullptr) {
            sumDeque.push_back(tmp->data);
            tmp = tmp->next;
        }
        tmp = other.head;
        while(tmp != nullptr) {
            sumDeque.push_back(tmp->data);
            tmp = tmp->next;
        }
        return sumDeque;
    }

    // TODO 4: overload operator<<
	friend ostream& operator<<(ostream& os, const Deque<T>& deque){
        // return (os << '['  << deque.str() << ']' << endl);
        os << "[";
        BiLNode<T> * tmp = deque.head;
        if (tmp == nullptr) {
            return (os << "]");
        }
        while(tmp->next!=nullptr) {
            os << tmp->data << "<-->";
            tmp = tmp->next;
        }
        os << tmp->data << "]";
        return os;
	}
};

#endif
