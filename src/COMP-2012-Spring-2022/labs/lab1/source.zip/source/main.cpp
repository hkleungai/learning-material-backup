#include "openningMessage.h"

int main() {
    sayHello();
    return 0;
}