#include <iostream>

using namespace std;

int sayHello() {
    cout << "Hello, visitors!" << endl;
    cout << "Welcome to HKUST 30th Anniversary!" << endl;
    return 0;
}