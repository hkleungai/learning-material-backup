#include <string>
#include <iostream>
#include "Vehicle.h"
#include "ParkingLot.h"
using namespace std;

//TODO: complete declaration of Truck