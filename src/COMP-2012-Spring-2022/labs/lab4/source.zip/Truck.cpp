#include "Truck.h"

//TODO: complete the constructor and all member functions of Truck