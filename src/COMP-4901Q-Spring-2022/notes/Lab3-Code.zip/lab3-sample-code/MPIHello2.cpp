#include <stdio.h>
#include <string.h> 
#include <mpi.h>

int main(int argc, char *argv[]) {
   int MAX_STRING = 100;
   char greeting[MAX_STRING];
   int number_of_processes; 
   int rank;
   MPI_Init(&argc, &argv);
   MPI_Comm_size(MPI_COMM_WORLD, &number_of_processes); 
   MPI_Comm_rank(MPI_COMM_WORLD, &rank); 
   if (rank != 0) { 
      sprintf(greeting, "Greetings from process %d of %d!", 
            rank, number_of_processes);
      MPI_Send(greeting, strlen(greeting)+1, MPI_CHAR, 0, 0,
            MPI_COMM_WORLD); 
   } else {  
      printf("Greetings from process %d of %d!\n", rank, number_of_processes);
      for (int q = 1; q < number_of_processes; q++) {
         MPI_Recv(greeting, MAX_STRING, MPI_CHAR, q,
            0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
         printf("%s\n", greeting);
      } 
   }
   MPI_Finalize(); 
   return 0;
} 
