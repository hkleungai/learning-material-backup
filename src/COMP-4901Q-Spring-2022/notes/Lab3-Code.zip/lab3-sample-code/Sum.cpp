// Program that computes the sum of an array of elements in parallel using
// MPI_Reduce.
//
#include <stdio.h>
#include <stdlib.h>
#include <mpi.h>
#include <assert.h>
#include <math.h>
#include <time.h>

int main(int argc, char **argv)
{
    int n, number_of_processes, rank;
    double *a, start_time;
    MPI_Init(&argc, &argv);

    MPI_Comm_size(MPI_COMM_WORLD, &number_of_processes);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);

    if (rank == 0) {
        printf("Please input n:\n");
        scanf("%d",&n);
        a = new double[n];
        for (int i = 0; i<n; i++) {
            a[i] = i % 10 + 1;
        }
    }
    start_time = MPI_Wtime();
    MPI_Bcast(&n, 1, MPI_INT, 0, MPI_COMM_WORLD);

    if (rank != 0) {
        a = new double[n];
    }

    MPI_Bcast(a, n, MPI_DOUBLE, 0, MPI_COMM_WORLD);

    int elements_per_process = ceil(n * 1.0 / number_of_processes);
    int init = elements_per_process * rank;
    double local_sum = 0;
    for (int i = init; i < init + elements_per_process && i < n; i++)
        for (int j = 0; j < n; j++)
            local_sum += a[i] / a[j];

    // Print the random numbers on each process
    printf("Local sum for process %d - %f\n",
            rank, local_sum);

    // Reduce all of the local sums into the global sum
    double global_sum;
    MPI_Reduce(&local_sum, &global_sum, 1, MPI_DOUBLE, MPI_SUM, 0,
                MPI_COMM_WORLD);

    // Print the result
    if (rank == 0)
    {
        printf("Total sum = %f\n", global_sum);
        double finish_time = MPI_Wtime();
        printf("Elapsed time is %f seconds\n", finish_time-start_time);
    }
    delete a;
    MPI_Barrier(MPI_COMM_WORLD);
    MPI_Finalize();
    return 0;
}