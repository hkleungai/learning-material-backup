#include <iostream> /* COMP2011 Lab 7: utils.cpp */
#include <cstring>
#include "my_include.h"

/* Task One */
void swap(double &x, double &y)
{
   double temp = x;
   x = y;
   y = temp;
}

// A function to implement bubble sort
void bubbleSort(double arr[], int n, bool ascending)
{
   int i, j;
   for (i = 0; i < n-1; i++)   
   
   // Last i elements are already in place
   for (j = 0; j < n-i-1; j++)
      if (ascending) {
         if (arr[j] > arr[j+1])
         swap(arr[j], arr[j+1]);
      }
      else {
         if (arr[j] < arr[j+1])
         swap(arr[j], arr[j+1]);
      }
}

/* Task Two */
void swap(char x[], char y[])
{
   char temp[MAX_ARRAY_LENGTH+1];
   strcpy(temp, x);
   strcpy(x, y);
   strcpy(y, temp);
}

// A function to implement bubble sort
void bubbleSort(char arr[][MAX_ARRAY_LENGTH+1], int n, bool ascending)
{
   int i, j;
   for (i = 0; i < n-1; i++)   
   
   // Last i elements are already in place
   for (j = 0; j < n-i-1; j++) {
      if (ascending) {
         if ( strcmp(arr[j] , arr[j+1]) > 0 )
         swap(arr[j], arr[j+1]);
      }
      else {
         if ( strcmp(arr[j] , arr[j+1]) < 0 )
         swap(arr[j], arr[j+1]);
      }

      
   
   }
}


/* Given Functions */
void printArray(const double arr[], int size)
{
   for (int i = 0; i < size; i++)
      cout << arr[i] << " ";
   cout << endl;
}

void printArray(const char arr[][MAX_ARRAY_LENGTH+1], int size)
{
   for (int i = 0; i < size; i++)
      cout << arr[i] << endl;
   cout << endl;
}

