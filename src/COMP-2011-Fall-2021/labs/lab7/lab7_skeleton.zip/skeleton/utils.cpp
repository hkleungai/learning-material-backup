#include <iostream> /* COMP2011 Lab 7: utils.cpp */
#include <cstring>
#include "my_include.h"


/* Task One */
void bubbleSort(double arr[], int n, bool ascending)
{
   
}



/* Task Two */
void bubbleSort(char arr[][MAX_ARRAY_LENGTH+1], int n, bool ascending)
{
   
}



/* Given Functions */
void printArray(const double arr[], int size)
{
   for (int i = 0; i < size; i++)
      cout << arr[i] << " ";
   cout << endl;
}

void printArray(const char arr[][MAX_ARRAY_LENGTH+1], int size)
{
   for (int i = 0; i < size; i++)
      cout << arr[i] << endl;
   cout << endl;
}

