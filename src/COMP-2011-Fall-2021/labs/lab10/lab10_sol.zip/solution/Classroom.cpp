#include "Classroom.h"
#include <cstring>
#include <iostream>
using namespace std;

//====================
//Implementation of the constructor
//Task 2: Implement the constructor
//  Copy ID and q to room_ID and quota, respectively
//  Initialize app_list and exam_list via 'new Course [MAX_NUM_COURSE_APP]'
//  Set num_app and num_exams to 0
Classroom::Classroom(char *ID, int q)
{
    room_ID = new char [strlen(ID)+1];
    strcpy(room_ID, ID);

    quota = q;

    app_list = new Course [MAX_NUM_COURSE_APP];
    exam_list = new Course [MAX_NUM_COURSE_APP];
    num_app = 0;
    num_exams = 0;

}
//Implementaton of the destructor
Classroom::~Classroom()
{
    delete [] app_list;
    delete [] exam_list;
    delete [] room_ID;
}

//===================
//Implementation of the accessor functions
char* Classroom::get_room_ID()
{
    return room_ID;
}

int Classroom::get_quota() const
{
    return quota;
}

Course* Classroom::get_app_list()
{
    return app_list;
}

Course* Classroom::get_exam_list()
{
    return exam_list;
}

int Classroom::get_num_exams()
{
    return num_exams;
}

//Task 3: Implement the member function receive_app()
//  If the number of students of Course c is less than or equal to the quota of the classroom 
//  Add the c to app_list and increment num_app
void Classroom::receive_app(Course c)
{
    if(c.get_num_stu()<=quota)
    {
        app_list[num_app] = c;
        ++num_app;
    }
}

//Task 4: Implement the member function gen_time_table() using the greedy algorithm
//  Step 1: Sort the app_list according to the courses' end_time
//  Step 2: From the beginning of app_list,
//          if a course (in app_list) has no time conflicts with those courses already added in exam_list,
//          add it to exam_list and increment num_exams 
void Classroom::gen_timetable()
{
    //Step 1
    for(int i=1;i<num_app;i++)
    {
        for(int j=0;j<i;j++)
        {
            int end_i = app_list[i].get_end_time();
            int end_j = app_list[j].get_end_time();
            if(end_j>end_i)
            {
                Course temp = app_list[i];
                app_list[i] = app_list[j];
                app_list[j] = temp;
            }
        }
    }
    //Step 2
    exam_list[num_exams] = app_list[0];
    ++num_exams;
    int pre_end_time = app_list[0].get_end_time();
    for(int i=1;i<num_app;i++)
    {
        int cur_start_time = app_list[i].get_start_time();
        int cur_end_time = app_list[i].get_end_time();
        if(cur_start_time>pre_end_time)
        {
            exam_list[num_exams] = app_list[i];
            ++num_exams;
            pre_end_time = cur_end_time;
        }
    }
}

void Classroom::print_timetable()
{
    cout<<"========================================"<<endl;
    cout<<"Final Week Time Table of "<<room_ID<<endl;
    cout<<"========================================"<<endl;
    cout<<" Course ID\tCourse Name\tTime\t#Students"<<endl;
    for(int i=0; i<num_exams;i++)
    {
        Course c = exam_list[i];
        cout<<i<<" "<<c.get_course_ID()<<" "<<c.get_course_name()<<" "<<c.get_start_time()
            <<"--"<<c.get_end_time()<<" "<<c.get_num_stu()<<endl;
    }
    cout<<"========================================"<<endl;
    cout<<"Number of (Valid) Applications: "<<num_app<<endl;
    cout<<"Number of Exams: "<<num_exams<<endl;
}