#include <iostream>
#include <cstring>
#include "cleaning_robot.h"
using namespace std;

/*
   *    COMP 2011 2021 Fall Programming Assignment 2
   *    Student Name        : 
   *    Student ID          :
   *    Student ITSC email  :        
   * 
   * You are not allowed to use extra library
*/

// Please do all your work in this file. You just need to submit this file.

