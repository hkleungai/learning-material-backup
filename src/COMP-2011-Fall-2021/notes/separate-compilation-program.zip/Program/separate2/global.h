/* File: global.h */
/* Global variable definitions */
int num_calls;
