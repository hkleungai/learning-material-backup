#include "ChessGame.h"

int main() {
	ChessGame chessGame;
	chessGame.startConsoleUI();

	return 0;
}
