#include "student_linked_list.h"
#include <algorithm>
using namespace std;

void print_student_list(const Student_List& student_list, bool reverse) {
  if (student_list.size == 0) {
    cout << "Student List is empty!" << endl;
  }

  if (!reverse) {
    for (Student_Node* current = student_list.head; current != nullptr; current = current->next) {
      print_student(current->student);
    }
  }
  else {
    for (Student_Node* current = student_list.tail; current != nullptr; current = current->prev) {
      print_student(current->student);
    }
  }
}

/* 
 * Task 4
 * Implement the insert_student() and delete_student() functions for the Student Linked List.
 * For insert(), the new node should be inserted before the index node, or at the end of the linked list if (index == student_list.size).
 * For delete(), the node at index should be deleted.
 * Remember to handle the special case of head/tail.
 * Also update student_list.head and/or student_list.tail if required, as well as student_list.size.
 * You can assume that index is always within valid range.
 */

void insert_student(Student_List& student_list, const Student& student, int index) {
  if ((index < 0) || (index > student_list.size)) {
    return;
  }
  // ADD YOUR CODE HERE
  Student_Node* current = student_list.head;
  Student_Node* new_student = new Student_Node;
  new_student->student = student;

  ++student_list.size;

  // special case: insert at beginning
  if (index == 0 || student_list.head == nullptr)
  {
	  new_student->next = student_list.head;
	  if (student_list.head != nullptr)
		  student_list.head->prev = new_student;
	  student_list.head = new_student;

	  return;
  }

  for (int pos = 0; pos < index-1 && current != nullptr; current = current->next, ++pos); //find the node after which the new node is to be added

  new_student->next = current->next;
  new_student->prev = current;
  current->next = new_student;

  if (new_student->next != nullptr)
  	  (new_student->next)->prev = new_student;
  else
	  student_list.tail = new_student;

}

void delete_student(Student_List& student_list, int index) {
  if ((index < 0) || (index >= student_list.size)) {
    return;
  }
  // ADD YOUR CODE HERE	
  Student_Node* current = student_list.head;

  --student_list.size;

  // special case: delete at beginning
  if (index == 0)
  {
	  student_list.head = student_list.head->next;
	  if (student_list.head != nullptr)
		  student_list.head->prev = nullptr;
	  delete current;
	  current = nullptr;

	  return;
  }

  for (int pos = 0; pos < index && current != nullptr; current = current->next, ++pos); //find the node to be deleted

  (current->prev)->next = current->next;

  if (current->next != nullptr)
	  (current->next)->prev = current->prev;
  else
	  student_list.tail = current->prev;

  delete current;
  current = nullptr;

  return;
}

/* 
 * Task 5
 * Swap the nodes located at index1 and index2.
 * Update their next/prev pointers, as well as their neighbors.
 * Remember to handle the special case of index1 and/or index2 being the head and/or tail.
 * Also special case if they are adjacent nodes.
 * Also update student_list.head and/or student_list.tail if required.
 * You can assume that index1 and index2 are always within valid range.
 * To simplify your code, swap index1 and index2 if index2 is smaller than index1.
 * If index1 == index2, do nothing.
 */

void swap_student(Student_List& student_list, int index1, int index2) {
  if ((index1 < 0) || (index2 < 0) || (index1 >= student_list.size) || (index2 >= student_list.size) || (index1 == index2)) {
    return;
  }

  // Make sure that index1 is always smaller than index2, to simplify our code.
  if (index1 > index2) {
    int temp = index1;
    index1 = index2;
    index2 = temp;
  }

  // ADD YOUR CODE HERE
  Student_Node* left = student_list.head;
  Student_Node* right = student_list.head;
  Student_Node* temp;

  for (int i = 0; i < index1 && left != nullptr; left = left->next, ++i);
  for (int i = 0; i < index2 && right != nullptr; right = right->next, ++i);

  temp = left->next;
  left->next = right->next;
  right->next = temp;

  if (left->next != nullptr)
	  left->next->prev = left;
  else
	  student_list.tail = left;

  if (right->next != nullptr)
	  right->next->prev = right;

  temp = left->prev;
  left->prev = right->prev;
  right->prev = temp;

  if (left->prev != nullptr)
	  left->prev->next = left;

  if (right->prev != nullptr)
	  right->prev->next = right;
  else
	  student_list.head = right;

}

/* 
 * Task 6
 * Delete the whole Student Linked List.
 * Make sure to delete all the nodes in the list.
 * Also remember to reset student_list.head and student_list.prev to nullptr.
 */

void delete_student_list(Student_List& student_list) {
  if (student_list.size == 0) {
    return;
  }

  // ADD YOUR CODE HERE
  Student_Node* current = student_list.head;
  while (student_list.head != nullptr)
  {
	  current = student_list.head;
	  student_list.head = student_list.head->next;

	  delete current;
  }

  student_list.head = nullptr;
  student_list.tail = nullptr;
  student_list.size = 0;
}

/* 
 * Bonus Task
 * You may use the swap() function that you have implemented in Task 5.
 * sort_options can be used as an argument to a switch-case statement.
 * Names should be sorted by alphanumeric order, you may use the <algorithm> library function lexicographical_compare() for the strings.
 * Gender is sorted as MALE first, FEMALE second.
 * ID, Age, and CGPA are both sorted by ascending numerical order.
 * If the student_list only has 0 or 1 elements, then do nothing.
 * For simplicity, you may use the Bubble Sort algorithm, which is inefficient but straightforward to code.
 */

void sort_student_list(Student_List& student_list, Sort_Options sort_options) {
  if ((student_list.size == 0) || (student_list.size == 1))
    return;

  // ADD YOUR CODE HERE
  int n = student_list.size;
  bool sorted = true;

  switch (sort_options)
  {
  	  case NAME:
		  do
		  {
			  sorted = true;

			  for (int i = 1; i < n; i++)
			  {
				  Student_Node* curr = student_list.head;
				  for (int j = 0; j < i && curr != nullptr; curr = curr->next, ++j) //dirty hack, could have been done in the first for, fix if have time
					  ;

				  if (lexicographical_compare(curr->student.name.begin(), curr->student.name.end(),
						  curr->prev->student.name.begin(), curr->prev->student.name.end()))
				  {
					  swap_student(student_list, i-1, i);
					  sorted = false;
				  }

			  }

			  --n;
		  } while (!sorted);
		  break;
  	  case GENDER:
		  do
		  {
			  sorted = true;

			  for (int i = 1; i < n; i++)
			  {
				  Student_Node* curr = student_list.head;
				  for (int j = 0; j < i && curr != nullptr; curr = curr->next, ++j)
					  ;

				  if (curr->prev->student.gender > curr->student.gender)
				  {
					  swap_student(student_list, i-1, i);
					  sorted = false;
				  }

			  }

			  --n;
		  } while (!sorted);
		  break;
  	  case ID:
		  do
		  {
			  sorted = true;

			  for (int i = 1; i < n; i++)
			  {
				  Student_Node* curr = student_list.head;
				  for (int j = 0; j < i && curr != nullptr; curr = curr->next, ++j)
					  ;

				  if (curr->prev->student.id > curr->student.id)
				  {
					  swap_student(student_list, i-1, i);
					  sorted = false;
				  }

			  }

			  --n;
		  } while (!sorted);
		  break;
  	  case AGE:
		  do
		  {
			  sorted = true;

			  for (int i = 1; i < n; i++)
			  {
				  Student_Node* curr = student_list.head;
				  for (int j = 0; j < i && curr != nullptr; curr = curr->next, ++j)
					  ;

				  if (curr->prev->student.age > curr->student.age)
				  {
					  swap_student(student_list, i-1, i);
					  sorted = false;
				  }

			  }

			  --n;
		  } while (!sorted);
		  break;
  	  case CGPA:
		  do
		  {
			  sorted = true;

			  for (int i = 1; i < n; i++)
			  {
				  Student_Node* curr = student_list.head;
				  for (int j = 0; j < i && curr != nullptr; curr = curr->next, ++j)
					  ;

				  if (curr->prev->student.cgpa > curr->student.cgpa)
				  {
					  swap_student(student_list, i-1, i);
					  sorted = false;
				  }

			  }

			  --n;
		  } while (!sorted);
		  break;
  }
}
