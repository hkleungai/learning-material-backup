#include "student.h"

void print_student(const Student& student) {
  cout << "Name: " << student.name << "\n"
       << "Gender: " << ((student.gender == MALE) ? "Male" : "Female") << "\n"
       << "ID: " << student.id << "\n"
       << "Age: " << student.age << "\n"
       << "CGPA: " << student.cgpa << "\n"
       << "\n";
}

/* 
 * Task 1 - Passing arguments by reference and as pointers
 * "." operator for member access directly.
 * "->" operator for member access via pointer.
 */

void initialize_student_by_reference(Student& student, string name, Gender gender, int id, int age, double cgpa) {
  // ADD YOUR CODE HERE
	student.name = name;
	student.gender = gender;
	student.id = id;
	student.age = age;
	student.cgpa = cgpa;

	return;
}

void initialize_student_by_pointer(Student* student, string name, Gender gender, int id, int age, double cgpa) {
  // ADD YOUR CODE HERE
	student->name = name;
	student->gender = gender;
	student->id = id;
	student->age = age;
	student->cgpa = cgpa;

	return;
}

void swap_student_by_reference(Student& student1, Student& student2) {
  // ADD YOUR CODE HERE
	Student temp = student1;
	student1 = student2;
	student2 = temp;

	return;
}

void swap_student_by_pointer(Student* student1, Student* student2) {
  // ADD YOUR CODE HERE
	Student temp = *student1;
	*student1 = *student2;
	*student2 = temp;

	return;
}
