#include "Queue_Linked_List.h"

void queue_linked_list_enqueue(Queue_Linked_List& queue, Person* person) {
	Node* incoming_person_node = new Node;
	incoming_person_node->person = person;

	if (queue.front == nullptr) {
		queue.front = queue.back = incoming_person_node;
	}
	else {
		queue.back = queue.back->next = incoming_person_node;
	}

	// C++11 doesn't allow brace-initialization of structs with default member initializations, but C++14 and above does.
	/*if (queue.front == nullptr) {
		queue.front = queue.back = new Node{person, nullptr};
	}
	else {
		queue.back = queue.back->next = new Node{person, nullptr};
	}*/
}

void queue_linked_list_dequeue(Queue_Linked_List& queue) {
	if (!queue_linked_list_is_empty(queue)) {
		Node* former_front = queue.front;
		queue.front = queue.front->next;
		if (queue.back == former_front) {
			queue.back = nullptr;
		}
		destroy_person(former_front->person);
		delete former_front;
	}
}

const Person* queue_linked_list_front(const Queue_Linked_List &queue) {
	return queue_linked_list_is_empty(queue) ? nullptr : queue.front->person;
}

bool queue_linked_list_is_empty(const Queue_Linked_List &queue) {
	return queue.front == nullptr;
}
