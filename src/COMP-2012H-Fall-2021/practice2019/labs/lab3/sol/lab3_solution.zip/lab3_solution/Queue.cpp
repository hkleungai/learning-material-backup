#include "Queue.h"

// For efficient performance and memory usage, we double the capacity whenever the array is full, and halve the capacity whenever the array is 1/4 full.

void reallocate_queue_array(Queue& queue, unsigned int new_capacity) {
	Person** new_queue_array = new Person*[new_capacity];
	for (unsigned int index = 0; index < queue.size; ++index) {
		new_queue_array[index] = queue.arr[index];
	}
	delete[] queue.arr;

	queue.arr = new_queue_array;
	queue.capacity = new_capacity;
}

void queue_enqueue(Queue& queue, Person* person) {
	if (queue.size >= queue.capacity) {
		reallocate_queue_array(queue, ((queue.capacity == 0) ? 1 : 2*queue.capacity));
	}

	queue.arr[queue.size] = person;
	queue.size += 1;
}

void queue_dequeue(Queue& queue) {
	if (!queue_is_empty(queue)) {
		destroy_person(queue.arr[0]);
		queue.size -= 1;

		for (unsigned int index = 0; index < queue.size; ++index) {
			queue.arr[index] = queue.arr[index + 1];
		}

		if (queue.size <= queue.capacity/4) {
			reallocate_queue_array(queue, queue.capacity/2);
		}
	}
}

const Person* queue_front(const Queue& queue) {
	return queue_is_empty(queue) ? nullptr : queue.arr[0];
}

bool queue_is_empty(const Queue& queue) {
	return queue.size == 0;
}

void destroy_queue(Queue& queue) {
//	// This is slow, since we are shifting every array element as we dequeue.
//	while (!queue_is_empty(queue)) {
//		queue_dequeue(queue);
//	}
//	delete[] queue.queue_array;
//
//	queue.queue_array = nullptr;
//	queue.queue_capacity = 0;

	// This is faster, since we don't waste time shifting the array elements as we delete them.
	for (unsigned int index = 0; index < queue.size; ++index) {
		destroy_person(queue.arr[index]);
	}
	delete[] queue.arr;

	queue.arr = nullptr;
	queue.size = 0;
	queue.capacity = 0;
}
