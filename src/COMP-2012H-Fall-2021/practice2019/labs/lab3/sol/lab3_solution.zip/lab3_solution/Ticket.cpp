#include "Ticket.h"

void print_ticket(const Ticket& ticket) {
	cout << "  Movie name: " << ticket.movie << endl;
	cout << "  Ticket class: " << (ticket.ticket_class == STANDARD ? "Standard" :
									ticket.ticket_class == PREMIUM ? "Premium" :
									ticket.ticket_class == GOLD ? "Gold" :
									"Platinum") << endl;
}

void initialize_ticket_by_reference(Ticket& ticket, string movie, TicketClass ticket_class) {
	ticket.movie = movie;
	ticket.ticket_class = ticket_class;
}

void initialize_ticket_by_pointer(Ticket* ticket, string movie, TicketClass ticket_class) {
	if (ticket != nullptr) {
		ticket->movie = movie;
		ticket->ticket_class = ticket_class;
	}
}

void swap_tickets_by_reference(Ticket& ticket1, Ticket& ticket2) {
	Ticket temp = ticket1;
	ticket1 = ticket2;
	ticket2 = temp;
}

void swap_tickets_by_pointer(Ticket* ticket1, Ticket* ticket2) {
	if ((ticket1 != nullptr) && (ticket2 != nullptr)) {
		Ticket temp = *ticket1;
		*ticket1 = *ticket2;
		*ticket2 = temp;
	}
}

Ticket* create_ticket(string movie, TicketClass ticket_class) {
//	Ticket* ticket = new Ticket;
//	initialize_ticket_by_pointer(ticket, movie, ticket_class);
//	return ticket;

	return new Ticket{movie, ticket_class};
}

void destroy_ticket(Ticket* ticket) {
	delete ticket; // delete does nothing on nullptr. No need to set ticket to nullptr in this function, as this ticket argument only exists inside this function.
}
