#include "Person.h"

void print_person(const Person& person) {
	cout << "Name: " << person.name << endl
		<< "Age: " << person.age << endl
		<< "Gender: " << (person.gender == MALE ? "Male" : "Female") << endl;
	if (person.ticket != nullptr) {
		cout << "Ticket: " << endl;
		print_ticket(*person.ticket);
	}
}

Person* create_person(string name, int age, Gender gender) {
	Person* person = new Person;
	person->name = name;
	person->age = age;
	person->gender = gender;
	person->ticket = nullptr;
	return person;

	//return new Person(name, age, gender, nullptr); // Not valid in C++11 because Person has a default member initializer, but valid in C++14 and above.
}

Person* create_person_with_ticket(string name, int age, Gender gender, string movie, TicketClass ticket_class) {
	Person* person = create_person(name, age, gender);
	person->ticket = create_ticket(movie, ticket_class);
	return person;

	//return new Person{name, age, gender, create_ticket(movie, ticket_class)}; // Not valid in C++11 because Person has a default member initializer, but valid in C++14 and above.
}

void destroy_person(Person* person) {
	if (person != nullptr) {
		destroy_ticket(person->ticket);
	}
	delete person; // No need to set person to nullptr, as this person argument only exists inside this function.
}