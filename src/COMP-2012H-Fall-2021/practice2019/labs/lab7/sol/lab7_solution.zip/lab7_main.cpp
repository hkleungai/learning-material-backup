/*
 * lab7_main.cpp
 * Grading file containing test cases for Lab 7
 * Please do not modify any section of this file not marked with "NOTE"!
 */
#include <iostream>
#include <string>
#include <chrono>

#include "Deque.h"

// Auxillary definitions for testing
void expect(bool condition) { std::cout << (condition ? "Test Passed" : "Test Failed") << std::endl; }
template <typename T>
void assert_equals(T expected, T actual) { expect(actual == expected); }
struct Int32 { int value; };
bool operator==(const Int32 &m, const Int32 &n) { return m.value == n.value; }
bool operator!=(const Int32 &m, const Int32 &n) { return !(m == n); }

// Test cases for main task
void main_task_test_cases() {
  std::cout << "Test Cases for Main Task" << std::endl << std::endl;
  // Correctness tests
  std::cout << "Part I: Correctness Tests" << std::endl << std::endl;
  std::cout << "Testing Deque<T>::Deque(), Deque<T>::is_empty() and Deque<T>::get_num_elements() ..." << std::endl;
  Deque<int> deque;
  expect(deque.is_empty());
  assert_equals(size_t {0}, deque.get_num_elements());
  std::cout << std::endl;
  std::cout << "Testing Deque<T>::push_back(), Deque<T>::operator[](), Deque<T>::front() and Deque<T>::back() ..." << std::endl;
  deque.push_back(1);
  deque.push_back(2);
  deque.push_back(3);
  expect(!deque.is_empty());
  assert_equals(1, deque[0]);
  assert_equals(2, deque[1]);
  assert_equals(3, deque[2]);
  assert_equals(1, deque.front());
  assert_equals(3, deque.back());
  assert_equals(size_t {3}, deque.get_num_elements());
  std::cout << std::endl;
  std::cout << "Testing Deque<T>::push_front() ..." << std::endl;
  deque.push_front(4);
  deque.push_front(5);
  deque.push_front(6);
  expect(!deque.is_empty());
  assert_equals(6, deque[0]);
  assert_equals(5, deque[1]);
  assert_equals(4, deque[2]);
  assert_equals(1, deque[3]);
  assert_equals(2, deque[4]);
  assert_equals(3, deque[5]);
  assert_equals(6, deque.front());
  assert_equals(3, deque.back());
  assert_equals(size_t {6}, deque.get_num_elements());
  std::cout << std::endl;
  std::cout << "A mixture of push_front and push_back ..." << std::endl;
  deque.push_front(7);
  deque.push_back(8);
  deque.push_back(9);
  deque.push_front(10);
  expect(!deque.is_empty());
  assert_equals(10, deque[0]);
  assert_equals(7, deque[1]);
  assert_equals(6, deque[2]);
  assert_equals(5, deque[3]);
  assert_equals(4, deque[4]);
  assert_equals(1, deque[5]);
  assert_equals(2, deque[6]);
  assert_equals(3, deque[7]);
  assert_equals(8, deque[8]);
  assert_equals(9, deque[9]);
  assert_equals(10, deque.front());
  assert_equals(9, deque.back());
  assert_equals(size_t {10}, deque.get_num_elements());
  std::cout << std::endl;
  std::cout << "Testing self-assignment ... ;-)" << std::endl;
  deque = deque;
  expect(!deque.is_empty());
  assert_equals(10, deque[0]);
  assert_equals(7, deque[1]);
  assert_equals(6, deque[2]);
  assert_equals(5, deque[3]);
  assert_equals(4, deque[4]);
  assert_equals(1, deque[5]);
  assert_equals(2, deque[6]);
  assert_equals(3, deque[7]);
  assert_equals(8, deque[8]);
  assert_equals(9, deque[9]);
  assert_equals(10, deque.front());
  assert_equals(9, deque.back());
  assert_equals(size_t {10}, deque.get_num_elements());
  std::cout << std::endl;
  std::cout << "Testing Deque<T>::pop_front() and Deque<T>::pop_back() ..." << std::endl;
  deque.pop_front();
  deque.pop_front();
  deque.pop_back();
  expect(!deque.is_empty());
  assert_equals(6, deque[0]);
  assert_equals(5, deque[1]);
  assert_equals(4, deque[2]);
  assert_equals(1, deque[3]);
  assert_equals(2, deque[4]);
  assert_equals(3, deque[5]);
  assert_equals(8, deque[6]);
  assert_equals(6, deque.front());
  assert_equals(8, deque.back());
  assert_equals(size_t {7}, deque.get_num_elements());
  std::cout << std::endl;
  std::cout << "Testing whether the return value of operator[] can be used as an lvalue ..." << std::endl;
  deque[2] = 42;
  deque[4] = 13;
  expect(!deque.is_empty());
  assert_equals(6, deque[0]);
  assert_equals(5, deque[1]);
  assert_equals(42, deque[2]);
  assert_equals(1, deque[3]);
  assert_equals(13, deque[4]);
  assert_equals(3, deque[5]);
  assert_equals(8, deque[6]);
  assert_equals(6, deque.front());
  assert_equals(8, deque.back());
  assert_equals(size_t {7}, deque.get_num_elements());
  std::cout << std::endl;
  std::cout << "More tests on pop_front and pop_back ..." << std::endl;
  deque.pop_back();
  deque.pop_back();
  deque.pop_back();
  deque.pop_front();
  expect(!deque.is_empty());
  assert_equals(5, deque[0]);
  assert_equals(42, deque[1]);
  assert_equals(1, deque[2]);
  assert_equals(5, deque.front());
  assert_equals(1, deque.back());
  assert_equals(size_t {3}, deque.get_num_elements());
  std::cout << std::endl;
  std::cout << "More tests on pop_front and pop_back, continued ..." << std::endl;
  deque.pop_front();
  deque.pop_back();
  expect(!deque.is_empty());
  assert_equals(42, deque[0]);
  assert_equals(42, deque.front());
  assert_equals(42, deque.back());
  assert_equals(size_t {1}, deque.get_num_elements());
  std::cout << std::endl;
  std::cout << "The final pop that makes the deque empty again ;-)" << std::endl;
  deque.pop_back();
  expect(deque.is_empty());
  assert_equals(size_t {0}, deque.get_num_elements());
  std::cout << std::endl;
  std::cout << "Pushing to our currently empty deque ..." << std::endl;
  deque.push_front(100);
  deque.push_front(200);
  deque.push_front(300);
  deque.push_back(400);
  expect(!deque.is_empty());
  assert_equals(300, deque[0]);
  assert_equals(200, deque[1]);
  assert_equals(100, deque[2]);
  assert_equals(400, deque[3]);
  assert_equals(300, deque.front());
  assert_equals(400, deque.back());
  assert_equals(size_t {4}, deque.get_num_elements());
  std::cout << std::endl;
  std::cout << "Testing Deque<T>::Deque(const Deque<T> &) ..." << std::endl;
  Deque<int> deque2 = deque;
  expect(!deque.is_empty());
  expect(!deque2.is_empty());
  assert_equals(300, deque[0]);
  assert_equals(300, deque2[0]);
  assert_equals(200, deque[1]);
  assert_equals(200, deque2[1]);
  assert_equals(100, deque[2]);
  assert_equals(100, deque2[2]);
  assert_equals(400, deque[3]);
  assert_equals(400, deque2[3]);
  assert_equals(300, deque.front());
  assert_equals(300, deque2.front());
  assert_equals(400, deque.back());
  assert_equals(400, deque2.back());
  assert_equals(size_t {4}, deque.get_num_elements());
  assert_equals(size_t {4}, deque2.get_num_elements());
  std::cout << std::endl;
  std::cout << "Popping a few elements off our copy-constructed deque ..." << std::endl;
  deque2.pop_back();
  deque2.pop_back();
  expect(!deque.is_empty());
  expect(!deque2.is_empty());
  assert_equals(300, deque[0]);
  assert_equals(200, deque[1]);
  assert_equals(100, deque[2]);
  assert_equals(400, deque[3]);
  assert_equals(300, deque2[0]);
  assert_equals(200, deque2[1]);
  assert_equals(300, deque.front());
  assert_equals(300, deque2.front());
  assert_equals(400, deque.back());
  assert_equals(200, deque2.back());
  assert_equals(size_t {4}, deque.get_num_elements());
  assert_equals(size_t {2}, deque2.get_num_elements());
  std::cout << std::endl;
  std::cout << "Testing ordinary usage of assignment (not self-assignment) ..." << std::endl;
  deque = deque2;
  expect(!deque.is_empty());
  expect(!deque2.is_empty());
  assert_equals(300, deque[0]);
  assert_equals(300, deque2[0]);
  assert_equals(200, deque[1]);
  assert_equals(200, deque2[1]);
  assert_equals(300, deque.front());
  assert_equals(300, deque2.front());
  assert_equals(200, deque.back());
  assert_equals(200, deque2.back());
  assert_equals(size_t {2}, deque.get_num_elements());
  assert_equals(size_t {2}, deque2.get_num_elements());
  std::cout << std::endl;
  std::cout << "Mixed tests ..." << std::endl;
  deque.push_front(1234);
  deque.push_back(5678);
  deque.push_front(9101112);
  deque2 = deque;
  expect(!deque.is_empty());
  expect(!deque2.is_empty());
  assert_equals(9101112, deque[0]);
  assert_equals(9101112, deque2[0]);
  assert_equals(1234, deque[1]);
  assert_equals(1234, deque2[1]);
  assert_equals(300, deque[2]);
  assert_equals(300, deque2[2]);
  assert_equals(200, deque[3]);
  assert_equals(200, deque2[3]);
  assert_equals(5678, deque[4]);
  assert_equals(5678, deque2[4]);
  assert_equals(9101112, deque.front());
  assert_equals(9101112, deque2.front());
  assert_equals(5678, deque.back());
  assert_equals(5678, deque2.back());
  assert_equals(size_t {5}, deque.get_num_elements());
  assert_equals(size_t {5}, deque2.get_num_elements());
  std::cout << std::endl;
  std::cout << "Pop until one of the deques is empty ..." << std::endl;
  while (!deque2.is_empty())
    deque2.pop_back();
  expect(!deque.is_empty());
  expect(deque2.is_empty());
  assert_equals(9101112, deque[0]);
  assert_equals(1234, deque[1]);
  assert_equals(300, deque[2]);
  assert_equals(200, deque[3]);
  assert_equals(5678, deque[4]);
  assert_equals(9101112, deque.front());
  assert_equals(5678, deque.back());
  assert_equals(size_t {5}, deque.get_num_elements());
  assert_equals(size_t {0}, deque2.get_num_elements());
  std::cout << std::endl;
  std::cout << "Cascading assignments ... ;-)" << std::endl;
  deque = deque2 = deque = deque2;
  expect(deque.is_empty());
  expect(deque2.is_empty());
  assert_equals(size_t {0}, deque.get_num_elements());
  assert_equals(size_t {0}, deque2.get_num_elements());
  std::cout << std::endl;
  std::cout << "Testing for parametric polymorphism ..." << std::endl;
  std::cout << "Refer to https://en.wikipedia.org/wiki/Parametric_polymorphism for more details" << std::endl;
  Deque<std::string> deque3;
  deque3.push_front("Adrian");
  deque3.push_front("Benjamin");
  deque3.push_front("Clark");
  deque3.push_back("Dominic");
  deque3.push_back("Eduardo");
  const Deque<std::string> deque4 = deque3;
  expect(!deque4.is_empty());
  assert_equals(std::string("Clark"), deque4[0]);
  assert_equals(std::string("Benjamin"), deque4[1]);
  assert_equals(std::string("Adrian"), deque4[2]);
  assert_equals(std::string("Dominic"), deque4[3]);
  assert_equals(std::string("Eduardo"), deque4[4]);
  assert_equals(std::string("Clark"), deque4.front());
  assert_equals(std::string("Eduardo"), deque4.back());
  assert_equals(size_t {5}, deque4.get_num_elements());
  std::cout << std::endl;
  std::cout << "Testing whether the return values of front and back can be used as lvalues ..." << std::endl;
  deque3.front() = "Frankie";
  deque3.back() = "Gary";
  expect(!deque3.is_empty());
  assert_equals(std::string("Frankie"), deque3[0]);
  assert_equals(std::string("Benjamin"), deque3[1]);
  assert_equals(std::string("Adrian"), deque3[2]);
  assert_equals(std::string("Dominic"), deque3[3]);
  assert_equals(std::string("Gary"), deque3[4]);
  assert_equals(std::string("Frankie"), deque3.front());
  assert_equals(std::string("Gary"), deque3.back());
  assert_equals(size_t {5}, deque3.get_num_elements());
  std::cout << std::endl;

  // Performance Tests
  std::cout << "Part II: Performance Tests" << std::endl << std::endl;
  std::chrono::steady_clock::time_point start = std::chrono::steady_clock::now();
  Deque<void *> deque5;
  for (int i = 0; i < 2e7; ++i) {
    if (rand() % 2)
      deque5.push_front(nullptr);
    else
      deque5.push_back(nullptr);
    deque5.front();
    deque5.back();
    deque5.is_empty();
  }
  for (int i = 0; i < 2e7; ++i)
    if (rand() % 2) {
      if (rand() % 2)
        deque5.push_front(nullptr);
      else
        deque5.push_back(nullptr);
      deque5.front();
      deque5.back();
      deque5.is_empty();
    } else {
      deque5.front();
      deque5.back();
      if (rand() % 2)
        deque5.pop_front();
      else
        deque5.pop_back();
      deque5.is_empty();
    }
  while (!deque5.is_empty()) {
    deque5.front();
    deque5.back();
    if (rand() % 2)
      deque5.pop_front();
    else
      deque5.pop_back();
  }
  expect(std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::steady_clock::now() - start).count() < 5000);
}

// Test cases for bonus task
void bonus_task_test_cases() {
  std::cout << "Test Cases for Bonus Task" << std::endl << std::endl;
  Int32 a[10] {Int32{1}, Int32{2}, Int32{3}, Int32{4}, Int32{5}, Int32{6}, Int32{7}, Int32{8}, Int32{9}, Int32{10}};
  Deque<Int32> deque;
  for (int i = 0; i < 10; ++i)
    deque.push_back(a[i]);
  std::cout << "A random access iterator:" << std::endl << std::endl;

  std::cout << "- is default-constructible, copy-constructible, copy-assignable and destructible" << std::endl;
  {
    Deque<Int32>::iterator it, it2 = deque.begin();
    it = it2;
  }
  expect(true);
  std::cout << std::endl;
  std::cout << "- can be compared for equivalence using the equality/inequality operators" << std::endl;
  Deque<Int32>::iterator it = deque.begin();
  expect(it == deque.begin());
  expect(!(it != deque.begin()));
  expect(it != deque.end());
  expect(!(it == deque.end()));
  it = it;
  expect(it == deque.begin());
  expect(!(it != deque.begin()));
  expect(it != deque.end());
  expect(!(it == deque.end()));
  it = it = it;
  expect(it == deque.begin());
  expect(!(it != deque.begin()));
  expect(it != deque.end());
  expect(!(it == deque.end()));
  std::cout << std::endl;
  std::cout << "- can be dereferenced as an rvalue" << std::endl;
  assert_equals(a[0], *it);
  assert_equals(1, it->value);
  std::cout << std::endl;
  std::cout << "- can be dereferenced as an lvalue" << std::endl;
  *it = a[4];
  assert_equals(a[4], *it);
  *it = a[0];
  assert_equals(a[0], *it);
  it->value = 42;
  assert_equals(42, it->value);
  it->value = 1;
  assert_equals(1, it->value);
  std::cout << std::endl;
  std::cout << "- can be incremented" << std::endl;
  int n = 0;
  while (it != deque.end()) {
    ++n;
    ++it;
  }
  assert_equals(10, n);
  n = 0;
  it = deque.begin();
  while (it != deque.end()) {
    ++n;
    it++;
  }
  assert_equals(10, n);
  n = 0;
  it = deque.begin();
  while (it != deque.end())
    assert_equals(a[n++], *it++);
  assert_equals(10, n);
  std::cout << std::endl;
  std::cout << "- can be decremented" << std::endl;
  n = 0;
  while (it != deque.begin()) {
    ++n;
    --it;
  }
  assert_equals(10, n);
  n = 0;
  it = deque.end();
  while (it != deque.begin()) {
    ++n;
    it--;
  }
  assert_equals(10, n);
  it = ++++++deque.begin();
  assert_equals(a[3], *it--);
  assert_equals(a[2], *it--);
  assert_equals(a[1], *it--);
  assert_equals(a[0], *it);
  assert_equals(deque.begin(), it);
  it = ------------deque.end();
  assert_equals(a[4], *it--);
  assert_equals(a[3], *it--);
  assert_equals(a[2], *it--);
  assert_equals(a[1], *it--);
  assert_equals(a[0], *it);
  assert_equals(deque.begin(), it);
  std::cout << std::endl;
  std::cout << "- supports the arithmetic operators + and - between an iterator and an integer value, or subtracting an iterator\
 from another" << std::endl;
  it = deque.begin() + 4;
  assert_equals(a[4], *it);
  assert_equals(a[7], *(3 + it));
  it = 3 + it;
  assert_equals(deque.begin() + 7, it);
  assert_equals(deque.end(), it + 3);
  assert_equals(6, (it - 2)->value);
  it = it - 4;
  assert_equals(a[3], *it);
  Deque<Int32>::iterator it2 = 6 + deque.begin();
  assert_equals(3, it2 - it);
  assert_equals(-3, it - it2);
  assert_equals(10, deque.end() - deque.begin());
  assert_equals(-10, deque.begin() - deque.end());
  assert_equals(7, deque.end() - it);
  assert_equals(4, deque.end() - it2);
  std::cout << std::endl;
  std::cout << "- can be compared with inequality relational operators (<, >, <= and >=)" << std::endl;
  expect(it < it2);
  expect(!(it2 < it));
  expect(!(it > it2));
  expect(it2 > it);
  expect(it <= it2);
  expect(!(it2 <= it));
  expect(!(it >= it2));
  expect(it2 >= it);
  it = it2 = it = it2;
  expect(!(it < it2));
  expect(!(it2 < it));
  expect(!(it > it2));
  expect(!(it2 > it));
  expect(it <= it2);
  expect(it2 <= it);
  expect(it >= it2);
  expect(it2 >= it);
  expect(deque.begin() < deque.end());
  expect(!(deque.end() < deque.begin()));
  expect(!(deque.begin() > deque.end()));
  expect(deque.end() > deque.begin());
  expect(deque.begin() <= deque.end());
  expect(!(deque.end() <= deque.begin()));
  expect(!(deque.begin() >= deque.end()));
  expect(deque.end() >= deque.begin());
  std::cout << std::endl;
  std::cout << "- supports compound assignment operations += and -=" << std::endl;
  it += 2;
  assert_equals(deque.begin() + 8, it);
  it -= 7;
  assert_equals(1 + deque.begin(), it);
  it += 4;
  assert_equals(deque.end() - 5, it);
  it -= 5;
  assert_equals(deque.begin(), it);
  std::cout << std::endl;
  std::cout << "- supports the offset dereference operator ([])" << std::endl;
  for (int i = 0; i < 10; ++i) {
    assert_equals(a[i], it[i]);
    assert_equals(a[i], it2[i - 6]);
  }
  it2[-3].value = 42;
  assert_equals(42, it2[-3].value);
  it2[-3].value = 4;
  assert_equals(4, it2[-3].value);
  std::cout << std::endl;
  std::cout << "N.B. const-qualified iterators should also provide most of the functionality offered by non-const iterators"
    << std::endl;
  { const Deque<Int32>::iterator it, it2 = deque.begin(); }
  const Deque<Int32>::iterator it3 = deque.begin() + 4;
  expect(it2 - 1 == 1 + it3);
  expect(!(it2 - 1 != 1 + it3));
  expect(!(it2 == it3));
  expect(it2 != it3);
  assert_equals(a[4], *it3);
  assert_equals(5, it3->value);
  *it3 = a[7];
  assert_equals(a[7], *it3);
  *it3 = a[4];
  assert_equals(a[4], *it3);
  it3->value = 42;
  assert_equals(42, it3->value);
  it3->value = 5;
  assert_equals(5, it3->value);
  assert_equals(deque.begin() + 7, it3 + 3);
  assert_equals(deque.begin() + 6, 2 + it3);
  assert_equals(deque.begin(), it3 - 4);
  assert_equals(-2, it3 - it2);
  assert_equals(2, it2 - it3);
  expect(!(it2 < it3));
  expect(it3 < it2);
  expect(it2 > it3);
  expect(!(it3 > it2));
  expect(!(it2 <= it3));
  expect(it3 <= it2);
  expect(it2 >= it3);
  expect(!(it3 >= it2));
  for (int i = 0; i < 10; ++i)
    assert_equals(a[i], it3[i - 4]);
  it3[-1].value = 42;
  assert_equals(42, it3[-1].value);
  it3[-1].value = 4;
  assert_equals(4, it3[-1].value);
}

int main(int argc, char *argv[]) {
  std::cout << "********************************************************************************" << std::endl;
  main_task_test_cases();
  // NOTE: Uncomment the two lines below to run the test cases for the bonus task
  std::cout << "================================================================================" << std::endl;
  bonus_task_test_cases();
  std::cout << "********************************************************************************" << std::endl;
  return 0;
}
