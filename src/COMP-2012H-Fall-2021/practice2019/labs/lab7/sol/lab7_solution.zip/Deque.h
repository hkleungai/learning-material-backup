#ifndef DEQUE_H_
#define DEQUE_H_

#include <iostream>

template <typename T>
class Deque final {
public:
	/****************************************************************************
	 * Constructors, Destructor, Copy-Assignment and Move-Assignment Operators. *
	 ****************************************************************************/

	Deque() : capacity{1} { data = new T[1]; }

	Deque(const Deque& deque) : num_elements{deque.num_elements}, capacity{deque.capacity}, head_index{deque.head_index} {
		this->data = new T[deque.capacity];
		for (size_t index{0}; index < deque.num_elements; ++index) {
			this->data[(this->head_index + index) % this->capacity] = deque.data[(deque.head_index + index) % deque.capacity];
		}
	}

	Deque(Deque&& deque) : num_elements{deque.num_elements}, capacity{deque.capacity}, head_index{deque.head_index}, data{deque.data} { deque.data = nullptr; }

	~Deque() { delete[] data; }

	Deque& operator=(const Deque& rhs) {
		if (this == &rhs) { return *this; }

		delete[] (this->data);
		this->num_elements = rhs.num_elements;
		this->capacity = rhs.capacity;
		this->data = new T[rhs.capacity];
		for (size_t index{0}; index < rhs.num_elements; ++index) {
			this->data[(this->head_index + index) % this->capacity] = rhs.data[(rhs.head_index + index) % rhs.capacity];
		}

		return *this;
	}

	Deque& operator=(Deque&& rhs) {
		if (this == &rhs) { return *this; }

		delete[] (this->data);
		this->num_elements = std::move(rhs.num_elements);
		this->capacity = std::move(rhs.capacity);
		this->head_index = std::move(rhs.head_index);
		this->data = std::move(rhs.data);
		rhs.data = nullptr;

		return *this;
	}



	/**********************************
	 * ostream and indexing Operators *
	 **********************************/

	friend std::ostream& operator<<(std::ostream& os, const Deque<T>& rhs) {
		os << "Number of elements: " << rhs.num_elements << '\n'
		   << "Capacity: " << rhs.capacity << '\n'
		   << "Head Index: " << rhs.head_index << '\n'
		   << "Contents: ";
		if (rhs.num_elements == 0) {
			os << "<empty>";
		}
		else {
			for (size_t i{0}; i < rhs.num_elements; ++i) {
				os << rhs.data[(rhs.head_index + i) % rhs.capacity] << ' ';
			}
		}
		os << std::endl;

		return os;
	}

	T& operator[](size_t index) { return data[(head_index + index) % capacity]; }
	const T& operator[](size_t index) const { return data[(head_index + index) % capacity]; }



	/*************************
	 * Deque Core Operations *
	 *************************/

	void push_front(const T& element) {
		if (num_elements >= capacity) {
			reallocate_capacity(capacity << 1);
		}
		head_index = (head_index - 1) % capacity;
		data[head_index] = element;
		num_elements += 1;
	}

	void push_front(T&& element) {
		if (num_elements >= capacity) {
			reallocate_capacity(capacity << 1);
		}
		head_index = (head_index - 1) % capacity;
		data[head_index] = element;
		num_elements += 1;
	}

	void push_back(const T& element) {
		if (num_elements >= capacity) {
			reallocate_capacity(capacity << 1);
		}
		data[(head_index + num_elements) % capacity] = element;
		num_elements += 1;
	}

	void push_back(T&& element) {
		if (num_elements >= capacity) {
			reallocate_capacity(capacity << 1);
		}
		data[(head_index + num_elements) % capacity] = element;
		num_elements += 1;
	}

	void pop_front() {
		if (is_empty()) { return; }

		head_index = (head_index + 1) % capacity;
		num_elements -= 1;
		if (num_elements <= (capacity >> 2)) {
			reallocate_capacity(capacity >> 1);
		}
	}

	void pop_back() {
		if (is_empty()) { return; }

		num_elements -= 1;
		if (num_elements <= (capacity >> 2)) {
			reallocate_capacity(capacity >> 1);
		}
	}

	T& front() { return data[head_index]; }
	const T& front() const { return data[head_index]; }
	T& back() { return data[(head_index + num_elements - 1) % capacity]; }
	const T& back() const { return data[(head_index + num_elements - 1) % capacity]; }
	bool is_empty() const { return num_elements == 0; }
	size_t get_num_elements() const { return num_elements; }



	class iterator final {
		friend class Deque;

	public:
		// Constructors, Destructor, Copy-Assignment and Move-Assignment Operators, can be left as compiler-default as no special memory management.

		/***************************************
		 * Dereference and Subscript Operators *
		 ***************************************/

		T& operator*() const { return (*deque)[offset]; }
		T* operator->() const { return &((*deque)[offset]); }
		T& operator[](size_t index) const { return (*deque)[offset + index]; }



		/*************************************
		 * Increment and Decrement Operators *
		 *************************************/

		iterator& operator++() {
			++offset;
			return *this;
		}

		iterator operator++(int) {
			Deque<T>::iterator result = *this;
			++offset;
			return result;
		}

		iterator& operator--() {
			--offset;
			return *this;
		}

		iterator operator--(int) {
			Deque<T>::iterator result = *this;
			--offset;
			return result;
		}



		/************************
		 * Arithmetic Operators *
		 ************************/

		iterator operator+(size_t n) const {
			iterator result = *this;
			result.offset += n;
			return result;
		}

		iterator operator-(size_t n) const {
			iterator result = *this;
			result.offset -= n;
			return result;
		}

		friend iterator operator+(size_t n, const iterator& it) { return it + n; }
		friend iterator operator-(size_t n, const iterator& it) { return it - n; }

		int operator-(const iterator& rhs) const { return this->offset - rhs.offset; }

		iterator& operator+=(size_t n) {
			offset += n;
			return *this;
		}

		iterator& operator-=(size_t n) {
			offset -= n;
			return *this;
		}



		/**********************
		 * Equality Operators *
		 **********************/

		bool operator==(const iterator& rhs) const { return this->offset == rhs.offset; }
		bool operator!=(const iterator& rhs) const { return this->offset != rhs.offset; }
		bool operator<(const iterator& rhs) const { return this->offset < rhs.offset; }
		bool operator>(const iterator& rhs) const { return this->offset > rhs.offset; }
		bool operator<=(const iterator& rhs) const { return this->offset <= rhs.offset; }
		bool operator>=(const iterator& rhs) const { return this->offset >= rhs.offset; }



	private:
		Deque* deque{nullptr};
		int offset{0};
	};



	/*******************************
	 * Iterator begin() and end(). *
	 *******************************/

	iterator begin() {
		iterator result;
		result.deque = this;
		result.offset = 0;
		return result;
	}

	iterator end() {
		iterator result;
		result.deque = this;
		result.offset = num_elements;
		return result;
	}



private:
	void reallocate_capacity(size_t new_capacity) {
		T* new_data{new T[new_capacity]};
		for (size_t index{0}; index < num_elements; ++index) {
			new_data[index] = data[(head_index + index) % capacity];
		}
		delete[] data;

		data = new_data;
		capacity = new_capacity;
		head_index = 0;
	}

	size_t num_elements{0};
	size_t capacity{0};
	size_t head_index{0};
	T* data{nullptr};
};

#endif /* DEQUE_H_ */
