#ifndef ARRAYSTACK_H_
#define ARRAYSTACK_H_

#include "ArrayAbstractSequentialContainer.h"

class ArrayStack : public ArrayAbstractSequentialContainer {
public:
	ArrayStack();
	ArrayStack(const ArrayStack& arrayStack);
	ArrayStack& operator=(const ArrayStack& rhs);
	virtual ~ArrayStack();

	virtual const UselessDataObject& peek() const override;
	virtual void insertElement(const UselessDataObject& element) override;
	virtual UselessDataObject removeElement() override;
	virtual void removeAll(UselessDataObject data[]) override;
};

#endif /* ARRAYSTACK_H_ */
