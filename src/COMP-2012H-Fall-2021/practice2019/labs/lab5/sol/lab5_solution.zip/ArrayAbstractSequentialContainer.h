#ifndef ARRAYABSTRACTSEQUENTIALCONTAINER_H_
#define ARRAYABSTRACTSEQUENTIALCONTAINER_H_

#include "AbstractSequentialContainer.h"
#include "UselessDataObject.h"

class ArrayAbstractSequentialContainer : public AbstractSequentialContainer {
public:
	virtual ~ArrayAbstractSequentialContainer();

	virtual void print(ostream& out) const override;
	virtual bool isEmpty() const override;
	virtual unsigned int getNumElements() const override;

protected:
	ArrayAbstractSequentialContainer();
	ArrayAbstractSequentialContainer(const ArrayAbstractSequentialContainer& arrayAbstractSequentialContainer);
	ArrayAbstractSequentialContainer& operator=(const ArrayAbstractSequentialContainer& rhs);

	enum OperationType {INSERTION, REMOVAL};
	void reallocateArrayCapacityIfNeeded(OperationType operationType);

	unsigned int numElements{0};
	unsigned int headIndex{0};
	unsigned int arrayCapacity{0};
	UselessDataObject* data{nullptr};
};

#endif /* ARRAYABSTRACTSEQUENTIALCONTAINER_H_ */
