#include "ArrayQueue.h"

ArrayQueue::ArrayQueue() {}

ArrayQueue::ArrayQueue(const ArrayQueue& arrayQueue) : ArrayAbstractSequentialContainer{arrayQueue} {}

ArrayQueue& ArrayQueue::operator=(const ArrayQueue& rhs) {
	this->ArrayAbstractSequentialContainer::operator=(rhs);
	return *this;
}

ArrayQueue::~ArrayQueue() {}

const UselessDataObject& ArrayQueue::peek() const {
	return data[headIndex];
}

void ArrayQueue::insertElement(const UselessDataObject& element) {
	reallocateArrayCapacityIfNeeded(INSERTION);
	data[(headIndex + numElements) % arrayCapacity] = element;
	numElements += 1;
}

UselessDataObject ArrayQueue::removeElement() {
	UselessDataObject target{data[headIndex]};
	headIndex += 1;
	numElements -= 1;
	reallocateArrayCapacityIfNeeded(REMOVAL);
	return target;
}

void ArrayQueue::removeAll(UselessDataObject elements[]) {
	for (unsigned int index{0}; index < numElements; ++index) {
		elements[index] = data[(headIndex + index) % arrayCapacity];
	}
	numElements = 0;
	headIndex = 0;
	reallocateArrayCapacityIfNeeded(REMOVAL);
}
