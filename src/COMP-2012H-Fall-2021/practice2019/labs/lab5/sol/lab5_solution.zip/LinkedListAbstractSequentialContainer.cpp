#include "LinkedListAbstractSequentialContainer.h"

/*******************************************************
 * Constructors, Destructors, and Assignment Operators *
 *******************************************************/

LinkedListAbstractSequentialContainer::LinkedListAbstractSequentialContainer() : sentinel{new LinkedListNode} {
	sentinel->prev = sentinel->next = sentinel;
}

LinkedListAbstractSequentialContainer::LinkedListAbstractSequentialContainer(const LinkedListAbstractSequentialContainer& linkedListAbstractContainer)
: LinkedListAbstractSequentialContainer() {
	LinkedListNode* thisCurrent = this->sentinel;
	LinkedListNode* rhsCurrent = linkedListAbstractContainer.sentinel->next;
	for (unsigned int index = 0; index < linkedListAbstractContainer.numElements; ++index, thisCurrent = thisCurrent->next, rhsCurrent = rhsCurrent->next) {
		thisCurrent->next = new LinkedListNode{rhsCurrent->data, thisCurrent, this->sentinel};
		this->sentinel->prev = thisCurrent->next;
	}
}

LinkedListAbstractSequentialContainer& LinkedListAbstractSequentialContainer::operator=(const LinkedListAbstractSequentialContainer& rhs) {
	if (this == &rhs) { return *this; }

	for (LinkedListNode* current{this->sentinel->next}; current != this->sentinel; current = current->next, delete current->prev) {}
	this->sentinel->prev = this->sentinel->next = this->sentinel;

	LinkedListNode* thisCurrent = this->sentinel;
	LinkedListNode* rhsCurrent = rhs.sentinel->next;
	for (unsigned int index = 0; index < rhs.numElements; ++index, thisCurrent = thisCurrent->next, rhsCurrent = rhsCurrent->next) {
		thisCurrent->next = new LinkedListNode{rhsCurrent->data, thisCurrent, this->sentinel};
		this->sentinel->prev = thisCurrent->next;
	}

	return *this;
}

LinkedListAbstractSequentialContainer::~LinkedListAbstractSequentialContainer() {
	for (LinkedListNode* current{sentinel->next}; current != sentinel; current = current->next, delete current->prev) {}
	delete sentinel;
}



/*******************************************
 * Abstract Sequential Container Overrides *
 *******************************************/

void LinkedListAbstractSequentialContainer::print(ostream& out) const {
	for (LinkedListNode* current{sentinel->next}; current != sentinel; current = current->next) {
		out << current->data << " ";
	}
}

bool LinkedListAbstractSequentialContainer::isEmpty() const {
	return numElements == 0;
}

unsigned int LinkedListAbstractSequentialContainer::getNumElements() const {
	return numElements;
}



/***********************************
 * Linked List Protected Functions *
 ***********************************/

// Return sentinel garbage data if index out-of-range.
const UselessDataObject& LinkedListAbstractSequentialContainer::getElementAtIndex(unsigned int index) const {
	return getNodeAtIndex(index)->data;
}

// Do nothing if index out-of-range.
void LinkedListAbstractSequentialContainer::insertAtIndex(const UselessDataObject& element, unsigned int index) {
	if (index > numElements) { return; }

	LinkedListNode* current{getNodeAtIndex(index)};
	LinkedListNode* insertNode{new LinkedListNode{element, current->prev, current}};
	insertNode->prev->next = insertNode;
	insertNode->next->prev = insertNode;

	numElements += 1;
}

// Don't remove any node, and return sentinel garbage data, if index out-of-range.
UselessDataObject LinkedListAbstractSequentialContainer::removeAtIndex(unsigned int index) {
	LinkedListNode* current{getNodeAtIndex(index)};
	UselessDataObject target = current->data;

	if (current != sentinel) {
		current->prev->next = current->next;
		current->next->prev = current->prev;
		delete current;

		numElements -= 1;
	}

	return target;
}



/*********************************
 * Linked List Private Functions *
 *********************************/

// Return sentinel if index out-of-range.
LinkedListAbstractSequentialContainer::LinkedListNode* LinkedListAbstractSequentialContainer::getNodeAtIndex(unsigned int index) const {
	LinkedListNode* current{sentinel->next};
	for (unsigned int i{0}; (current != sentinel) && (i < index); current = current->next, ++i) {}
	return current;
}
