#ifndef ARRAYQUEUE_H_
#define ARRAYQUEUE_H_

#include "ArrayAbstractSequentialContainer.h"

class ArrayQueue : public ArrayAbstractSequentialContainer {
public:
	ArrayQueue();
	ArrayQueue(const ArrayQueue& arrayQueue);
	ArrayQueue& operator=(const ArrayQueue& rhs);
	virtual ~ArrayQueue();

	virtual const UselessDataObject& peek() const override;
	virtual void insertElement(const UselessDataObject& element) override;
	virtual UselessDataObject removeElement() override;
	virtual void removeAll(UselessDataObject elements[]) override;
};

#endif /* ARRAYQUEUE_H_ */
