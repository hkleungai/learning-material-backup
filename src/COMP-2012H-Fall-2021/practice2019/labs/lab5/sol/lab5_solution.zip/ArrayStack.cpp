#include "ArrayStack.h"

ArrayStack::ArrayStack() {}

ArrayStack::ArrayStack(const ArrayStack& arrayStack) : ArrayAbstractSequentialContainer{arrayStack} {}

ArrayStack& ArrayStack::operator=(const ArrayStack& rhs) {
	this->ArrayAbstractSequentialContainer::operator=(rhs);
	return *this;
}

ArrayStack::~ArrayStack() {}

const UselessDataObject& ArrayStack::peek() const {
	return data[numElements - 1];
}

void ArrayStack::insertElement(const UselessDataObject& element) {
	reallocateArrayCapacityIfNeeded(INSERTION);
	data[numElements] = element;
	numElements += 1;
}

UselessDataObject ArrayStack::removeElement() {
	UselessDataObject target{data[numElements - 1]};
	numElements -= 1;
	reallocateArrayCapacityIfNeeded(REMOVAL);
	return target;
}

void ArrayStack::removeAll(UselessDataObject elements[]) {
	for (unsigned int index{0}; index < numElements; ++index) {
		elements[index] = data[(numElements - 1) - index];
	}
	numElements = 0;
	headIndex = 0;
	reallocateArrayCapacityIfNeeded(REMOVAL);
}
