#include "ArrayAbstractSequentialContainer.h"

/*******************************************************
 * Constructors, Destructors, and Assignment Operators *
 *******************************************************/

ArrayAbstractSequentialContainer::ArrayAbstractSequentialContainer() : arrayCapacity{1}, data{new UselessDataObject[1]} {}

ArrayAbstractSequentialContainer::ArrayAbstractSequentialContainer(const ArrayAbstractSequentialContainer& arrayAbstractSequentialContainer) {
	this->data = new UselessDataObject[arrayAbstractSequentialContainer.arrayCapacity];
	this->arrayCapacity = arrayAbstractSequentialContainer.arrayCapacity;
	for (unsigned int index{0}; index < arrayAbstractSequentialContainer.numElements; ++index) {
		this->data[index] = arrayAbstractSequentialContainer.data[(arrayAbstractSequentialContainer.headIndex + index) % arrayAbstractSequentialContainer.arrayCapacity];
	}
	this->numElements = arrayAbstractSequentialContainer.numElements;
}

ArrayAbstractSequentialContainer& ArrayAbstractSequentialContainer::operator=(const ArrayAbstractSequentialContainer& rhs) {
	if (this == &rhs) { return *this; }

	delete[] this->data;

	this->data = new UselessDataObject[rhs.arrayCapacity];
	this->arrayCapacity = rhs.arrayCapacity;
	for (unsigned int index{0}; index < rhs.numElements; ++index) {
		this->data[index] = rhs.data[(rhs.headIndex + index) % rhs.arrayCapacity];
	}
	this->numElements = rhs.numElements;

	return *this;
}

ArrayAbstractSequentialContainer::~ArrayAbstractSequentialContainer() {
	delete[] data;
}



/*******************************************
 * Abstract Sequential Container Overrides *
 *******************************************/

void ArrayAbstractSequentialContainer::print(ostream& out) const {
	for (unsigned int index{0}; index < numElements; ++index) {
		out << data[(headIndex + index) % arrayCapacity] << " ";
	}
}

bool ArrayAbstractSequentialContainer::isEmpty() const {
	return numElements == 0;
}

unsigned int ArrayAbstractSequentialContainer::getNumElements() const {
	return numElements;
}



/*****************************
 * Array Protected Functions *
 *****************************/

// Reallocate the dynamic array capacity if needed. Double size if array full before insertion. Halve size if array 1/4-size after removal.
void ArrayAbstractSequentialContainer::reallocateArrayCapacityIfNeeded(OperationType operationType) {
	bool isReallocationNeeded = false;
	unsigned int newArrayCapacity;

	switch (operationType) {
	case INSERTION:
		if (numElements >= arrayCapacity) {
			isReallocationNeeded = true;
			newArrayCapacity = 2*arrayCapacity;
		}
		break;

	case REMOVAL:
		if (numElements <= arrayCapacity/4) {
			isReallocationNeeded = true;
			newArrayCapacity = arrayCapacity/2;
		}
		break;

	default:
		break;
	}

	if (isReallocationNeeded) {
		UselessDataObject* reallocatedDataArray = new UselessDataObject[newArrayCapacity];
		for (unsigned int index{0}; index < numElements; ++index) {
			reallocatedDataArray[index] = data[(headIndex + index % arrayCapacity)];
		}
		arrayCapacity = newArrayCapacity;
		headIndex = 0;
		delete data;
		data = reallocatedDataArray;
	}
}
