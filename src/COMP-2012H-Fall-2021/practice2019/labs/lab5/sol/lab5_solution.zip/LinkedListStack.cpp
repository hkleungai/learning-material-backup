#include "LinkedListStack.h"

LinkedListStack::LinkedListStack() {}

LinkedListStack::LinkedListStack(const LinkedListStack& linkedListStack) : LinkedListAbstractSequentialContainer(linkedListStack) {}

LinkedListStack& LinkedListStack::operator=(const LinkedListStack& rhs) {
	this->LinkedListAbstractSequentialContainer::operator=(rhs);
	return *this;
}

LinkedListStack::~LinkedListStack() {}

const UselessDataObject& LinkedListStack::peek() const {
	return getElementAtIndex(getNumElements() - 1);
}

void LinkedListStack::insertElement(const UselessDataObject& element) {
	insertAtIndex(element, getNumElements());
}

UselessDataObject LinkedListStack::removeElement() {
	return removeAtIndex(getNumElements() - 1);
}

void LinkedListStack::removeAll(UselessDataObject data[]) {
	unsigned int numElements = getNumElements();
	for (unsigned int index{0}; index < numElements; ++index) {
		data[index] = removeElement();
	}
}
