#include "LinkedListQueue.h"

LinkedListQueue::LinkedListQueue() {}

LinkedListQueue::LinkedListQueue(const LinkedListQueue& linkedListQueue) : LinkedListAbstractSequentialContainer{linkedListQueue} {}

LinkedListQueue& LinkedListQueue::operator=(const LinkedListQueue& rhs) {
	this->LinkedListAbstractSequentialContainer::operator=(rhs);
	return *this;
}

LinkedListQueue::~LinkedListQueue() {}

const UselessDataObject& LinkedListQueue::peek() const {
	return getElementAtIndex(0);
}

void LinkedListQueue::insertElement(const UselessDataObject& element) {
	insertAtIndex(element, getNumElements());
}

UselessDataObject LinkedListQueue::removeElement() {
	return removeAtIndex(0);
}

void LinkedListQueue::removeAll(UselessDataObject data[]) {
	unsigned int numElements = getNumElements();
	for (unsigned int index{0}; index < numElements; ++index) {
		data[index] = removeElement();
	}
}
