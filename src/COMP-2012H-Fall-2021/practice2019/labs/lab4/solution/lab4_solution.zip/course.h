#ifndef COURSE_H
#define COURSE_H

#include <string>
using std::string;

#include "linked_list.h"

class Course
{
public:
	Course(const string& course_name, unsigned int quota);
	~Course();

	string enroll(const string &student_name);
	string drop(const string &student_name);
	string query_status(const string &student_name);

	int get_num_enrolled() const;
	int get_num_waitlisted() const;

private:
	string course_name;
	unsigned int quota;
	LinkedList student_list;
};

#endif
