#include "linked_list.h"

Node::Node() {}

Node::Node(string content) : content{content} {}

LinkedList::LinkedList() {
	head = tail = new Node; // Sentinel with garbage content.
}

LinkedList::~LinkedList() {
	for (Node *previous{head}, *current{head->next}; current != nullptr; delete previous, previous = current, current = current->next) {}
	delete tail;
}

unsigned int LinkedList::get_size() const { return size; }

Node* LinkedList::get_head() const { return head; }

Node* LinkedList::get_tail() const { return tail; }

void LinkedList::insert(Node* prev, Node* ins) {
	if (prev == nullptr || ins == nullptr) { return; }

	ins->next = prev->next;
	prev->next = ins;
	if (prev == get_tail()) {
		tail = ins;
	}
	size += 1;
}

void LinkedList::remove(Node* prev, Node* del) {
	if (prev == nullptr || del == nullptr) { return; }

	prev->next = del->next;
	if (del == get_tail()) {
		tail = prev;
	}
	delete del;
	size -= 1;
}

void LinkedList::push_back(const string& content) {
	insert(get_tail(), new Node{content});
}
