#include <vector>
using std::vector;
#include <string>
using std::string;
#include <iostream>
using std::cout;
using std::endl;

#include "course.h"

int rand() {
    static int seed = 233;
    seed = (1ll * seed * 37 + 47) % 998244353;
    return seed;
}

vector<string> getNameRoster(int len) {
    vector<string> ret;

    for (int i{0}; i < len; ++i) {
        int nameLen = rand() % 6 + 1;
        while (true) {
            string name;
            for (int j {0}; j < nameLen; ++j) {
                char c = 'a' + rand() % 26;
                name = name + c;
            }
            bool existed{false};
            for (int j{0}; j < i; ++j) {
                if (name == ret[j]) {
                    existed = true;
                }
            }
            if (!existed) {
                ret.push_back(name);
                break;
            }
        }
    }

    return ret;
}

int main() {
    // Task 1
    cout << "Task 1" << endl << endl;
    cout << "Create a list of 4 people" << endl;
    LinkedList* ll{new LinkedList};
    ll->push_back("Ann"); Node* Ann{ll->get_tail()};
    ll->push_back("Bob"); Node* Bob{ll->get_tail()};
    ll->push_back("Charlie"); Node* Charlie{ll->get_tail()};
    ll->push_back("David"); Node* David{ll->get_tail()};
    for (Node* it{ll->get_head()->next}; it != nullptr; it = it->next) {
        cout << it->content << endl;
    }
    cout << endl;

    cout << "Remove Ann" << endl;
    ll->remove(ll->get_head(), Ann);
    for (Node* it{ll->get_head()->next}; it != nullptr; it = it->next) {
        cout << it->content << endl;
    }
    cout << endl;

    cout << "Remove Charlie" << endl;
    ll->remove(Bob, Charlie);
    for (Node* it{ll->get_head()->next}; it != nullptr; it = it->next) {
        cout << it->content << endl;
    }
    cout << endl;

    cout << "Remove David" << endl;
    ll->remove(Bob, David);
    for (Node* it{ll->get_head()->next}; it != nullptr; it = it->next) {
        cout << it->content << endl;
    }
    cout << endl;

    cout << "Insert Emma before Bob" << endl;
    ll->insert(ll->get_head(), new Node{"Emma"});
    for (Node* it{ll->get_head()->next}; it != nullptr; it = it->next) {
        cout << it->content << endl;
    }
    cout << endl;

    delete ll;

    // Task 2
    cout << "Task 2" << endl << endl;

    int trial{1000};
    Course* course{new Course("COMP2012Honors", 50)};
    vector<string> roster = getNameRoster(100);

    while (trial--) {
        int op{rand() % 6};
        string name = roster[rand() % 100];

        if (op < 2) {
            cout << "Enroll " << name << ": "
                      << course->enroll(name)
                      << endl;
        }

        if (op == 2) {
            cout << "Drop " << name << ": "
                      << course->drop(name)
                      << endl;
        }

        if (op == 3) {
            cout << "Waitlist: "
                      << course->get_num_waitlisted()
                      << endl;
        }

        if (op == 4) {
            cout << "Enrolled: "
                      << course->get_num_enrolled()
                      << endl;
        }

        if (op == 5) {
            cout << "Status of " << name << ": "
                      << course->query_status(name)
                      << endl;
        }
    }

    delete course;

    return 0;
}
