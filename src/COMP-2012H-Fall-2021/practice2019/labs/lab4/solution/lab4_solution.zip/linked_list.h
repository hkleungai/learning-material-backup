#ifndef LINKED_LIST_H
#define LINKED_LIST_H

#include <string>
using std::string;

class Node {
public:
	Node();
	Node(string content);

	string content;

	Node* next{nullptr};
};

class LinkedList {
public:
	LinkedList();
	~LinkedList();

	unsigned int get_size() const;
	Node* get_head() const;
	Node* get_tail() const;

	void insert(Node* prev, Node* ins);
	void remove(Node* prev, Node* del);
	void push_back(const string& content);

private:
	Node* head{nullptr};
	Node* tail{nullptr};
	int size{0};
};

#endif // LINKED_LIST_H
