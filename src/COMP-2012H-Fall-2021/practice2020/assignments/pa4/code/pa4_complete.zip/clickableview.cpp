#include <QMouseEvent>

#include "clickableview.h"

ClickableView::ClickableView(QWidget *parent):QGraphicsView(parent) {}

void ClickableView::mousePressEvent(QMouseEvent *event) {
    QPointF scene_pos = mapToScene(event->pos());
    int row = int(scene_pos.y() / 16);
    int col = int(scene_pos.x() / 16);
    if (row >= 0 && col >= 0) emit mouseClicked(row, col);
}
