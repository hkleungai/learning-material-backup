#include <fstream>

#include <QFileDialog>
#include <QDebug>
#include <QGraphicsPixmapItem>
#include <QMessageBox>

#include "gamewindow.h"
#include "ui_gamewindow.h"

#include "clickableview.h"

using namespace std;

GameWindow::GameWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::GameWindow)
{
    ui->setupUi(this);

    ui->graphicsView->setScene(&scene);
    ui->graphicsView->show();

    connect(ui->graphicsView, &ClickableView::mouseClicked, this, &GameWindow::map_clicked);

    ui->actionPlayers->setVisible(false);
    ui->actionStart->setVisible(false);
    ui->actionHeal->setVisible(false);
}

GameWindow::~GameWindow()
{
    delete ui;
    for (int i=0; i<num_players; i++) delete players[i];
    delete[] players;
}


void GameWindow::on_actionMap_triggered()
{
    QString filename = QFileDialog::getOpenFileName(this, tr("Open Map File"), ".", tr("Text Files (*.txt)"));
    qDebug() << filename;
    if (filename == "") return;
    for (int i=0; i<num_players; i++) delete players[i];
    delete[] players;
    num_players = 0;
    players = nullptr;
    game_map.load_terrain_map(filename.toStdString());
//    game_map.render_and_print_display_map(players, 0);
    game_map.render_map_gui(scene);
    ui->actionPlayers->setVisible(true);
    ui->actionStart->setVisible(false);
}

void GameWindow::on_actionPlayers_triggered()
{
    QString filename = QFileDialog::getOpenFileName(this, tr("Open Map File"), ".", tr("Text Files (*.txt)"));
    qDebug() << filename;
    if (filename == "") return;
    load_players_and_units(filename.toStdString());
    game_map.render_units_gui(scene, players, num_players);
    ui->actionStart->setVisible(true);
}

void GameWindow::load_players_and_units(const string& filename) {
    for (int i=0; i<num_players; i++) delete players[i];
    delete[] players;

    ifstream players_and_units_file(filename);

    players_and_units_file >> num_players;

    players = new Player*[num_players];

    for (int p = 0; p < num_players; p += 1) {
        string name;
        int num_units;
        players_and_units_file >> name >> num_units;
        //cout << name << " " << num_units << endl;
        Unit** units = new Unit*[num_units];

        QTreeWidgetItem *player_item = new QTreeWidgetItem(ui->treeWidget, {QString::fromStdString(name)});

        for (int u = 0; u < num_units; u += 1) {
            char id;
            string unit_type_string;
            int row, col;
            players_and_units_file >> id >> unit_type_string >> row >> col;
            //cout << id << " " << unit_type_string << " " << row << " " << col << endl;

            Unit* unit = nullptr;
            if (unit_type_string == "Swordsman") {
                unit = new Swordsman{id, row, col};
            } else if (unit_type_string == "Pikeman") {
                unit = new Pikeman{id, row, col};
            } else if (unit_type_string == "Knight") {
                unit = new Knight{id, row, col};
            } else if (unit_type_string == "Archer") {
                unit = new Archer{id, row, col};
            }
            units[u] = unit;
            //cout << unit->to_string() << endl;
            game_map.update_terrain_map(row, col, GameMap::TerrainState::OCCUPIED);

            QTreeWidgetItem *unit_item = new QTreeWidgetItem(player_item, {"test", "test"});
            units[u]->register_list_item(unit_item);
            units[u]->refresh_list_item_status();
        }
        players[p] = new Player{name, num_units, units};
        players[p]->register_list_item(player_item);
    }
}

int GameWindow::next_player() {
    for (int i=1; i<=num_players; i++) {
        int id_of_interest = (active_player_id + i) % num_players;
        if (players[id_of_interest]->has_units_alive()) {
            return active_player_id = id_of_interest;
        }
    }
    return active_player_id = -1;
}

void GameWindow::get_player_unit_by_pos(int row, int col, int &player_out, int &unit_out) {
    player_out = -1;
    unit_out = -1;
    for (int pi=0; pi<num_players; pi++) {
        for (int ui=0; ui<players[pi]->get_num_units(); ui++) {
            if (players[pi]->get_units()[ui]->get_position_row() == row
                    && players[pi]->get_units()[ui]->get_position_col() == col
                    && players[pi]->get_units()[ui]->is_alive()) {
                player_out = pi;
                unit_out = ui;
            }
        }
    }
}

void GameWindow::on_actionStart_triggered()
{
    players[next_player()]->ready_all_units();
    players[active_player_id]->refresh_list_item_status();
    ui->actionMap->setVisible(false);
    ui->actionPlayers->setVisible(false);
    ui->actionStart->setVisible(false);
}

void GameWindow::on_treeWidget_itemPressed(QTreeWidgetItem *item, int column)
{
    if (item != nullptr) {
        if (item->parent() != nullptr) {  // unit
            QTreeWidgetItem *player_item = item->parent();
            int player_id = ui->treeWidget->indexOfTopLevelItem(player_item);
            int unit_id = player_item->indexOfChild(item);
            Player *p = players[player_id];
            Unit *u = p->get_units()[unit_id];
            if (u->is_alive() && u->is_ready() && command_stage != 2) {
                unit_wait_command = unit_id;
                command_stage = 1;
                game_map.indicate_area(u->get_position_row(), u->get_position_col(), u->get_movement_range());
                ui->actionHeal->setVisible(true);
            }
        } else {  // player
            int player_id = ui->treeWidget->indexOfTopLevelItem(item);
        }
    }
}

void GameWindow::map_clicked(int row, int col) {
    if (active_player_id != -1) {
        if (unit_wait_command != -1) {
            switch (command_stage) {
            case 0: { // normal
                break;
            }
            case 1: { // move
                qDebug() << "case 1" << row << col;
                Player *p = players[active_player_id];
                Unit *u = p->get_units()[unit_wait_command];
                int starting_row = u->get_position_row();
                int starting_col = u->get_position_col();
                int delta_row = row - starting_row;
                int delta_col = col - starting_col;
                bool move_success = false;
                if ((delta_row != 0) || (delta_col != 0)) {
                    if (game_map.is_valid_path(u->get_position_row(), u->get_position_col(), delta_row, delta_col, u->get_movement_range())) {
                        u->move_delta(delta_row, delta_col);
                        game_map.update_terrain_map(starting_row, starting_col, GameMap::TerrainState::EMPTY);
                        game_map.update_terrain_map(starting_row + delta_row, starting_col + delta_col, GameMap::TerrainState::OCCUPIED);
                        u->refresh_view_position();
                        move_success = true;
                    }
                } else {
                    move_success = true;
                }
                if (move_success) {
                    this->ui->actionHeal->setVisible(false);
                    bool can_attack = false;
                    for (int pi = 0; pi < num_players; pi += 1) {
                        if (pi == active_player_id) { continue; }
                        for (int ui = 0; ui < players[pi]->get_num_units(); ui += 1) {
                            Unit* enemy_unit = players[pi]->get_units()[ui];
                            if (enemy_unit->is_alive()) {
                                int distance_row = ((u->get_position_row() > enemy_unit->get_position_row()) ? (u->get_position_row() - enemy_unit->get_position_row()) : (enemy_unit->get_position_row() - u->get_position_row()));
                                int distance_col = ((u->get_position_col() > enemy_unit->get_position_col()) ? (u->get_position_col() - enemy_unit->get_position_col()) : (enemy_unit->get_position_col() - u->get_position_col()));
                                if ((distance_row + distance_col) <= u->get_attack_range()) {
                                    can_attack = true;
                                }
                            }
                        }
                    }
                    if (can_attack) {
                        command_stage = 2;
                        game_map.indicate_area(row, col, u->get_attack_range());
                    } else {
                        game_map.reset_indicators();
                        u->end_turn();
                        u->refresh_list_item_status();
                        unit_wait_command = -1;
                        command_stage = 0;
                        if (!p->has_units_ready()) {
                            next_player();
                            Player *p_next = players[active_player_id];
                            p_next->ready_all_units();
                            p_next->refresh_list_item_status();
                        }
                    }
                }
                break;
            }
            case 2: { //attack
                qDebug() << "case 2" << row << col;
                Player *p = players[active_player_id];
                Unit *u = p->get_units()[unit_wait_command];
                int distance_row = ((u->get_position_row() > row) ? (u->get_position_row() - row) : (row - u->get_position_row()));
                int distance_col = ((u->get_position_col() > col) ? (u->get_position_col() - col) : (col - u->get_position_col()));
                if ((distance_row + distance_col) <= u->get_attack_range()) {  // in attack range
                    int epi, eui;
                    get_player_unit_by_pos(row, col, epi, eui);
                    if (epi != -1 && eui != -1) {  // whether have unit
                        Player *ep = players[epi];
                        Unit *eu = ep->get_units()[eui];
                        if (!((epi==active_player_id && eui!=unit_wait_command) || !eu->is_alive())) {  // do nothing if same player or enemy is dead
                            if (!(epi==active_player_id && eui==unit_wait_command)) {  // click self to abort attack
                                u->attack_unit(eu);
                                if (!u->is_alive()) { game_map.update_terrain_map(u->get_position_row(), u->get_position_col(), GameMap::TerrainState::EMPTY); }
                                if (!eu->is_alive()) { game_map.update_terrain_map(eu->get_position_row(), eu->get_position_col(), GameMap::TerrainState::EMPTY); }
                                u->refresh_view_position();
                                u->refresh_list_item_status();
                                eu->refresh_view_position();
                                eu->refresh_list_item_status();
                            }
                            game_map.reset_indicators();
                            u->end_turn();
                            u->refresh_list_item_status();
                            unit_wait_command = -1;
                            command_stage = 0;
                            if (is_game_over()) {
                                qDebug() << "End";
                                QMessageBox::information(this, tr("Info"), tr("Game End"));
                            } else if (!p->has_units_ready()) {
                                next_player();
                                Player *p_next = players[active_player_id];
                                p_next->ready_all_units();
                                p_next->refresh_list_item_status();
                            }
                        }
                    }
                }
                break;
            }};
        } else {
            switch (command_stage) {
            case 0: { // normal
                qDebug() << "case 0" << row << col;
                int pi;
                int ui;
                get_player_unit_by_pos(row, col, pi, ui);
                if (pi != -1 && ui != -1 && players[pi]->get_units()[ui]->is_ready()) {
                    unit_wait_command = ui;
                    command_stage = 1;
                    game_map.indicate_area(row, col, players[pi]->get_units()[ui]->get_movement_range());
                    this->ui->actionHeal->setVisible(true);
                }
                break;
            }
            case 1: { // move
                break;
            }
            case 2: { //attack
                break;
            }};
        }
    }
}

bool GameWindow::is_game_over() const {
    int num_players_remaining = 0;
    for (int i = 0; i < num_players; i += 1) {
        if (players[i]->has_units_alive()) { num_players_remaining += 1; }
        if (num_players_remaining > 1) { return false; }
    }
    return true;
}

void GameWindow::on_actionHeal_triggered()
{
    if (active_player_id != -1 && unit_wait_command != -1 && command_stage == 1) {
        Player *p = players[active_player_id];
        Unit *u = p->get_units()[unit_wait_command];
        u->heal();
        this->ui->actionHeal->setVisible(false);
        game_map.reset_indicators();
        u->end_turn();
        u->refresh_list_item_status();
        unit_wait_command = -1;
        command_stage = 0;
        if (!p->has_units_ready()) {
            next_player();
            Player *p_next = players[active_player_id];
            p_next->ready_all_units();
            p_next->refresh_list_item_status();
        }
    }
}
