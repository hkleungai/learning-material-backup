#include "Deque.h"

// Task 1 - Constructors and Destructor of Node and Deque
Deque::Deque() : front{nullptr}, back{nullptr} {}
Deque::~Deque() {
    Node *curr=front, *next=front;
    do {
        curr = next;
        if (curr != nullptr) next = curr->next;
        delete curr;
    } while(curr != back);
}

// Task 2 - Essential operations for Deque
bool Deque::is_empty() const { return front == nullptr; }

void Deque::push_front(int data)
{
    if (is_empty())
    {
        front = back = new Node{data};
        return;
    }
    Node *new_front = new Node{data, nullptr, front};
    front->prev = new_front;
    front = new_front;
}

void Deque::push_back(int data)
{
    if (is_empty())
    {
        front = back = new Node{data};
        return;
    }
    Node *new_back = new Node{data, back, nullptr};
    back->next = new_back;
    back = new_back;
}

void Deque::pop_front()
{
    if (is_empty())
        return;
    if (front == back)
    {
        delete front;
        front = back = nullptr;
        return;
    }
    Node *new_front = front->next;
    new_front->prev = nullptr;
    delete front;
    front = new_front;
}

void Deque::pop_back()
{
    if (is_empty())
        return;
    if (front == back)
    {
        delete back;
        front = back = nullptr;
        return;
    }
    Node *new_back = back->prev;
    new_back->next = nullptr;
    delete back;
    back = new_back;
}

const Node *Deque::peek_front() const { return front; }

const Node *Deque::peek_back() const { return back; }

// Task 3 - Extended operations for Deque
const Node *Deque::get_node_at(int idx) const
{
    if (idx < 0)
        return nullptr;
    const Node *result = front;
    while (idx > 0 && result != nullptr)
    {
        --idx;
        result = result->next;
    }
    return result;
}

void Deque::insert_data_at(int idx, int data)
{
    if (idx < 0)
        return;
    if (idx == 0)
        return push_front(data);
    Node *next = front;
    while (idx > 0 && next != nullptr)
    {
        --idx;
        next = next->next;
    }
    if (idx > 0)
        return;
    if (next == nullptr)
        return push_back(data);
    Node *current = new Node{data, next->prev, next};
    next->prev->next = current;
    next->prev = current;
}

void Deque::remove_at(int idx)
{
    if (idx < 0)
        return;
    if (idx == 0)
        return pop_front();
    Node *nd = front;
    while (idx > 0 && nd != nullptr)
    {
        --idx;
        nd = nd->next;
    }
    if (idx > 0 || nd == nullptr)
        return;
    if (nd == back)
        return pop_back();
    nd->prev->next = nd->next;
    nd->next->prev = nd->prev;
    delete nd;
}
