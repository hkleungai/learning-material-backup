#include "Node.h"

// Task 1 - Constructors and Destructor of Node and Deque
Node::Node(int data) : data{data}, prev{nullptr}, next{nullptr} {}
Node::Node(int data, Node *prev, Node *next) : data{data}, prev{prev}, next{next} {}
Node::~Node() {}
