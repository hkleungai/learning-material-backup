#include "Node.h"

class Deque
{
    Node *front;
    Node *back;

public:
    Deque();
    ~Deque();
    void push_front(int);
    void push_back(int);
    void pop_front();
    void pop_back();
    const Node *peek_front() const;
    const Node *peek_back() const;
    bool is_empty() const;
    const Node *get_node_at(int) const;
    void insert_data_at(int, int);
    void remove_at(int);
};
