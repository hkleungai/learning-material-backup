#include "Utils.h"
#include "FilesystemStub.h"
#include <TinySHA1.hpp>
#include <string>
#include <ctime>
#include <stdexcept>

using namespace std;

void stage_content(const std::string &filename) {
    auto iter = FilesystemStub::cwd_files.find(filename);
    if (iter != FilesystemStub::cwd_files.end()) {
        FilesystemStub::staged_files[filename] = iter->second;
    }
}

bool is_file_exist(const std::string &filename) {
    return FilesystemStub::cwd_files.find(filename) != FilesystemStub::cwd_files.end();
}

std::string get_string_sha1(const string &str) {
    sha1::SHA1 s;
    s.processBytes(str.c_str(), str.size());
    uint32_t digest[5];
    s.getDigest(digest);
    char buf[48];
    snprintf(buf, 42, "%08x%08x%08x%08x%08x",
             digest[0], digest[1], digest[2], digest[3], digest[4]);
    return buf;
}

std::string get_sha1(const std::string &message, const std::string &time) {
    return get_string_sha1(message + time);
}

std::string get_sha1(const std::string &filename) {
    auto iter = FilesystemStub::cwd_files.find(filename);
    if (iter == FilesystemStub::cwd_files.end()) {
        throw std::runtime_error("failed to open " + filename);
    }

    return get_string_sha1(iter->second);
}

std::string get_time_string() {
    std::time_t now = std::time(nullptr);
    return std::ctime(&now);
}

bool write_file(const std::string &filename, const std::string &ref) {
    auto src = FilesystemStub::blobs.find(ref);
    if (src == FilesystemStub::blobs.end()) {
        return false;
    }

    FilesystemStub::cwd_files[filename] = src->second;
    return true;
}

bool restricted_delete(const std::string &filename) {
    auto iter = FilesystemStub::cwd_files.find(filename);
    if (iter == FilesystemStub::cwd_files.end()) {
        return false;
    }

    FilesystemStub::cwd_files.erase(iter);
    return true;
}

void add_conflict_marker(const std::string &filename, const std::string &ref) {
    string header = "<<<<<<< HEAD\n";
    string separator = "=======\n";
    string footer = ">>>>>>>\n";

    auto src_iter = FilesystemStub::cwd_files.find(filename);
    auto ref_iter = FilesystemStub::blobs.find(ref);

    if (ref.empty()) {
        if (src_iter == FilesystemStub::cwd_files.end()) {
            return;
        }
        string head_content = src_iter->second;
        string marker = header + head_content + separator + footer;
        src_iter->second = marker;
        return;
    }

    if (src_iter == FilesystemStub::cwd_files.end() && ref_iter == FilesystemStub::blobs.end()) {
        return;
    }

    string head_content = src_iter != FilesystemStub::cwd_files.end() ? src_iter->second : string();
    string other_content = ref_iter != FilesystemStub::blobs.end() ? ref_iter->second : string();
    string marker = header + head_content + separator + other_content + footer;
    FilesystemStub::cwd_files[filename] = marker;
}
