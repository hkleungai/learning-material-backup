#include <iostream>
#include <string>
#include <vector>

#include "Repository.h"
#include "Tester.h"
#include "FilesystemStub.h"

using std::cout;
using std::endl;

// Clean the testing directory for further testing
void clean_environment() {
    FilesystemStub::cwd_files.clear();
    FilesystemStub::staged_files.clear();
    FilesystemStub::blobs.clear();
}

bool test_handler(const std::string &filename, bool verbose) {
    try {
        Tester tester(filename, verbose);
        clean_environment();
        if (!tester.run()) {
            cout << "Test FAILED" << endl;
            return false;
        }
    } catch (const std::exception &e) {
        cout << e.what() << endl << "Test FAILED" << endl;
        return false;
    }
    return true;
}

int run_test(const std::string &filename, bool verbose) {
    test_handler(filename, verbose);
    Repository::close();
    return 0;
}

int main(int argc, char *argv[]) {
    if (Repository::check_file_structure()) {
        Repository::load_repository();
    }

    if (argc == 1) {
        return 0;
    }

    std::vector<std::string> args;
    for (int i = 1; i < argc; ++i) {
        args.emplace_back(argv[i]);
    }

    if (args.size() == 2 && args[0] == "-t") {
        return run_test(args[1], false);
    }

    if (args.size() == 2 && (args[0] == "-tv" || args[0] == "-vt")) {
        return run_test(args[1], true);
    }

    if (!validate_args(args)) {
        return 0;
    }
    parse_args(args);
    Repository::close();

    return 0;
}
