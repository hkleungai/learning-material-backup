#ifndef COMP2012H_FA21_PA2_FILESYSTEMSTUB_H
#define COMP2012H_FA21_PA2_FILESYSTEMSTUB_H

#include <string>
#include <unordered_map>

class FilesystemStub {
public:
    static void clean_environment(bool cleanUpBlobs = true);
    static void init_source_files();

    static std::unordered_map<std::string, std::string> cwd_files;      // files in CWD
    static std::unordered_map<std::string, std::string> staged_files;   // files in .gitlite/index
    static std::unordered_map<std::string, std::string> blobs;          // files in .gitlite/blobs
    static std::unordered_map<std::string, std::string> tester_src;     // files in testing/src
};


#endif //COMP2012H_FA21_PA2_FILESYSTEMSTUB_H
