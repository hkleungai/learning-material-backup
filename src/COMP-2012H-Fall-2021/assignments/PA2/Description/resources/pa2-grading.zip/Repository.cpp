//
// Autograder version
//

#include <fstream>
#include <unordered_set>
#include <regex>

#include "Repository.h"
#include "Utils.h"
#include "gitlite.h"
#include "FilesystemStub.h"

using namespace std;

std::unordered_map<std::string, Commit *> Repository::commits;

Commit *Repository::head_commit = nullptr;
List *Repository::tracked_files = nullptr;
List *Repository::branches = nullptr;
List *Repository::staged_files = nullptr;
Blob *Repository::current_branch = nullptr;

void Repository::make_file_structure() { }

void Repository::load_repository() { }

bool Repository::init() {
    try {
        make_file_structure();
    } catch (const std::runtime_error &err) {
        cout << err.what() << endl;
        return false;
    }

    ::init(current_branch, branches, staged_files, tracked_files, head_commit);
    commits.insert({head_commit->commit_id, head_commit});
    return true;
}

bool Repository::add(const string &filename) {
    auto iter = FilesystemStub::cwd_files.find(filename);
    if (iter == FilesystemStub::cwd_files.end()) {
        cout << "File does not exist." << endl;
        return false;
    }

    if (::add(filename, staged_files, tracked_files, head_commit)) {
        // Stage the files to .gitlite/index
        FilesystemStub::staged_files[filename] = iter->second;
    } else {
        // Remove from staged files
        auto staged_file = FilesystemStub::staged_files.find(filename);
        if (staged_file != FilesystemStub::staged_files.end()) {
            FilesystemStub::staged_files.erase(staged_file);
        }
    }

    return true;
}

bool Repository::commit(const string &message) {
    if (::commit(message, current_branch, staged_files, tracked_files, head_commit)) {
        commits.insert({head_commit->commit_id, head_commit});
        flush_staged_changes();
        return true;
    }
    return false;
}

bool Repository::remove(const string &filename) {
    if (::remove(filename, staged_files, tracked_files, head_commit)) {
        auto iter = FilesystemStub::staged_files.find(filename);
        if (iter != FilesystemStub::staged_files.end()) {
            FilesystemStub::staged_files.erase(iter);
        }
        return true;
    }
    return false;
}

void Repository::log() {
    ::log(head_commit);
}

void Repository::global_log() {
    for (auto &entry : commits) {
        cout << "===" << endl;
        commit_print(entry.second);
        cout << endl << endl;
    }
}

bool Repository::find(const string &message) {
    bool found = false;
    for (auto &entry : commits) {
        if (entry.second->message == message) {
            cout << entry.second->commit_id << endl;
            found = true;
        }
    }
    if (!found) {
        cout << "Found no commit with that message." << endl;
    }
    return found;
}

void Repository::status() {
    List *files = get_cwd_files();
    ::status(current_branch, branches, staged_files, tracked_files, files, head_commit);
    list_delete(files);
}

bool Repository::checkout_file(const string &filename) {
    return ::checkout(filename, head_commit);
}

bool Repository::checkout_file(const string &commit_id, const string &filename) {
    string full_id = resolve_commit_id(commit_id);
    auto commit = commits.find(full_id);
    if (commit == commits.end()) {
        return ::checkout(filename, nullptr);
    } else {
        return ::checkout(filename, commit->second);
    }
}

bool Repository::checkout_branch(const string &branch_name) {
    List *filenames = get_cwd_files();
    if (::checkout(branch_name, current_branch, branches, staged_files, tracked_files, filenames, head_commit)) {
        clear_staging_area();
        list_delete(filenames);
        return true;
    }
    list_delete(filenames);
    return false;
}

bool Repository::branch(const string &branch_name) {
    if (::branch(branch_name, branches, head_commit)) {
        return true;
    }
    return false;
}

bool Repository::remove_branch(const string &branch_name) {
    if (::remove_branch(branch_name, current_branch, branches)) {
        return true;
    }
    return false;
}

bool Repository::reset(const std::string &commit_id) {
    string full_id = resolve_commit_id(commit_id);
    List *filenames = get_cwd_files();
    auto commit = commits.find(full_id);
    if (commit == commits.end()) {
        ::reset(nullptr, current_branch, staged_files, tracked_files, filenames, head_commit);
        list_delete(filenames);
        return false;
    } else {
        if (::reset(commit->second, current_branch, staged_files, tracked_files, filenames, head_commit)) {
            clear_staging_area();
            list_delete(filenames);
            return true;
        }
        list_delete(filenames);
        return false;
    }
}

bool Repository::merge(const std::string &branch_name) {
    List *filenames = get_cwd_files();
    Commit *prev_head_commit = head_commit;
    if (::merge(branch_name, current_branch, branches, staged_files, tracked_files, filenames, head_commit)) {
        list_delete(filenames);

        if (prev_head_commit != head_commit) {
            commits.insert({head_commit->commit_id, head_commit});
        }
        return true;
    }
    list_delete(filenames);
    return false;
}

void Repository::flush_track_records() { }

List *Repository::get_cwd_files() {
    List *list = list_new();
    for (auto &entry : FilesystemStub::cwd_files) {
        ::list_put(list, entry.first, string());
    }
    return list;
}

void Repository::clear_staging_area() {
    FilesystemStub::staged_files.clear();
}

std::string Repository::resolve_commit_id(const string &commit_id) {
    if (commit_id.size() < 2 || commit_id.size() > 40) {
        return {};    // return empty string if no match
    }

    string candidate;
    for (auto &entry : commits) {
        auto result = mismatch(commit_id.begin(), commit_id.end(), entry.first.begin());
        if (result.first == commit_id.end()) {
            if (!candidate.empty()) {
                return {};      // multiple matches
            }
            candidate = entry.first;
        }
    }
    return candidate;
}

void Repository::close() {
    // Free all pointers
    list_delete(tracked_files);
    list_delete(staged_files);
    list_delete(branches);
    for (auto &entry : commits) {
        Commit *commit = entry.second;
        list_clear(commit->tracked_files);
        delete commit->tracked_files->head;
        delete commit->tracked_files;
        delete commit;
    }
}

bool Repository::check_file_structure() {
    return true;
}

void Repository::flush_staged_changes() {
    for (auto &entry : FilesystemStub::staged_files) {
        string hash = get_string_sha1(entry.second);
        FilesystemStub::blobs[hash] = entry.second;
    }

    FilesystemStub::staged_files.clear();
}

// Reset all the in-memory states. Used for the tester when running multiple tests.
void Repository::reset_states() {
    head_commit = nullptr;
    tracked_files = staged_files = branches = nullptr;
    current_branch = nullptr;
    commits.clear();
}

bool validate_args(const std::vector<std::string> &args) {
    std::string command = args[0];
    if (command == "init" || command == "log" || command == "global-log" || command == "status") {
        if (args.size() != 1) {
            cout << "Incorrect operands." << endl;
            return false;
        }
        return true;
    }
    if (command == "add" || command == "rm" || command == "find"|| command == "branch" || command == "rm-branch"
        || command == "reset" || command == "merge") {
        if (args.size() != 2) {
            cout << "Incorrect operands." << endl;
            return false;
        }
        return true;
    }
    if (command == "checkout") {
        if (args.size() < 2 || args.size() > 4) {
            cout << "Incorrect operands." << endl;
            return false;
        }
        return true;
    }
    if (command == "commit") {
        if (args.size() < 2) {
            cout << "Please enter a commit message." << endl;
            return false;
        }
        if (args.size() > 2) {
            cout << "Incorrect operands." << endl;
            return false;
        }
        return true;
    }
    if (command == "quit") {
        if (args.size() != 1) {
            cout << "Incorrect operands." << endl;
            return false;
        }
        return true;
    }
    cout << "No command with that name exists." << endl;
    return false;
}

bool parse_args(const std::vector<std::string> &args) {
    std::string command = args[0];
    if (command == "init") {
        return Repository::init();
    } else {
        if (!Repository::check_file_structure()) {
            std::cout << "Not in an initialized Gitlite directory." << std::endl;
            return false;
        }
        if (command == "add") {
            return Repository::add(args[1]);
        }
        if (command == "commit") {
            return Repository::commit(args[1]);
        }
        if (command == "rm") {
            return Repository::remove(args[1]);
        }
        if (command == "log") {
            Repository::log();
            return true;
        }
        if (command == "global-log") {
            Repository::global_log();
            return true;
        }
        if (command == "find") {
            return Repository::find(args[1]);
        }
        if (command == "status") {
            Repository::status();
            return true;
        }
        if (command == "checkout") {
            if (args.size() == 2) {
                return Repository::checkout_branch(args[1]);
            }
            if (args[1] == "--") {
                return Repository::checkout_file(args[2]);
            }
            if (args[2] == "--") {
                return Repository::checkout_file(args[1], args[3]);
            }
            std::cout << "Incorrect operands." << std::endl;
            return false;
        }
        if (command == "branch") {
            return Repository::branch(args[1]);
        }
        if (command == "rm-branch") {
            return Repository::remove_branch(args[1]);
        }
        if (command == "reset") {
            return Repository::reset(args[1]);
        }
        if (command == "merge") {
            return Repository::merge(args[1]);
        }
    }
    return false;
}

std::vector<std::string> split_args(std::string input) {
    std::regex pattern(R"(("(?:\\.|[^"\\])*")|([^\s]+))");  // this captures escaped chars, but we do not actually escape them...
    std::vector<std::string> args;
    std::smatch match;
    while (std::regex_search(input, match, pattern)) {
        std::string arg(*match.begin());
        if (arg.length() > 2 && arg[0] == '"' && arg[arg.length() - 1] == '"') {
            args.emplace_back(arg.substr(1, arg.length() - 2));
        } else {
            args.emplace_back(arg);
        }
        input = match.suffix().str();
    }
    return args;
}
