//
// Created by Benran on 2021/7/30.
//

#include "FilesystemStub.h"

std::unordered_map<std::string, std::string> FilesystemStub::cwd_files;
std::unordered_map<std::string, std::string> FilesystemStub::staged_files;
std::unordered_map<std::string, std::string> FilesystemStub::blobs;
std::unordered_map<std::string, std::string> FilesystemStub::tester_src;

void FilesystemStub::clean_environment(bool cleanUpBlobs) {
    cwd_files.clear();
    staged_files.clear();
    if (cleanUpBlobs) {
        blobs.clear();
    }
}

void FilesystemStub::init_source_files() {
    tester_src.insert({"v1.txt", "v1\n"});
    tester_src.insert({"v2.txt", "v2\n"});
    tester_src.insert({"v3.txt", "v3\n"});
    tester_src.insert({"v4.txt", "v4\n"});
    tester_src.insert({"v5.txt", "v5\n"});
    tester_src.insert({"v6.txt", "v6\n"});

    tester_src.insert({"conflict1.txt", "<<<<<<< HEAD\n"
                                       "v4\n"
                                       "=======\n"
                                       "v5\n"
                                       ">>>>>>>\n"});
    tester_src.insert({"conflict2.txt", "<<<<<<< HEAD\n"
                                       "v4\n"
                                       "=======\n"
                                       "v5\n"
                                       ">>>>>>>\n"});
    tester_src.insert({"conflict3.txt", "<<<<<<< HEAD\n"
                                       "v5\n"
                                       "=======\n"
                                       ">>>>>>>\n"});
    tester_src.insert({"conflict4.txt", "<<<<<<< HEAD\n"
                                       "=======\n"
                                       "v6\n"
                                       ">>>>>>>\n"});

    tester_src.insert({"akari.c", "akari.c\n"});
    tester_src.insert({"img.png", "img.png\n"});
    tester_src.insert({"text1.txt", "Almost before we knew it, we had left the ground.\n"});
    tester_src.insert({"text2.txt", "Over the horizon comes the break of dawn.\n"});
}
