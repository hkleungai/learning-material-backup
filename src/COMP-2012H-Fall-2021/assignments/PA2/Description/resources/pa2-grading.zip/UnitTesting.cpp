#include <iostream>
#include <vector>
#include <algorithm>
#include <unordered_set>
#include <sstream>
#include <set>
#include "Commit.h"
#include "Utils.h"
#include "gitlite.h"
#include "FilesystemStub.h"

#define TEST_NAME(test_suite_name, test_name) test_suite_name##_##test_name
#define TEST(test_suite_name, test_name) \
void TEST_NAME(test_suite_name, test_name)()

#define ASSERT_TRUE(cond) \
do {                      \
    if (!(cond)) {        \
        cerr << "Assertion failed on line " << __LINE__ << endl; \
        exit (1);         \
    }                     \
} while (false)

#define ASSERT_NE(a, b) \
do {                    \
    if ((a) == (b)) {   \
        cerr << "Assertion failed on line " << __LINE__ << endl; \
        exit (1);       \
    }                   \
} while (false)

#define ASSERT_EQ(a, b) \
do {                    \
    if ((a) != (b)) {   \
        cerr << "Assertion failed on line " << __LINE__ << endl; \
        exit (1);       \
    }                   \
} while (false)

#define EXPECT_TRUE(cond) \
do {                      \
    if (!(cond)) {        \
        cerr << "Expected true on line " << __LINE__ << endl; \
        exit (1);         \
    }                     \
} while (false)

#define EXPECT_FALSE(cond) \
do {                      \
    if ((cond)) {        \
        cerr << "Expected false on line " << __LINE__ << endl; \
        exit (1);         \
    }                     \
} while (false)

#define EXPECT_EQ(a, b) \
do {                    \
    if ((a) != (b)) {   \
        cerr << "Equality check failed on line " << __LINE__ << endl; \
        exit(1); }      \
    } while (false)

#define EXPECT_EQ_TRIM(a, b) \
do {                    \
    if (rtrim_copy((a)) != rtrim_copy((b))) {   \
        cerr << "Equality check failed on line " << __LINE__ << endl; \
        exit(1); }      \
    } while (false)

using namespace std;

namespace UnitTesting {
    Blob *blob_create(const string &name, const string &ref) {
        Blob *blob = new Blob;
        blob->name = name;
        blob->ref = ref;
        blob->commit = nullptr;
        return blob;
    }

    Blob *blob_create(const string &name, Commit *commit) {
        Blob *blob = new Blob;
        blob->name = name;
        blob->ref = "";
        blob->commit = commit;
        return blob;
    }

    void blob_init(Blob &blob, const string &name, const string &ref, Commit *commit = nullptr) {
        blob.name = name;
        blob.ref = ref;
        blob.commit = commit;
    }

    Commit commit_init(const string &message, List *tracked_files = nullptr, Commit *parent = nullptr,
                       Commit *second_parent = nullptr) {
        Commit commit;
        commit.message = message;
        commit.time = get_time_string();
        commit.commit_id = get_sha1(commit.message, commit.time);
        commit.parent = parent;
        commit.second_parent = second_parent;
        commit.tracked_files = tracked_files;
        return commit;
    }

    Commit *commit_create(const string &message, List *tracked_files = nullptr, Commit *parent = nullptr,
                          Commit *second_parent = nullptr) {
        Commit *commit = new Commit;
        commit->message = message;
        commit->time = get_time_string();
        commit->commit_id = get_sha1(commit->message, commit->time);
        commit->parent = parent;
        commit->second_parent = second_parent;
        commit->tracked_files = tracked_files;
        return commit;
    }

    void list_push_back(List *list, Blob *blob) {
        Blob *head = list->head;
        blob->prev = head->prev;
        blob->next = head;
        head->prev->next = blob;
        head->prev = blob;
    }

    Blob *list_put(List *list, const string &name, const string &ref) {
        Blob *blob = list_find_name(list, name);
        if (blob != nullptr) {
            blob->ref = ref;
            return blob;
        }

        blob = new Blob;
        blob->name = name;
        blob->ref = ref;

        Blob *cur;
        for (cur = list->head->next; cur != list->head; cur = cur->next) {
            if (cur->name > name) {
                break;
            }
        }

        blob->prev = cur->prev;
        blob->next = cur;
        cur->prev->next = blob;
        cur->prev = blob;

        return blob;
    }

    Blob *list_put(List *list, const string &name, Commit *commit) {
        Blob *blob = list_find_name(list, name);
        if (blob != nullptr) {
            blob->commit = commit;
            return blob;
        }

        blob = new Blob;
        blob->name = name;
        blob->commit = commit;

        Blob *cur;
        for (cur = list->head->next; cur != list->head; cur = cur->next) {
            if (cur->name > name) {
                break;
            }
        }

        blob->prev = cur->prev;
        blob->next = cur;
        cur->prev->next = blob;
        cur->prev = blob;

        return blob;
    }

    bool list_empty(const List *list) {
        if (list == nullptr || list->head == nullptr) {
            return false;
        }

        return list->head == list->head->next && list->head->prev == list->head;
    }

    int list_size(const List *list) {
        int count = 0;
        for (Blob *blob = list->head->next; blob != list->head; blob = blob->next) {
            ++count;
        }
        return count;
    }

    List *list_create(const std::vector<Blob> &blobs) {
        List *list = new List;
        Blob *head = list->head = new Blob;
        head->prev = head->next = head;

        for (auto &node : blobs) {
            Blob *blob = new Blob(node);
            blob->prev = head->prev;
            blob->next = head;
            head->prev->next = blob;
            head->prev = blob;
        }
        return list;
    }

    void list_delete(List *list) {
        Blob *blob = list->head->next;
        while (blob != list->head) {
            blob = blob->next;
            delete blob->prev;
        }
        delete list->head;
        delete list;
    }

    void commit_free(Commit *commit) {
        UnitTesting::list_delete(commit->tracked_files);
        delete commit;
    }

    bool check_list_equivalence(const List *actual, std::vector<Blob> expected) {
        auto blob_comparator = [](const Blob &b1, const Blob &b2) -> bool {
            return b1.name != b2.name ? b1.name < b2.name : b1.ref < b2.ref;
        };

        std::set<Blob, decltype(blob_comparator)> actual_set(blob_comparator);
        std::set<Blob, decltype(blob_comparator)> expected_set(expected.begin(), expected.end(), blob_comparator);

        for (Blob *blob = actual->head->next; blob != actual->head; blob = blob->next) {
            actual_set.insert(*blob);
        }

        return actual_set == expected_set;
    }

    bool check_file_content(const string &filename, const string &expected_content) {
        auto iter = FilesystemStub::cwd_files.find(filename);
        if (iter == FilesystemStub::cwd_files.end()) {
            return false;
        }
        return iter->second == expected_content;
    }

    bool is_file_staged(const string &filename) {
        auto iter = FilesystemStub::staged_files.find(filename);
        return iter != FilesystemStub::staged_files.end();
    }

    void add_blob_to_filesystem(const string &content) {
        FilesystemStub::blobs.insert({get_string_sha1(content), content});
    }

    // Used in linked list operations
    const string filename1 = "filename1";
    const string filename2 = "filename2";
    const string filename3 = "filename3";
    const string filename4 = "filename4";
    const string filename5 = "filename5";
    const string filename6 = "filename6";

    const string ref1 = get_string_sha1("content1");
    const string ref2 = get_string_sha1("content2");

    Commit commit1 = commit_init("message1");
    Commit commit2 = commit_init("message2");

    // Used in Gitlite commands
    Blob v1, v2, v3_old, v3_new, v4;

    List *tracked_files;
    List *staged_files;
    List *branches;
    List *cwd_files;
    vector<Blob> head_tracked_files;

    Commit *head_commit;
    Blob *current_branch;

    Blob master, dev;
    Commit *m0, *m1, *n1;

    stringstream output_buffer;
    streambuf *cout_buffer;

    void BasicOperationTestSetup() {
        blob_init(v1, "v1", get_string_sha1("v1\n"));
        blob_init(v2, "v2", get_string_sha1("v2\n"));
        blob_init(v3_old, "v3", get_string_sha1("v3 old\n"));
        blob_init(v3_new, "v3", get_string_sha1("v3 new\n"));
        blob_init(v4, "v4", get_string_sha1("v4\n"));

        tracked_files = list_create({v1, v3_new});
        staged_files = list_create({v1, v3_new});
        head_tracked_files = {v3_old, v4};

        head_commit = commit_create("c0", list_create(head_tracked_files));
        current_branch = blob_create("master", head_commit);

        cout_buffer = cout.rdbuf();
        output_buffer = stringstream();
        cout.rdbuf(output_buffer.rdbuf());

        FilesystemStub::cwd_files.insert({"v1", "v1 new\n"});
        FilesystemStub::cwd_files.insert({"v2", "v2\n"});
        FilesystemStub::cwd_files.insert({"v3", "v3 new\n"});
        FilesystemStub::cwd_files.insert({"v4", "v4\n"});
    }

    void BasicOperationTestTeardown() {
        UnitTesting::list_delete(tracked_files);
        UnitTesting::list_delete(staged_files);
        UnitTesting::list_delete(head_commit->tracked_files);

        delete head_commit;
        delete current_branch;

        cout.rdbuf(cout_buffer);

        FilesystemStub::clean_environment();
    }

    void MultiBranchTestSetup() {
        blob_init(v1, "v1", get_string_sha1("v1\n"));
        blob_init(v2, "v2", get_string_sha1("v2\n"));
        blob_init(v3_old, "v3", get_string_sha1("v3 old\n"));
        blob_init(v3_new, "v3", get_string_sha1("v3 new\n"));
        blob_init(v4, "v4", get_string_sha1("v4\n"));

        tracked_files = list_create({v2, v3_new, v4});
        staged_files = list_create({v4});
        cwd_files = list_create({v2, v3_new});

        m0 = commit_create("m0", list_create({v1, v3_old}));
        m1 = commit_create("m1", list_create({v2, v3_new}), m0);
        n1 = commit_create("n1", list_create({v1, v3_old, v4}), m0);

        blob_init(master, "master", string(), m1);
        blob_init(dev, "dev", string(), n1);
        branches = list_create({dev, master});
        current_branch = list_find_name(branches, "master");

        head_commit = m1;

        cout_buffer = cout.rdbuf();
        output_buffer = stringstream();
        cout.rdbuf(output_buffer.rdbuf());

        FilesystemStub::cwd_files.insert({"v2", "v2\n"});
        FilesystemStub::cwd_files.insert({"v3", "v3 new\n"});

        add_blob_to_filesystem("v1\n");
        add_blob_to_filesystem("v2\n");
        add_blob_to_filesystem("v3 old\n");
        add_blob_to_filesystem("v3 new\n");
        add_blob_to_filesystem("v4\n");
    }

    void MultiBranchTestTeardown() {
        UnitTesting::list_delete(tracked_files);
        UnitTesting::list_delete(staged_files);
        UnitTesting::list_delete(cwd_files);
        UnitTesting::list_delete(branches);
        commit_free(m0);
        commit_free(m1);
        commit_free(n1);

        cout.rdbuf(cout_buffer);

        FilesystemStub::clean_environment();
    }

    // trim from end (in place)
    static inline void rtrim(std::string &s) {
        s.erase(std::find_if(s.rbegin(), s.rend(), [](unsigned char ch) {
            return !std::isspace(ch);
        }).base(), s.end());
    }

    // trim from end (copying)
    static inline std::string rtrim_copy(std::string s) {
        rtrim(s);
        return s;
    }
}

TEST(LinkedListOperations, ListNew) {
    List *list1 = list_new();

    ASSERT_TRUE(list1 != nullptr);

    // Check sentinel node
    Blob *sentinel = list1->head;
    ASSERT_TRUE(sentinel != nullptr);
    EXPECT_EQ(sentinel->next, sentinel);
    EXPECT_EQ(sentinel->prev, sentinel);

    // Check sentinel node content
    EXPECT_EQ(sentinel->name, "");
    EXPECT_EQ(sentinel->ref, "");
    EXPECT_EQ(sentinel->commit, nullptr);
}

TEST(LinkedListOperations, ListPushBackOne) {
    List *list1 = list_new();
    Blob *file1 = UnitTesting::blob_create(UnitTesting::filename1, UnitTesting::ref1);

    list_push_back(list1, file1);

    // Forward traversal
    EXPECT_EQ(list1->head->next, file1);
    EXPECT_EQ(file1->next, list1->head);

    // Backward traversal
    EXPECT_EQ(list1->head->prev, file1);
    EXPECT_EQ(file1->prev, list1->head);
}

TEST(LinkedListOperations, ListPushBackMultiple) {
    List *list1 = list_new();
    Blob *file1 = UnitTesting::blob_create(UnitTesting::filename1, UnitTesting::ref1);
    Blob *file2 = UnitTesting::blob_create(UnitTesting::filename2, UnitTesting::ref1);
    Blob *file3 = UnitTesting::blob_create(UnitTesting::filename3, UnitTesting::ref1);

    list_push_back(list1, file1);
    list_push_back(list1, file3);
    list_push_back(list1, file2);

    // Forward traversal
    EXPECT_EQ(list1->head->next, file1);
    EXPECT_EQ(file1->next, file3);
    EXPECT_EQ(file3->next, file2);
    EXPECT_EQ(file2->next, list1->head);

    // Backward traversal
    EXPECT_EQ(list1->head->prev, file2);
    EXPECT_EQ(file2->prev, file3);
    EXPECT_EQ(file3->prev, file1);
    EXPECT_EQ(file1->prev, list1->head);
}

TEST(LinkedListOperations, ListFindNameFound) {
    List *list1 = list_new();
    Blob *file1 = UnitTesting::blob_create(UnitTesting::filename1, UnitTesting::ref1);
    Blob *file2 = UnitTesting::blob_create(UnitTesting::filename2, UnitTesting::ref1);
    Blob *file3 = UnitTesting::blob_create(UnitTesting::filename3, UnitTesting::ref1);

    Blob *result;
    UnitTesting::list_push_back(list1, file1);

    result = list_find_name(list1, UnitTesting::filename1);
    EXPECT_EQ(result, file1);

    UnitTesting::list_push_back(list1, file3);
    UnitTesting::list_push_back(list1, file2);

    result = list_find_name(list1, UnitTesting::filename2);
    EXPECT_EQ(result, file2);

    result = list_find_name(list1, UnitTesting::filename3);
    EXPECT_EQ(result, file3);
}

TEST(LinkedListOperations, ListFindNameNotFound) {
    List *list1 = list_new();
    Blob *file1 = UnitTesting::blob_create(UnitTesting::filename1, UnitTesting::ref1);
    Blob *file2 = UnitTesting::blob_create(UnitTesting::filename2, UnitTesting::ref1);
    Blob *file3 = UnitTesting::blob_create(UnitTesting::filename3, UnitTesting::ref1);

    Blob *result;

    result = list_find_name(list1, UnitTesting::filename4);
    EXPECT_EQ(result, nullptr);

    UnitTesting::list_push_back(list1, file1);

    result = list_find_name(list1, UnitTesting::filename4);
    EXPECT_EQ(result, nullptr);

    UnitTesting::list_push_back(list1, file3);
    UnitTesting::list_push_back(list1, file2);

    result = list_find_name(list1, UnitTesting::filename4);
    EXPECT_EQ(result, nullptr);

    result = list_find_name(list1, UnitTesting::filename4);
    EXPECT_EQ(result, nullptr);
}

TEST(LinkedListOperations, ListPutNewOne) {
    List *list1 = list_new();
    Blob *file1 = list_put(list1, UnitTesting::filename1, UnitTesting::ref1);

    ASSERT_NE(file1, nullptr);
    EXPECT_EQ(file1->name, UnitTesting::filename1);
    EXPECT_EQ(file1->ref, UnitTesting::ref1);

    // Forward traversal
    EXPECT_EQ(list1->head->next, file1);
    EXPECT_EQ(file1->next, list1->head);

    // Backward traversal
    EXPECT_EQ(list1->head->prev, file1);
    EXPECT_EQ(file1->prev, list1->head);
}

TEST(LinkedListOperations, ListPutNewMultiple) {
    List *list1 = list_new();
    Blob *file1 = list_put(list1, UnitTesting::filename1, UnitTesting::ref1);
    Blob *file3 = list_put(list1, UnitTesting::filename3, UnitTesting::ref1);
    Blob *file2 = list_put(list1, UnitTesting::filename2, UnitTesting::ref1);

    ASSERT_NE(file1, nullptr);
    EXPECT_EQ(file1->name, UnitTesting::filename1);
    EXPECT_EQ(file1->ref, UnitTesting::ref1);

    ASSERT_NE(file2, nullptr);
    EXPECT_EQ(file2->name, UnitTesting::filename2);
    EXPECT_EQ(file2->ref, UnitTesting::ref1);

    ASSERT_NE(file3, nullptr);
    EXPECT_EQ(file3->name, UnitTesting::filename3);
    EXPECT_EQ(file3->ref, UnitTesting::ref1);

    // Forward traversal
    EXPECT_EQ(list1->head->next, file1);
    EXPECT_EQ(file1->next, file2);
    EXPECT_EQ(file2->next, file3);
    EXPECT_EQ(file3->next, list1->head);

    // Backward traversal
    EXPECT_EQ(list1->head->prev, file3);
    EXPECT_EQ(file3->prev, file2);
    EXPECT_EQ(file2->prev, file1);
    EXPECT_EQ(file1->prev, list1->head);
}

TEST(LinkedListOperations, ListPutNewMultipleCommit) {
    List *list1 = list_new();
    Blob *branch1 = list_put(list1, UnitTesting::filename1, &UnitTesting::commit1);
    Blob *branch3 = list_put(list1, UnitTesting::filename3, &UnitTesting::commit1);
    Blob *branch2 = list_put(list1, UnitTesting::filename2, &UnitTesting::commit1);

    ASSERT_NE(branch1, nullptr);
    EXPECT_EQ(branch1->name, UnitTesting::filename1);
    EXPECT_EQ(branch1->commit, &UnitTesting::commit1);

    ASSERT_NE(branch2, nullptr);
    EXPECT_EQ(branch2->name, UnitTesting::filename2);
    EXPECT_EQ(branch2->commit, &UnitTesting::commit1);

    ASSERT_NE(branch3, nullptr);
    EXPECT_EQ(branch3->name, UnitTesting::filename3);
    EXPECT_EQ(branch3->commit, &UnitTesting::commit1);

    // Forward traversal
    EXPECT_EQ(list1->head->next, branch1);
    EXPECT_EQ(branch1->next, branch2);
    EXPECT_EQ(branch2->next, branch3);
    EXPECT_EQ(branch3->next, list1->head);

    // Backward traversal
    EXPECT_EQ(list1->head->prev, branch3);
    EXPECT_EQ(branch3->prev, branch2);
    EXPECT_EQ(branch2->prev, branch1);
    EXPECT_EQ(branch1->prev, list1->head);
}

TEST(LinkedListOperations, ListPutUpdateOne) {
    List *list1 = list_new();
    Blob *file1 = UnitTesting::list_put(list1, UnitTesting::filename1, UnitTesting::ref1);

    Blob *new_file1;
    new_file1 = list_put(list1, UnitTesting::filename1, UnitTesting::ref2);

    ASSERT_EQ(file1, new_file1);
    EXPECT_EQ(file1->name, UnitTesting::filename1);
    EXPECT_EQ(file1->ref, UnitTesting::ref2);

    // Forward traversal
    EXPECT_EQ(list1->head->next, file1);
    EXPECT_EQ(file1->next, list1->head);

    // Backward traversal
    EXPECT_EQ(list1->head->prev, file1);
    EXPECT_EQ(file1->prev, list1->head);
}

TEST(LinkedListOperations, ListPutUpdateMultiple) {
    List *list1 = list_new();
    Blob *file1 = UnitTesting::list_put(list1, UnitTesting::filename1, UnitTesting::ref1);
    Blob *file2 = UnitTesting::list_put(list1, UnitTesting::filename2, UnitTesting::ref1);
    Blob *file3 = UnitTesting::list_put(list1, UnitTesting::filename3, UnitTesting::ref1);

    Blob *new_file1 = list_put(list1, UnitTesting::filename1, UnitTesting::ref2);

    ASSERT_EQ(file1, new_file1);
    EXPECT_EQ(file1->name, UnitTesting::filename1);
    EXPECT_EQ(file1->ref, UnitTesting::ref2);

    Blob *new_file2 = list_put(list1, UnitTesting::filename2, UnitTesting::ref2);

    ASSERT_EQ(file2, new_file2);
    EXPECT_EQ(file2->name, UnitTesting::filename2);
    EXPECT_EQ(file2->ref, UnitTesting::ref2);

    Blob *new_file3 = list_put(list1, UnitTesting::filename3, UnitTesting::ref2);

    ASSERT_EQ(file3, new_file3);
    EXPECT_EQ(file3->name, UnitTesting::filename3);
    EXPECT_EQ(file3->ref, UnitTesting::ref2);

    // Forward traversal
    EXPECT_EQ(list1->head->next, file1);
    EXPECT_EQ(file1->next, file2);
    EXPECT_EQ(file2->next, file3);
    EXPECT_EQ(file3->next, list1->head);

    // Backward traversal
    EXPECT_EQ(list1->head->prev, file3);
    EXPECT_EQ(file3->prev, file2);
    EXPECT_EQ(file2->prev, file1);
    EXPECT_EQ(file1->prev, list1->head);
}

TEST(LinkedListOperations, ListPutUpdateMultipleCommit) {
    List *list1 = list_new();
    Blob *branch1 = list_put(list1, UnitTesting::filename1, &UnitTesting::commit1);
    Blob *branch3 = list_put(list1, UnitTesting::filename3, &UnitTesting::commit1);
    Blob *branch2 = list_put(list1, UnitTesting::filename2, &UnitTesting::commit1);

    Blob *new_branch1 = list_put(list1, UnitTesting::filename1, &UnitTesting::commit2);

    ASSERT_EQ(branch1, new_branch1);
    EXPECT_EQ(branch1->name, UnitTesting::filename1);
    EXPECT_EQ(branch1->commit, &UnitTesting::commit2);

    Blob *new_file2 = list_put(list1, UnitTesting::filename2, &UnitTesting::commit2);

    ASSERT_EQ(branch2, new_file2);
    EXPECT_EQ(branch2->name, UnitTesting::filename2);
    EXPECT_EQ(branch2->commit, &UnitTesting::commit2);

    Blob *new_file3 = list_put(list1, UnitTesting::filename3, &UnitTesting::commit2);

    ASSERT_EQ(branch3, new_file3);
    EXPECT_EQ(branch3->name, UnitTesting::filename3);
    EXPECT_EQ(branch3->commit, &UnitTesting::commit2);

    // Forward traversal
    EXPECT_EQ(list1->head->next, branch1);
    EXPECT_EQ(branch1->next, branch2);
    EXPECT_EQ(branch2->next, branch3);
    EXPECT_EQ(branch3->next, list1->head);

    // Backward traversal
    EXPECT_EQ(list1->head->prev, branch3);
    EXPECT_EQ(branch3->prev, branch2);
    EXPECT_EQ(branch2->prev, branch1);
    EXPECT_EQ(branch1->prev, list1->head);
}

TEST(LinkedListOperations, ListRemoveNotFound) {
    List *list1 = list_new();
    bool result;

    result = list_remove(list1, UnitTesting::filename1);
    EXPECT_EQ(result, false);

    Blob *file1 = UnitTesting::list_put(list1, UnitTesting::filename1, UnitTesting::ref1);
    Blob *file2 = UnitTesting::list_put(list1, UnitTesting::filename2, UnitTesting::ref1);
    Blob *file3 = UnitTesting::list_put(list1, UnitTesting::filename3, UnitTesting::ref1);

    result = list_remove(list1, UnitTesting::filename4);
    EXPECT_EQ(result, false);

    result = list_remove(list1, UnitTesting::filename4);
    EXPECT_EQ(result, false);

    result = list_remove(list1, UnitTesting::filename4);
    EXPECT_EQ(result, false);

    // Forward traversal
    EXPECT_EQ(list1->head->next, file1);
    EXPECT_EQ(file1->next, file2);
    EXPECT_EQ(file2->next, file3);
    EXPECT_EQ(file3->next, list1->head);

    // Backward traversal
    EXPECT_EQ(list1->head->prev, file3);
    EXPECT_EQ(file3->prev, file2);
    EXPECT_EQ(file2->prev, file1);
    EXPECT_EQ(file1->prev, list1->head);
}

TEST(LinkedListOperations, ListRemoveOne) {
    List *list1 = list_new();
    bool result;

    Blob *file1 = UnitTesting::list_put(list1, UnitTesting::filename1, UnitTesting::ref1);
    UnitTesting::list_put(list1, UnitTesting::filename2, UnitTesting::ref1);
    Blob *file3 = UnitTesting::list_put(list1, UnitTesting::filename3, UnitTesting::ref1);

    result = list_remove(list1, UnitTesting::filename2);
    EXPECT_EQ(result, true);

    // Forward traversal
    EXPECT_EQ(list1->head->next, file1);
    EXPECT_EQ(file1->next, file3);
    EXPECT_EQ(file3->next, list1->head);

    // Backward traversal
    EXPECT_EQ(list1->head->prev, file3);
    EXPECT_EQ(file3->prev, file1);
    EXPECT_EQ(file1->prev, list1->head);
}

TEST(LinkedListOperations, ListRemoveAll) {
    List *list1 = list_new();
    bool result;

    UnitTesting::list_put(list1, UnitTesting::filename1, UnitTesting::ref1);
    UnitTesting::list_put(list1, UnitTesting::filename2, UnitTesting::ref1);
    UnitTesting::list_put(list1, UnitTesting::filename3, UnitTesting::ref1);

    result = list_remove(list1, UnitTesting::filename2);
    EXPECT_EQ(result, true);

    result = list_remove(list1, UnitTesting::filename3);
    EXPECT_EQ(result, true);

    result = list_remove(list1, UnitTesting::filename1);
    EXPECT_EQ(result, true);

    // Forward traversal
    EXPECT_EQ(list1->head->next, list1->head);

    // Backward traversal
    EXPECT_EQ(list1->head->prev, list1->head);
}

TEST(LinkedListOperations, ListSize) {
    List *list1 = list_new();
    int result;

    result = list_size(list1);
    EXPECT_EQ(result, 0);

    UnitTesting::list_put(list1, UnitTesting::filename1, UnitTesting::ref1);

    result = list_size(list1);
    EXPECT_EQ(result, 1);

    UnitTesting::list_put(list1, UnitTesting::filename2, UnitTesting::ref1);
    UnitTesting::list_put(list1, UnitTesting::filename3, UnitTesting::ref1);

    result = list_size(list1);
    EXPECT_EQ(result, 3);
}

TEST(LinkedListOperations, ListClearEmpty) {
    List *list1 = list_new();
    list_clear(list1);

    // Forward traversal
    EXPECT_EQ(list1->head->next, list1->head);

    // Backward traversal
    EXPECT_EQ(list1->head->prev, list1->head);
}

TEST(LinkedListOperations, ListClearNonEmpty) {
    List *list1 = list_new();
    UnitTesting::list_put(list1, UnitTesting::filename1, UnitTesting::ref1);
    UnitTesting::list_put(list1, UnitTesting::filename2, UnitTesting::ref1);
    UnitTesting::list_put(list1, UnitTesting::filename3, UnitTesting::ref1);

    list_clear(list1);

    // Forward traversal
    EXPECT_EQ(list1->head->next, list1->head);

    // Backward traversal
    EXPECT_EQ(list1->head->prev, list1->head);
}

TEST(LinkedListOperations, ListReplaceEmptyByEmpty) {
    List *list1 = list_new();
    List *list2 = list_new();

    list_replace(list1, list2);

    // Forward traversal
    EXPECT_EQ(list1->head->next, list1->head);

    // Backward traversal
    EXPECT_EQ(list1->head->prev, list1->head);
}

TEST(LinkedListOperations, ListReplaceEmptyByNonEmpty) {
    List *list1 = list_new();
    List *list2 = list_new();

    UnitTesting::list_put(list2, UnitTesting::filename1, UnitTesting::ref1);
    UnitTesting::list_put(list2, UnitTesting::filename2, UnitTesting::ref1);
    UnitTesting::list_put(list2, UnitTesting::filename3, UnitTesting::ref1);

    list_replace(list1, list2);

    // Forward traversal
    Blob *curr;
    curr = list1->head->next;
    EXPECT_EQ(curr->name, UnitTesting::filename1);
    curr = curr->next;
    EXPECT_EQ(curr->name, UnitTesting::filename2);
    curr = curr->next;
    EXPECT_EQ(curr->name, UnitTesting::filename3);
    curr = curr->next;
    EXPECT_EQ(curr, list1->head);

    // Backward traversal
    curr = list1->head->prev;
    EXPECT_EQ(curr->name, UnitTesting::filename3);
    curr = curr->prev;
    EXPECT_EQ(curr->name, UnitTesting::filename2);
    curr = curr->prev;
    EXPECT_EQ(curr->name, UnitTesting::filename1);
    curr = curr->prev;
    EXPECT_EQ(curr, list1->head);
}

TEST(LinkedListOperations, ListReplaceNonEmptyByEmpty) {
    List *list1 = list_new();
    List *list2 = list_new();

    UnitTesting::list_put(list1, UnitTesting::filename1, UnitTesting::ref1);
    UnitTesting::list_put(list1, UnitTesting::filename2, UnitTesting::ref1);
    UnitTesting::list_put(list1, UnitTesting::filename3, UnitTesting::ref1);

    list_replace(list1, list2);

    // Forward traversal
    EXPECT_EQ(list1->head->next, list1->head);

    // Backward traversal
    EXPECT_EQ(list1->head->prev, list1->head);
}

TEST(LinkedListOperations, ListReplaceNonEmptyByNonEmpty) {
    List *list1 = list_new();
    List *list2 = list_new();

    UnitTesting::list_put(list1, UnitTesting::filename4, UnitTesting::ref1);
    UnitTesting::list_put(list1, UnitTesting::filename5, UnitTesting::ref1);
    UnitTesting::list_put(list1, UnitTesting::filename6, UnitTesting::ref1);

    UnitTesting::list_put(list2, UnitTesting::filename1, UnitTesting::ref1);
    UnitTesting::list_put(list2, UnitTesting::filename2, UnitTesting::ref1);
    UnitTesting::list_put(list2, UnitTesting::filename3, UnitTesting::ref1);

    list_replace(list1, list2);

    // Forward traversal
    Blob *curr;
    curr = list1->head->next;
    EXPECT_EQ(curr->name, UnitTesting::filename1);
    curr = curr->next;
    EXPECT_EQ(curr->name, UnitTesting::filename2);
    curr = curr->next;
    EXPECT_EQ(curr->name, UnitTesting::filename3);
    curr = curr->next;
    EXPECT_EQ(curr, list1->head);

    // Backward traversal
    curr = list1->head->prev;
    EXPECT_EQ(curr->name, UnitTesting::filename3);
    curr = curr->prev;
    EXPECT_EQ(curr->name, UnitTesting::filename2);
    curr = curr->prev;
    EXPECT_EQ(curr->name, UnitTesting::filename1);
    curr = curr->prev;
    EXPECT_EQ(curr, list1->head);
}

TEST(LinkedListOperations, ListCopyEmpty) {
    List *list1 = list_new();
    List *list2 = list_copy(list1);

    // Forward traversal
    EXPECT_EQ(list2->head->next, list2->head);

    // Backward traversal
    EXPECT_EQ(list2->head->prev, list2->head);
}

TEST(LinkedListOperations, ListCopyNonEmpty) {
    List *list1 = list_new();

    UnitTesting::list_put(list1, UnitTesting::filename1, UnitTesting::ref1);
    UnitTesting::list_put(list1, UnitTesting::filename2, UnitTesting::ref1);
    UnitTesting::list_put(list1, UnitTesting::filename3, UnitTesting::ref1);

    List *list2 = list_copy(list1);

    // Forward traversal
    Blob *curr;
    curr = list2->head->next;
    EXPECT_EQ(curr->name, UnitTesting::filename1);
    curr = curr->next;
    EXPECT_EQ(curr->name, UnitTesting::filename2);
    curr = curr->next;
    EXPECT_EQ(curr->name, UnitTesting::filename3);
    curr = curr->next;
    EXPECT_EQ(curr, list2->head);

    // Backward traversal
    curr = list2->head->prev;
    EXPECT_EQ(curr->name, UnitTesting::filename3);
    curr = curr->prev;
    EXPECT_EQ(curr->name, UnitTesting::filename2);
    curr = curr->prev;
    EXPECT_EQ(curr->name, UnitTesting::filename1);
    curr = curr->prev;
    EXPECT_EQ(curr, list2->head);
}

TEST(LinkedListOperations, ListDeleteEmpty) {
    List *list = list_new();

    list_delete(list);
}

TEST(LinkedListOperations, ListDeleteNonEmpty) {
    List *list = list_new();

    UnitTesting::list_put(list, UnitTesting::filename1, UnitTesting::ref1);
    UnitTesting::list_put(list, UnitTesting::filename2, UnitTesting::ref1);
    UnitTesting::list_put(list, UnitTesting::filename3, UnitTesting::ref1);

    list_delete(list);
}

TEST(LinkedListOperations, ListDeleteNonEmptyCommit) {
    List *list = list_new();

    UnitTesting::list_put(list, UnitTesting::filename1, &UnitTesting::commit1);
    UnitTesting::list_put(list, UnitTesting::filename2, &UnitTesting::commit1);
    UnitTesting::list_put(list, UnitTesting::filename3, &UnitTesting::commit1);

    list_delete(list);
}

TEST(InitTest, Init) {
    Blob *current_branch;
    List *branches, *staged_files, *tracked_files;
    Commit *head_commit;

    ::init(current_branch, branches, staged_files, tracked_files, head_commit);

    EXPECT_TRUE(UnitTesting::list_empty(staged_files));
    EXPECT_TRUE(UnitTesting::list_empty(tracked_files));

    EXPECT_EQ(head_commit->message, "initial commit");
    EXPECT_EQ(head_commit->parent, nullptr);
    EXPECT_EQ(head_commit->second_parent, nullptr);
    EXPECT_TRUE(UnitTesting::check_list_equivalence(head_commit->tracked_files, std::vector<Blob>()));

    EXPECT_EQ(UnitTesting::list_size(branches), 1);
    Blob *branch = branches->head->next;
    EXPECT_EQ(branch->name, "master");
    EXPECT_EQ(branch->commit, head_commit);
    EXPECT_EQ(current_branch, branch);

    UnitTesting::list_delete(branches);
    UnitTesting::list_delete(staged_files);
    UnitTesting::list_delete(tracked_files);
    UnitTesting::list_delete(head_commit->tracked_files);
    delete head_commit;
}

TEST(BasicOperationTest, AddUntrackedFiles) {
    using namespace UnitTesting;
    BasicOperationTestSetup();

    EXPECT_TRUE(::add("v2", staged_files, tracked_files, head_commit));

    EXPECT_TRUE(check_list_equivalence(tracked_files, {v1, v2, v3_new}));
    EXPECT_TRUE(check_list_equivalence(staged_files, {v1, v2, v3_new}));
    EXPECT_TRUE(check_list_equivalence(head_commit->tracked_files, head_tracked_files));

    // Add the same file again
    EXPECT_TRUE(::add("v2", staged_files, tracked_files, head_commit));

    EXPECT_TRUE(check_list_equivalence(tracked_files, {v1, v2, v3_new}));
    EXPECT_TRUE(check_list_equivalence(staged_files, {v1, v2, v3_new}));
    EXPECT_TRUE(check_list_equivalence(head_commit->tracked_files, head_tracked_files));

    BasicOperationTestTeardown();
}

TEST(BasicOperationTest, AddUpdatedFiles) {
    using namespace UnitTesting;
    BasicOperationTestSetup();

    FilesystemStub::cwd_files["v1"] = "v1 new\n";

    EXPECT_TRUE(::add("v1", staged_files, tracked_files, head_commit));

    Blob v1_new;
    blob_init(v1_new, "v1", get_string_sha1("v1 new\n"));
    EXPECT_TRUE(check_list_equivalence(tracked_files, {v1_new, v3_new}));
    EXPECT_TRUE(check_list_equivalence(staged_files, {v1_new, v3_new}));
    EXPECT_TRUE(check_list_equivalence(head_commit->tracked_files, head_tracked_files));

    BasicOperationTestTeardown();
}

TEST(BasicOperationTest, AddUnchangedFiles) {
    using namespace UnitTesting;
    BasicOperationTestSetup();

    FilesystemStub::cwd_files["v3"] = "v3 old\n";

    EXPECT_FALSE(::add("v3", staged_files, tracked_files, head_commit));

    EXPECT_TRUE(check_list_equivalence(tracked_files, {v1, v3_old}));
    EXPECT_TRUE(check_list_equivalence(staged_files, {v1}));
    EXPECT_TRUE(check_list_equivalence(head_commit->tracked_files, head_tracked_files));

    BasicOperationTestTeardown();
}

TEST(BasicOperationTest, AddRemovedFiles) {
    using namespace UnitTesting;
    BasicOperationTestSetup();

    EXPECT_FALSE(::add("v4", staged_files, tracked_files, head_commit));

    EXPECT_TRUE(check_list_equivalence(tracked_files, {v1, v3_new, v4}));
    EXPECT_TRUE(check_list_equivalence(staged_files, {v1, v3_new}));
    EXPECT_TRUE(check_list_equivalence(head_commit->tracked_files, head_tracked_files));

    FilesystemStub::cwd_files["v4"] = "v4 new\n";
    Blob v4_new;
    blob_init(v4_new, "v4", get_string_sha1("v4 new\n"));

    EXPECT_TRUE(::add("v4", staged_files, tracked_files, head_commit));

    EXPECT_TRUE(check_list_equivalence(tracked_files, {v1, v3_new, v4_new}));
    EXPECT_TRUE(check_list_equivalence(staged_files, {v1, v3_new, v4_new}));
    EXPECT_TRUE(check_list_equivalence(head_commit->tracked_files, head_tracked_files));

    BasicOperationTestTeardown();
}

TEST(BasicOperationTest, CommitWithChanges) {
    using namespace UnitTesting;
    BasicOperationTestSetup();

    auto *prev_commit = head_commit;
    EXPECT_TRUE(::commit("c1", current_branch, staged_files, tracked_files, head_commit));

    EXPECT_EQ(head_commit->message, "c1");
    EXPECT_TRUE(head_commit->parent == prev_commit);
    EXPECT_TRUE(head_commit->second_parent == nullptr);
    EXPECT_EQ(head_commit->commit_id, get_sha1(head_commit->message, head_commit->time));

    EXPECT_TRUE(check_list_equivalence(head_commit->tracked_files, {v1, v3_new}));
    EXPECT_TRUE(check_list_equivalence(tracked_files, {v1, v3_new}));

    EXPECT_TRUE(current_branch->commit == head_commit);
    EXPECT_TRUE(list_empty(staged_files));
    commit_free(prev_commit);

    BasicOperationTestTeardown();
}

TEST(BasicOperationTest, CommitWithoutChanges) {
    using namespace UnitTesting;
    BasicOperationTestSetup();

    auto *prev_commit = head_commit;
    auto *new_tracked_files = list_create(head_tracked_files);
    auto *empty_staged_files = list_create({});

    EXPECT_FALSE(::commit("c1", current_branch, empty_staged_files, new_tracked_files, head_commit));
    EXPECT_EQ_TRIM(output_buffer.str(), "No changes added to the commit.\n");
    EXPECT_TRUE(head_commit == prev_commit);

    UnitTesting::list_delete(new_tracked_files);
    UnitTesting::list_delete(empty_staged_files);

    BasicOperationTestTeardown();
}

TEST(BasicOperationTest, CommitWithRemovalOnly) {
    using namespace UnitTesting;
    BasicOperationTestSetup();

    auto *prev_commit = head_commit;
    auto *new_tracked_files = list_create({v3_old});
    auto *empty_staged_files = list_create({});

    EXPECT_TRUE(::commit("c1", current_branch, empty_staged_files, new_tracked_files, head_commit));
    EXPECT_TRUE(check_list_equivalence(head_commit->tracked_files, {v3_old}));
    EXPECT_TRUE(check_list_equivalence(new_tracked_files, {v3_old}));

    EXPECT_TRUE(prev_commit != head_commit);
    EXPECT_TRUE(current_branch->commit == head_commit);
    EXPECT_TRUE(list_empty(empty_staged_files));

    UnitTesting::list_delete(new_tracked_files);
    UnitTesting::list_delete(empty_staged_files);
    commit_free(prev_commit);

    BasicOperationTestTeardown();
}

TEST(BasicOperationTest, RemoveStagedFiles) {
    using namespace UnitTesting;
    BasicOperationTestSetup();

    EXPECT_TRUE(::remove("v1", staged_files, tracked_files, head_commit));

    EXPECT_TRUE(check_list_equivalence(tracked_files, {v3_new}));
    EXPECT_TRUE(check_list_equivalence(staged_files, {v3_new}));
    EXPECT_TRUE(check_list_equivalence(head_commit->tracked_files, head_tracked_files));
    EXPECT_TRUE(is_file_exist("v1"));

    BasicOperationTestTeardown();
}

TEST(BasicOperationTest, RemoveHeadTrackedFiles) {
    using namespace UnitTesting;
    BasicOperationTestSetup();

    EXPECT_TRUE(::remove("v3", staged_files, tracked_files, head_commit));

    EXPECT_TRUE(check_list_equivalence(tracked_files, {v1}));
    EXPECT_TRUE(check_list_equivalence(staged_files, {v1}));
    EXPECT_TRUE(check_list_equivalence(head_commit->tracked_files, head_tracked_files));
    EXPECT_FALSE(is_file_exist("v3"));

    // Double remove
    EXPECT_TRUE(::remove("v4", staged_files, tracked_files, head_commit));

    EXPECT_TRUE(check_list_equivalence(tracked_files, {v1}));
    EXPECT_TRUE(check_list_equivalence(staged_files, {v1}));
    EXPECT_TRUE(check_list_equivalence(head_commit->tracked_files, head_tracked_files));
    EXPECT_FALSE(is_file_exist("v4"));

    BasicOperationTestTeardown();
}

TEST(BasicOperationTest, RemoveFilesNotExist) {
    using namespace UnitTesting;
    BasicOperationTestSetup();

    EXPECT_FALSE(::remove("v2", staged_files, tracked_files, head_commit));
    EXPECT_EQ_TRIM(output_buffer.str(), "No reason to remove the file.\n");

    EXPECT_TRUE(check_list_equivalence(tracked_files, {v1, v3_new}));
    EXPECT_TRUE(check_list_equivalence(staged_files, {v1, v3_new}));
    EXPECT_TRUE(check_list_equivalence(head_commit->tracked_files, head_tracked_files));
    EXPECT_TRUE(is_file_exist("v2"));

    BasicOperationTestTeardown();
}

TEST(MultiBranchTest, CheckoutFiles) {
    using namespace UnitTesting;
    MultiBranchTestSetup();

    EXPECT_TRUE(::checkout("v1", m0));
    EXPECT_TRUE(check_file_content("v1", "v1\n"));

    EXPECT_TRUE(::checkout("v4", n1));
    EXPECT_TRUE(check_file_content("v4", "v4\n"));

    MultiBranchTestTeardown();
}

TEST(MultiBranchTest, CheckoutFilesNotExist) {
    using namespace UnitTesting;
    MultiBranchTestSetup();

    EXPECT_FALSE(::checkout("v5", m0));
    EXPECT_EQ_TRIM(output_buffer.str(), "File does not exist in that commit.\n");

    MultiBranchTestTeardown();
}

TEST(MultiBranchTest, CheckoutCommitNotExist) {
    using namespace UnitTesting;
    MultiBranchTestSetup();

    EXPECT_FALSE(::checkout("v1", nullptr));
    EXPECT_EQ_TRIM(output_buffer.str(), "No commit with that id exists.\n");

    MultiBranchTestTeardown();
}

TEST(MultiBranchTest, CheckoutBranch) {
    using namespace UnitTesting;
    MultiBranchTestSetup();

    ASSERT_TRUE(list_find_name(branches, "dev"));

    EXPECT_TRUE(::checkout("dev", current_branch, branches, staged_files, tracked_files, cwd_files, head_commit));

    EXPECT_EQ(current_branch->name, "dev");
    EXPECT_TRUE(head_commit == n1);
    EXPECT_TRUE(current_branch->commit == n1);
    EXPECT_TRUE(list_empty(staged_files));
    EXPECT_TRUE(check_list_equivalence(tracked_files, {v1, v3_old, v4}));

    EXPECT_TRUE(check_file_content("v1", "v1\n"));
    EXPECT_TRUE(check_file_content("v3", "v3 old\n"));
    EXPECT_TRUE(check_file_content("v4", "v4\n"));
    EXPECT_FALSE(is_file_exist("v2"));

    MultiBranchTestTeardown();
}

TEST(MultiBranchTest, CheckoutBranchNotExists) {
    using namespace UnitTesting;
    MultiBranchTestSetup();

    EXPECT_FALSE(::checkout("non-existing", current_branch, branches, staged_files, tracked_files, cwd_files, head_commit));
    EXPECT_EQ_TRIM(output_buffer.str(), "A branch with that name does not exist.\n");

    MultiBranchTestTeardown();
}

TEST(MultiBranchTest, CheckoutCurrentBranch) {
    using namespace UnitTesting;
    MultiBranchTestSetup();

    EXPECT_FALSE(::checkout("master", current_branch, branches, staged_files, tracked_files, cwd_files, head_commit));
    EXPECT_EQ_TRIM(output_buffer.str(), "No need to checkout the current branch.\n");

    MultiBranchTestTeardown();
}

TEST(MultiBranchTest, ResetToParent) {
    using namespace UnitTesting;
    MultiBranchTestSetup();

    FilesystemStub::cwd_files.insert({"v4", "v4\n"});
    List *new_cwd_files = list_create({v2, v3_new, v4});

    EXPECT_TRUE(::reset(m0, current_branch, staged_files, tracked_files, new_cwd_files, head_commit));
    EXPECT_EQ(output_buffer.str(), "");

    EXPECT_EQ(current_branch->name, "master");
    EXPECT_TRUE(head_commit == m0);
    EXPECT_TRUE(current_branch->commit == m0);
    EXPECT_TRUE(list_empty(staged_files));
    EXPECT_TRUE(check_list_equivalence(tracked_files, {v1, v3_old}));

    EXPECT_TRUE(check_file_content("v1", "v1\n"));
    EXPECT_TRUE(check_file_content("v3", "v3 old\n"));
    EXPECT_TRUE(check_file_content("v4", "v4\n"));
    EXPECT_FALSE(is_file_exist("v2"));

    UnitTesting::list_delete(new_cwd_files);

    MultiBranchTestTeardown();
}

TEST(MultiBranchTest, ResetToSelf) {
    using namespace UnitTesting;
    MultiBranchTestSetup();

    FilesystemStub::cwd_files.insert({"v4", "v4\n"});
    FilesystemStub::cwd_files["v2"] = "v2 new\n";
    List *new_cwd_files = list_create({v2, v3_new, v4});

    EXPECT_TRUE(::reset(m1, current_branch, staged_files, tracked_files, new_cwd_files, head_commit));
    EXPECT_EQ(output_buffer.str(), "");

    EXPECT_EQ(current_branch->name, "master");
    EXPECT_TRUE(head_commit == m1);
    EXPECT_TRUE(current_branch->commit == m1);
    EXPECT_TRUE(list_empty(staged_files));
    EXPECT_TRUE(check_list_equivalence(tracked_files, {v2, v3_new}));

    EXPECT_TRUE(check_file_content("v2", "v2\n"));
    EXPECT_TRUE(check_file_content("v3", "v3 new\n"));
    EXPECT_TRUE(check_file_content("v4", "v4\n"));

    UnitTesting::list_delete(new_cwd_files);

    MultiBranchTestTeardown();
}

TEST(MultiBranchTest, ResetToCommitNotExists) {
    using namespace UnitTesting;
    MultiBranchTestSetup();

    EXPECT_FALSE(::reset(nullptr, current_branch, staged_files, tracked_files, cwd_files, head_commit));
    EXPECT_EQ_TRIM(output_buffer.str(), "No commit with that id exists.\n");

    MultiBranchTestTeardown();
}

TEST(MultiBranchTest, CreateNewBranch) {
    using namespace UnitTesting;
    MultiBranchTestSetup();

    Blob *new_branch = ::branch("new", branches, head_commit);

    EXPECT_TRUE(new_branch != nullptr);
    EXPECT_EQ(new_branch->name, "new");
    EXPECT_TRUE(new_branch->commit == head_commit);
    EXPECT_EQ(UnitTesting::list_size(branches), 3);

    MultiBranchTestTeardown();
}

TEST(MultiBranchTest, CreateBranchWithDuplicateName) {
    using namespace UnitTesting;
    MultiBranchTestSetup();

    Blob *new_branch = ::branch("dev", branches, head_commit);

    EXPECT_TRUE(new_branch == nullptr);
    EXPECT_EQ_TRIM(output_buffer.str(), "A branch with that name already exists.\n");

    MultiBranchTestTeardown();
}

TEST(MultiBranchTest, RemoveBranch) {
    using namespace UnitTesting;
    MultiBranchTestSetup();

    EXPECT_TRUE(::remove_branch("dev", current_branch, branches));
    EXPECT_EQ(UnitTesting::list_size(branches), 1);
    EXPECT_EQ(n1->message, "n1");
    EXPECT_TRUE(check_list_equivalence(n1->tracked_files, {v1, v3_old, v4}));

    MultiBranchTestTeardown();
}

TEST(MultiBranchTest, RemoveBranchNotExists) {
    using namespace UnitTesting;
    MultiBranchTestSetup();

    EXPECT_FALSE(::remove_branch("new", current_branch, branches));
    EXPECT_EQ_TRIM(output_buffer.str(), "A branch with that name does not exist.\n");

    MultiBranchTestTeardown();
}

TEST(MultiBranchTest, RemoveCurrentBranch) {
    using namespace UnitTesting;
    MultiBranchTestSetup();

    EXPECT_FALSE(::remove_branch("master", current_branch, branches));
    EXPECT_EQ_TRIM(output_buffer.str(), "Cannot remove the current branch.\n");

    MultiBranchTestTeardown();
}

TEST(MultiBranchTest, MergeAncestors) {
    using namespace UnitTesting;
    MultiBranchTestSetup();

    Blob ancestor;
    blob_init(ancestor, "ancestor", "", m0);
    List *new_branches = list_create({ancestor, dev, master});
    current_branch = list_find_name(new_branches, "master");

    // Make sure no staged_files changes exist
    UnitTesting::list_delete(staged_files);
    UnitTesting::list_delete(tracked_files);
    staged_files = list_create({});
    tracked_files = list_create({v2, v3_new});

    EXPECT_TRUE(::merge("ancestor", current_branch, new_branches, staged_files, tracked_files, cwd_files, head_commit));
    EXPECT_EQ_TRIM(output_buffer.str(), "Given branch is an ancestor of the current branch.\n");

    EXPECT_EQ(current_branch->name, "master");
    EXPECT_TRUE(head_commit == m1);
    EXPECT_TRUE(check_list_equivalence(tracked_files, {v2, v3_new}));
    EXPECT_TRUE(check_list_equivalence(staged_files, std::vector<Blob>()));

    UnitTesting::list_delete(new_branches);

    MultiBranchTestTeardown();
}

TEST(MultiBranchTest, MergeHandlesFastForwading) {
    using namespace UnitTesting;
    MultiBranchTestSetup();

    Blob ancestor;
    blob_init(ancestor, "ancestor", "", m0);
    FilesystemStub::clean_environment(false);
    UnitTesting::list_delete(tracked_files);
    UnitTesting::list_delete(staged_files);
    UnitTesting::list_delete(cwd_files);
    UnitTesting::list_delete(branches);

    FilesystemStub::cwd_files.insert({"v1", "v1\n"});
    FilesystemStub::cwd_files.insert({"v3", "v3 old\n"});
    FilesystemStub::cwd_files.insert({"v4", "v4\n"});

    tracked_files = list_create({v1, v3_old});
    staged_files = list_create({});
    cwd_files = list_create({v1, v3_old, v4});
    branches = list_create({ancestor, dev, master});
    current_branch = list_find_name(branches, "ancestor");
    head_commit = m0;

    EXPECT_TRUE(::merge("master", current_branch, branches, staged_files, tracked_files, cwd_files, head_commit));
    EXPECT_EQ_TRIM(output_buffer.str(), "Current branch fast-forwarded.\n");
    EXPECT_EQ(current_branch->name, "ancestor");
    EXPECT_TRUE(current_branch->commit == m1);
    EXPECT_TRUE(head_commit == m1);
    EXPECT_TRUE(list_empty(staged_files));

    EXPECT_FALSE(is_file_exist("v1"));
    EXPECT_TRUE(check_file_content("v2", "v2\n"));
    EXPECT_TRUE(check_file_content("v3", "v3 new\n"));
    EXPECT_TRUE(check_file_content("v4", "v4\n"));

    MultiBranchTestTeardown();
}

TEST(MultiBranchTest, MergeOverwritingUntrackedFiles) {
    using namespace UnitTesting;
    MultiBranchTestSetup();

    FilesystemStub::cwd_files.insert({"v4", "v4\n"});
    List *new_files = list_create({v2, v3_new, v4});

    // Make sure no staged_files changes exist
    UnitTesting::list_delete(staged_files);
    UnitTesting::list_delete(tracked_files);
    staged_files = list_create({});
    tracked_files = list_create({v2, v3_new});

    EXPECT_FALSE(::merge("dev", current_branch, branches, staged_files, tracked_files, new_files, head_commit));
    EXPECT_EQ_TRIM(output_buffer.str(), "There is an untracked file in the way; delete it, or add and commit it first.\n");
    EXPECT_EQ(current_branch->name, "master");
    EXPECT_TRUE(head_commit == m1);
    EXPECT_TRUE(current_branch->commit == m1);
    EXPECT_TRUE(check_file_content("v2", "v2\n"));
    EXPECT_TRUE(check_file_content("v3", "v3 new\n"));
    EXPECT_TRUE(check_file_content("v4", "v4\n"));

    UnitTesting::list_delete(new_files);

    MultiBranchTestTeardown();
}

TEST(MultiBranchTest, MergeGeneralTest) {
    using namespace UnitTesting;
    MultiBranchTestSetup();

    // Make sure no staged_files changes exist
    UnitTesting::list_delete(staged_files);
    UnitTesting::list_delete(tracked_files);
    staged_files = list_create({});
    tracked_files = list_create({v2, v3_new});

    EXPECT_TRUE(::merge("dev", current_branch, branches, staged_files, tracked_files, cwd_files, head_commit));
    EXPECT_EQ(current_branch->name, "master");
    EXPECT_TRUE(current_branch->commit == head_commit);
    EXPECT_TRUE(head_commit->parent == m1);
    EXPECT_TRUE(head_commit->second_parent == n1);
    EXPECT_EQ_TRIM(head_commit->message, "Merged dev into master.");

    EXPECT_TRUE(check_list_equivalence(head_commit->tracked_files, {v2, v3_new, v4}));
    EXPECT_TRUE(list_empty(staged_files));

    EXPECT_FALSE(is_file_exist("v1"));
    EXPECT_TRUE(check_file_content("v2", "v2\n"));
    EXPECT_TRUE(check_file_content("v3", "v3 new\n"));
    EXPECT_TRUE(check_file_content("v4", "v4\n"));
    EXPECT_TRUE(is_file_staged("v4"));

    commit_free(head_commit);  // avoid memory leak

    MultiBranchTestTeardown();
}

TEST(MultiBranchTest, MergeBranchNotExists) {
    using namespace UnitTesting;
    MultiBranchTestSetup();

    // Make sure no staged_files changes exist
    UnitTesting::list_delete(staged_files);
    UnitTesting::list_delete(tracked_files);
    staged_files = list_create({});
    tracked_files = list_create({v2, v3_new});

    EXPECT_FALSE(::merge("non-existing", current_branch, branches, staged_files, tracked_files, cwd_files, head_commit));
    EXPECT_EQ_TRIM(output_buffer.str(), "A branch with that name does not exist.\n");

    MultiBranchTestTeardown();
}

TEST(MultiBranchTest, MergeCurrentBranch) {
    using namespace UnitTesting;
    MultiBranchTestSetup();

    // Make sure no staged_files changes exist
    UnitTesting::list_delete(staged_files);
    UnitTesting::list_delete(tracked_files);
    staged_files = list_create({});
    tracked_files = list_create({v2, v3_new});

    EXPECT_FALSE(::merge("master", current_branch, branches, staged_files, tracked_files, cwd_files, head_commit));
    EXPECT_EQ_TRIM(output_buffer.str(), "Cannot merge a branch with itself.\n");

    MultiBranchTestTeardown();
}

TEST(MultiBranchTest, MergeWithUncommitedChanges) {
    using namespace UnitTesting;
    MultiBranchTestSetup();

    EXPECT_FALSE(::merge("dev", current_branch, branches, staged_files, tracked_files, cwd_files, head_commit));
    EXPECT_EQ_TRIM(output_buffer.str(), "You have uncommitted changes.\n");

    MultiBranchTestTeardown();
}

TEST(SplitPoint, Same) {
    Commit initial_commit = UnitTesting::commit_init("initial commit");

    EXPECT_EQ(get_lca(&initial_commit, &initial_commit), &initial_commit);
}

TEST(SplitPoint, Ahead) {
    Commit initial_commit = UnitTesting::commit_init("initial commit");
    Commit c1 = UnitTesting::commit_init("c1", nullptr, &initial_commit);
    Commit c2 = UnitTesting::commit_init("c2", nullptr, &c1);
    Commit a1 = UnitTesting::commit_init("a1", nullptr, &c2);
    Commit a2 = UnitTesting::commit_init("a2", nullptr, &a1);

    EXPECT_EQ(get_lca(&a2, &c2), &c2);
    EXPECT_EQ(get_lca(&c2, &a2), &c2);
}

TEST(SplitPoint, Diverged) {
    Commit initial_commit = UnitTesting::commit_init("initial commit");
    Commit c1 = UnitTesting::commit_init("c1", nullptr, &initial_commit);
    Commit c2 = UnitTesting::commit_init("c2", nullptr, &c1);
    Commit a1 = UnitTesting::commit_init("a1", nullptr, &c2);
    Commit a2 = UnitTesting::commit_init("a2", nullptr, &a1);
    Commit b1 = UnitTesting::commit_init("b1", nullptr, &c2);
    Commit b2 = UnitTesting::commit_init("b2", nullptr, &b1);

    EXPECT_EQ(get_lca(&a2, &b2), &c2);
    EXPECT_EQ(get_lca(&b2, &a2), &c2);
}

TEST(SplitPoint, Merged1) {
    Commit initial_commit = UnitTesting::commit_init("initial commit");
    Commit c1 = UnitTesting::commit_init("c1", nullptr, &initial_commit);
    Commit c2 = UnitTesting::commit_init("c2", nullptr, &c1);
    Commit a1 = UnitTesting::commit_init("a1", nullptr, &c2);
    Commit b1 = UnitTesting::commit_init("b1", nullptr, &c2);
    Commit a2 = UnitTesting::commit_init("a2", nullptr, &a1, &b1);
    Commit b2 = UnitTesting::commit_init("b2", nullptr, &b1);

    EXPECT_EQ(get_lca(&a2, &b2), &b1);
    EXPECT_EQ(get_lca(&b2, &a2), &b1);
}

TEST(SplitPoint, Merged2) {
    Commit initial_commit = UnitTesting::commit_init("initial commit");
    Commit c1 = UnitTesting::commit_init("c1", nullptr, &initial_commit);
    Commit c2 = UnitTesting::commit_init("c2", nullptr, &c1);
    Commit a1 = UnitTesting::commit_init("a1", nullptr, &c2);
    Commit b1 = UnitTesting::commit_init("b1", nullptr, &c2);
    Commit a2 = UnitTesting::commit_init("a2", nullptr, &a1, &b1);
    Commit b2 = UnitTesting::commit_init("b2", nullptr, &b1);
    Commit a3 = UnitTesting::commit_init("a3", nullptr, &a2);
    Commit b3 = UnitTesting::commit_init("b3", nullptr, &b2, &a2);
    Commit b4 = UnitTesting::commit_init("b4", nullptr, &b3);

    EXPECT_EQ(get_lca(&a3, &b4), &a2);
    EXPECT_EQ(get_lca(&b4, &a3), &a2);
}

typedef void (*Testcase)();

std::vector<Testcase> testcases = {
    TEST_NAME(LinkedListOperations, ListNew), // 1
    TEST_NAME(LinkedListOperations, ListPushBackOne),
    TEST_NAME(LinkedListOperations, ListPushBackMultiple),
    TEST_NAME(LinkedListOperations, ListFindNameFound),
    TEST_NAME(LinkedListOperations, ListFindNameNotFound), // 5
    TEST_NAME(LinkedListOperations, ListPutNewOne),
    TEST_NAME(LinkedListOperations, ListPutNewMultiple),
    TEST_NAME(LinkedListOperations, ListPutNewMultipleCommit),
    TEST_NAME(LinkedListOperations, ListPutUpdateOne),
    TEST_NAME(LinkedListOperations, ListPutUpdateMultiple), // 10
    TEST_NAME(LinkedListOperations, ListPutUpdateMultipleCommit),
    TEST_NAME(LinkedListOperations, ListRemoveNotFound),
    TEST_NAME(LinkedListOperations, ListRemoveOne),
    TEST_NAME(LinkedListOperations, ListRemoveAll),
    TEST_NAME(LinkedListOperations, ListSize), // 15
    TEST_NAME(LinkedListOperations, ListClearEmpty),
    TEST_NAME(LinkedListOperations, ListClearNonEmpty),
    TEST_NAME(LinkedListOperations, ListReplaceEmptyByEmpty),
    TEST_NAME(LinkedListOperations, ListReplaceEmptyByNonEmpty),
    TEST_NAME(LinkedListOperations, ListReplaceNonEmptyByEmpty), // 20
    TEST_NAME(LinkedListOperations, ListReplaceNonEmptyByNonEmpty),
    TEST_NAME(LinkedListOperations, ListCopyEmpty),
    TEST_NAME(LinkedListOperations, ListCopyNonEmpty),
    TEST_NAME(LinkedListOperations, ListDeleteEmpty),
    TEST_NAME(LinkedListOperations, ListDeleteNonEmpty), // 25
    TEST_NAME(LinkedListOperations, ListDeleteNonEmptyCommit),
    TEST_NAME(InitTest, Init),
    TEST_NAME(BasicOperationTest, AddUntrackedFiles),
    TEST_NAME(BasicOperationTest, AddUpdatedFiles),
    TEST_NAME(BasicOperationTest, AddUnchangedFiles), // 30
    TEST_NAME(BasicOperationTest, AddRemovedFiles),
    TEST_NAME(BasicOperationTest, CommitWithChanges),
    TEST_NAME(BasicOperationTest, CommitWithoutChanges),
    TEST_NAME(BasicOperationTest, CommitWithRemovalOnly),
    TEST_NAME(BasicOperationTest, RemoveStagedFiles), // 35
    TEST_NAME(BasicOperationTest, RemoveHeadTrackedFiles),
    TEST_NAME(BasicOperationTest, RemoveFilesNotExist),
    TEST_NAME(MultiBranchTest, CheckoutFiles),
    TEST_NAME(MultiBranchTest, CheckoutFilesNotExist),
    TEST_NAME(MultiBranchTest, CheckoutCommitNotExist), // 40
    TEST_NAME(MultiBranchTest, CheckoutBranch),
    TEST_NAME(MultiBranchTest, CheckoutBranchNotExists),
    TEST_NAME(MultiBranchTest, CheckoutCurrentBranch),
    TEST_NAME(MultiBranchTest, ResetToParent),
    TEST_NAME(MultiBranchTest, ResetToSelf), // 45
    TEST_NAME(MultiBranchTest, ResetToCommitNotExists),
    TEST_NAME(MultiBranchTest, CreateNewBranch),
    TEST_NAME(MultiBranchTest, CreateBranchWithDuplicateName),
    TEST_NAME(MultiBranchTest, RemoveBranch),
    TEST_NAME(MultiBranchTest, RemoveBranchNotExists), // 50
    TEST_NAME(MultiBranchTest, RemoveCurrentBranch),
    TEST_NAME(MultiBranchTest, MergeAncestors),
    TEST_NAME(MultiBranchTest, MergeHandlesFastForwading),
    TEST_NAME(MultiBranchTest, MergeOverwritingUntrackedFiles),
    TEST_NAME(MultiBranchTest, MergeGeneralTest), // 55
    TEST_NAME(MultiBranchTest, MergeBranchNotExists),
    TEST_NAME(MultiBranchTest, MergeCurrentBranch),
    TEST_NAME(MultiBranchTest, MergeWithUncommitedChanges),
    TEST_NAME(SplitPoint, Same),
    TEST_NAME(SplitPoint, Ahead), // 60
    TEST_NAME(SplitPoint, Diverged),
    TEST_NAME(SplitPoint, Merged1),
    TEST_NAME(SplitPoint, Merged2)
};

int main(int argc, char **argv)
{
    if (argc == 2) {
        int testcase = atoi(argv[1]) - 1;

        if (testcase >= 0 && testcase < testcases.size()) {
            testcases[testcase]();
            cout << "Test " << argv[1] << " PASSED" << endl;
        }

        else if (testcase == -1) {
            for (auto t: testcases)
                t();
            cout << "All tests PASSED" << endl;
        }
    }

    if (argc == 1) {
        for (auto t: testcases)
            t();
        cout << "All tests PASSED" << endl;
    }
}