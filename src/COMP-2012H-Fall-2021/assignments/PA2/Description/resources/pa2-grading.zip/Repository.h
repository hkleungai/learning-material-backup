//
// Autograder version
//

#ifndef COMP2012H_FA21_PA2_REPOSITORY_H
#define COMP2012H_FA21_PA2_REPOSITORY_H

#include <string>
#include <unordered_map>

#include "Commit.h"


// This class works as a wrapper for all the tasks
// It handles the persistence and part of the filesystem operations
class Repository {
public:
    static void make_file_structure();
    static void load_repository();
    static void close();
    static void reset_states();
    static bool check_file_structure();

    // Wrappers for all the tasks
    static bool init();
    static bool add(const std::string &filename);
    static bool commit(const std::string &message);
    static bool remove(const std::string &filename);
    static void log();
    static void global_log();        // implemented for you to facilitate debugging
    static bool find(const std::string &message);   // implemented for you to facilitate debugging
    static void status();
    static bool checkout_file(const std::string &filename);
    static bool checkout_file(const std::string &commit_id, const std::string &filename);
    static bool checkout_branch(const std::string &branch_name);
    static bool branch(const std::string &branch_name);
    static bool remove_branch(const std::string &branch_name);
    static bool reset(const std::string &commit_id);
    static bool merge(const std::string &branch_name);

private:
    static void flush_track_records();
    static void flush_staged_changes();
    static void clear_staging_area();
    static List *get_cwd_files();
    static std::string resolve_commit_id(const std::string &commit_id);

    static std::unordered_map<std::string, Commit *> commits;   // hashmap from commit id to pointers, used only internally

    static Commit *head_commit;      // current head commit
    static List *tracked_files;      // currently tracked files
    static List *staged_files;       // a linked list recording the state of the staging area
    static List *branches;           // a linked list of all the branches, the blobs has pointers to Commit instead of char
    static Blob *current_branch;     // current branch we are on, mainly for convenience and performance
};

bool validate_args(const std::vector<std::string> &args);

bool parse_args(const std::vector<std::string> &args);

std::vector<std::string> split_args(std::string input);

#endif //COMP2012H_FA21_PA2_REPOSITORY_H
