#include "GameEngine.h"

int main() {
    GameEngine game;
    game.run();

    return 0;
}
