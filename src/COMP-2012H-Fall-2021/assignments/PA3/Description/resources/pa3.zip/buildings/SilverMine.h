#ifndef SILVERMINE_H
#define SILVERMINE_H

#include "Revenue.h"
class SilverMine: public Revenue {

};
#endif // SILVERMINE_H
