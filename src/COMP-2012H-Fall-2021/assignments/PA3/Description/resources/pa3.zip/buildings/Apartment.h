#ifndef APARTMENT_H
#define APARTMENT_H

#include "Residential.h"
class Apartment: public Residential {

};
#endif // APARTMENT_H
