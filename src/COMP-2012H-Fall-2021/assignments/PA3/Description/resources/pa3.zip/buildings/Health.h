#ifndef HEALTH_H
#define HEALTH_H

#include "Building.h"
class Health: public Building {

};
#endif // HEALTH_H
