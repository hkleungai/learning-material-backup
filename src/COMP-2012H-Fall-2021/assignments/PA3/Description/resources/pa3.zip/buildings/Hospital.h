#ifndef HOSPITAL_H
#define HOSPITAL_H

#include "Health.h"
class Hospital: public Health {

};
#endif // HOSPITAL_H
