#ifndef CLINIC_H
#define CLINIC_H

#include "Health.h"
class Clinic: public Health {

};
#endif // CLINIC_H
