#ifndef RESIDENTIAL_H
#define RESIDENTIAL_H

#include "Building.h"
class Residential: public Building {

};
#endif // RESIDENTIAL_H
