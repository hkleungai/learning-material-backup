#ifndef HOUSE_H
#define HOUSE_H

#include "Residential.h"
class House: public Residential {

};
#endif // HOUSE_H
