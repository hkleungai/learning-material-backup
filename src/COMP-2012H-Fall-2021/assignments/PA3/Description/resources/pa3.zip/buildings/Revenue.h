#ifndef REVENUE_H
#define REVENUE_H

#include "Building.h"
class Revenue: public Building {

};
#endif // REVENUE_H
