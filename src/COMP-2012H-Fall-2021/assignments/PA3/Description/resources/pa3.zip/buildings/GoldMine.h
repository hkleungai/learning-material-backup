#ifndef GOLDMINE_H
#define GOLDMINE_H

#include "Revenue.h"
class GoldMine: public Revenue {

};
#endif // GOLDMINE_H
