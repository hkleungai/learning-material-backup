Student tom("Tom", CSE, 3.9);
print_label(tom);
