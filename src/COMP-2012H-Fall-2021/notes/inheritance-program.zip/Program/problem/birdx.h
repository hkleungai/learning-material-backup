class Swallow : public Bird { ... };
class Eagle : public Bird { public: void hunt(Bird* prey); };
