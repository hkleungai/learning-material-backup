void Penguin::fly()     /* File: penguin1.cpp */
{
    cerr << "Penguins cannot fly!" << endl;
    exit(999);
}
