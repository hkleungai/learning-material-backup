#include "word.h" // File: word.cpp
Word::Word(const char* s, int k = 1) 
{
    ...
}
