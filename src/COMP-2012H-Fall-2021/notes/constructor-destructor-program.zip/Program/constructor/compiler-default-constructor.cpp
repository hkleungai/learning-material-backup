class Word    /* File: compiler-default-constructor.cpp */
{   // Implicitly private members
    int frequency;
    char* str; 
};

int main() { Word movie; }
