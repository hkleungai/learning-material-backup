class Word              /* File: default-initializer.cpp */
{
    int frequency {0};
    const char* str {nullptr};
};

int main() { Word movie; }
