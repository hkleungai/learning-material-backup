void Example()  /* File: default-destructor-problem.cpp */
{
    Word x("bug", 4);
    ... 
}

int main() { Example(); .... }
