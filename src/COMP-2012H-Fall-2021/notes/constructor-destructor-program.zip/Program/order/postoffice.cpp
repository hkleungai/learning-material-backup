#include <iostream> /* File postoffice1.cpp */
using namespace std;
#include "postoffice1.h"
int main()
{
    cout << "Beginning of main\n";
    Postoffice x;
    cout << "End of main\n";
}
