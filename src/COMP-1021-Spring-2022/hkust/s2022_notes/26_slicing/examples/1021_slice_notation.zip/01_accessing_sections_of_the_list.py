# The following demonstrates the techniques with an integer list
print("The following demonstrates the techniques with an integer list.")
print()
samples = [0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20]
print("samples =", samples)
print("samples[ :int(len(samples)/2)] =", samples[ :int(len(samples)/2)])
print("samples[ :int(len(samples)*0.25)] =", samples[ :int(len(samples)*0.25)])
print("samples[int(len(samples)/2): ] =", samples[int(len(samples)/2): ])
print("samples[int(len(samples)*0.75): ] =", samples[int(len(samples)*0.75): ])
print()
print()

