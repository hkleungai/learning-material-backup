# This example separates sentences with newline characters

print("Hello!\nI am Python!\nHow are you?")