# This example outputs different numbers of tab characters

for x in range(5):
    print( "\t" * x + "hello")
