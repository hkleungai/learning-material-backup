# This example outputs different numbers of newline characters

for x in range(5):
    print( "hello" + "\n" * x, end="")
