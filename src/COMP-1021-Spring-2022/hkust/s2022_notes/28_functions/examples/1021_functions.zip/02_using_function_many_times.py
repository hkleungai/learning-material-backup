def response():
    print("Very good!")

print("Is it a good course?")
response()
print("Is the instructor good?")
response()
print("Do I look good?")
response()
