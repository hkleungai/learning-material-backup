def magic_mirror(name):
    if name == "Dave":
        print("What a good name!")
    else:
        print("How are you?")

name = input("What is your name? ")
magic_mirror(name)
