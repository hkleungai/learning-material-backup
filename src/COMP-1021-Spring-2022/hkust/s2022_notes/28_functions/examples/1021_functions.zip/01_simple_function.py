def greeting():
    name = input("What is your name? ")
    print ("Welcome " + name + "!")

print("I am going to ask you a question...")
greeting()
