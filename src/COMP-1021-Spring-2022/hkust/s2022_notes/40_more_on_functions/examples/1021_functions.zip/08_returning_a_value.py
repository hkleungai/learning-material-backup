def square(number):
    return number * number

input_number = int(input("Please give me a number: "))
print("The square of the number is: ", end="")
print(square(input_number))
