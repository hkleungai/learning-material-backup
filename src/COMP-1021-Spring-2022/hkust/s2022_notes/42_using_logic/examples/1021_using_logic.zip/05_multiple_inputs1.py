funny = True
friendly = False
wealthy = True
has_car = True
cute = False
suitable_partner = funny and friendly and \
	wealthy and has_car and cute
print(suitable_partner)

