funny = False
friendly = True
suitable_partner = funny or friendly
print(suitable_partner)
