funny = True
friendly = True

if funny == True and friendly == True:
	suitable_partner = True
else:
	suitable_partner = False

print(suitable_partner)

suitable_partner = funny and friendly

print(suitable_partner)

