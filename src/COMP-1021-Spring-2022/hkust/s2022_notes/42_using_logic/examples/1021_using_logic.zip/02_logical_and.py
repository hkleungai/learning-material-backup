funny = False
friendly = True
suitable_partner = funny and friendly
print(suitable_partner)

