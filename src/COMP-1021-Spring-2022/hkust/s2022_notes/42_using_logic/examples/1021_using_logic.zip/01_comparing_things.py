x = 100
result = x > 50
print(result)

x = 10
result = x > 50
print(result)

