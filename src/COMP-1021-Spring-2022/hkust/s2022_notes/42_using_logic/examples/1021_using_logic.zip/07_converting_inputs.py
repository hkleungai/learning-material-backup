response = input("Are you alive? (yes/no) ")
response = response == "yes"
print("response =", response)
print("Are you dead?")
print("The answer is:", not response)
