# An example of inputting and outputting text.

# Use print() to display a message 
print("It's a typhoon!")

# Use input() to display a message
# and request some input from the user
input("What is your name?")
