# An example of converting text into a number.

# Store the input from the user as text into variable 'money'
money = input("How much money do you have in your pocket?")

# 'money' is now displayed as text
print(money)

# Use int() to convert the text into an actual number
money = int(money)
print(money)

# Now you can manipulate 'money' as a number
money = money + 5
print(money)
