# An example of generating a random number.

# Tell Python that we want to do something random
import random

# Use randint() to generate a random integer number 
# (so no decimal place) within a range
x = random.randint(1, 5)

# Print the random number that was just generated
print("The random value is", x)
