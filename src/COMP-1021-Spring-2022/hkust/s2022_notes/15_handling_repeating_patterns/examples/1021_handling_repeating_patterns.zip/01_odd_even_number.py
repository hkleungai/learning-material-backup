"""
This is an example of finding odd/even numbers using the modulus operator.
"""

number = int(input("Please give me a number: "))

if number % 2 == 1:
    print("It is an odd number!")
else:
    print("It is an even number!")
