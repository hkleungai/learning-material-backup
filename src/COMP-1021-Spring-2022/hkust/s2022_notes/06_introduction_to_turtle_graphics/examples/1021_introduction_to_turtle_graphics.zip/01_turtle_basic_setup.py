# An example of setting up a turtle.

import turtle

# After importing the turtle module, you can start drawing here.
# In this example, we draw nothing.

turtle.done()
