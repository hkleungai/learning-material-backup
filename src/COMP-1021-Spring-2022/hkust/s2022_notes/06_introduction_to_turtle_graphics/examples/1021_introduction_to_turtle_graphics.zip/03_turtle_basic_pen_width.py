# An example showing drawing lines with different thickness.

import turtle

# Draw a thin line
turtle.forward(125)

# Set the pen width to 5 pixels
turtle.width(5)

# Draw a thick line
turtle.forward(125)

turtle.done()
