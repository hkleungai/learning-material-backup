import turtle

# Take the pen off the paper
turtle.up() 

# Go to the starting point 
# (remember that (0,0) is the middle of the screen)
turtle.goto(-300, 60) 

# Show the text
turtle.write("COMP1021", font=("Arial", 20, "bold"))

turtle.done()
