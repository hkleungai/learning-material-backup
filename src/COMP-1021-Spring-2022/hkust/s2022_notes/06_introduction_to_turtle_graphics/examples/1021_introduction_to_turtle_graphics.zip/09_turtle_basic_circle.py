# An example showing the drawing of a circle and curve

import turtle

turtle.width(5)

# Draw a circle with radius 100 pixels
turtle.circle(100)

# Draw an arc
turtle.circle(250, 90)

turtle.done()
