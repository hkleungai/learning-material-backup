# An example of a turtle walking forward and drawing a line.
#
# The turtle holds a pen.
# The pen will draw on the "ground" when the turtle moves.

import turtle

# Walk forward 250 pixels
turtle.forward(250)

turtle.done()

