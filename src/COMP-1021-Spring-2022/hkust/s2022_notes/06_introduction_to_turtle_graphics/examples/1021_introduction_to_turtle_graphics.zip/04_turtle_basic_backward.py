# An example of a turtle walking backwards and drawing a line.

import turtle

# Set the pen width to 3 pixels
turtle.width(3)

# Walk backward 250 pixels
turtle.backward(250)

turtle.done()

