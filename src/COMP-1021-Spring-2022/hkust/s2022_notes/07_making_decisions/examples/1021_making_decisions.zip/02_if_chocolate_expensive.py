cost_of_chocolate = 12 # Now more expensive 
money_in_pocket = 10

if money_in_pocket >= cost_of_chocolate:
    print("I have enough money to buy the chocolate!")
