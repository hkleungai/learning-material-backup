age = input("How old are you? ")
age = int(age)
if age >= 80:
    print("You are old")
elif age >= 20:
    print("You are an adult")
elif age >= 12:
    print("You are a teenager")
else:
    print("You are a child")

