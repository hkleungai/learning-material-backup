cost_of_chocolate = 12 
money_in_pocket = 10

if money_in_pocket >= cost_of_chocolate:
    print("I have enough money to buy the chocolate!")
else:
    print("No chocolate for me today...")
