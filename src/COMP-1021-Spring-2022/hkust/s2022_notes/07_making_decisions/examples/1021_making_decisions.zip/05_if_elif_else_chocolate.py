cost_of_large_chocolate_bar = 12 
cost_of_small_chocolate_bar = 8 

money_in_pocket = 11

if money_in_pocket >= cost_of_large_chocolate_bar:
    print("Yes! I can afford to buy the chocolate!")
elif money_in_pocket >= cost_of_small_chocolate_bar:
    print("I can't afford the large bar, but I can afford the small bar!")
else:
    print("No chocolate for me...")
