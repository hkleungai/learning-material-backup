<?php
    /*
     * This program uses a color selector created using a set of divs.
     * When the form is submitted a JavaScript function is used to check
     * whether the colour value is changed or not compared to the old
     * colour value. If the colour value is changed a confirmation is
     * required from the user.
     *
     * This example assumes a colour value has been selected and
     * transmitted to this page from another page such as the previous
     * example, 01_color_selector.html.
     */
    $my_color = $_GET['color'];
?>
<html>
    <head>
        <title>Color Selector</title>
        <style>
            div {
                position: absolute;
                width: 50px;
                height: 50px;
            }
        </style>
        <script>
        function select(color) {
            var fld = document.getElementById("color");
            if (color != fld.value) {
                if (!confirm("Do you want to use the new color?"))
                    return;
                fld.value=color;
                fld.form.submit();
            }
        }
        </script>
    </head>
    <body>
        <h2>Please select a color:</h2>
        <div style="position:relative">
            <div style="background-color:red;left:0px" onclick="select('red')"></div>
            <div style="background-color:yellow;left:50px" onclick="select('yellow')"></div>
            <div style="background-color:green;left:100px" onclick="select('green')"></div>
            <div style="background-color:cyan;left:150px" onclick="select('cyan')"></div>
            <div style="background-color:blue;left:200px" onclick="select('blue')"></div>
            <div style="background-color:magenta;left:250px" onclick="select('magenta')"></div>
        </div>
        <form action="02_color_selector.php" method="GET">
            <input type="hidden" name="color" id="color" value="<?php print $my_color; ?>" />
        </form>
    </body>
</html>
