These examples display the same xml file, dahl.xml, using two different
techniques.

XML and CSS
    - open dahl.xml in a browser
    - the browser reads author_profile.css for CSS style rules for the XML tags
    - the XML file is displayed in the browser according to these CSS rules

Javascript and CSS
    - open author_profile.html in a browser
    - the browser executes the JavaScript in the file
    - the JavaScript parses the content of the dahl.xml, reads the DOM and
      arrange the content using DIV tags and SPAN tags
    - the page is displayed according to the CSS rules defined in
      author_profile_html.css
