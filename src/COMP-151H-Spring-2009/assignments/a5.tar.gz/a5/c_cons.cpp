/**
 * \file c_cons.cpp
 *
 * Implementation of the wrapper functions for the C++ functions in
 * Cell.hpp. 
 */
#include "c_cons.h"
#include "Cell.hpp"
#include "eval.hpp"
#include <stack>

extern "C" {


  CCell* c_make_int(const int i) {
    return (CCell*)make_int(i);
  }  


  CCell* c_make_double(const double d) {
    return (CCell*)make_double(d);
  }  


  CCell* c_make_symbol(const char* const s) {
    return (CCell*)make_symbol(s);
  }


  CCell* c_cons(CCell* const my_car, CCell* const my_cdr){
    return (CCell*)cons((Cell*)my_car, (Cell*)my_cdr);
  }

  void c_delete(CCell* tcell) {
    delete (Cell*)tcell;
  }

}
