/**
 * \file c_cons.h
 *
 * Encapsulates an abstract interface layer for a cons list ADT,
 * without using member functions. Makes no assumptions about what
 * kind of concrete type Cell will be defined to be.
 * This is a wrapper file for the C++ functions that are used in the
 * C-based bison parser, therefore, for all the functions that you need
 * from your previous C++ implementation from last semester should be
 * wrapped up to be linked by C compilers.
 */

#ifndef C_CONS_H
#define C_CONS_H



typedef void CCell;
#ifdef __cplusplus
extern "C" {
#endif
  
  /**
   * \brief Make an int cell.
   * \param i The initial int value to be stored in the new cell.
  */
  CCell* c_make_int(const int i); 

   /**
   * \brief Make a double cell.
   * \param d The initial double value to be stored in the new cell.
   */
  CCell* c_make_double(const double d);

  /**
   * \brief Make a symbol cell.
   * \param s The initial symbol name to be stored in the new cell.
   */
  CCell* c_make_symbol(const char* const s);

  /**
   * \brief Make a conspair cell.
   * \param my_car The initial car pointer to be stored in the new cell.
   * \param my_cdr The initial cdr pointer to be stored in the new cell.
   */
  CCell* c_cons(CCell* const my_car, CCell* const my_cdr);

  /**
   * \brief Delete the Cell tcell.
   * \param tcell The Cell to be deleted.
   */
  void c_delete(CCell* tcell);

#ifdef __cplusplus
}
#endif


#endif // C_CONS_H
