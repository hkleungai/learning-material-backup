#include "parse.hpp"

using namespace std;

extern "C" {
extern int yyparse();
extern CCell* sexpr_root;
extern int scan_string(char* str);
extern int delete_buffer( );
}

Cell* parse(string sexpr) {
  scan_string((char*)sexpr.c_str());
  yyparse( );
  delete_buffer( );
  return (Cell*)sexpr_root;
}


