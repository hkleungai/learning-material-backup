/**
 * \file parser.hpp
 * the parsing function that is to be called by the main function.
 * the parsing function calls yy_scan_string and yyparse to do the parsing.
 */
#ifndef PARSE_HPP
#define PARSE_HPP


#include "c_cons.h"
#include <string>
#include "Cell.hpp"


/**
 * \brief Parse the input string.
 * \param sexpr  The s expression to be parsed.
 */
Cell* parse(std::string sexpr);




#endif // PARSE_HPP
