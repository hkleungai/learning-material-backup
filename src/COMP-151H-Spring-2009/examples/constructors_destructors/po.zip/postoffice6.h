class Clock
{
    int HHMM;
  public:
    Clock() : HHMM(0) { cout << "Constructor Clock\n"; }
    Clock(int hhmm) : HHMM(hhmm)
        { cout<<"Constructor Clock at "<< HHMM <<endl; }
    ~Clock() { cout << "Destructor Clock\n"; }
};

class Postoffice
{
    Clock clock;
  public:
    Postoffice()
        { clock = Clock(800); cout << "Constructor Postoffice\n"; }
    ~Postoffice(){ cout << "Destructor Postoffice\n"; }
};
