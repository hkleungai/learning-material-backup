class Clock
{
    int HHMM; // hour, minute

  public:
    Clock(int hhmm) : HHMM(hhmm) { cout << "Constructor Clock at " << HHMM << endl; }
    ~Clock() { cout << "Destructor Clock at " << HHMM << endl; }
};
