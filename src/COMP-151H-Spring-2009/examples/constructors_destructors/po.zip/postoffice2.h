class Clock
{
  public:
    Clock() { cout << "Constructor Clock\n"; }
    ~Clock() { cout << "Destructor Clock\n"; }
};

class Postoffice
{
    Clock *clock;
  public:
    Postoffice() { clock = new Clock; cout << "Constructor Postoffice\n"; }
    ~Postoffice(){ cout << "Destructor Postoffice\n"; }
};
