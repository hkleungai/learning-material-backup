class Clock
{
    int HHMM; // hour, minute

  public:
    Clock(int hhmm) : HHMM(hhmm) { cout << "Constructor Clock at " << HHMM << endl; }
    ~Clock() { cout << "Destructor Clock at " << HHMM << endl; }
};

class Postoffice
{
    Clock clock;

  public:
    Postoffice() : clock(800) { cout<< "Constructor Postoffice\n"; }
    ~Postoffice() { cout<< "Destructor Postoffice\n"; }
};
