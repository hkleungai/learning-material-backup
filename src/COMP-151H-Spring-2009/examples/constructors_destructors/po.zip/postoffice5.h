class Clock
{
  public:
    Clock() { cout << "Constructor Clock\n"; }
    ~Clock() { cout << "Destructor Clock\n"; }
};

class Room
{
    Clock clock;
  public:
    Room()  { cout << "Constructor Room\n"; }
    ~Room() { cout << "Destructor Room\n"; }
};

class Postoffice
{
    Room room;
  public:
    Postoffice(){cout << "Constructor Postoffice\n"; }
    ~Postoffice(){cout << "Destructor Postoffice\n"; }
};
