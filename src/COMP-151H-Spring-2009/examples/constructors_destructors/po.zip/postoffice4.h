class Clock
{
    int HHMM;
  public:
    Clock() : HHMM(0) { cout << "Constructor Clock\n"; }
    Clock(int hhmm) : HHMM(hhmm)
        { cout<<"Constructor Clock at "<< HHMM <<endl; }
    ~Clock() { cout << "Destructor Clock at " << HHMM << endl; }
};

class Room 
{
  public:
    Room()  { cout << "Constructor Room\n"; }
    ~Room() { cout << "Destructor Room\n"; }
};

class Postoffice
{
    Clock clock;
    Room room;
  public:
    Postoffice()  { cout << "Constructor Postoffice\n"; }
    ~Postoffice() { cout << "Destructor Postoffice\n"; }
};
