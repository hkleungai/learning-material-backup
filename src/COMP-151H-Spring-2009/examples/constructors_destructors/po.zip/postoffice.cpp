#include <iostream.h>
#include "postoffice.h"
int main() {
    cout << "Beginning of main\n";
    Postoffice x;
    cout << "End of main\n";
    return 0;
}
