//source: Chau Ming Kit
//date: 23/9/2000

#include <iostream>
#include <string>
#include "List.h"
using namespace std;

extern string *arrCity;
extern int intNumCity;
extern void ResBuild();

int main()
{
	

	List list;

	ResBuild();
	list.Init(arrCity, intNumCity);

	cout<<"The Cities to access are: "<<endl;
	list.Print();
	cout<<endl;

	cout<<"Please enter the city that you want to add."<<endl;
	string targetCity;
	cin>>targetCity;

	cout<<"Please enter the location of the list you want to add the new city."<<endl;
	cout<<"Currently there are "<<list.length()<<" cities in the list."<<endl;

	int index;
	cin>>index;
	
	list.insert_after_index(targetCity, index);
	
	cout<<"The new list is:"<<endl;
	list.Print();

	
	return 0;
}