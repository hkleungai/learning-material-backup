

#ifndef LIST_H
#define LIST_H

#include <iostream>
#include <string>
using namespace std;

class List {
private:
	struct sCity {
		string strCity;
		sCity* ptrNext;
	};
	sCity* m_Head;

	bool Insert(string strCity);

public:
	List();
	~List();

	void Init(string arrCity[], int intCity);
	void Print();
	int Access(string strCity);
	
	//----------------------------------------------------------------------
	
	//WRITE THE IMPLEMENTATION OF FUNCTION length
	//THAT RETURNS THE LENGTH OF THE LIST
	int length(); 
	
	//WRITE THE IMPLEMENTATION OF A FUNCTION THAT INSERTS A CITY NAMED targetCity
	//AFTER THE index LOCATION IN THE LIST.
	void insert_after_index(string targetCity, int index);
};

#endif