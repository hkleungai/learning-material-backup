﻿using System;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

namespace ASUWebApplication.Code_File
{
    public class EnrollmentData
    {
        // Set the connection string to connect to the Enrollment database.
        SqlConnection EnrollmentDBConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["EnrollmentConnectionString"].ConnectionString);

        // Process a SQL SELECT statement.
        public DataTable getData(string sql)
        {
            try
            {
                DataTable dt = new DataTable();
                if (EnrollmentDBConnection.State != ConnectionState.Open)
                {
                    EnrollmentDBConnection.Open();
                    SqlDataAdapter da = new SqlDataAdapter(sql, EnrollmentDBConnection);
                    da.Fill(dt);
                    EnrollmentDBConnection.Close();
                }
                else
                {
                    SqlDataAdapter da = new SqlDataAdapter(sql, EnrollmentDBConnection);
                    da.Fill(dt);
                }
                return dt;
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (ApplicationException ex)
            {
                MessageBox.Show(ex.Message);
            }
            return null;
        }

        // Process SQL INSERT, UPDATE and DELETE statements.
        public void setData(string sql, SqlTransaction trans)
        {
            try
            {
                SqlCommand SQLCmd = new SqlCommand(sql, EnrollmentDBConnection);
                SQLCmd.Transaction = trans;
                SQLCmd.CommandType = CommandType.Text;
                SQLCmd.ExecuteNonQuery();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (ApplicationException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (InvalidOperationException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        // Process an SQL SELECT statement that returns only a single value.
        public decimal getAggregateValue(string sql)
        {
            try
            {
                object aggregateValue;
                if (EnrollmentDBConnection.State != ConnectionState.Open)
                {
                    EnrollmentDBConnection.Open();
                    SqlCommand SQLCmd = new SqlCommand(sql, EnrollmentDBConnection);
                    SQLCmd.CommandType = CommandType.Text;
                    aggregateValue = SQLCmd.ExecuteScalar();
                    EnrollmentDBConnection.Close();
                }
                else
                {
                    SqlCommand SQLCmd = new SqlCommand(sql, EnrollmentDBConnection);
                    SQLCmd.CommandType = CommandType.Text;
                    aggregateValue = SQLCmd.ExecuteScalar();
                }
                return (DBNull.Value == aggregateValue ? 0 : Convert.ToDecimal(aggregateValue));
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
                return -1;
            }
        }

        // Make the processing of a SQL statement atomic.
        public SqlTransaction beginTransaction()
        {
            EnrollmentDBConnection.Open();
            SqlTransaction trans = EnrollmentDBConnection.BeginTransaction();
            return trans;
        }

        public void commitTransaction(SqlTransaction trans)
        {
            try
            {
                trans.Commit();
                EnrollmentDBConnection.Close();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (ApplicationException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}