#include <stdio.h> /* include standard IO header file */


/* our main function */
int main(void) 
{
	int n, sum;
	int i;

	printf("please enter a number: ");
	scanf("%d", &n);

	sum = 0;
	for (i=0; i<=n; i++)
		sum += i;
	printf("Sum: %d\n", sum);
	
	for (i=0,sum=0; i<=n; i++) sum += i;
	printf("Sum: %d\n", sum);

	for (i=0,sum=0; i<=n; sum+=i++);
	printf("Sum: %d\n", sum);

	return 0;
}