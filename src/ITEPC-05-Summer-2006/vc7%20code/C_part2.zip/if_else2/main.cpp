#include <stdio.h> /* include standard IO header file */


/* our main function */
int main(void) 
{
	int mark;

	printf("please enter your mark: ");
	scanf("%d", &mark);

	if (mark >= 100)
	{
		printf("well done!\n");
		printf("you are the best\n");
	}
	else 
		if (mark >= 80)
			printf("Good!\n");
		else
			if (mark >= 60)
				printf("Not bad.\n");
			else
				printf("you have failed...\n");


	return 0;
}