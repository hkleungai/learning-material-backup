#include <stdio.h> /* include standard IO header file */

/* our main function */
int main(void) 
{
	int sum;
	int input, n;

	printf("Please enter a number: ");
	scanf("%d", &input);

	sum = 0;
	n = input;
	while (n > 0)
	{
		sum += n;
		n--;
	}
	printf("Sum: %d\n", sum);

	sum = 0;
	n = input;
	do 
	{
		sum += n;
		n--;
	} 
	while(n > 0);
	printf("Sum: %d\n", sum);
}