#include <stdio.h> /* include standard IO header file */

/* 
This program find the largest number of three user input numbers.
*/


/* our main function */
int main(void) 
{
	int age;

	printf("please enter your age: ");
	scanf("%d", &age);

	if (age >= 18)
	{
		printf("welcome!\n");
		printf("May I have your order?\n");
	}
	else
		printf("adult only!\n");


	return 0;
}