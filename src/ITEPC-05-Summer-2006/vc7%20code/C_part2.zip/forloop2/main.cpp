#include <stdio.h> /* include standard IO header file */


/* our main function */
int main(void) 
{
	int n;

	printf("please enter a number: ");
	scanf("%d", &n);

	for (int i=0; i<n; i++)
		printf("*");
	printf("\n\n");

	for (int i=1; i<=n; i++)
	{
		for (int j=1; j<=i; j++)
			printf("*");
		printf("\n");
	}

	for (int i=n; i>0; i--)
	{
		for (int j=1; j<=i; j++)
			printf("*");
		printf("\n");
	}

	return 0;
}