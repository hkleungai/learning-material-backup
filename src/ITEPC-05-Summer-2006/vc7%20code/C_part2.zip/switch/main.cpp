#include <stdio.h> /* include standard IO header file */


/* our main function */
int main(void) 
{
	char ch;

	printf("please enter a character: ");
	scanf("%c", &ch);

	// what will happen if some "break" are removed?
	switch (ch)
	{
	case 'a':
		printf("A for apple\n");
		break;
	case 'b':
		printf("A for banana\n");
		break;
	case 'c':
		printf("C for cat\n");
		break;
	case 'd':
		printf("D for dog\n");
		break;
	case 'e':
		printf("E for elephant\n");
		break;
	default:
		printf("???\n");
	}

	return 0;
}