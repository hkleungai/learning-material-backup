#include <stdlib.h>
#include <stdio.h>
#include <gl/glut.h>

int winWidth = 640;
int winHeight = 480;
int frustumLeft = 0;
int frustumBottom = 0;
int frustumRight = 640;
int frustumTop = 480;
int nRect = 5;	// number of rectangles
bool isLeftButtonDown  = false;
double downX, downY; // unprojected mouse down position
double currX, currY; // unprojected mouse current position

void myInit()
{
	glClearColor(0.0, 0.0, 0.0, 0.0); // set black background color
	glColor3f(0.0, 1.0, 0.0); // set the drawing color
	glPointSize(10.0);   // a 'dot' is 10 by 10 pixels
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluOrtho2D(frustumLeft, frustumRight, frustumBottom, frustumTop);
}

void myDisplay()
{
	glClear(GL_COLOR_BUFFER_BIT); // clear the screen
	glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);	// draw filled polygon

	// compute step sizes
	int stepX = 640 / (nRect * 2);
	int stepY = 480 / (nRect * 2);

	// draw red rectangle
	int left = stepX;
	int bottom = stepY;
	int width = 640 - stepX * 2;
	int height = 480 - stepY * 2;
	glColor3d(1.0, 0.0, 0.0);
	glRecti(left, bottom, left + width, bottom + height);

	// draw blue rectangle
	left += stepX; bottom += stepY;
	width -= stepX * 2; height -= stepY * 2;
	glColor3d(0.0, 1.0, 0.0);
	glRecti(left, bottom, left + width, bottom + height);

	// draw green rectangle
	left += stepX; bottom += stepY;
	width -= stepX * 2; height -= stepY * 2;
	glColor3d(0.0, 0.0, 1.0);
	glRecti(left, bottom, left + width, bottom + height);

	// draw yellow rectangle
	left += stepX; bottom += stepY;
	width -= stepX * 2; height -= stepY * 2;
	glColor3d(1.0, 1.0, 0.0);
	glRecti(left, bottom, left + width, bottom + height);

	// draw our boundary box (if left mouse button is down)
	if (isLeftButtonDown)
	{
		glColor3d(1.0, 1.0, 1.0);
		glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);	// draw lines only (No fill)
		glRecti(downX, downY, currX, currY);
	}

	glutSwapBuffers();	// swap 2 display buffers
}

void myMouse(int button, int state, int x, int y)
{
	// print info to console
	// you can remove this safely
	switch (button)
	{
	case GLUT_LEFT_BUTTON: printf("left "); break;
	case GLUT_RIGHT_BUTTON: printf("right "); break;
	case GLUT_MIDDLE_BUTTON: printf("middle "); break;
	}
	switch (state)
	{
	case GLUT_DOWN: printf("down "); break;
	case GLUT_UP: printf("up "); break;
	}
	printf("%d %d\n", x, y);

	// if left button is pressed
	if (button == GLUT_LEFT_BUTTON && state == GLUT_DOWN) 
	{
		isLeftButtonDown = true;	// mark left button is down

		// compute the unprojected position
		// please note the casting from integer to double
		double ratioX = (double)x / (double)winWidth;
		double ratioY = (double)(winHeight-y) / (double)winHeight;
		downX = currX = frustumLeft + ratioX * (frustumRight - frustumLeft);
		downY = currY = frustumBottom + ratioY * (frustumTop - frustumBottom);

		glutPostRedisplay();	// ask for redraw
	}

	// if left button is released
	if (button == GLUT_LEFT_BUTTON && state == GLUT_UP) 
	{
		isLeftButtonDown  = false; // mark left button is up

		// mark the new frustum volume
		// and set the projection matrix
		frustumLeft = (currX<downX)? currX : downX;
		frustumBottom = (currY<downY)? currY : downY;
		frustumRight  = frustumLeft + abs(currX - downX);
		frustumTop = frustumBottom + abs(currY - downY);
		myInit();

		glutPostRedisplay();	// ask for redraw
	}
}

void myMovedMouse(int x, int y)
{
	// print info to console
	// you can remove this safely
	printf("move %d %d\n", x, y);

	// if dragged with left button
	if (isLeftButtonDown)
	{
		// compute the CURRENT unprojected position
		double ratioX = (double)x / (double)winWidth;
		double ratioY = (double)(winHeight-y) / (double)winHeight;
		currX = frustumLeft + ratioX * (frustumRight - frustumLeft);
		currY = frustumBottom + ratioY * (frustumTop - frustumBottom);
		
		glutPostRedisplay();	// ask for redraw
	}
}

void myKeyboard(unsigned char key, int x, int y)
{
	switch (key)
	{
	// exit program when q is pressed
	case 'q':
	case 'Q':
		exit(0);
		break;

	// reset frustum volume when r is pressed
	case 'r':
	case 'R':
		frustumLeft = 0;
		frustumBottom = 0;
		frustumRight = 640;
		frustumTop = 480;
		myInit();
		glutPostRedisplay();
		break;
	}
}

void myReshape(int w, int h)
{
	// record the window size
	winWidth = w;
	winHeight = h;
}

int main(int argc, char** argv)
{
	glutInit(&argc, argv);	// initialize the toolkit
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB); // set the display mode

	glutInitWindowSize(winWidth, winHeight); // set window size
	glutInitWindowPosition(100, 150); // set window position
	glutCreateWindow("2D Projection"); // open the screen window

	glutDisplayFunc(myDisplay);		// register redraw function
	glutMouseFunc(myMouse);			// register mouse click callback
	glutMotionFunc(myMovedMouse);	// register mouse motion callback
	glutKeyboardFunc(myKeyboard);	// register keyboard callback
	glutReshapeFunc(myReshape);

	myInit();		// additional initializations as necessary
	glutMainLoop();	// go into a perpetual loop
}