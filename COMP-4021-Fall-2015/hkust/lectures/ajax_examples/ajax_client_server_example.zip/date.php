<?php

// Set the timezone to HongKong
date_default_timezone_set('Asia/Hong_Kong');

// date() gets the server's time/date,
// you can construct the output format using these parameters
// H - 24-hour format of an hour (00 to 23)
// i - Minutes with leading zeros (00 to 59)
// s - Seconds, with leading zeros (00 to 59)
echo date("H:i:s");

?>
