<?php

// This example prints the cookie created
// by the previous example

	echo $_COOKIE["last_message"];
?>
