<?php
header("Location: http://www.yahoo.com/"); /* Redirect browser to another page */

/* Any PHP code below will not have an effect */
/* Any HTML code below will not be seen */
echo "<h1>My web page. . .</h1>";
?>
