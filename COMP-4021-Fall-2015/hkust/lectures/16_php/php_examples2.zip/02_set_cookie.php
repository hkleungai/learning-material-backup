<?php

// This example will correctly create a cookie.
// The cookie will expire 1 hour later.

setcookie("last_message", "Bye for now", time()+3600 );  

?>

