<html>
<head>
</head>

<?php

// This example appears to have correct code for creating a cookie.
// However, the HTTP header has already been sent,
// therefore it is too late to create the cookie.
// PHP will give you an error to inform you of this.

setcookie("last_message", "Bye for now", time()+3600 );  /* expire in 1 hour */

?>

<body>

<p>This is the web page.</p>

</body>
</html>
