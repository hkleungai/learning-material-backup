<?php
	setcookie ("last_message");//cookie is now deleted
?>