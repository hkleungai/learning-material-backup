<?php

// This example prints all the cookies for this web site
print_r($_COOKIE);

?>