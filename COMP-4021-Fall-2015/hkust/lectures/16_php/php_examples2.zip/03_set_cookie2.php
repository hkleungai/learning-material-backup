<?php
// This example will correctly create a cookie.
setcookie("last_message", "Bye for now", time()+3600 );
?>

<html>
<head>
</head>

<body>
<p>This is the web page.</p>
</body>
</html>
