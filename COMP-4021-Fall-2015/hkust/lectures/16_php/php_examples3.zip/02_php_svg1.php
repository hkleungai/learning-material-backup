<?php
header("Content-type: image/svg+xml");

print "<?xml version=\"1.0\"?>";
print "<?xml-stylesheet href=\"style.css\" type=\"text/css\"?>";
?>
<svg xmlns="http://www.w3.org/2000/svg" version="1.1" baseProfile="full">
    <defs>
        <linearGradient id="gradient" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" style="stop-color:red"/>
            <stop offset="100%" style="stop-color:yellow"/>
        </linearGradient>
    </defs>
    <text x="6" y="100">Text!</text>
</svg>
