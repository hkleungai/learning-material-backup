<?php
header("Content-type: image/svg+xml");

print "<?xml version=\"1.0\"?>";
?>
<svg xmlns="http://www.w3.org/2000/svg" version="1.1" baseProfile="full">
<style type="text/css">
<?php
include("style.css");
?>
</style>
<text x="6" y="100">Text!!</text>
</svg>
