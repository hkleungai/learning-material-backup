<html>
<body>
<?php
$name = 'donald';
?>
<script>
<?php print "var name='$name';"; ?>
alert("The variable name has now been transferred from php to JavaScript, it has the value " + name);
</script>
</body>
</html>