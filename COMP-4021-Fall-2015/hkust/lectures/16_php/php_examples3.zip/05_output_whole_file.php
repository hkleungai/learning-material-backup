<?php
// Tell the browser a PDF file is coming
header('Content-type: application/pdf');
// For the browser, it will be called downloaded.pdf
header('Content-Disposition: attachment;filename="download.pdf"');
// The PDF source is in original.pdf
readfile('original.pdf'); // File is sent to the browser
?>