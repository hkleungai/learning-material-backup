<?php
header ("Content-Type: text/xml");
print ('<?xml version="1.0" encoding="utf-8"?>');
?>
<xml>
<message>This file will be interpreted as XML</message>
</xml>