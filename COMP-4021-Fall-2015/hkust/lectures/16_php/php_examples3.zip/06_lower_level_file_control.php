<?php
$fp = fopen("flowers.jpg", "rb"); //open the file
$mybuf = fread($fp, filesize("flowers.jpg")); // read it
fclose($fp); // close the file
header("Content-type: image/jpeg"); // mime type
print("$mybuf"); // Output the JPEG image
?>