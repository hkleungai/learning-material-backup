<html>
<head>
<title>PHP Test</title>
</head>
<body>
<?php
// This is very simple information window
phpinfo();
?>
</body>
</html>