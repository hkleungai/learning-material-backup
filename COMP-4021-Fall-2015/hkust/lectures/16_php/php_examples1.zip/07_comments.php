<html>
<head>
<title>PHP Test</title>
</head>
<body>
<?php
	// This example demonstrates the usage of various comment types

	echo "<p>This is a test</p>";

	// This is a one-line c++ style comment

	/* This is a multi line comment
	which includes these words */

	echo "<p>This is yet another test</p>";
	echo "<p>One Final Test</p>";

	# This is the last comment
?>
</body>
</html>