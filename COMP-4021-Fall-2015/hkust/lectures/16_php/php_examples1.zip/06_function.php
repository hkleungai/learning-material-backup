<html>
<head>
<title>PHP Test</title>
</head>
<body>
<?php
	// This example prints out the date in the specific format
	function print_data(){
		$today = date("Y-m-d");
		PRINT "<CENTER>Today is: $today.</CENTER>";
	}
	print_data();
?>
</body>
</html>