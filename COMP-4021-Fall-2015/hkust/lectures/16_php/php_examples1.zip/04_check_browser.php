<html>
<head>
<title>PHP Test</title>
</head>
<body>
<?php
	// This example checks the browser's version and detects whether
	// the user is using IE or not.
	if(strstr($HTTP_SERVER_VARS['HTTP_USER_AGENT'],"MSIE")) {
?>
<center><b>You are using Internet Explorer</b></center>
<?
	} else {
?>
<center><b>You are not using Internet Explorer</b></center>
<?
	}	
?>
</body>
</html>