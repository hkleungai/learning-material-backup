<html>
<head>
<title>PHP Test</title >
</head>
<body>
<!-- A very simple example print a single line of text
// -->
<?php echo "Hello World";?>
</body>
</html>