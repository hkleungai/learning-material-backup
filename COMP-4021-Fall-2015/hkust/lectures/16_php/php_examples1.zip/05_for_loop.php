<html>
<body>
<?php 
	// This example simply prints out a list of integer in a for loop
	for ($i=1;$i<10;$i++)
		print $i;
?>
</body>
</html>