<html>
<head>
<title>PHP Test</title>
</head>
<body>
<?php
	// This example will print a text stored in the a variable $va
	$va= "This is a variable";
	echo $va;
?>
</body>
</html>