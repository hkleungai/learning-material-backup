<html>
<head>
<title>PHP Test</title>
</head>
<body>
<?php
	// This example demonstrates uploading file
	// The file is uploaded in the PHP directory, e.g. c:\php

	move_uploaded_file($_FILES['userfile']['tmp_name'], $_FILES['userfile']['name']);

	echo $_FILES['userfile']['name'], " is uploaded to the PHP directory";
	

?>
</body>
</html>