<html>
<head>
<title>PHP Test</title>
</head>
<!-- This example is the action of 08_form.htm -->
<body>
Hi <?php echo $_POST['name']?>. You are <?php echo $_POST['age']?> years old.
</body>
</html>