<html>
<head>
<title>PHP Test</title>
</head>
<body>
<?php 
	// This example prints a constant of value Hello world.

	define("CONSTANT", "Hello world."); 
	echo CONSTANT; // outputs "Hello world."
?> 
</body>
</html>