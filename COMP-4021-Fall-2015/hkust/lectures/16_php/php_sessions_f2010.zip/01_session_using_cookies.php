<?php
    /*
     * This program creates a session using cookies. A count session variable
     * is created to keep on counting the number of times a user has visited
     * the page.
     */

    session_start();

    if (!isset($_SESSION['count'])) // If does not exist, create it
        $_SESSION['count'] = 0;
    else
        $_SESSION['count']++;       // Increment count by one

    echo "You have visited here ".$_SESSION['count']." time(s).";
?>
