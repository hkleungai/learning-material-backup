<?php
    /*
     * This program deletes a session variable from the current session, if
     * there is.
     */

    session_start();

    unset($_SESSION['count']);  // Dump the session variable

    /*
     * You can run 01_session_using_cookies.php again to see the value of the
     * session variable.
     */
?>
