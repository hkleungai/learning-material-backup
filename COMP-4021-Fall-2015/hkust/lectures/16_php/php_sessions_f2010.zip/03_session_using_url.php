<?php
    /*
     * This program creates a session using the URL if cookies is not
     * available. The session ID is passed on using the GET method in the URL.
     * If the session is not created the session ID is added at the end of the
     * URL.
     */

    session_start();  // This will check for both cookie and URL methods

    if (!isset($_SESSION['count'])) {
        // The constant SID is created only if the cookies method fails.
        // Therefore SID will be an empty string if cookies has been enabled.
        header("Location: 03_session_using_url.php?" . SID);
        $_SESSION['count'] = 0;
    }
    else {
        echo "You have visited here " . $_SESSION['count'] . " time(s)";
        $_SESSION['count']++;
    }
?>
