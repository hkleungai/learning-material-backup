#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <GL/glut.h>

int winHeight = 400;
int winWidth = 400;
int newtonSteps = 50;
double sin60 = 0.86602540378443864676372317075294;
double cos60 = 0.5;
float red[3] = { 1.0, 0.0, 0.0 };
float green[3] = { 0.0, 1.0, 0.0 };
float blue[3] = { 0.0, 0.0, 1.0 };

struct complex
{
	double r, i;
	complex()
	{
		r = i = 0;
	}
	complex(double rl, double im)
	{
		r = rl;
		i = im;
	}
};

inline complex add(complex a, complex b)
{
	complex c;
	c.r = a.r + b.r;
	c.i = a.i + b.i;
	return c;
}

inline complex sub(complex a, complex b)
{
	complex c;
	c.r = a.r - b.r;
	c.i = a.i - b.i;
	return c;
}

inline complex mult(complex a, double s)
{
	complex c;
	c.r = a.r * s;
	c.i = a.i * s;
	return c;
}

inline complex div(complex a, complex b)
{
	double q = b.r * b.r + b.i * b.i;
	complex c(0, 0);
	if (q == 0.0) return c;
	c.r = (a.r * b.r + a.i * b.i) / q;
	c.i = (a.i * b.r - a.r * b.i) / q;
	return c;
}

inline complex sq(complex a)
{
	complex c;
	c.r = a.r*a.r - a.i*a.i;
	c.i = 2.0 * a.r * a.i;
	return c;
}

inline complex cube(complex a)
{
	complex c;
	c.r = a.r * a.r * a.r - 3.0 * a.r * a.i * a.i;
	c.i = 3.0 * a.r * a.r * a.i - a.i * a.i * a.i;
	return c;
}

inline complex newtonMethod(complex a, int step)
{
	complex next = a;

	for (int i=0; i<step; i++)
	{
		complex tmp1 = sub(cube(next), complex(1.0, 0.0));
		complex tmp2 = mult(sq(next), 3.0);
		next = sub(next, div(tmp1, tmp2));
	}
	return next;
}

void myInit()
{
	glClearColor(0.0, 0.0, 0.0, 0.0); // set red background color
	glColor3f(0.0, 1.0, 0.0); // set the drawing color
	glPointSize(10.0);   // a 'dot' is 10 by 10 pixels
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluOrtho2D(0, winWidth, 0, winHeight);
	glViewport(0, 0, winWidth, winHeight);
}

void myDisplay()
{
	glClear(GL_COLOR_BUFFER_BIT); // clear the screen

	double stepX = (double)winWidth / 4.0;
	double stepY = (double)winHeight / 4.0;
	double shiftX = (double)winWidth / 2.0;
	double shiftY = (double)winHeight / 2.0;

	for (int i=0; i<winWidth; i++)
	{		for (int j=0; j<winHeight; j++)
		{
			complex c((i-shiftX) / stepX, (j-shiftY) / stepY);
			c = newtonMethod(c, newtonSteps);
			double sqDis1 = (c.r - 1.0) * (c.r - 1.0) + (c.i * c.i);
			double sqDis2 = (c.r+cos60) * (c.r+cos60) + (c.i-sin60) * (c.i-sin60);
			double sqDis3 = (c.r+cos60) * (c.r+cos60) + (c.i+sin60) * (c.i+sin60);

			if (sqDis1 < 0.1)
			{
				glRasterPos2d(i, j);
				glDrawPixels(1, 1, GL_RGB, GL_FLOAT, red);
			}
			else if (sqDis2 < 0.1)
			{
				glRasterPos2d(i, j);
				glDrawPixels(1, 1, GL_RGB, GL_FLOAT, green);
			}
			else if (sqDis3 < 0.1)
			{
				glRasterPos2d(i, j);
				glDrawPixels(1, 1, GL_RGB, GL_FLOAT, blue);
			}
		}
	}

	glFlush();
}

void myMouse(int button, int state, int x, int y)
{
	if (button == GLUT_LEFT_BUTTON && state == GLUT_DOWN)
	{
		newtonSteps++;
		glutPostRedisplay();
	}
}

void myKeyboard(unsigned char key, int mouseX, int mouseY)
{
	switch(key)
	{
	case 'E': 
		exit(-1); // terminate the program
		break;
	}
}

void myReshape(int w, int h)
{
	winWidth = w;
	winHeight = h;
	myInit();
}

int main(int argc, char** argv)
{
	glutInit(&argc, argv);	// initialize the toolkit
	glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB); // set the display mode

	glutInitWindowSize(winWidth, winHeight); // set window size
	glutInitWindowPosition(100, 150); // set window position
	glutCreateWindow("my first attemp"); // open the screen window

	glutDisplayFunc(myDisplay);		// register redraw function
	glutMouseFunc(myMouse);			// register mouse click callback
	glutKeyboardFunc(myKeyboard);	// register keyboard callback
	glutReshapeFunc(myReshape);

	myInit();		// additional initializations as necessary
	glutMainLoop();	// go into a perpetual loop
}