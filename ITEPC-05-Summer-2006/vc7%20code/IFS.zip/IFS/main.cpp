#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <time.h>
#include <GL/glut.h>

// 2D point structure
struct Point
{
	double x, y;
	
	// default constructor
	Point()
	{
		x = y = 0;
	}
	// constructor
	Point(double X, double Y)
	{
		x = X;
		y = Y;
	}
};

int winHeight = 600;		// window height
int winWidth = 500;			// window width
double spaceHeight = 12;	// height of space to be rendered
double spaceWidth = 10;		// width of space to be rendered
int steps = 100000;			// number of steps
float green[3] = { 0.2, 1.0, 0.2 };	// color of pixel
double shift = 1.6;		// shape control variable
double angle = 0.04;	// shape control variable
double size = 2;		// shape control variable

void myInit()
{
	glClearColor(0.0, 0.0, 0.0, 0.0); // set red background color
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluOrtho2D(0, winWidth, 0, winHeight);
	glViewport(0, 0, winWidth, winHeight);

	srand(time(0));	// set seed for random number generator
}

void myDisplay()
{
	glClear(GL_COLOR_BUFFER_BIT); // clear the screen

	double stepX = winWidth / spaceWidth;	// step size in x direction
	double stepY = winHeight / spaceHeight;	// step size in y direction
	Point p(0,0);	// our initial point

	for (int i=0; i<steps; i++)
	{
		// compute the screen position
		double x = (p.x * stepX) + (winWidth / 2.0);
		double y = (p.y * stepY);

		// render the point
		glRasterPos2d(x, y);
		glDrawPixels(1, 1, GL_RGB, GL_FLOAT, green);

		// compute the next position
		int r = ((double)rand() / (double)RAND_MAX) * 100;
		if (r == 0) // 1%
			p = Point(0, 0.16*p.y);
		else if (r < 7) // 7%
			p = Point(0.20*p.x - 0.26*p.y, 0.23*p.x + 0.22*p.y + shift);
		else if (r < 14) // 7%
			p = Point(-0.15*p.x + 0.28*p.y, 0.26*p.x  + 0.24*p.y + 0.44);
		else // 85%
			p = Point(0.85*p.x  + angle*p.y, -angle*p.x + 0.85*p.y + size);
	}

	glFlush();
}

void myMouse(int button, int state, int x, int y)
{
	if (button == GLUT_LEFT_BUTTON && state == GLUT_DOWN)
	{
		glutPostRedisplay();
	}
}

void myKeyboard(unsigned char key, int mouseX, int mouseY)
{
	switch(key)
	{
	case 'E': 
		exit(-1); // terminate the program
		break;
	}
}

void myReshape(int w, int h)
{
	winWidth = w;
	winHeight = h;
	myInit();
}

int main(int argc, char** argv)
{
	glutInit(&argc, argv);	// initialize the toolkit
	glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB); // set the display mode

	glutInitWindowSize(winWidth, winHeight); // set window size
	glutInitWindowPosition(100, 150); // set window position
	glutCreateWindow("Fractal - Newton's method"); // open the screen window

	glutDisplayFunc(myDisplay);		// register redraw function
	glutMouseFunc(myMouse);			// register mouse click callback
	glutKeyboardFunc(myKeyboard);	// register keyboard callback
	glutReshapeFunc(myReshape);

	myInit();		// additional initializations as necessary
	glutMainLoop();	// go into a perpetual loop
}