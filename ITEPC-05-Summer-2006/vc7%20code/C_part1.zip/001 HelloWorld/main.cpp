#include <stdio.h> /* include standard IO header file */

/* 
This is our first program.
This lines are comment lines. 
All text within here will be ignored by the compiler.
*/


/* our main function */
int main(void) 
{
	printf("Hello World!\n");	/* print the line "Hello World!" */
	return 0;					/* end the program and return 0 to system */
}