#include <stdio.h> /* include standard IO header file */

/* 
This program compute the sum of two user input numbers.
*/


/* our main function */
int main(void) 
{
	float a, b;	/* define two float variables */

	printf("please enter the first number: ");
	scanf("%f", &a);		/* read value from screen and assign to variable a */
	printf("please enter the second number: ");
	scanf("%f", &b);		/* read value from screen and assign to variable b */

	printf("sum: %f\n", a + b);	/* print the sum */
	return 0;					/* end the program and return 0 to system */
}