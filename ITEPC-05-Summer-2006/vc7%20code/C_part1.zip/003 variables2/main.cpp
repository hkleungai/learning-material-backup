#include <stdio.h> /* include standard IO header file */

/* 
This program compute the perimeter and area of square with given side length/
*/


/* our main function */
int main(void) 
{
	float side = 3.0;		/* define variable side and assign 3 to it */
	float perimeter, area;	/* define two float variables */
	 
	perimeter = side * 4;		/* assign side*4 to variable perimeter */
	area = side * side;			/* assign side*side to variable area */

	printf("side: %f\n", side);				/* print the side */
	printf("perimeter: %f\n", perimeter);	/* print the perimeter */
	printf("area: %f\n", area);				/* print the area */
	return 0;					/* end the program and return 0 to system */
}