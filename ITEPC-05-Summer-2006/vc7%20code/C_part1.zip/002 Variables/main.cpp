#include <stdio.h> /* include standard IO header file */

/* 
This program compute the perimeter and area of square with given side length/
*/


/* our main function */
int main(void) 
{
	int side, perimeter, area;	/* define three int variables */

	side = 3;					/* assign 3 to variable side */
	perimeter = side * 4;		/* assign side*4 to variable perimeter */
	area = side * side;			/* assign side*side to variable area */

	printf("side: %d\n", side);				/* print the side */
	printf("perimeter: %d\n", perimeter);	/* print the perimeter */
	printf("area: %d\n", area);				/* print the area */
	return 0;					/* end the program and return 0 to system */
}