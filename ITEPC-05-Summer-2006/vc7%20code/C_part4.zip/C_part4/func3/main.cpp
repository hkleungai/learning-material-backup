#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

void Reverse(char s[])
{
	int i, j;
	int len =strlen(s);
	char ch;

	for (i=0,j=len-1; i<len/2; i++,j--)
	{
		ch = s[i];
		s[i] = s[j];
		s[j] = ch;
	}
}

void PrintArray(int arr[], int n)
{
	int i;
	for (i=0; i<n; i++) printf("%d ", arr[i]);
	printf("\n");
}

void SortArray(int arr[], int n)
{
	int i, j, tmp;

	for (i=n-1; i>0; i--)
		for (j=0; j<i; j++)
			if (arr[j] > arr[j+1])
			{
				tmp = arr[j];
				arr[j] = arr[j+1];
				arr[j+1] = tmp;
			}
}

int BiarySearch(int a, int arr[], int low, int up)
{
	int mid = (low+up) / 2;

	if (low == mid && arr[low] != a) return -1;

	if (arr[mid] == a) 
		return mid;
	else if (arr[mid] > a)
		return BiarySearch(a, arr, low, mid);
	else
		return BiarySearch(a, arr, mid, up);
}

int main()
{
	char s[1024];
	printf("Please enter a string: ");
	scanf("%s", s);

	Reverse(s);
	printf("%s\n", s);

	int i;
	int arr[10];
	srand(time(0));
	for (i=0; i<10; i++) arr[i] = rand();
	PrintArray(arr, 10);

	SortArray(arr, 10);
	PrintArray(arr, 10);

	int a;
	printf("Please enter a string: ");
	scanf("%d", &a);
	int index = BiarySearch(a, arr, 0, 10);
	printf("%d\n", index);

	return 0;
}