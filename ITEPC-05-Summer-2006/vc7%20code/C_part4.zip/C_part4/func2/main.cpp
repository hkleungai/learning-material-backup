#include <stdio.h>
#include <math.h>

// recursive function 
long Fibonacci(long n)
{
	if (n<0) return 0;
	else if (n==1) return 1;
	else if (n==2) return 1;
	else return Fibonacci(n-2) + Fibonacci(n-1);
}

// another way to compute Fibonacci number
long Fibonacci2(long n)
{
	long t[100];

	t[0] = 1;
	t[1] = 1;
	for (long i=2; i<n; i++)
		t[i] = t[i-1] + t[i-2];

	return t[n-1];
}

long main()
{
	long n, f;

	printf("Please enter a number: ");
	scanf("%d", &n);

	f = Fibonacci(n);
	printf("The %dth Fibonacci number is %d\n", n, f);

	return 0;
}