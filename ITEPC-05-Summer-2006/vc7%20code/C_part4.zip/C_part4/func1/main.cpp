#include <stdio.h>
#include <math.h>

int add(int a, int b)
{
	return a + b;
}

void swap(int a, int b)
{
	int tmp = a;
	a = b;
	b = tmp;
}

bool isPrime(int a)
{
	int i;
	int root = (int)sqrt((double)a) + 1;

	for (i=2; i<root; i++)
		if (a%i == 0) return false;

	return true;
}

int main()
{
	int n1, n2, n3, tmp;

	printf("Please enter two numbers: ");
	scanf("%d %d", &n1, & n2);

	// add two number
	n3 = add(n1, n2);
	printf("Sum: %d\n", n3);

	// swap two number
	swap(n1, n2);
	printf("swap: %d %d\n", n1, n2);

	tmp = n1;
	n1 = n2;
	n2 = tmp;
	printf("swap2: %d %d\n", n1, n2);

	// test for prime number
	if (isPrime(n1))
		printf("%d is prime.\n", n1);
	else
		printf("%d is not prime.\n", n1);

	if (isPrime(n2))
		printf("%d is prime.\n", n2);
	else
		printf("%d is not prime.\n", n2);

	return 0;
}