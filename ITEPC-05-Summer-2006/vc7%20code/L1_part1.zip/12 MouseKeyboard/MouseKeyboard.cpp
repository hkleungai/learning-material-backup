#include <stdlib.h>
#include <gl/glut.h>

int screenHeight = 480, screenWidth = 640;

void myInit()
{
	glClearColor(1.0, 0.0, 0.0, 0.0); // set red background color
	glColor3f(0.0, 1.0, 0.0); // set the drawing color
	glPointSize(10.0);   // a 'dot' is 10 by 10 pixels
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluOrtho2D(0, 640, 0, 480);
}

void myDisplay()
{
	glClear(GL_COLOR_BUFFER_BIT); // clear the screen
	glBegin(GL_POINTS);
		glVertex2i(100, 50); // draw three dots
		glVertex2i(100, 130);
		glVertex2i(150, 130);
	glEnd();

	glFlush();	// send all output to display
}

void myMouse(int button, int state, int x, int y)
{
	if (button == GLUT_LEFT_BUTTON && state == GLUT_DOWN)
	{
		glBegin(GL_POINTS);
			glVertex2i(x, screenHeight - y);
		glEnd();
		glFlush();
	}
}

void myMovedMouse(int mouseX, int mouseY)
{
	GLint x = mouseX;
	GLint y = screenHeight - mouseY;	// flip it as usual
	GLint brushSize = 20;
	glRecti(x, y, x + brushSize, y + brushSize);
	glFlush();
}

void myKeyboard(unsigned char key, int mouseX, int mouseY)
{
	GLint x = mouseX;
	GLint y = screenHeight - mouseY;	// flip it as usual
	switch(key)
	{
	case 'p':			// draw a dot at the mouse position
		glBegin(GL_POINTS);
		glVertex2i(x, y);
		glEnd();
		glFlush();
		break;	
	case 'E': exit(-1); // terminate the program
	}
}

int main(int argc, char** argv)
{
	glutInit(&argc, argv);	// initialize the toolkit
	glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB); // set the display mode

	glutInitWindowSize(screenWidth, screenHeight); // set window size
	glutInitWindowPosition(100, 150); // set window position
	glutCreateWindow("my first attemp"); // open the screen window

	glutDisplayFunc(myDisplay);		// register redraw function
	glutMouseFunc(myMouse);			// register mouse click callback
	glutMotionFunc(myMovedMouse);	// register mouse motion callback
	glutKeyboardFunc(myKeyboard);	// register keyboard callback

	myInit();		// additional initializations as necessary
	glutMainLoop();	// go into a perpetual loop
}