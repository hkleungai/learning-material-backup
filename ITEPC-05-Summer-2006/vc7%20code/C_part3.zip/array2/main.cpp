#include <stdio.h> /* include standard IO header file */
#include <string.h>
#include <ctype.h>

int main(void) 
{
	char s[255];
	int i, len;

	// read string
	// separated with ' ' or \n
	scanf("%s\n", s);		// no '&' for reading string
	len = strlen(s);		// get the length
	printf("%s\n", s);

	for (i=0; i<len; i++)
		if (islower(s[i]))
			s[i] = toupper(s[i]);
	printf("%s\n", s);

/*
	for (i=0; i<len; i++)	
		if (s[i]>='a' && s[i]<='z') // same as toupper function
			s[i] = s[i]-'a'+'A';
	printf("%s\n", s);
*/

	// read line
	gets(s);			// read line
	len = strlen(s);	// get the length

	for (i=0; i<len; i++)
		if (i==0 || s[i-1]==' ') // NOTE: short cut OR
			s[i] = toupper(s[i]);

	printf("%s\n", s);

	return 0;
}