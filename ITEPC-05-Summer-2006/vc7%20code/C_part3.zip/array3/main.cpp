#include <stdio.h> /* include standard IO header file */
#include <string.h>
#include <stdlib.h> // for atoi function

int main(void) 
{
	char s[255];
	int arr[100];
	int n = 0, tmp;
	int i, j;

	// read numbers (end with -1)
	do
	{
		scanf("%s", s);		// read string
		tmp = atoi(s);		// ASCII (string) to integer 

		if (tmp != -1)
			arr[n++] = tmp;	
	}
	while (tmp != -1);

	// sort the numbers (bubble sort)
	for (i=n-1; i>0; i--)	// form last index to first index (n-1 to 0)
		for (j=0; j<i; j++)		// form zero to i-1
			if (arr[j] > arr[j+1])	// if previous number is bigger
			{
				// swap the two number
				tmp      = arr[j];	
				arr[j]   = arr[j+1];
				arr[j+1] = tmp;
			}


	// print result
	for (i=0; i<n; i++)
		printf("%d ", arr[i]);
	printf("\n");
}