#include <stdio.h> /* include standard IO header file */


/* our main function */
int main(void) 
{
	int i;
	int arr[10];

	for (i=0; i<10; i++)
		arr[i] = (i+1)*(i+1);

	for (i=0; i<10; i++)
		printf("%d ", arr[i]);
	printf("\n\n");

	return 0;
}