int x = 5;

int f() { return ++x; }
