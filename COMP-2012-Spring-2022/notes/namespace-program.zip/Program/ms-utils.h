/* File: ms-utils.h */
class Stack       { /* incomplete */ };
class Other_Class { /* incomplete */ };
void edge()       { cout << "Microsoft's browser" << endl; };
void app(int x)   { cout << "Microsoft's app: " << x << endl; };
