#include <iostream>     /* File: std-using.cpp */
using namespace std;

int main()
{
    string s;
    cin >> s;
    cout << s << endl;

    s += " is good!";
    cout << s << endl;
    
    return 0;
}
 
