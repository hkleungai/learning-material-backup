const int MAP_SIDE_LEN = 5; // the gameboard is a perfect square

const int LINK_ENDS[][2] = {{4, 13}, {1, 22}, {8, 10}, {14, 20}, {21, 7}, {24, 3}, {19, 11}, {17, 15}};// the generalization of snakes and ladders
const int LANDSLIDE_LOCS[] = {6, 11, 13, 23};