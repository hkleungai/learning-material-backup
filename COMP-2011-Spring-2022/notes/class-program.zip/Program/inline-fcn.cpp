class temperature
{   ...
    double kelvin() const { return degree; }
    double celsius() const { return degree - 273.15; }
};
