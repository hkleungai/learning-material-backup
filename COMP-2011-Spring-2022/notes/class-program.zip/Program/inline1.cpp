int f(int x) { return 4*x*x + 9*x + 1; }
int main() { int y = f(5); }
