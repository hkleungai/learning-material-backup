/* File: add.cpp */
#include <iostream>     // Load info of a Standard C++ library
using namespace std;    // Standard C++ namespace

int main()              // Program's entry point
{
    /* Major program codes */
    cout << "123 + 456 = " << 123 + 456 << endl; 

    return 0;           // A nice ending
}
