//modify and submit this file only
#include "pa3.h"
#include <iostream>
using namespace std;
//you are NOT allowed to include any additional library; see FAQ

TrainCar* createTrainHead()
{
}

bool addCar(TrainCar* head, int position, CarType type, int maxLoad)
{
}

bool deleteCar(TrainCar* head, int position)
{
}

bool swapCar(TrainCar* head, int a, int b)
{
}

void sortTrain(TrainCar* head, bool ascending)
{
}

bool load(TrainCar* head, CarType type, int amount)
{
}

bool unload(TrainCar* head, CarType type, int amount)
{
}

void printCargoStats(const TrainCar* head)
{
}

void divide(const TrainCar* head,  TrainCar* results[CARGO_TYPE_COUNT])
{
}

TrainCar* optimizeForMaximumPossibleCargos(const TrainCar* head, int upperBound)
{
}

void deallocateTrain(TrainCar* head)
{
}
