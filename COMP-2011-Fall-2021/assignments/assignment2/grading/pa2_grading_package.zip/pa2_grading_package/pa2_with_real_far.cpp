#include <iostream>
#include <cstring>
#include "cleaning_robot.h"
using namespace std;

/*
   *    COMP 2011 2021 Fall Programming Assignment 2
   *    Student Name        : 
   *    Student ID          :
   *    Student ITSC email  :        
   * 
   * You are not allowed to use extra library
*/

// Please do all your work in this file. You just need to submit this file.

int findMaximumPlace(int robot_x, int robot_y, int robot_energy, int robot_full_energy,
                     char result_map[MAP_HEIGHT][MAP_WIDTH], char temp_map[MAP_HEIGHT][MAP_WIDTH])
{
    if (robot_x < 0 || robot_y < 0 || robot_x >= MAP_WIDTH || robot_y >= MAP_HEIGHT)
        return 0;
    if (robot_x < 0 || robot_y < 0 || robot_x >= MAP_WIDTH || robot_y >= MAP_HEIGHT)
        return 0;
    if (result_map[robot_y][robot_x] == BLOCKED)
        return 0;
    if (robot_energy < 0)
        return 0;
    if (result_map[robot_y][robot_x] == CHARGER)
    {
        // cout << "get charger, fully charged." << endl;
        robot_energy = robot_full_energy;
    }

    int resultValue = 0;
    if (result_map[robot_y][robot_x] != VISITED)
    {
        result_map[robot_y][robot_x] = VISITED;
        resultValue += 1;
    }

    resultValue += findMaximumPlace(robot_x, robot_y - 1, robot_energy - 1, robot_full_energy, result_map, temp_map);

    resultValue += findMaximumPlace(robot_x + 1, robot_y, robot_energy - 1, robot_full_energy, result_map, temp_map);

    resultValue += findMaximumPlace(robot_x, robot_y + 1, robot_energy - 1, robot_full_energy, result_map, temp_map);

    resultValue += findMaximumPlace(robot_x - 1, robot_y, robot_energy - 1, robot_full_energy, result_map, temp_map);

    return resultValue;
}

int findShortestDistance(int robot_x, int robot_y, int target_x, int target_y, int robot_energy,
                         int robot_full_energy, const char map[MAP_HEIGHT][MAP_WIDTH], char temp_map[MAP_HEIGHT][MAP_WIDTH])
{

    int maximum = PA2_MAX_PATH;

    if (robot_x < 0 || robot_y < 0 || robot_x >= MAP_WIDTH || robot_y >= MAP_HEIGHT)
        return maximum;
    if (robot_energy < 0)
        return maximum;
    if (map[robot_y][robot_x] == BLOCKED)
        return maximum;
    // if (temp_map[robot_y][robot_x] == VISITED)
    //     return maximum;

    if (robot_x == target_x && robot_y == target_y)
    {
        return 1;
    };

    char original = temp_map[robot_y][robot_x];
    if (map[robot_y][robot_x] == CHARGER && temp_map[robot_y][robot_x] != VISITED)
    {
        // cout << "get charger, fully charged." << endl;
        robot_energy = robot_full_energy;
    }
    temp_map[robot_y][robot_x] = VISITED;

    // Find In four direction
    int shortest = maximum;
    int resultUP = findShortestDistance(robot_x, robot_y - 1,
                                        target_x, target_y, robot_energy - 1, robot_full_energy, map, temp_map);
    if (shortest > resultUP)
    {
        shortest = resultUP;
        // shortestDirection = 0;
    }
    int resultRight = findShortestDistance(robot_x + 1, robot_y,
                                           target_x, target_y, robot_energy - 1, robot_full_energy, map, temp_map);
    if (shortest > resultRight)
    {
        shortest = resultRight;
        // shortestDirection = 1;
    }

    int resultDown = findShortestDistance(robot_x, robot_y + 1,
                                          target_x, target_y, robot_energy - 1, robot_full_energy, map, temp_map);
    if (shortest > resultDown)
    {
        shortest = resultDown;
        // shortestDirection = 2;
    }

    int resultLeft = findShortestDistance(robot_x - 1, robot_y,
                                          target_x, target_y, robot_energy - 1, robot_full_energy, map, temp_map);
    if (shortest > resultLeft)
    {
        shortest = resultLeft;
        // shortestDirection = 3;
    }

    temp_map[robot_y][robot_x] = original;

    if (shortest < maximum)
    {
        // cout << "Found!" << shortest << "in" << robot_x << ":" << robot_y << endl;
        return 1 + shortest;
    }
    else
    {
        return maximum;
    }
}

int findPathSequence(int robot_x, int robot_y, int target_x, int target_y, int robot_energy,
                     int robot_full_energy, char result_sequence[], const char map[MAP_HEIGHT][MAP_WIDTH], char temp_map[MAP_HEIGHT][MAP_WIDTH])
{
    // temp_map can be used or without used.
    int maximum = PA2_MAX_PATH;
    char temp_result_sequence[MAX_STRING_SIZE];

    // cout << "Called! findPathSequence" << robot_x << " " << robot_y << endl;
    if (robot_x < 0 || robot_y < 0 || robot_x >= MAP_WIDTH || robot_y >= MAP_HEIGHT)
        return maximum;
    if (robot_x < 0 || robot_y < 0 || robot_x >= MAP_WIDTH || robot_y >= MAP_HEIGHT)
        return maximum;
    if (map[robot_y][robot_x] == BLOCKED)
        return maximum;

    if (robot_energy < 0)
        return maximum;

    if (map[robot_y][robot_x] == CHARGER && temp_map[robot_y][robot_x] != VISITED)
    {
        // temp_map[robot_y][robot_x] = VISITED;
        // cout << "get charger, fully charged." << robot_x<<":"<<robot_y<< endl;
        robot_energy = robot_full_energy;
    }
    char original = temp_map[robot_y][robot_x];
    temp_map[robot_y][robot_x] = VISITED;

    if (robot_x == target_x && robot_y == target_y)
    {
        strcpy(result_sequence, "T");
        return 1; // Found case
    }

    int resultRight = 0, resultDown = 0, resultLeft = 0, resultUP = 0;
    char resultUpSeq[MAX_STRING_SIZE] = "",
         resultRightSeq[MAX_STRING_SIZE] = "",
         resultDownSeq[MAX_STRING_SIZE] = "",
         resultLeftSeq[MAX_STRING_SIZE] = "";

    int minimal = maximum;
    int direction = -1;
    // Find In four direction
    resultUP = 1 + findShortestDistance(robot_x, robot_y - 1,
                                        target_x, target_y, robot_energy - 1, robot_full_energy, map, temp_map);

    if (resultUP < minimal)
    {
        direction = 0;
        minimal = resultUP;
    }

    resultRight = 1 + findShortestDistance(robot_x + 1, robot_y,
                                           target_x, target_y, robot_energy - 1, robot_full_energy, map, temp_map);

    if (resultRight < minimal)
    {
        direction = 1;
        minimal = resultRight;
    }

    resultDown = 1 + findShortestDistance(robot_x, robot_y + 1,
                                          target_x, target_y, robot_energy - 1, robot_full_energy, map, temp_map);

    if (resultDown < minimal)
    {
        direction = 2;
        minimal = resultDown;
    }
    resultLeft = 1 + findShortestDistance(robot_x - 1, robot_y,
                                          target_x, target_y, robot_energy - 1, robot_full_energy, map, temp_map);

    if (resultLeft < minimal)
    {
        direction = 3;
        minimal = resultLeft;
    }

    temp_map[robot_y][robot_x] = original;

    if (!(direction == -1))
    {
        // cout << "Line 319:" << robot_x << ":" << robot_y << ":" << resultLeft << ":" << resultRight << ":" << resultUP << ":" << resultDown << ":" << endl;
        switch (direction)
        {
        case 0:
            findPathSequence(robot_x, robot_y - 1,
                             target_x, target_y, robot_energy - 1, robot_full_energy, resultUpSeq,
                             map, temp_map);
            strcpy(temp_result_sequence, "U");
            strcat(temp_result_sequence, resultUpSeq);
            strcpy(result_sequence, temp_result_sequence);
            return resultUP;

            break;
        case 1:
            findPathSequence(robot_x + 1, robot_y,
                             target_x, target_y, robot_energy - 1, robot_full_energy, resultRightSeq,
                             map, temp_map);
            strcpy(temp_result_sequence, "R");
            strcat(temp_result_sequence, resultRightSeq);
            strcpy(result_sequence, temp_result_sequence);
            // cout << result_sequence << endl;
            return resultRight;
            break;
        case 2:
            findPathSequence(robot_x, robot_y + 1,
                             target_x, target_y, robot_energy - 1, robot_full_energy, resultDownSeq,
                             map, temp_map);
            strcpy(temp_result_sequence, "D");
            strcat(temp_result_sequence, resultDownSeq);
            strcpy(result_sequence, temp_result_sequence);
            // cout << result_sequence << endl;
            return resultDown;
            break;
        case 3:
            findPathSequence(robot_x - 1, robot_y,
                             target_x, target_y, robot_energy - 1, robot_full_energy, resultLeftSeq,
                             map, temp_map);
            strcpy(temp_result_sequence, "L");
            strcat(temp_result_sequence, resultLeftSeq);
            strcpy(result_sequence, temp_result_sequence);
            // cout << result_sequence << endl;
            return resultLeft;
            break;
        }
    }
    // No result here.
    return maximum;
}

int findFarthestPossibleCharger(int robot_x, int robot_y, int robot_original_x, int robot_original_y,
                                int &target_x, int &target_y, int robot_energy, int robot_full_energy,
                                const char map[MAP_HEIGHT][MAP_WIDTH], char temp_map[MAP_HEIGHT][MAP_WIDTH])
{
    if (robot_x < 0 || robot_y < 0 || robot_x >= MAP_WIDTH || robot_y >= MAP_HEIGHT)
        return -1;

    if (robot_energy < 0)
        return -1;
    if (temp_map[robot_y][robot_x] == VISITED)
        return -1;

    if (map[robot_y][robot_x] == BLOCKED)
        return -1;
    // cout << "Line 350:" << robot_x << ":" << robot_y << endl;

    char original = temp_map[robot_y][robot_x];
    if (map[robot_y][robot_x] == CHARGER && temp_map[robot_y][robot_x] != VISITED)
    {
        // cout << "get charger, fully charged." << endl;
        robot_energy = robot_full_energy;
    }

    temp_map[robot_y][robot_x] = VISITED;

    char temp_map2[MAP_HEIGHT][MAP_WIDTH];

    // Variables
    int target_x_temp = -1, target_y_temp = -1;
    int target_x_U = -1, target_y_U = -1, target_x_R = -1, target_y_R = -1, target_x_D = -1, target_y_D = -1, target_x_L = -1, target_y_L = -1;
    int largest = -1;
    int direction = -1;

    // If it is the charger
    if (map[robot_y][robot_x] == CHARGER)
    {
        copyMap(temp_map2, map);
        int resultHere = findShortestDistance(robot_original_x, robot_original_y, robot_x, robot_y, robot_full_energy, robot_full_energy, map, temp_map2);

        if (resultHere >= PA2_MAX_PATH)
            resultHere = -1;

        // cout << "Current path distance" << resultHere << endl;

        if (largest < resultHere)
        {
            largest = resultHere;
            target_x_temp = robot_x;
            target_y_temp = robot_y;
            direction = 4;
            // cout << "Current is the highest" << largest << endl;
        }
        // cout << "Considered charger here:" << robot_x << ":" << robot_y << endl;
    };

    // Find In four direction
    // cout << "Call up" << endl;
    int resultUP = findFarthestPossibleCharger(robot_x, robot_y - 1, robot_original_x, robot_original_y,
                                               target_x_U, target_y_U, robot_energy - 1, robot_full_energy, map, temp_map);
    if (resultUP != -1)
    {
        copyMap(temp_map2, map);
        resultUP = findShortestDistance(robot_original_x, robot_original_y, target_x_U, target_y_U, robot_full_energy, robot_full_energy, map, temp_map2);
        if (resultUP >= PA2_MAX_PATH)
            resultUP = -1;
        if (largest < resultUP)
        {
            largest = resultUP;
            target_x_temp = target_x_U;
            target_y_temp = target_y_U;
            direction = 0;
        }
    }
    // cout << "Call right" << endl;

    int resultRight = findFarthestPossibleCharger(robot_x + 1, robot_y, robot_original_x, robot_original_y,
                                                  target_x_R, target_y_R, robot_energy - 1, robot_full_energy, map, temp_map);
    if (resultRight != -1)
    {
        copyMap(temp_map2, map);
        resultRight = findShortestDistance(robot_original_x, robot_original_y, target_x_R, target_y_R, robot_full_energy, robot_full_energy, map, temp_map2);
        if (resultRight >= PA2_MAX_PATH)
            resultRight = -1;
        if (largest < resultRight)
        {
            largest = resultRight;
            target_x_temp = target_x_R;
            target_y_temp = target_y_R;
            direction = 1;
        }
    }

    // cout << "Call down" << endl;
    int resultDown = findFarthestPossibleCharger(robot_x, robot_y + 1, robot_original_x, robot_original_y,
                                                 target_x_D, target_y_D, robot_energy - 1, robot_full_energy, map, temp_map);
    if (resultDown != -1)
    {
        copyMap(temp_map2, map);
        resultDown = findShortestDistance(robot_original_x, robot_original_y, target_x_D, target_y_D, robot_full_energy, robot_full_energy, map, temp_map2);
        if (resultDown >= PA2_MAX_PATH)
            resultDown = -1;
        if (largest < resultDown)
        {
            largest = resultDown;
            target_x_temp = target_x_D;
            target_y_temp = target_y_D;
            direction = 2;
        }
    }

    // cout << "Call left" << endl;
    int resultLeft = findFarthestPossibleCharger(robot_x - 1, robot_y, robot_original_x, robot_original_y,
                                                 target_x_L, target_y_L, robot_energy - 1, robot_full_energy, map, temp_map);
    if (resultLeft != -1)
    {
        copyMap(temp_map2, map);
        resultLeft = findShortestDistance(robot_original_x, robot_original_y, target_x_L, target_y_L, robot_full_energy, robot_full_energy, map, temp_map2);
        if (resultLeft >= PA2_MAX_PATH)
            resultLeft = -1;
        if (largest < resultLeft)
        {
            largest = resultLeft;
            target_x_temp = target_x_L;
            target_y_temp = target_y_L;
            direction = 3;
        }
    }
    // compare to the reserved one
    if (target_x != -1 && target_y != -1)
    {
        // cout << "Line 380 outside:" << target_x << ":" << target_y << endl;
        // cout << "Line 383 something found before!" << endl;
        int resultOutside = findShortestDistance(robot_original_x, robot_original_y, target_x, target_y, robot_full_energy, robot_full_energy, map, temp_map2);
        if (resultOutside >= PA2_MAX_PATH)
            resultOutside = -1;
        if (largest < resultOutside)
        {
            largest = resultOutside;
            target_x_temp = target_x;
            target_y_temp = target_y;
            direction = 5;
            // cout << "Outside is the highest" << largest << endl;
        }
    }
    // Consider the current position, if it is charger.

    if (largest != -1)
    {
        // cout << "Line 396" << target_x_temp << ":" << target_y_temp << endl;
        target_x = target_x_temp;
        target_y = target_y_temp;
    }

    temp_map[robot_y][robot_x] = original;
    return largest;
}
