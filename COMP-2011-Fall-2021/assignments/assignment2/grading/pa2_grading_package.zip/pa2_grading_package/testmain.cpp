#include <iostream>
#include <cstring>
#include <fstream>
#include "cleaning_robot.h"
using namespace std;

/*
Displayed demo output
"1 1 1 1 5",
"1 3 1 1 5",
"1 1 2 2 5",
"1 1 3 2 5",
"1 3 1 2 5",
"1 3 4 2 5",
"1 1 2 3 5",
"1 1 3 3 5",
"1 3 1 3 5",
"1 3 4 3 5",
"1 1 1 4 5", 
"1 3 1 4 5", // Have 2 version

Task 1
"1 1 1 1 5",
"1 3 1 1 5",
(Given)
1 11 1 1 1-10 header1
2 1 1 1 1-10
1 4 1 1 1-10
3 1 1 1 1-10

1 3 1 1 1-5     header2
1 211 1 1 1-5   header2
2 211 1 1 1-5
2 212 1 1 1-5
3 212 1 1 1-5   header2
3 2 1 1 1 1-6
4 2 1 1 1 1-9

1 42 1 1 1-10 header3
2 11 1 1 1-10
3 11 1 1 1-10
4 11 1 1 1-10  header3

Task 2
"1 1 2 2 5",
"1 1 3 2 5",
"1 3 1 2 5",
"1 3 4 2 5",
(Given)
Header1
1 12 5 2 5 
1 13 1 2 5
3 22 25 2 5
3 22 21 2 5
2 2 1 2 5 (Cannot find)


2 211 21 2 5
2 211 221 2 5
2 221 222 2 5
3 221 223 2 5
1 211 1 2 2 (Cannot find)

Header3
2 322 324 2 5 
2 12 5 2 5
3 22 25 2 5
3 22 322 2 5
3 22 323 2 5(Cannot find)

Task 3
"1 1 2 3 5",
"1 1 3 3 5",
"1 3 1 3 5",
"1 3 4 3 5",
(Given)
1 12 5 3 5 Header1
1 13 1 3 5
3 22 25 3 5
3 22 21 3 5
2 2 1 3 5 (Cannot find)


2 211 21 3 5
2 211 221 3 5
2 221 222 3 5
3 221 223 3 5
1 211 1 3 2 (Cannot find)

2 322 324 3 5  Header3
2 12 5 3 5
3 22 25 3 5
3 22 322 3 5
3 22 323 3 5(Cannot find)

Task 4
"1 1 1 4 5", 
"1 3 1 4 5"
(Given)
1 13 1 4 5 2 version
2 43 1 4 5 2 version
2 2 1 4 5 1 version

2 221 1 4 5 2 version
2 241 1 4 5 1 version
3 213 1 4 5 1 version

2 13 1 4 5 1 version
2 44 1 4 5 1 version
3 341 1 4 4 1 version

*/

int main(int argc, char **argv)
{
    cout << "Welcome to the cleaning program" << endl;

    char map[MAP_HEIGHT][MAP_WIDTH] = {};
    char temp_map[MAP_HEIGHT][MAP_WIDTH] = {};
    char empty_map[MAP_HEIGHT][MAP_WIDTH] = {};
    char result_map[MAP_HEIGHT][MAP_WIDTH] = {};

    int robot_full_energy = 10;

    int robot_x = 0;
    int robot_y = 0;

    int choice = 0;
    int int_result = 0;
    int dest_x = 0, dest_y = 0;

    char result_sequence[MAX_STRING_SIZE] = "";

    bool map_loaded = false;

    int testcase;
    int testcase2;
    int testcase3;
    int testcase4;

    if (argc < 6)
    {
        cout << "Which testcase you want to test?" << endl;
        cin >> testcase;
        cin >> testcase2;
        cin >> testcase3;
        cin >> testcase4;
        cin >> robot_full_energy;
    }
    else
    {
        testcase = atoi(argv[1]);
        testcase2 = atoi(argv[2]);
        testcase3 = atoi(argv[3]);
        testcase4 = atoi(argv[4]);
        robot_full_energy = atoi(argv[5]);
    }

    switch (testcase)
    {
    case 1:
        loadMap("map_given.txt", map);
        break;
    case 2:
        loadMap("map2.txt", map);
        break;
    case 3:
        loadMap("map3.txt", map);
        break;
    default:
        loadMap("map_empty.txt", map);
        break;
    }

    switch (testcase2)
    {
    case 1:
        robot_x = 5;
        robot_y = 5;
        break;
    case 2:
        robot_x = 0;
        robot_y = 0;
        break;
    case 3:
        robot_x = 3;
        robot_y = 4;
        break;
    case 4:
        robot_x = 11;
        robot_y = 11;
        break;
    case 11:
        robot_x = 11;
        robot_y = 10;
        break;
    case 12:
        robot_x = 0;
        robot_y = 11;
        break;
    case 13:
        robot_x = 3;
        robot_y = 11;
        break;
    case 21:
        robot_x = 6;
        robot_y = 5;
        break;
    case 22:
        robot_x = 3;
        robot_y = 6;
        break;
    case 41:
        robot_x = 19;
        robot_y = 19;
        break;
    case 42:
        robot_x = 15;
        robot_y = 16;
        break;
    case 43:
        robot_x = 9;
        robot_y = 10;
        break;
    case 44:
        robot_x = 5;
        robot_y = 9;
        break;
    case 211:
        robot_x = 4;
        robot_y = 4;
        break;
    case 212:
        robot_x = 2;
        robot_y = 2;
        break;
    case 213:
        robot_x = 1;
        robot_y = 2;
        break;
    case 221:
        robot_x = 6;
        robot_y = 3;
        break;
    case 241:
        robot_x = 2;
        robot_y = 1;
        break;
    case 321:
        robot_x = 15;
        robot_y = 16;
        break;
    case 322:
        robot_x = 5;
        robot_y = 15;
        break;
    case 341:
        robot_x = 9;
        robot_y = 13;
        break;
    }

    switch (testcase3)
    {
    case 1:
        dest_x = 5;
        dest_y = 5;
        break;
    case 2:
        dest_x = 2;
        dest_y = 2;
        break;
    case 3:
        dest_x = 7;
        dest_y = 6;
        break;
    case 4:
        dest_x = 3;
        dest_y = 11;
        break;
    case 5:
        dest_x = 3;
        dest_y = 11;
        break;
    case 6:
        dest_x = 8;
        dest_y = 8;
        break;
    case 7:
        dest_x = 13;
        dest_y = 13;
        break;

    case 8:
        dest_x = 4;
        dest_y = 6;
        break;
    
    case 9:
        dest_x = 8;
        dest_y = 5;
        break;

    case 21:
        dest_x = 1;
        dest_y = 1;
        break;
    case 22:
        dest_x = 1;
        dest_y = 3;
        break;
    case 23:
        dest_x = 5;
        dest_y = 3;
        break;
    case 24:
        dest_x = 6;
        dest_y = 4;
        break;
    case 25:
        dest_x = 5;
        dest_y = 6;
        break;
    case 221:
        dest_x = 6;
        dest_y = 0;
        break;
    case 222:
        dest_x = 0;
        dest_y = 4;
        break;
    case 223:
        dest_x = 1;
        dest_y = 2;
        break;
    case 321:
        dest_x = 13;
        dest_y = 9;
        break;

    case 322:
        dest_x = 1;
        dest_y = 11;
        break;
    
    case 323:
        dest_x = 1;
        dest_y = 12;
        break;
    case 324:
        dest_x = 3;
        dest_y = 11;
        break;
    }
    
    map[robot_y][robot_x] = ROBOT;
    copyMap(result_map, map);
    copyMap(temp_map, empty_map);
    int robot_energy = robot_full_energy;

    printMap(map);

    cout << "Robot position: (" << robot_x << "," << robot_y << ")" << endl;
    cout << "Robot energy: " << robot_energy << "/" << robot_full_energy << endl;

    switch (testcase4)
    {
    case 1:
        copyMap(result_map, map);
        copyMap(temp_map, empty_map);
        int_result = findMaximumPlace(robot_x, robot_y, robot_energy, robot_full_energy, result_map, temp_map);
        cout << int_result << endl;
        cout << "The result map will be:" << endl;
        printMap(result_map);
        break;
    case 2:
        // cout << "Please enter the target x and y, separated by space: ";
        // cin >> dest_x >> dest_y;
        // dest_x = 7;
        // dest_y = 6;
        cout << "dest_x: " << dest_x << endl;
        cout << "dest_y: " << dest_y << endl;
        copyMap(temp_map, empty_map);
        int_result = findShortestDistance(robot_x, robot_y,
                                          dest_x, dest_y, robot_energy, robot_full_energy, map, temp_map);

        if (int_result >= PA2_MAX_PATH)
        {
            cout << "The destination is unreachable." << endl;
        }
        else
        {
            cout << int_result << endl;
        }
        break;
    case 3:
        // cout << "Please enter the target x and y, separated by space: ";
        // cin >> dest_x >> dest_y;
        // dest_x = 7;
        // dest_y = 6;
        cout << "dest_x: " << dest_x << endl;
        cout << "dest_y: " << dest_y << endl;
        copyMap(temp_map, empty_map);
        int_result = findPathSequence(robot_x, robot_y,
                                      dest_x, dest_y,
                                      robot_energy, robot_full_energy, result_sequence,
                                      map, temp_map);
        if (int_result >= PA2_MAX_PATH)
        {
            cout << "The destination is unreachable." << endl;
        }
        else
        {
            cout << int_result << ":" << result_sequence << endl;
        }
        break;
    case 4:
        int target_x = -1, target_y = -1;
        copyMap(temp_map, empty_map);
        int_result = findFarthestPossibleCharger(robot_x, robot_y, robot_x, robot_y, target_x, target_y, robot_energy, robot_full_energy, map, temp_map);

        if (int_result > -1)
        {
            cout << "The farthest position is (" << target_x << ":" << target_y << ")"
                 << " and the distance is " << int_result << endl;
        }
        else
        {
            cout << "Cannot find" << endl;
        }
    }

    while (choice != -1 && false)
    {
        cout << "Please select from the following options:" << endl;
        cout << "0: Load map" << endl;
        if (map_loaded)
        {
            cout << "1. Print original map" << endl;
            cout << "2. Print robot details" << endl;
            cout << "3. Display the maximum range for the robot in the current place:" << endl;
            cout << "4. Find the shortest distance from current position to a designated position" << endl;
            cout << "5. Find the shortest distance and the shortest path from current position to a designated position" << endl;
            cout << "6. Find the position of the farthest charger and the shortest distance from that charger" << endl;
        }
        cout << "-1. Exit program" << endl;
        cout << "Please enter your choice: ";

        cin >> choice;
        switch (choice)
        {
        case 0:
            char filename[MAX_STRING_SIZE];
            cout << "Please type the file you want to use: ";
            cin >> filename;

            if (loadMap(filename, map))
            {
                printMap(map);
                map_loaded = true;
                setRobot(robot_x, robot_y, robot_full_energy, map);
                robot_energy = robot_full_energy;
                printMap(map);
            }
            else
            {
                cout << "Cannot load map. Please check if the file exists." << endl;
            }
            break;
        case 1:
            printMap(map);
            break;

        case 2:
            cout << "Robot position: (" << robot_x << "," << robot_y << ")" << endl;
            cout << "Robot energy: " << robot_energy << "/" << robot_full_energy << endl;
            break;
        case 3:
            copyMap(result_map, map);
            copyMap(temp_map, empty_map);
            int_result = findMaximumPlace(robot_x, robot_y, robot_energy, robot_full_energy, result_map, temp_map);
            cout << int_result << endl;
            cout << "The result map will be:" << endl;
            printMap(result_map);
            break;
        case 4:
            cout << "Please enter the target x and y, separated by space: ";
            cin >> dest_x >> dest_y;
            copyMap(temp_map, empty_map);
            int_result = findShortestDistance(robot_x, robot_y,
                                              dest_x, dest_y, robot_energy, robot_full_energy, map, temp_map);

            if (int_result >= PA2_MAX_PATH)
            {
                cout << "The destination is unreachable." << endl;
            }
            else
            {
                cout << int_result;
            }
            break;
        case 5:
            cout << "Please enter the target x and y, separated by space: ";
            cin >> dest_x >> dest_y;
            copyMap(temp_map, empty_map);
            int_result = findPathSequence(robot_x, robot_y,
                                          dest_x, dest_y,
                                          robot_energy, robot_full_energy, result_sequence,
                                          map, temp_map);
            if (int_result >= PA2_MAX_PATH)
            {
                cout << "The destination is unreachable." << endl;
            }
            else
            {
                cout << int_result << ":" << result_sequence << endl;
            }
            break;
        case 6:
            int target_x = -1, target_y = -1;
            copyMap(temp_map, empty_map);
            int_result = findFarthestPossibleCharger(robot_x, robot_y, robot_x, robot_y, target_x, target_y, robot_energy, robot_full_energy, map, temp_map);

            if (int_result > -1)
            {
                cout << "The farthest position is (" << target_x << ":" << target_y << ")"
                     << " and the distance is " << int_result << endl;
            }
            else
            {
                cout << "Cannot find" << endl;
            }
        }
        cout << endl;
    };
    cout << "Program ends." << endl;
    return 0;
}
