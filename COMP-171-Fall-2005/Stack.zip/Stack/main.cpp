#include <iostream>
#include "Stack.h"

using namespace std;

int main(void) {
	Stack stack(5);
	stack.Push(5.0);
	stack.Push(6.5);
	stack.Push(-3.0);
	stack.Push(-8.0);
	stack.DisplayStack();
	cout << "Top: " << stack.Top() << endl;
	
	stack.Pop();
	cout << "Top: " << stack.Top() << endl;
	
	while (!stack.IsEmpty())
		stack.Pop();

	stack.DisplayStack();
	return 0;
}