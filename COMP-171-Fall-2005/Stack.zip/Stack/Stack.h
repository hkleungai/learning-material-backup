#ifndef STACK_H
#define STACK_H

class Stack {
public:
	// constructor
	Stack(int size = 10);
	
	// destructor
	~Stack() {
		delete [] values;
	}
	
	// return true if stack is empty,
	// return false otherwise
	bool IsEmpty() {
		return top == -1;
	}
	
	// return true if stack is full,
	// return false otherwise
	bool IsFull() {
		return top == maxTop;
	}	
	
	// add an element to the top of stack
	void Push(const double x);
	
	// delete the element at the top of stack
	double Pop();

	// return the element at the top of stack
	// only examine, without popping
	double Top();
	
	// print all the data in the stack
	void DisplayStack();
	
private:
	// the max size of stack, max stack size = size - 1
	int maxTop;
	
	// the index of the top element of stack
	int top;
	
	// point to an array which stores elements of stack
	double* values;
};

#endif