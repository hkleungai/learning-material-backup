#include <iostream>
#include "Stack.h"
using namespace std;

// ---------------------------------
//  Allocate a stack array of size.
//  By default, size = 10.
// ---------------------------------

Stack::Stack(int size) {	
	values = new double[size];

	// Initially top is set to -1. It means the stack is empty.
	top	= -1;

	// When the stack is full, top will have its maximum value,
	// i.e. size - 1.
	maxTop = size - 1;
}

// ----------------------------------------------------------
//  Push an element onto the stack
//  Note top always represents the index of the top element.
// ----------------------------------------------------------

void Stack::Push(const double x) {
	// if stack is full, print error
	if (IsFull())
		cout << "Error: the stack is full." << endl;
	else 
		// After pushing an element, increment top
		values[++top] = x;
}

// ----------------------------------------------------
//  Pop and return the element at the top of the stack
// ----------------------------------------------------

double Stack::Pop() {
	//if stack is empty, print error
	if (IsEmpty()) {
		cout << "Error: the stack is empty." << endl;
		return -1;
	}	
	else
		// Pop and return the element at the top of the stack
        // Don�t forgot to decrement top
		return values[top--];
}

// -----------------------------------------------------------
//  Return the top element of the stack
//  Unlike Pop, this function does not remove the top element
// -----------------------------------------------------------

double Stack::Top() {
	if (IsEmpty()) {
		cout << "Error: the stack is empty." << endl;
		return -1;			
	}
	else 
		// Return the top element of the stack        
		return values[top];
}

// ------------------------
//  Print all the elements
// ------------------------

void Stack::DisplayStack() {
	cout << "top -->";
	
	for (int i = top; i >= 0; i--) 
		cout << "\t|\t" << values[i] << "\t|" << endl;
	cout << "\t|---------------|" << endl;
}