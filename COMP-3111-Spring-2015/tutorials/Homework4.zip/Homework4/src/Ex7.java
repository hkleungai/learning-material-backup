import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.text.AbstractDocument;
import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.DocumentFilter;

public class Ex7 extends JFrame implements ActionListener {
	
	 private static final long serialVersionUID = 1L;
	 JTextField field = new JTextField(30);
	 JButton button= new JButton("Input");
	public Ex7()
	 {
        ((AbstractDocument)(field.getDocument())).setDocumentFilter(
                new DocumentFilter(){
                   
                    public void insertString(FilterBypass fb, 
                    		int offset, 
                    		String string, 
                    		AttributeSet attr)throws BadLocationException
                    {
                        fb.insertString(offset,string.toUpperCase(),attr);
                    }
                
                    public void replace(DocumentFilter.FilterBypass fb,
                    		int offset,
                            int length,
                            String string,
                            AttributeSet attr) throws BadLocationException{
                        fb.replace(offset,length,string.toUpperCase(), attr);
                    }
                });
       
        this.setLayout(new FlowLayout(FlowLayout.LEFT,6,6));
        this.add(field);
        
        button.addActionListener(this);
        this.add(button);
      
	 }
	
	public void actionPerformed(ActionEvent e) {
        if (e.getSource() == button) {
        	if(field.getDocument().getLength()>=20)
        	{
            JOptionPane.showMessageDialog(this, "Input more than 20 characters!");
        	}
        } else 
            System.exit(0);
        
    }	

	public static void main(String[] args) {
		
	  JFrame h = new Ex7();
	  h.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	  h.setSize(240,100);
	  h.setVisible(true);
	  h.setLocation(200,300);
	  h.setResizable(false);
	 }

}
