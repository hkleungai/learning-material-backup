<?php
#appendfile.php
    # method 1: a+ enables read and append
    $file = fopen("palindrome.txt", "a+") or die("Unable to open file!");
    $new_text = "Madam in Eden, I'm Adam\n";
    fwrite($file, "\n". $new_text);
    fclose($file);
    # method 2:
    $new_text = "A Santa lived as a devil at NASA\n";
    file_put_contents("palindrome.txt", $new_text, FILE_APPEND);

    readfile("palindrome.txt");
?>
