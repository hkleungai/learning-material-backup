<?php
# filereverse.php
$text = file_get_contents("palindrome.txt");
$text = strrev($text);
echo "$text";
file_put_contents("palindrome.txt", $text);
?>

