<?php
# glob.php
$poems = glob("poetry/poem*.txt");
foreach ($poems as $poemfile) {
    $text = file_get_contents($poemfile);
    file_put_contents($poemfile, strrev($text));
    print "Reversed: ". basename($poemfile). "\n";
}
?>