<?php
    $filename = fopen("marvel.txt", "w") or die("Unable to open file!");
    $txt = "Captin American\n";
    fwrite($filename, $txt);
    $txt = "Thor\n";
    fwrite($filename, $txt);
    fclose($filename);
?>
