<?php
    include("function.php");
    doit();
?>