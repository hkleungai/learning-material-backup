<?php
# fileread1.php
    $filename = "CapitalCity.txt";
    $file = fopen( $filename, "r" ) or exit("Unable to open file");
    $linenum = 0;

    while (!feof($file))
    {
        $line = fgets($file);
        $linenum++;
        echo "$linenum : $line \n";
    }
     fclose($file);
?>