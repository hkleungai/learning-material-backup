<?php
$filename = "fileinsert2.txt";
$file = fopen($filename, "r+") or die("Unable to open file");
$filecontents = fread($file, filesize($filename));
fseek($file, strpos($filecontents, "// Insert here"));
fwrite($file, "Insert successfully\n");
fclose($file);
?>