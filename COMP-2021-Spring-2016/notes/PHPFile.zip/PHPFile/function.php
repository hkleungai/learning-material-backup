<?php
    function doit(){
        echo "did it";
    }
?>