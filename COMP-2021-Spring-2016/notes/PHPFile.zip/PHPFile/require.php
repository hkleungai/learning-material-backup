<?php
require("noFileExistsHere.php");
echo "Hello World!";
?>