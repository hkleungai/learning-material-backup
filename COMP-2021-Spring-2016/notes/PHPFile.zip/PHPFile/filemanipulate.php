<?php
#filenaminpulate.php
    $srcfile = fopen("readfrom.txt", "r");
    $destfile = fopen("writeto.txt", 'a');

    while(!feof($srcfile)) {
        $line = fgets($srcfile);
        $lineAry = explode("=", $line);
        if (strlen($lineAry[0]) >= 3)
            fwrite($destfile, $line);
    }

    fclose($srcfile);
    fclose($destfile);

?>