<?php
$filename = "fileinsert1.txt";
$new_line = "Text7 = This is eighth line in the file";
$element_number_to_replace = 7; /* remember the count starts with 0 being line 1 */
$line_array = file($filename);

$line_number_to_insert = 7;
$line_array[$line_number_to_insert] = $new_line;
$all_content = implode("\n", $line_array);
file_put_contents($filename,$all_content);
?>