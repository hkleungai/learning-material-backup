<?php
#copyfile.php
$file = "CaptialCity.txt";
$newfile = 'CapticalCity.txt.bak';

copy($file, $newfile) or die("failed to copy $file...\n");
?>