<?php
foreach (file("explode.txt") as $book) {
    list($title, $author) = explode(",", $book);
    echo "Book title: $title, Author: $author\n";
}
?>