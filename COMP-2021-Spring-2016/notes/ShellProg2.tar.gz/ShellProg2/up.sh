#! /bin/sh 
# move up in the directory tree

echo "Your current directory $PWD"
LEVEL=$1 
for ((i = 1; i <= LEVEL; i++)) 
do 
  CDIR=../$CDIR 
done 
cd $CDIR 
echo "You are now moved to $PWD" 
