# swap contents of 2 files

#!/bin/sh
file=/tmp/tmp$$
echo "Prepare a temp file name $file"
mv $1 $file
mv $2 $1
mv $file $2
