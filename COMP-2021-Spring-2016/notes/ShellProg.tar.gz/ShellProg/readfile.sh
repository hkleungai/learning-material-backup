# read file line-by-line
# try with ladygaga_bornthisway as input
#!/bin/sh
echo "Start to read file $1"
if [ -f $1 ]
then
	filename="$1"
	linenum=1
	while read -r line
	do
		echo "Line $linenum: $line"
		linenum=`expr $linenum + 1`
	done < "$filename"
fi
