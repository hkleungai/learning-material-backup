#!/bin/sh
for file
do
	if [ -f $file ]
	then
		cat $file
	fi
done
