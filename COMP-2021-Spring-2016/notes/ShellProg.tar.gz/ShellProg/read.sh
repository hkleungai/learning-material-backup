#!/bin/sh
# Use read command to get and store input from the user

echo "Enter name: "
read name
echo "How many girlfriends do you have?"
read number
echo "$name has $number girlfriends!"
