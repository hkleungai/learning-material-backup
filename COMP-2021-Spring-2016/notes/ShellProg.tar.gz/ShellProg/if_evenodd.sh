#!/bin/sh
echo "Enter the number:"
read n
num=`expr $n % 2`
if [ $num -eq 0 ]
then
	echo "is a even number."
else
	echo "is an odd number."
fi
