#!/bin/sh
for (( i=1; i<=5; i++ ))
	do echo "Random number $i: $RANDOM"
done
