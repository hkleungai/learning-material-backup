#!/bin/sh
# File operations
# The file name is sent as command line argument

filename=$1

#if the file exists
if [ -f $filename ]
then
	echo "File found!"
	#file statistic
	w=`cat $filename | wc -w`
	echo "Number of words in $filename is $w."
	
	echo "Number of lines in $filename is `cat $filename | wc -l`"
	
	#access file line-by-line
	i=1
	while read -r line
	do 
		echo "Line $i: $line"
		i=`expr $i + 1`
	done < $filename
		
else
	echo "File doesn't exist!"	
fi
