# swap the contents of two files
# work with file1 and file2

#!/bin/sh
if [ -f $1 ] && [ -f $2 ]
then
	mv $1 /tmp/$1
	mv $2 $1
	mv /tmp/$1 $2
else
	echo "file doesn't exist!"
fi
