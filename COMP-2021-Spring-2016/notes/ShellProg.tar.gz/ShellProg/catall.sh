#!/bin/sh
for file in *
do
	if [ -f $file ]
	then
		echo "View $file [y/n]?"
		read resp
		if [ $resp = "y" ]
		then	
			cat $file
		fi
	fi
done
