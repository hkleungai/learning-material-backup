#!/bin/sh
# read csv file and distribute student grade via email
# try with SampleGrade.csv, put a valid email in that file first

input="SampleGrade.csv"
# set "," as the field separator using $IFS
# and read line by line using while loop

subject="COMP2021 HW1 grade"

while IFS="," read -r stuid email grade
do
  echo "$stuid $email $grade"
  echo "Dear $stuid Your COMP2021 HW1 grade is $grade" | tr -d \\r | mail -s "$subject" $email
  echo "email sent!" 
done < "$input"

