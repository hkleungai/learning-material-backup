#!/bin/sh
# Print out the $ sign
echo "Enter amount: "
read cost
echo "The total is \$$cost"
