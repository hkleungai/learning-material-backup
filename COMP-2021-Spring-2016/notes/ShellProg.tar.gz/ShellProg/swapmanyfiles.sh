#!/bin/sh
orig1=$1
mv $1 /tmp/$1
while [ $2 ]
do
	mv $2 $1
	shift
done
mv /tmp/$orig1 $1
