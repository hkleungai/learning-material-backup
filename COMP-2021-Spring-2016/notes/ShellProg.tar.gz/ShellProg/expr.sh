#!/bin/sh
# Example of expr, a simple calculator

echo "Enter the first operand: "
read a
echo "Enter the second operand: "
read b

echo "$a + $b = `expr $a + $b`"

x=`expr $a - $b`
echo "$a - $b = $x"

y=`expr $a \* $b`
echo "$a * $b = $y"

echo "$a / $b = `expr $a / $b` (integer division)"
echo "$a / $b = `bc <<< "scale = 3; $a / $b"` (floating division with bc)"
