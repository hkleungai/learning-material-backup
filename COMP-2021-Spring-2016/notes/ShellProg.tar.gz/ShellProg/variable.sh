#!/bin/sh
# There cannot be any space before or after the "="
# Internally, all values are stored as strings

number=50
course="COMP2021"
echo "$course has $number students"
