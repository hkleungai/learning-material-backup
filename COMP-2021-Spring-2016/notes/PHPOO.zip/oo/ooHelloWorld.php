<?php
# ooHelloWorld.php
class MyClass{
    public $prop1 = "I'm a class property!";
}
$obj = new MyClass;
# see the contents of the class
var_dump($obj);
# access an object
echo $obj->prop1; # Output the property
?>