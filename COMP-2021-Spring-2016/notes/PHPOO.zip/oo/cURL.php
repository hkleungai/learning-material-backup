
<?php

#$ch = curl_init("http://home.cse.ust.hk/~lixin/");
$ch = curl_init("http://www.ust.hk");
$fp = fopen("example_homepage.txt", "w");

curl_setopt($ch, CURLOPT_FILE, $fp);
curl_setopt($ch, CURLOPT_HEADER, 0);

curl_exec($ch);
curl_close($ch);
fclose($fp);
?>
