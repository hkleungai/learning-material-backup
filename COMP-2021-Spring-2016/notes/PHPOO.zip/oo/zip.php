<?php
    $zip = new ZipArchive();
    $zip->open("zipExample.zip");
    $zip->extractTo("zipExample/");
    $zip->close();
?>