<?php
#ooDocBlock.php

/**
 * A simple class
 *
 * This is the long description for this class.
 * It may span as many lines as needed.
 * Not compusorly but nice to have.
 *
 * It can also span multiple paragraphs.
 *
 * @author Cindy LI <lixin@cse.ust.hk>
 * @copyright 2016 Cindy LI
 * @license http://www.php.net/license/3_01.txt PHP License 3.01
 */

class SimpleClass {
    /**
     * A public variable
     *
     * @var string stores data for the class
     */
    public $foo;

    /**
     * Sets $foo to a new value upon class instantiation
     *
     * @param string $val a value required for the class
     * @return void
     */
    public function __construct($val) {
        $this->foo = $val;
    }

    /**
     * Multiplies two integers
     *
     * Accepts a pair of integers and returns the
     * product of the two.
     *
     * @param int $bat a number to be multiplied
     * @param int $baz a number to be multiplied
     * @return int the product of the two parameters
     */
    public function bar($bat, $baz){
        return $bat * $baz;
    }
}
?>