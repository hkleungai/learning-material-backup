<!DOCTYPE HTML>
<html style="color:#333;background-color:#eee;font-family:'Trebuchet MS'">
<head>
<meta http-equiv="Content-Language" content="en-us">
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-5">
<title>Object-Oriented Programming Demo</title>
<style>
ol li {
	margin: 1.5em;
}
pre {
	border: 1px grey dotted;
	padding: 1em;
}
</style>
</head>
<body>