<?php
include 'stdlib.php';

$site = new csite();

// this is a function specific to this site!
initialise_site($site);

$page = new cpage("COMP2021 Lab9: PHP: Object-Oriented Programming");
$site->setPage($page);

$content = "The first thing we're going to produce will be a very simple OOP site that has a site class, csite, and a page class, cpage.";
    $page->setContent($content);

    $site->render();
?>